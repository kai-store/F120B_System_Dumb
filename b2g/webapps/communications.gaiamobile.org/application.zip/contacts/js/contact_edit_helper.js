/* global Contacts, contacts, OptionHelper, NavigationManager */
(function() {
  'use strict';
  var ContactEditHelper = function() {
  };

  ContactEditHelper.prototype.init = function() {
    window.addEventListener('keydown', this);
  };

  ContactEditHelper.prototype.handleEvent = function(evt) {
    if (Contacts.selectionMode) {
      // if action list activated, go on
      if (!('action-list-softkey' === OptionHelper.getLastParamName() &&
        'Backspace' === evt.key)) {
        return;
      }
    }
    var key = evt.key;
    switch (key) {
      case 'Backspace':
        if (contacts.List.phoneSelectionList.visibility) {
          contacts.List.phoneSelectionList.hide();
          evt.preventDefault();
        }
        break;
      case 'Clear':
        window.dispatchEvent(new CustomEvent('BackspaceDeleteContact'));
        break;
      case 'Call':
        if ('ice-view' === Contacts.navigation.currentView()) {
          contacts.List.onICEContactPress('call');
        } else if (Contacts.isContactListTab()) {
          if (contacts.List.isPhoneSelectionListVisible) {
            // call focused number by click hanlder, not that good and should be optimized later
            contacts.List.phoneSelectionList.clickHandler();
          } else {
            var focus = document.querySelector('.focus[data-uuid]');
            if (!focus) {
              return;
            }
            contacts.List.selectPhoneNumberMenu(focus, 'call');
          }
        } else if (Contacts.isSpeedDialTab()) {
          contacts.List.callNumber();
        } else if (Contacts.isContactDetailsPage()) {
          var focusedEl = NavigationManager.getFocusedEl();
          if (focusedEl && focusedEl.dataset && focusedEl.dataset.tel) {
            contacts.List.callNumber(focusedEl.dataset.tel);
          }
        }
        break;
    }
  };

  ContactEditHelper.prototype.doBrowserBack = function(evt) {
    if (contacts.List.isPhoneSelectionListVisible) {
      return;
    } else if (Contacts.navigation.isCurrentView('view-contacts-list') &&
        !document.getElementById('selectable-form')
        .classList.contains('hide')) {
      Contacts.navigation.pushOptionMenu('contact-list', 'view-contacts-list');
      contacts.List.exitSelectMode();
    } else if (Contacts.navigation.isCurrentView('view-contact-details')) {
      contacts.Details.handleDetailsBack();
    } else {
      Contacts.cancel();
    }
  };

  var editHelper = new ContactEditHelper();
  editHelper.init();
}());
