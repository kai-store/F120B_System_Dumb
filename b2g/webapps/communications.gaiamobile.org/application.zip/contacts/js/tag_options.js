'use strict';
/* exported TAG_OPTIONS */
var _ = navigator.mozL10n.get;

var TAG_OPTIONS = {
  'phone-type' : [
    {type: 'mobile', value: _('mobile')},
    {type: 'home', value: _('home')},
    {type: 'work', value: _('work')},
    {type: 'personal', value: _('personal')},
    {type: 'faxHome', value: _('faxHome')},
    {type: 'faxOffice', value: _('faxOffice')},
    {type: 'faxOther', value: _('faxOther')}
  ],
  'email-type' : [
    {type: 'personal', value: _('personal')},
    {type: 'home', value: _('home')},
    {type: 'work', value: _('work')},
    {type: 'other', value: _('other')},
    {type: 'customTag', value: _('customTag'), custom: true},
  ],
  'address-type' : [
    {type: 'current', value: _('current')},
    {type: 'home', value: _('home')},
    {type: 'work', value: _('work')},
    {type: 'customTag', value: _('customTag'), custom: true},
  ],
  'date-type': [
    {type: 'birthday', value: _('birthday')},
    {type: 'anniversary', value: _('anniversary')}
  ],
  'ringselect-type': [
    {type: 'systemring', value: _('systemring')},
    {type: 'moremusic', value: _('moremusic')}
  ],
  'sort-type': [
    {type: 'sort-by-first-name', vlaue: _('sort-by-first-name') },
    {type: 'sort-by-last-name', value: _('sort-by-last-name')}
  ],
  'status-type': [
    {type: 'on' , vlaue: _('on') },
    {type: 'off', value: _('off')}
  ]

};
