/* global Cache */
/* global Contacts */
/* global ContactsBTExport */
/* global ContactsExporter */
/* global ContactsSDExport */
/* global ContactsSIMExport */
/* global fb */
/* global IccHandler */
/* global LazyLoader */
/* global Rest */
/* global SimContactsImporter */
/* global SimDomGenerator */
/* global utils */
/* global VCFReader */
/* global Toaster */
/* global OptionHelper */
/* global ContactsTag */
/* global NavigationManager */
/* global CustomDialog */
/* global TabNavigation */
/* global navigation, ConfirmDialogHelper */
/* jshint -W069 */

'use strict';
var contacts = window.contacts || {};

/***
 This class handles all the activity regarding
 the settings screen for contacts
 **/
contacts.Settings = (function() {

  var navigationHandler,
    orderCheckBox,
    orderContactsStatus,
    orderItem,
    orderByLastName,
    setICEButton,
    importSettingsPanel,
    importSettingsTitle,
    importContacts,
    exportContacts,
    importOptions,
    exportOptions,
    importLiveOption,
    importGmailOption,
    importSDOption,
    exportSDOption,
    fbImportOption,
    fbImportCheck,
    fbSwitcher,
    fbImportCheckContainer,
    fbUpdateButton,
    fbOfflineMsg,
    fbTotalsMsg,
    fbPwdRenewMsg,
    fbImportedValue,
    newOrderByLastName = null,
    PENDING_LOGOUT_KEY = 'pendingLogout',
    bulkDeleteButton,
    optionParamName,
    exporter,
    exportCancelled,

    progress        = null,
    cancelled       = null,
    contactsRead    = null,
    importer        = null,
    importFrom      = null;


    var EXPORT_TRANSITION_LEVEL = 2, DELETE_TRANSITION_LEVEL = 1;

  // Initialise the settings screen (components, listeners ...)
  var init = function initialize() {
    // Create the DOM for our SIM cards and listen to any changes
    IccHandler.init(new SimDomGenerator(), contacts.Settings.cardStateChanged);

    fb.init(function onFbInit() {
      initContainers();

      orderContactsStatus.dataset.l10nId = getOrderL10nId();

      // To avoid any race condition we listen for online events once
      // containers have been initialized
      window.addEventListener('online', checkOnline);
      window.addEventListener('offline', checkOnline);
    });

    // Subscribe to events related to change state in the sd card
    utils.sdcard.subscribeToChanges('check_sdcard', function(value) {
      updateStorageOptions(utils.sdcard.checkStorageCard());
    });

    window.addEventListener('timeformatchange', updateTimestamps);

  };

  // Get the different values that we will show in the app
  var getData = function getData() {
    var config = utils.cookie.load();
    var order;
    if (config && config.firstLoad) {
      order = true;
    } else {
      order = config ? config.order : false;
    }
    orderByLastName = order;
    newOrderByLastName = null;
    updateOrderingUI();

    if (fb.isEnabled) {
      fb.utils.getImportChecked(checkFbImported);
    }
  };

  function getOrderL10nId() {
    return orderCheckBox.checked ? 'sort-by-first-name' : 'sort-by-last-name';
  }

  var updateOrderingUI = function updateOrderingUI() {
    var value = newOrderByLastName === null ? orderByLastName :
      newOrderByLastName;
    orderCheckBox.checked = value;
    orderItem.setAttribute('aria-checked', value);
    orderContactsStatus.dataset.l10nId = getOrderL10nId();
    orderItem.dataset.value = getOrderL10nId();
  };

  var updateImportTitle = function updateImportTitle(l10nString, callback) {
    importSettingsTitle.setAttribute('data-l10n-id', l10nString);

    if (typeof callback === 'function'){
      callback();
    }

  };

  // Initialises variables and listener for the UI
  var initContainers = function initContainers() {

    orderItem           = document.getElementById('settingsOrder');
    orderCheckBox       = orderItem.querySelector('[name="order.lastname"]');

    orderContactsStatus = orderItem.querySelector(':first-child').querySelector('#settings-contact-ordering-status');

    if (!orderContactsStatus){
      orderContactsStatus = document.createElement('p');
      orderContactsStatus.setAttribute('id', 'settings-contact-ordering-status');
      orderItem.appendChild(orderContactsStatus);
    }


    navigationHandler = Contacts.navigation;
    navigationHandler.pushOptionMenu('contact-settings', 'view-contacts-settings');
    navigationHandler.pushOptionMenu('contact-import-settings', 'import-settings');

    // Init panel & elements for caching them
    importSettingsPanel = document.getElementById('import-settings');
    importSDOption = document.getElementById('import-sd-option');
    exportSDOption = document.getElementById('export-sd-option');
    importSettingsTitle = document.getElementById('import-settings-title');
    importLiveOption = document.getElementById('import-live-option');
    importGmailOption = document.getElementById('import-gmail-option');


    // ICE view
    setICEButton = document.getElementById('set-ice');

    /*
     * Adding listeners
     */

    // Listener for updating the timestamp based on extServices
    window.addEventListener('message', function updateList(e) {
      if (e.data.type === 'import_updated') {
        updateTimestamps();
        checkNoContacts();
      }
    });

    // Navigation back
    // importSettingsHeader = document.getElementById('import-settings-header');
    // importSettingsHeader.addEventListener('action', importSettingsBackHandler);

    // Handlers for the navigation through the panels
    importContacts = document.getElementById('importContacts');

    exportContacts = document.getElementById('exportContacts');
    // exportContacts.firstElementChild.
    //   addEventListener('click', exportContactsHandler);

    // Handlers for the actions related with EXPORT/IMPORT
    importOptions = document.getElementById('import-options');


    exportOptions = document.getElementById('export-options');
    //exportOptions.addEventListener('click', exportOptionsHandler);

    // ICE view
    // setICEButton.addEventListener('click', showICEScreen);

    // Bulk delete
    bulkDeleteButton = document.getElementById('bulkDelete');
    if (fb.isEnabled) {
      fbImportOption = document.querySelector('#settingsFb');
      fbSwitcher = fbImportOption.querySelector('.sync-facebook-status');
      fbImportCheckContainer = fbImportOption.querySelector('.fb-item');
      // fbImportCheckContainer.onclick = onFbEnable;
      fbImportCheck = document.querySelector('[name="fb.imported"]');

      fbUpdateButton = document.querySelector('#import-fb');
      fbOfflineMsg = document.querySelector('#no-connection');
      fbUpdateButton.onclick = Contacts.extServices.importFB;
      fbTotalsMsg = document.querySelector('#fb-totals');
      fbPwdRenewMsg = document.querySelector('#renew-pwd-msg');

      document.addEventListener('fb_changed', function onFbChanged(evt) {
        // We just received an event saying something might be changed
        fbGetTotals(false);
      });

      document.addEventListener('fb_token_ready', function onTokenReady(evt) {
        // We just received an event saying we imported the contacts
        fb.utils.getImportChecked(checkFbImported);
      });

      document.addEventListener('fb_token_error', function() {
        fbImportedValue = 'renew-pwd';
        fbImportOption.dataset.state = fbImportedValue;
      });

      document.addEventListener('fb_cleaned', function onFbCleaned(evt) {
        checkNoContacts();
      });
    }
    else {
      document.querySelector('#settings-article').dataset.state = 'fb-disabled';
    }
  };

  // UI event handlers
  function importSettingsBackHandler() {
    navigationHandler.back(function navigateBackHandler() {
        // Removing the previous assigned style for having
        // a clean view
        importSettingsPanel.classList.remove('export');
        importSettingsPanel.classList.remove('import');
    });
  }

  function importContactsHandler() {
      // Hide elements for export and transition
      importSettingsPanel.classList.remove('export');
      importSettingsPanel.classList.add('import');
      updateImportTitle('importContactsTitle', function(){
        importSettingsTitle.style.margin = 0;
      });

      navigationHandler.go('import-settings', 'right-left');
      OptionHelper.safeSetVisibility(true, 'contact-import-settings', 'Select', true);
  }

  function exportContactsHandler() {
      // Hide elements for import and transition
      LazyLoader.load(['/contacts/js/export/contacts_exporter.js'], function() {
        // Contacts.view('search', function() {
          importSettingsPanel.classList.remove('import');
          importSettingsPanel.classList.add('export');
          updateImportTitle('exportContactsTitle');
          navigationHandler.go('import-settings', 'right-left');
      });
        // }, Contacts.SHARED_CONTACTS);
      // }
  }

  function showICEScreen(cb) {
    LazyLoader.load([
      '/contacts/js/utilities/ice_data.js',
      '/contacts/js/views/ice_settings.js',
      '/shared/js/contacts/utilities/ice_store.js'], function(){
      contacts.ICE.refresh();
      navigationHandler.go('ice-settings', 'right-left');
      if (typeof cb === 'function') {
        cb();
      }
    });
  }

  // Given an event, select wich should be the targeted
  // import/export source
  function getSource(e) {
    var source = e.target.parentNode.dataset.source;
    if (e.target && e.target.hasAttribute('disabled')) {
      return '';
    }
    // Check special cases
    if (source && source.indexOf('-') != -1) {
      source = source.substr(0, source.indexOf('-'));
    }
    return source;
  }

  var importOptionsHandler = function importOptionsHandler(e) {
    /* jshint validthis:true */

    var source = getSource(e);
    switch (source) {
      case 'sim':
        var iccId = e.target.parentNode.dataset.iccid;
        window.setTimeout(requireSimImport.bind(this,
          onSimImport.bind(this, iccId)), 0);
        break;
      case 'sd':
        window.setTimeout(requireOverlay.bind(this, onSdImport), 0);
        break;
      case 'gmail':
        Contacts.extServices.importGmail();
        break;
      case 'live':
        Contacts.extServices.importLive();
        break;
    }
    OptionHelper.safeSetVisibility(false, 'contact-import-settings', 'Select', true);
  };

  var bulkDeleteHandler = function bulkDeleteHandler() {
    contacts.List.toggleICEGroup(false);
    Contacts.hideTabNavigation();
    LazyLoader.load(
      [
        '/contacts/js/contacts_bulk_delete.js',
        '/contacts/js/contacts_remover.js'
      ],
      function() {
        Contacts.updateSelectCountTitle(0);
          contacts.List.selectFromList('DeleteTitle',
            contacts.BulkDelete.performDelete,
            null, navigationHandler, {
              transitionLevel: DELETE_TRANSITION_LEVEL
            }
          );
        if (contacts.List.loading) {
          navigationHandler.pushOptionMenu('none',
              'view-contacts-list');
        } else {
          navigationHandler.pushOptionMenu('contact-notSelected-selectAll',
              'view-contacts-list');
        }

        // }, Contacts.SHARED_CONTACTS);
      }
    );
  };

  function exportOptionsHandler(e) {
    var source = getSource(e);
    switch (source) {
      case 'sim':
        var iccId = e.target.parentNode.dataset.iccid;
        LazyLoader.load(['/contacts/js/export/sim.js'],
          function() {
            doExport(new ContactsSIMExport(IccHandler.getIccById(iccId)));
          }
        );
        break;
      case 'sd':
        LazyLoader.load(
          [
            '/shared/js/device_storage/get_storage_if_available.js',
            '/shared/js/device_storage/get_unused_filename.js',
            '/shared/js/contact2vcard.js',
            '/shared/js/setImmediate.js',
            '/contacts/js/export/sd.js'
          ],
          function() {
            doExport(new ContactsSDExport());
          }
        );
        break;
      case 'bluetooth':
        LazyLoader.load(
          [
            '/shared/js/device_storage/get_storage_if_available.js',
            '/shared/js/device_storage/get_unused_filename.js',
            '/shared/js/contact2vcard.js',
            '/shared/js/setImmediate.js',
            '/contacts/js/export/bt.js'
          ],
          function() {
            doExport(new ContactsBTExport());
          }
        );
        break;
    }
  }

  function iceSettingsHandler(){
    contacts.ICE.iceSettingsHandler();
  }

  var setOverlayHeader = function setOverlayHeader(title){
    document.getElementById('overlay-title').setAttribute('data-l10n-id', title);
  };

  function handleBackInExport(evt){
    if (evt.key === 'BrowserBack' || evt.key === 'Backspace') {
      if ( !evt.manualCall ) {
        evt.stopPropagation();
        utils.overlay.isShown && evt.preventDefault();
      }
    } else {
      return;
    }
    onCancelExport();
  }

  var onCancelExport = function onCancelExport(){
    document.removeEventListener('keydown', handleBackInExport);
    exporter.getStrategy().cancelExport();
    utils.overlay.hide();
    setPrevMenuOnSelectionView();
    exportCancelled = true;
  };



  function doExport(strategy) {
    // Launch the selection mode in the list, and then invoke
    // the export with the selected strategy.

    // We need to know the number of FB contacts in the device to filter them
    // out properly.
    var numFbContactsReq = fb.utils.getNumFbContacts();

    numFbContactsReq.onsuccess = function() {
      openSelectList(numFbContactsReq.result);
    };

    numFbContactsReq.onerror = function() {
      openSelectList(0);
      console.error('Number of fb contacts in device could not be retrieved',
        numFbContactsReq.error && numFbContactsReq.error.name);
    };

    function openSelectList(numFilteredContacts) {
      contacts.List.toggleICEGroup(false);
      Contacts.hideTabNavigation();
      Contacts.selectionMode = true;
      TabNavigation.hideTab('speed-dial');
      navigationHandler.pushOptionMenu('contact-notSelected-selectAll', 'view-contacts-list');
      contacts.List.selectFromList('exportContactsAction',
        function onSelectedContacts(promise) {
          // Resolve the promise, meanwhile show an overlay to
          // warn the user of the ongoin operation, dismiss it
          // once we have the result
          requireOverlay(function _loaded() {

            exportCancelled = false;
            utils.overlay.show('preparing-contacts', null, 'spinner');
            promise.onsuccess = function onSuccess(ids) {
              // Once we start the export process we can exit from select mode
              // This will have to evolve once export errors can be captured
              // contacts.List.exitSelectMode();
              exporter = new ContactsExporter(strategy);
              optionParamName = OptionHelper.lastParamName;
              document.addEventListener('keydown', handleBackInExport);
              OptionHelper.optionParams['none'].items[0] = {
                                                  name: 'Cancel',
                                                  l10nId: 'cancel',
                                                  method: function(){
                                                    onCancelExport();
                                                  },
                                                  priority: '1'
                                                };
              Contacts.navigation.pushOptionMenu('none', 'view-contacts-list');

              setOverlayHeader('exportContactsTitle');


              exporter.init(ids, function onExporterReady() {
                // Leave the contact exporter to deal with the overlay
                exporter.start();
              });
            };
            promise.onerror = function onError() {
              contacts.List.exitSelectMode();
              utils.overlay.hide();
              Contacts.navigation.pushOptionMenu('contact-list', 'view-contacts-list');
            };
          });
        },
        null,
        navigationHandler,
        {
          isDanger: false,
          transitionLevel: EXPORT_TRANSITION_LEVEL,
          filterList: [
            {
              'containerClass': 'disable-fb-items',
              'numFilteredContacts': numFilteredContacts
            }
          ]
        }
      );
    }
  }

  // Options checking & updating

  var checkSIMCard = function checkSIMCard() {
    var statuses = IccHandler.getStatus();
    statuses.forEach(function onStatus(status) {
      enableSIMOptions(status.iccId, status.cardState);
    });
  };

  var onCancelDelete = function onCancelDelete(){
    document.removeEventListener('keydown', handleBackInDelete);
    contacts.BulkDelete.doCancel();
  };

  function handleBackInDelete(evt){
    if (evt.key === 'BrowserBack' || evt.key === 'Backspace') {
      if ( !evt.manualCall ) {
        evt.stopPropagation();
        utils.overlay.isShown && evt.preventDefault();
      }
    } else {
      return;
    }
    onCancelDelete();
  }

  // Disables/Enables an option and show the error if needed
  var updateOptionStatus =
    function updateOptionStatus(domOption, disabled, error) {
    if (domOption === null) {
      return;
    }
    var optionButton = domOption.firstElementChild;
    if (disabled) {
      optionButton.setAttribute('disabled', 'disabled');
      if (error) {
        domOption.classList.add('error');
      } else {
        domOption.classList.remove('error');
      }
    } else {
      optionButton.removeAttribute('disabled');
      domOption.classList.remove('error');
    }
  };

  // Disables/Enables the actions over the sim import functionality
  var enableSIMOptions = function enableSIMOptions(iccId, cardState) {
    var importSimOption = document.getElementById('import-sim-option-' + iccId);
    var exportSimOption = document.getElementById('export-sim-option-' + iccId);
    var disabled = (cardState !== 'ready' && cardState !== 'illegal');
    updateOptionStatus(importSimOption, disabled, true);
    updateOptionStatus(exportSimOption, disabled, true);
  };

  /**
   * Disables/Enables the actions over the sdcard import/export functionality
   * @param {Boolean} cardAvailable Whether functions should be enabled or not.
   */
  var updateStorageOptions = function updateStorageOptions(cardAvailable) {
    // Enable/Disable button and shows/hides error message
    updateOptionStatus(importSDOption, !cardAvailable, true);
    updateOptionStatus(exportSDOption, !cardAvailable, true);

    var importSDErrorL10nId = null;
    var exportSDErrorL10nId = null;

    var cardShared = utils.sdcard.status === utils.sdcard.SHARED;
    if (!cardAvailable) {
      importSDErrorL10nId = 'noMemoryCardMsg';
      exportSDErrorL10nId = 'noMemoryCardMsgExport';

      if (cardShared) {
        importSDErrorL10nId = exportSDErrorL10nId = 'memoryCardUMSEnabled';
      }
    }

    // update the message
    var importSDErrorNode = importSDOption.querySelector('p.error-message');
    if (importSDErrorL10nId) {
      importSDErrorNode.setAttribute('data-l10n-id', importSDErrorL10nId);
    } else {
      importSDErrorNode.removeAttribute('data-l10n-id');
      importSDErrorNode.textContent = '';
    }

    var exportSDErrorNode = exportSDOption.querySelector('p');
    if (exportSDErrorL10nId) {
      exportSDErrorNode.setAttribute('data-l10n-id', exportSDErrorL10nId);
    } else {
      exportSDErrorNode.removeAttribute('data-l10n-id');
      exportSDErrorNode.textContent = '';
    }

  };

  // Callback that will modify the ui depending if we imported or not
  // contacts from FB
  var checkFbImported = function checkFbImportedCb(value) {
    fbImportedValue = value;
    // Changing the state thus the CSS will select the correct values
    fbImportOption.dataset.state = fbImportedValue;

    if (fbImportedValue === 'logged-in') {
      fbSetEnabledState();
    }
    else if (fbImportedValue === 'logged-out') {
      fbSetDisabledState();
      // fbTotalsMsg.textContent = _('notEnabledYet');
    }
    else if (fbImportedValue === 'renew-pwd') {
      fbSetEnabledState();
    }
  };

  function fbSetEnabledState() {
    // We always get the totals from the cached value instead of remote value
    // This due to the fact that friend_count query from Facebook returns
    // all friends included those that have their accounts deactivated
    // See https://bugzilla.mozilla.org/show_bug.cgi?id=838605
    fbGetTotals(false);

    fbSwitcher.setAttribute('data-l10n-id', 'on');
    fbImportCheckContainer.setAttribute('aria-checked', true);
    document.dispatchEvent(new CustomEvent('facebookEnabled'));
    Cache.evict();
  }

  function fbSetDisabledState() {
    fbSwitcher.setAttribute('data-l10n-id', 'off');
    fbImportCheckContainer.setAttribute('aria-checked', false);
    Cache.evict();
  }

  // Get total number of contacts imported from fb
  var fbGetTotals = function fbGetTotals(requestRemoteData) {
    var req = fb.utils.getNumFbContacts();

    req.onsuccess = function() {
      var friendsOnDevice = req.result;

      var callbackListener = {
        'local': function localContacts(number) {
          fbUpdateTotals(friendsOnDevice, number);
        },
        'remote': function remoteContacts(number) {
          fbUpdateTotals(friendsOnDevice, number);
        }
      };

      // Do not ask for remote data if not necessary
      if (requestRemoteData === false) {
        callbackListener.remote = null;
      }

      fb.utils.numFbFriendsData(callbackListener);
    };

    req.onerror = function() {
      console.error('Could not get number of local contacts');
    };
  };

  /**
   * Loads the overlay class before showing
   */
  function requireOverlay(callback) {
    Contacts.utility('Overlay', callback, Contacts.SHARED_UTILITIES);
  }

  /**
   * Loads required libraries for sim import
   */
  function requireSimImport(callback) {
    var libraries = ['Overlay', 'Import_sim_contacts'];
    var pending = libraries.length;

    libraries.forEach(function onPending(library) {
      Contacts.utility(library, next, Contacts.SHARED_UTILITIES);
    });

    function next() {
      if (!(--pending)) {
        callback();
      }
    }
  }

  var fbUpdateTotals = function fbUpdateTotals(imported, total) {
    // If the total is not available then an empty string is showed
    var theTotal = total || '';

    navigator.mozL10n.setAttributes(fbTotalsMsg, 'facebook-import-msg2', {
      'imported': imported,
      'total': theTotal
    });
  };

  var onFbImport = function onFbImportClick(evt) {
    Contacts.extServices.importFB();
  };

  var onFbEnable = function onFbEnable(status) {
    var WAIT_UNCHECK = 400;
    var boolStatus = (status === 'on');
    if (fbImportedValue === 'logged-out' && boolStatus) {
      fbSwitcher.setAttribute('data-l10n-id', 'on');
      // fbImportCheck.checked = true;
      fbImportCheckContainer.setAttribute('aria-checked', true);
      onFbImport();
      // We need to uncheck just in case the user closes the window
      // without logging in (we don't have any mechanism to know that fact)
      window.setTimeout(function() {
        fbSwitcher.setAttribute('data-l10n-id', 'off');
        fbImportCheckContainer.setAttribute('aria-checked', true);
      }, WAIT_UNCHECK);
    } else if(!boolStatus) {
      fbSwitcher.setAttribute('data-l10n-id', 'off');
      // fbImportCheck.checked = false;
      fbImportCheckContainer.setAttribute('aria-checked', false);
      var msg = 'cleanFbConfirmMsg';
      var yesObject = {
        title: 'remove',
        isDanger: true,
        callback: function() {
          CustomDialog.hide();
          requireOverlay(doFbUnlink);
        }
      };

      var noObject = {
        title: 'cancel',
        callback: function onCancel() {
          fbSwitcher.setAttribute('data-l10n-id', 'off');
          fbImportCheckContainer.setAttribute('aria-checked', true);
          CustomDialog.hide();
        }
      };

      CustomDialog.show('importContactsTitle', msg, noObject, yesObject);
    }
  };

  function resetWait(wakeLock) {
    Contacts.hideOverlay();
    if (wakeLock) {
      wakeLock.unlock();
    }
  }


  function doFbUnlink() {
    var progressBar = Contacts.showOverlay('cleaningFbData', 'progressBar');
    var wakeLock = navigator.requestWakeLock('cpu');

    fb.markFbCleaningInProgress(1);
    var req = fb.utils.clearFbData();

    req.onsuccess = function() {
      var cleaner = req.result;
      progressBar.setTotal(cleaner.lcontacts.length);
      cleaner.onsuccess = function() {
        fb.markFbCleaningInProgress(0);
        document.dispatchEvent(new CustomEvent('fb_cleaned'));

        Contacts.showOverlay('loggingOutFb', 'activityBar');
        var logoutReq = fb.utils.logout();

        logoutReq.onsuccess = function() {
          checkFbImported('logged-out');
          // And it is needed to clear any previously set alarm
          window.asyncStorage.getItem(fb.utils.ALARM_ID_KEY, function(data) {
            if (data) {
              navigator.mozAlarms.remove(Number(data));
            }
            window.asyncStorage.removeItem(fb.utils.ALARM_ID_KEY);
          });

          window.asyncStorage.removeItem(fb.utils.LAST_UPDATED_KEY);
          fb.utils.removeCachedNumFriends();

          resetWait(wakeLock);
        };

        logoutReq.onerror = function(e) {
          resetWait(wakeLock);
          // We need to restore the check on settings in order to show
          // consistent information to the user
          fb.utils.getImportChecked(checkFbImported);
          window.console.error('Contacts: Error while FB logout: ',
            e.target.error);
        };
      };

      cleaner.oncleaned = function(num) {
        progressBar.update();
      };

      cleaner.onerror = function(contactid, error) {
        window.console.error('Contacts: Error while FB cleaning contact: ',
          contactid, 'Error: ', error.name);
        // Wait state is not resetted because the cleaning process will continue
      };
    };

    req.onerror = function(e) {
      window.console.error('Error while starting the cleaning operations',
        req.error.name);
      resetWait(wakeLock);
    };
  }

  // Listens for any change in the ordering preferences
  var onOrderingChange = function onOrderingChange(status) {

    if (status === 'sort-by-first-name'){
      //true
      newOrderByLastName = true;
      utils.cookie.update({order: true});
    } else {
      //false;
      newOrderByLastName = false;
      utils.cookie.update({
        order: false,
        firstLoad: false
      });
    }

    updateOrderingUI();
    // Force the reset of the dom, we know that we changed the order
    contacts.List.setOrderByLastName(!newOrderByLastName);
    contacts.List.load(null, true, function(){
      resetFocusContactList();
    });
    Cache.evict();

  };

  var selectionTagHandler = function selectionTagHandler(originalTag, status) {
    var switchAction = originalTag.getAttribute('action');
    switch (switchAction) {
      case 'switchSelectContact':
        contacts.ICE.changeSwitchStatus(originalTag, status);
        break;

      case 'sync-facebook':
        onFbEnable(status);
        break;

      case 'order':
        onOrderingChange(status);
        break;
    }
    Toaster.showToast({
      messageL10nId: 'tcl-oder-notification',
      latency: 2000,
    });
  };

  function resetFocusContactList(){
      var sel = navigationHandler.getNavigationSelector('view-contacts-list');
      var navId = document.querySelector(sel).getAttribute('data-nav-id');
      NavigationManager.update(sel);
      NavigationManager.context[sel] = navId;
  }
  // Import contacts from SIM card and updates ui
  var onCancelImport = function onCancelImport(evt){

      if (evt.key === 'BrowserBack' || evt.key === 'Backspace'){

        if ( !evt.manualCall ){
          evt.stopPropagation();
          utils.overlay.isShown && evt.preventDefault();
        }

      }else{
        return;
      }

      document.removeEventListener('keydown', onCancelImport);


      if (importFrom === 'simcard'){

        cancelled = true;
        importer.finish();
        if (contactsRead) {
          // A message about canceling will be displayed while the current chunk
          // is being cooked
          progress.setClass('activityBar');
          utils.overlay.hideMenu();
          progress.setHeaderMsg('messageCanceling');
        } else {
          importer.onfinish(); // Early return while reading contacts
        }

      }else if (importFrom === 'sdcard'){

        cancelled = true;
        importer ? importer.finish() : Contacts.hideOverlay();

      }
      OptionHelper.safeSetVisibility(true, 'contact-import-settings', 'Select', true);
  };

  var onSimImport = function onSimImport(iccId, done) {
    var icc = IccHandler.getIccById(iccId);
    if (icc === null) {
      return;
    }

    setOverlayHeader('importContactsTitle');

    progress = Contacts.showOverlay('simContacts-reading',
      'activityBar');

    var wakeLock = navigator.requestWakeLock('cpu');

    cancelled = false;
    contactsRead = false;

    importer = new SimContactsImporter(icc);

    document.addEventListener('keydown', onCancelImport);
    importFrom = 'simcard';

    var totalContactsToImport;
    var importedContacts = 0;
    // Delay for showing feedback to the user after importing
    var DELAY_FEEDBACK = 200;

    importer.onread = function import_read(n) {

      contactsRead = true;
      totalContactsToImport = n;

      if (totalContactsToImport > 0) {

        setProgress('progressBar', 'simContacts-importing', totalContactsToImport);

      }
    };

    importer.onfinish = function import_finish(numDupsMerged) {
      window.setTimeout(function onfinish_import() {
        resetWait(wakeLock);

        document.removeEventListener('keydown', onCancelImport);

        if (importedContacts > 0) {
          var source = 'sim-' + iccId;
          utils.misc.setTimestamp(source, function() {
            // Once the timestamp is saved, update the list
            updateTimestamps();
            checkNoContacts();
          });
        }
        if (!cancelled) {
          var statusMessage = navigator.mozL10n.get('tcl-imported-status', {
            n: importedContacts,
            numDups: !numDupsMerged ? 0 : numDupsMerged
          });
          Contacts.showStatus({
            message: statusMessage,
            latency: 2000
          });
        }

        typeof done === 'function' && done();

        contacts.List.load(null, null, function(value){
          resetFocusContactList();
        });


      }, DELAY_FEEDBACK);

      importer.onfinish = null;
    };

    importer.onimported = function imported_contact() {
      importedContacts++;
      if (!cancelled) {
        progress.update();
      }

    };

    importer.onerror = function import_error() {
      var cancel = {
        title: 'cancel',
        callback: function() {
          document.removeEventListener('keydown', onCancelImport);
          CustomDialog.hide();
        }
      };
      var retry = {
        title: 'retry',
        isRecommend: true,
        callback: function() {
          document.removeEventListener('keydown', onCancelImport);
          CustomDialog.hide();
          // And now the action is reproduced one more time
          window.setTimeout(requireSimImport.bind(this,
            onSimImport.bind(this, iccId)), 0);
        }
      };
      CustomDialog.show('importContactsTitle', 'simContacts-error', cancel, retry);
      resetWait(wakeLock);
    };

    importer.start();
  };

  var onSdImport = function onSdImport(cb) {
    document.addEventListener('keydown', onCancelImport);
    importFrom = 'sdcard';

    cancelled = false;
    importer = null;

    setOverlayHeader('importContactsTitle');

    progress = Contacts.showOverlay(
      'memoryCardContacts-reading', 'activityBar');

    var wakeLock = navigator.requestWakeLock('cpu');

    var importedContacts = 0;
    // Delay for showing feedback to the user after importing
    var DELAY_FEEDBACK = 200;

    utils.sdcard.retrieveFiles([
      'text/vcard',
      'text/x-vcard',
      'text/directory;profile=vCard',
      'text/directory'
    ], ['vcf', 'vcard'], function(err, fileArray) {
      if (err) {
        return import_error(err, cb);
      }

      if (cancelled) {
        return;
      }

      if (fileArray.length) {
        utils.sdcard.getTextFromFiles(fileArray, '', onFiles);
      } else {
        import_error('No contacts were found.', cb);
      }
    });

    function onFiles(err, text) {
      if (err) {
        return import_error(err, cb);
      }

      if (cancelled) {
        return;
      }

      importer = new VCFReader(text);
      if (!text || !importer) {
        return import_error('No contacts were found.', cb);
      }

      importer.onread = import_read;
      importer.onimported = imported_contact;
      importer.onerror = import_error;

      importer.process(function import_finish(total, numDupsMerged) {
        window.setTimeout(function onfinish_import() {
          utils.misc.setTimestamp('sd', function() {

            // Once the timestamp is saved, update the list
            updateTimestamps();
            checkNoContacts();
            resetWait(wakeLock);

            if (!cancelled) {
              var statusMessage = navigator.mozL10n.get('tcl-imported-status', {
                n: importedContacts,
                numDups: !numDupsMerged ? 0 : numDupsMerged
              });
              Contacts.showStatus({
                message: statusMessage,
                latency: 2000
              });
              var listSelector = navigation
                  .getNavigationSelector('view-contacts-list');
              window.NavigationManager.context[listSelector] = {};
              if (typeof cb === 'function') {
                cb();
              }

            }

            document.removeEventListener('keydown', onCancelImport);

            contacts.List.load(null, null, function(value){
              //resetFocusContactList();
            });


          });
        }, DELAY_FEEDBACK);
      });
    }

    function import_read(n) {

      setProgress ('progressBar', 'memoryCardContacts-importing', n);

    }

    function imported_contact() {
      importedContacts++;
      progress.update();
    }

    function import_error(e, cb) {
      var cancelcb = () => {
        document.removeEventListener('keydown', onCancelImport);
        CustomDialog.hide();
      };
      var retrycb = () => {
        CustomDialog.hide();
        document.removeEventListener('keydown', onCancelImport);
        // And now the action is reproduced one more time
        window.setTimeout(requireOverlay.bind(this, onSdImport), 0);
      };
      var config = {
        title: {id: 'importContactsTitle', args: {}},
        body: {id: 'memoryCardContacts-error', args: {}},
        backcallback: function() {},
        cancel: {
          l10nId: 'cancel',
          callback: cancelcb
        },
        confirm: {
          l10nId: 'retry',
          callback: retrycb
        }
      };
      var dialog = new ConfirmDialogHelper(config);
      dialog.show(document.getElementById('app-dialog'));
      resetWait(wakeLock);
      if (typeof cb === 'function') {
        cb();
      }
    }
  };

  var checkOnline = function() {
    // Perform pending automatic logouts
    window.setTimeout(automaticLogout, 0);

    // Facebook settings
    if (fb.isEnabled) {
      if (navigator.onLine === true) {
        fbImportOption.querySelector('li').removeAttribute('aria-disabled');
        fbUpdateButton.classList.remove('hide');
        fbOfflineMsg.classList.add('hide');
      } else {
        fbImportOption.querySelector('li.fb-item').setAttribute('aria-disabled',
          'true');
        fbUpdateButton.classList.add('hide');
        fbOfflineMsg.classList.remove('hide');
      }
    }

    // Other import services settings
    updateOptionStatus(importGmailOption, !navigator.onLine, true);
    updateOptionStatus(importLiveOption, !navigator.onLine, true);
  };

  var checkNoContacts = function checkNoContacts() {
    return new Promise(function(resolve, reject) {
      var exportButton = exportContacts;
      var req = navigator.mozContacts.getCount();
      req.onsuccess = function () {
        if (req.result === 0) {
          exportButton.setAttribute('disabled', 'disabled');
          bulkDeleteButton.setAttribute('disabled', 'disabled');
          setICEButton.setAttribute('disabled', 'disabled');
        } else {
          exportButton.removeAttribute('disabled');
          bulkDeleteButton.removeAttribute('disabled');
          setICEButton.removeAttribute('disabled');
        }
        return resolve();
      };

      req.onerror = function () {
        window.console.warn('Error while trying to know the contact number',
            req.error.name);
        // In case of error is safer to leave enabled
        exportButton.removeAttribute('disabled');
        bulkDeleteButton.removeAttribute('disabled');
        return reject();
      };
    });
  };

  function saveStatus(data) {
    window.asyncStorage.setItem(PENDING_LOGOUT_KEY, data);
  }

  function automaticLogout() {
    if (navigator.offLine === true) {
      return;
    }

    LazyLoader.load(['/shared/js/contacts/utilities/http_rest.js'],
    function() {
      window.asyncStorage.getItem(PENDING_LOGOUT_KEY, function(data) {
        if (!data) {
          return;
        }
        var services = Object.keys(data);
        var numResponses = 0;

        services.forEach(function(service) {
          var url = data[service];

          var callbacks = {
            success: function logout_success() {
              numResponses++;
              window.console.log('Successfully logged out: ', service);
              delete data[service];
              if (numResponses === services.length) {
                saveStatus(data);
              }
            },
            error: function logout_error() {
              numResponses++;
              if (numResponses === services.length) {
                saveStatus(data);
              }
            },
            timeout: function logout_timeout() {
              numResponses++;
              if (numResponses === services.length) {
                saveStatus(data);
              }
            }
          };
          Rest.get(url, callbacks);
        });
      });
    });
  }

  var updateTimestamps = function updateTimestamps() {
    // TODO Add the same functionality to 'EXPORT' methods when ready.
    var importSources =
      document.querySelectorAll('#import-options li[data-source]');
    Array.prototype.forEach.call(importSources, function(node) {
      utils.misc.getTimestamp(node.dataset.source,
                                      function(time) {
        var spanID = 'notImported';
        if (time) {
          spanID = 'imported';
          var timeElement = node.querySelector('p > time');
          timeElement.setAttribute('datetime',
                                             (new Date(time)).toLocaleString());
          timeElement.textContent = utils.time.pretty(time);
        }
        node.querySelector('p > span').setAttribute('data-l10n-id', spanID);
      });
    });
  };

  var refresh = function refresh() {
    getData();
    checkOnline();
    checkSIMCard();
    utils.sdcard.getStatus(function statusUpdated() {
      updateStorageOptions(utils.sdcard.checkStorageCard());
    });
    updateTimestamps();
    return checkNoContacts();
  };

  var setChosenTag = function setChosenTag() {
    var selector = 'label[data-value="' + getOrderL10nId() + '"]';
    var tagLabel = document.querySelector(selector);
    ContactsTag.selectTag(tagLabel.firstChild);
  };


  var isSettings = function isSettings() {

    var status = navigationHandler.stack.every(function(element, index, array){

      if (element.view === 'view-contacts-settings'){
        return false;
      }

      return true;

    });

    return !status;

  };

  var setPrevMenuOnSelectionView = function setPrevMenuOnSelectionView() {
    navigationHandler.pushOptionMenu(optionParamName, 'view-contacts-list');
  };


  var goToPage = function goToPage() {

    var selector = NavigationManager.getFocusedEl();
    var action = selector.getAttribute('action');
    if (!action) {
      return;
    }
    switch (action) {
      case 'order':
        Contacts.goToSelectTag(document.getElementById('settingsOrder'),
            false, () => {
          var title = document.getElementById('dialog-title');
          title.dataset.l10nId = 'settings-sort-contacts-title';
          setChosenTag();
          OptionHelper.show('contact-ordering-settings');
        });
        break;

      case 'import':
        importContactsHandler();
        break;

      case 'export':
        checkContactsExist() && exportContactsHandler();
        break;
      case 'sync-facebook':
          if (!checkAriaDisabled) {
            Contacts.goToSelectTag(document.getElementById('sync-facebook-switch'));
            document.getElementById('dialog-title').setAttribute('data-l10n-id', 'facebookSwitchMsg');
            setTimeout(setChosenTag, 0);
            OptionHelper.show('contact-ordering-settings');
          }
          break;
      case 'ice-contact':
        checkContactsExist() && showICEScreen(function() {
          NavigationManager.reset(contacts.ICE.navigationSelector);
        });
        break;

      case 'delete':
        checkContactsExist() && bulkDeleteHandler();
        break;

      default:
        console.error('Wrong action!');
        break;
    }

    function checkContactsExist() {
      var contactsExist = !!contacts.List.total;
      if (!contactsExist) {
        Toaster.showToast({
          messageL10nId: 'noContactsActivity2',
          latency: 2000,
        });
      }
      return contactsExist;
    }

    function checkAriaDisabled(){
      return selector.getAttribute('aria-disabled');
    }
  };


  function setProgress(typeClass, headerMsg, total) {
    progress.setClass(typeClass);
    progress.setHeaderMsg(headerMsg);
    progress.setTotal(total);
  }

  function removeIceContactDialog() {
    var removeICEDialogConfig = {
      title: {id: 'confirm-dialog-title-default', args: {}},
      body: {id: 'delete-ice-contact-warning', args: {}},
      backcallback: function() {},
      cancel: {
        l10nId: 'cancel',
        callback: function() {}
      },
      confirm: {
        l10nId: 'remove',
        callback: function() {
          var iceindex = NavigationManager
	      .getFocusedEl().dataset.iceindex;
          if (iceindex !== '') {
            contacts.ICE.changeSwitchStatus(iceindex, 'off');
          }
        }
      }
    };
    var dialog = new ConfirmDialogHelper(removeICEDialogConfig);
    dialog.show(document.getElementById('app-dialog'));
  }

  return {
    'init'                      : init,
    'close'                     : close,
    'goToPage'                  : goToPage,
    'refresh'                   : refresh,
    'onOrderingChange'          : onOrderingChange,
    'selectionTagHandler'       : selectionTagHandler,
    'cardStateChanged'          : checkSIMCard,
    'updateTimestamps'          : updateTimestamps,
    'showICEScreen'             : showICEScreen,
    'setChosenTag'              : setChosenTag,
    get navigation() { return navigationHandler; },
    'importOptionsHandler'      : importOptionsHandler,
    'exportOptionsHandler'      : exportOptionsHandler,
    'iceSettingsHandler'        : iceSettingsHandler,
    'importSettingsBackHandler' : importSettingsBackHandler,
    'importFromSIMCard'         : onSimImport,
    'onCancelImport'            : onCancelImport,
    'importFromSDCard'          : onSdImport,
    'isSettings'                : isSettings,
    'setPrevMenuOnSelectionView': setPrevMenuOnSelectionView,
    'setOverlayHeader'          : setOverlayHeader,
    'onCancelExport'            : onCancelExport,
    'handleBackInExport'        : handleBackInExport,
    'onCancelDelete'            : onCancelDelete,
    'handleBackInDelete'        : handleBackInDelete,
    'removeIceContactDialog': removeIceContactDialog,

    get exportCancelled(){
      return exportCancelled;
    },

    get navigationSelector(){

      if (importSettingsPanel.classList.contains('import')){
        return '#import-options li';
      }else if (importSettingsPanel.classList.contains('export')){
        return '#export-options li';
      }else{
        return '#import-settings article section ul li';
      }

    },

    get navigationSelectorMainPage(){
      return '#view-contacts-settings article section .settings-main-link:not(.hide):not([disabled])';
    },

  };
})();
