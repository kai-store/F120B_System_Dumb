/* global ActivityHandler */
/* global ContactPhotoHelper */
/* global Contacts */
/* global OptionHelper */
/* global fb */
/* global NavigationManager */
/* global LazyLoader */
/* global MozActivity */
/* global utils */
/* global MergeHelper */
/* global Toaster */
/* global navigation, ConfirmDialogHelper */
/* jshint esnext: true */
/* jshint -W075 */

'use strict';
var contacts = window.contacts || {};

contacts.Form = (function () {
  const ITEMS_SELECTOR = '#contact-form :not([hidden]) > .input-container:not([hidden]):not(.hide)';
  var _needConfirm = true;
  var formShow = false;
  var counters = {
    'tel': 0,
    'email': 0,
    'adr': 0,
    'date': 0,
    'note': 0
  };

  var availableActions = {
    addPhoto: function () {},
    addPhone: function (e) {},
    addEmail: function () {},
    addAddress: function () {}, //todo add address action
    addDate: function () {
      var dateInput = document.querySelector('.focus input[type="date"]');
      dateInput.focus();
    },
    addRingtone: function () {},
    addRingselect: function () {},
    addComment: function () {}
  };

  var currentContact = {};
  var originalContactData = {};
  var closeCb = function () {};
  var dom,
    contactForm,
    deleteContactButton,
    addPhotoBtn,
    thumb,
    thumbAction,
    saveButton,
    formHeader,
    formTitle,
    currentContactId,
    givenName,
    phonesArea,
    emailsArea,
    addressesArea,
    datesArea,
    notesArea,
    ringtoneDetail,
    ringtoneButton,
    notesTemplate,
    company,
    familyName,
    _,
    formView,
    throbber,
    mode,
    cancelHandler,
    mergeHandler,
    nonEditableValues,
    deviceContact,
    fbContact,
    currentPhoto,
    photoInsertArea,
    photoAddBtn,
    _isActivityMode = false;

  var FB_CLASS = 'facebook';
  var INVALID_CLASS = 'invalid';
  var formFields = ['tel', 'email', 'adr', 'date', 'note'];

  // The size we want our contact photos to be
  var PHOTO_WIDTH = 320;
  var PHOTO_HEIGHT = 320;
  // bug 1038414: ask for an image about 2MP before
  // doing the crop to save memory in both apps
  var MAX_PHOTO_SIZE = 200000;

  var touchstart = 'ontouchstart' in window ? 'touchstart' : 'mousedown';

  // Indicates whether a tel number has been deleted
  // (useful for warning about ICE Contacts)
  var deletedTelNumber = false;

  var textFieldsCache = {
    _textFields: null,

    get: function textFieldsCache_get() {
      if (!this._textFields) {
        var fields = contactForm.querySelectorAll('input[data-field]');

        var fbFields =
          Array.slice(contactForm.querySelectorAll(
            '.facebook input[data-field]'));
        var invalidFields =
          Array.slice(contactForm.querySelectorAll(
            '.invalid input[data-field]'));

        this._textFields = Array.filter(fields, function (field) {
          return (fbFields.indexOf(field) === -1 &&
            invalidFields.indexOf(field) === -1);
        });
      }

      return this._textFields;
    },

    clear: function textFieldsCache_clear() {
      this._textFields = null;
    }
  };

  var initContainers = function cf_initContainers() {
    thumb = dom.querySelector('#thumbnail-photo');
    thumbAction = dom.querySelector('#thumbnail-action');
    thumbAction.querySelector('#photo-button').onclick = photoAction;
    saveButton = dom.querySelector('#save-button');
    deleteContactButton = dom.querySelector('#delete-contact');
    contactForm = dom.getElementById('contact-form');
    formHeader = dom.querySelector('#contact-form-header');
    formTitle = dom.getElementById('contact-form-title');
    currentContactId = dom.getElementById('contact-form-id');
    givenName = dom.getElementById('givenName');
    company = dom.getElementById('org');
    familyName = dom.getElementById('familyName');
    formView = dom.getElementById('view-contact-form');
    throbber = dom.getElementById('throbber');
    phonesArea = dom.getElementById('contact-detail-phone-area');
    emailsArea = dom.getElementById('contact-detail-email-area');
    addressesArea = dom.getElementById('contact-detail-address-area');
    datesArea = dom.getElementById('contact-detail-date-area');
    notesArea = dom.getElementById('contact-detail-comment-area');
    ringtoneDetail = dom.getElementById('contact-detail-ringtone-area');
    ringtoneButton = dom.getElementById('ringtone-button');
    notesTemplate = dom.getElementById('add-comment-template');
    addPhotoBtn = dom.getElementById('contacts-form-add-photo');
    photoInsertArea = dom.getElementById('contact-detail-photo-area');
    photoAddBtn = dom.querySelector('p[data-option-name="add-photo-button"]');
  };

  var isInputValueWasChanged = function (el) {
    var result = false;
    if (el.dataset.oldValue) {
      (result = (el.dataset.oldValue != el.value)) && (el.dataset.oldValue = el.value);
    } else if (el.value) {
      (result = true) && (el.dataset.oldValue = el.value);
    }
    return result;
  };

  var isInputEl = function (e) {
    return e && e.target && e.target.tagName.toLowerCase() === 'input';
  };

  var init = function cf_init(tags, currentDom) {
    dom = currentDom || document;

    _ = navigator.mozL10n.get;
    initContainers();
    function input_change_handler(event) {
      if (Contacts.navigation.currentView() === 'view-contact-form' && isInputEl(event)) {
        isInputValueWasChanged(event.target) && checkDisableButton();
        var current_focused = event.target.parentNode;
        if (current_focused) {
          var optionName = current_focused.dataset.optionName;
          checkCurOptionName(optionName);
        }
      }
    }
    //Cannot receive 'keyup' event sometimes, so change to listen 'input' event.
    dom.addEventListener('input', input_change_handler);
    dom.addEventListener('keydown', function input(event) {
      var focusEl = NavigationManager.getFocusedEl();
      if (Contacts.navigation.currentView() === 'view-contact-form') {
        if (event.key == 'Enter' &&
            focusEl.classList.contains('contact-detail-date')) { //clear for device
          focusEl.querySelector('input').focus();
        }
      }
    });

    document.addEventListener('accepted', doAccepted);
    contactForm.addEventListener(touchstart, function click(event) {
      var tgt = event.target;
      if (tgt.tagName == 'BUTTON' && tgt.getAttribute('type') == 'reset') {
        event.preventDefault();
        var input = tgt.previousElementSibling;

        if (input.getAttribute('name').startsWith('tel') &&
          input.dataset.field === 'value') {
          var telId = input.id;
          var telIndex = telId.substring(telId.indexOf('_') + 1);
          var carrierField =
            document.getElementById('carrier' + '_' + telIndex);
          carrierField.parentNode.classList.add(INVALID_CLASS);

          textFieldsCache.clear();
          deletedTelNumber = true;
        }
        input.value = '';
        checkDisableButton();
      }
    });

    formView.addEventListener('ValueModified', function onValueModified(event) {
      if (!event.detail) {
        return;
      }
      if (event.detail.newValue && (event.detail.prevValue !== event.detail.newValue)) {
        changeSaveBtnState('enabled');
      }
    });

    // Add listeners
    utils.listeners.add({
      '#contact-form-header': [{
        event: 'action',
        handler: Contacts.cancel // Cancel edition
      }],
      '#save-button': saveContact,
      '#contact-form button[data-field-type]': newField
    });

    prpareFormLabels();
    var inputElinCash;
    document.addEventListener('focusChanged', function (e) {
      if (['view-contact-form', 'view-select-tag']
          .indexOf(navigation.currentView()) < 0) {
        return;
      }
      var activeEl = e.detail.focusedElement, inputEl;
      if (!activeEl) {
        return;
      }
      inputEl = activeEl.querySelector('input:not([type=date])') ||
          activeEl.querySelector('button');
      if (inputEl) {
        inputElinCash = inputEl;
        inputEl.focus();
      } else if (inputElinCash) {
        inputElinCash.blur();
        inputElinCash = null;
      }
      var optionName = activeEl.dataset.optionName;
      checkCurOptionName(optionName);
    });

    window.addEventListener('changedView', function (evt) {
      var view = evt.detail.currentView;
      if (view !== 'view-contact-form') {
        setSofkeyButtonVisible();
        formShow = false;
      } else {
        formShow = true;
        if (!_isActivityMode) {
          changeSaveBtnState('disabled', true);
        }
      }
    });
    Contacts.navigation.subscribe('beforeTransition', function (details) {
      if (details.fromView === 'view-contact-form' && details.toView !== 'view-select-tag') {
        //details.scope.cancelTransition();
        if (ActivityHandler.currentlyHandling &&
            (ActivityHandler.activityName === 'new' || ActivityHandler.activityName === 'update')) {
          // Contacts.navigation sets focus on a forward view so activity gets focused after closing
          // To avoid it, we need to cancel transition
          Contacts.navigation.cancelTransition();
        }
        beforeExit(function() {
          if (ActivityHandler.activityName === 'new' || ActivityHandler.activityName === 'update') {
            var curInputEl = NavigationManager
                .getFocusedEl().querySelector('input');
            curInputEl && curInputEl.setAttribute('readOnly', true);
            ActivityHandler.postCancel();
          }
        },false);
      }
      if (details.toView === 'view-contact-form') {
        checkFieldsExist(['phone', 'email']); //this fields must be existed
        //todo set buton state ('hide or not')
        //isActivityMode
      }
    });
    Contacts.navigation.subscribe('afterTransition', (details) => {
      if (details.toView === 'view-contact-form') {
        checkElForOwnMnu();
      }
    });
  };

  var checkElForOwnMnu = function () {
    var focused = NavigationManager.getFocusedEl();
    if (focused && focused.dataset && focused.dataset.optionName) {
      document.dispatchEvent(new CustomEvent('focusChanged', {
        detail: {
          focusedElement: focused
        }
      }));
    }
  };

  var checkCurOptionName = function(optionName) {
    var judgeBeforeRunCallback = function(name) {
      generateContactData((contactData) => {
        OptionHelper.safeSetVisibility(!objectEquals(originalContactData, contactData),
          name, 'Save', true);
      });
    };
    if (optionName && optionName.indexOf('-type-options') > -1) {
      judgeBeforeRunCallback(optionName);
    } else {
      optionName = OptionHelper.getLastParamName();
      if (['contact-details-edit', 'add-photo-button', 'add-phone-button',
          'add-email-button', 'add-address-button', 'add-date-button',
          'add-ringtone-button', 'add-comment-button'].indexOf(optionName) !== -1) {
        judgeBeforeRunCallback(optionName);
      } else {
        return false;
      }
    }
  };

  var setSofkeyButtonVisible = function setSofkeyButtonVisible() {
    OptionHelper.changeBtnState('left', 'show');
  };

  var goBack = function(isMerge) {
    if (isMerge) {
      _needConfirm = false;
      backOrExit();
    } else {
      closeCb = function() {};
      beforeExit( (isCancel) => {
        if (!isCancel) {
          _needConfirm = false;
          backOrExit();
        }
      }, false);
    }
  };

  var backOrExit = function() {
    if (ActivityHandler && ActivityHandler.activityName === 'open') {
      ActivityHandler.postCancel();
    } else {
      Contacts.navigation.back();
    }
  };

  var isDataChanged = function (callback) {
    if (!_needConfirm) {
      callback(false);
    } else {
      generateContactData((contactData) => {
        callback(!objectEquals(originalContactData, contactData));
      });
    }
  };
  var _inDialogue = false;
  var beforeExit = function cf_beforeExit(callFn, doClose) {
    if (typeof callFn !== 'function') {
      callFn = function() {};
    }
    function dataChangeConfirm() {
      var doCancel = function(isCancel) {
        callFn(isCancel);
        if (!isCancel) {
          closeCb();
        }
      };
      var bodyId = isNewContact() ? 'contact-confirm-save' : 'contact-confirm-form-save';
      var dialogConfig = {
        title: { id: 'confirm-dialog-title-default', args: {} },
        body: { id: bodyId, args: {} },
        backcallback: function() {},
        cancel: {
          l10nId: 'cancel',
          callback: doCancel.bind(null, true)
        },
        accept: {
          l10nId: 'save',
          callback: function() {
            _inDialogue = true;
            contacts.Form.saveContact();
            callFn(false);
          }
        },
        confirm: {
          l10nId: 'discard',
          callback: doCancel.bind(null, false)
        }
      };
      var dialog = new ConfirmDialogHelper(dialogConfig);
      dialog.show(document.getElementById('app-dialog'));
    }

    if(doClose) {
      dataChangeConfirm();
    } else {
      isDataChanged((dataChanged) => {
        if (dataChanged) {
          dataChangeConfirm();
        } else {
          callFn();
        }
      });
    }
  };

  var doClose = function cf_doClose() {
    return new Promise(function (resolve, reject) {
      closeCb = resolve;
      beforeExit(null,true);
    });
  };
  /*
   * l10n.js add placeholder attribute for labels moz bug is not resolved
   * get all placeholder contains label into form and set text content
   */
  var prpareFormLabels = function () {
    var labels = Array.prototype.slice.call(contactForm.querySelectorAll('label[placeholder], span[placeholder]'));
    if (labels.length > 0) {
      labels.map((el) => el.textContent = el.getAttribute('placeholder'));
    }
  };

  var newField = function newField(evt) {
    return contacts.Form.onNewFieldClicked(evt);
  };

  var render = function cf_render(contact, callback, pFbContactData, params) {
    resetForm();
    var fbContactData = pFbContactData || [];
    fbContact = fbContactData[2] || {};
    nonEditableValues = fbContactData[1] || {};
    deviceContact = contact;
    var renderedContact = fbContactData[0] || deviceContact;
    // We need to check against the string 'undefined' because of bug 951829.
    (renderedContact && renderedContact.id && renderedContact.id != 'undefined') ?
      showEdit(renderedContact, params) : showAdd(renderedContact);

    // reset the scroll from (possible) previous renders
    setTimeout(() => contactForm.scrollTop = 0, 13);
    if (callback) {
      callback();
    }
  };

  function fillDates(contact) {
    if (contact.bday) {
      contact.date = [];

      contact.date.push({
        type: 'birthday',
        value: contact.bday
      });
    }

    if (contact.anniversary) {
      contact.date = contact.date || [];
      contact.date.push({
        type: 'anniversary',
        value: contact.anniversary
      });
    }
  }

  function renderPhoto(contact) {
    if (contact.photo && contact.photo.length > 0) {
      currentPhoto = ContactPhotoHelper.getFullResolution(contact);
      renderPhotoFromBlob(currentPhoto);
    }
  }

  var setInputValue = function (data) {
    if (Object.prototype.toString.call(data) === '[object Array]') {
      data.forEach(setInputValue);
    } else {
      if (data.val instanceof Date) {
        data.el.valueAsDate = data.val;
      } else {
        data.el.value = data.val;
      }
      data.el.dataset.oldValue = data.val;
    }
  };

  var showEdit = function showEdit(contact, params) {
    mode = 'edit';
    resetForm();
    if (!contact || !contact.id) {
      console.warn('contact id doesn\'t found');
      return;
    }
    _isActivityMode = true; //Bug 1390 by Elena Kustova in Edit mode save btn allways can be shownz
    renderPhoto(contact);
    currentContact = contact;
    formTitle.setAttribute('data-l10n-id', 'editContact');
    currentContactId.value = contact.id;
    setInputValue([{
      el: givenName,
      val: utils.extractValue(contact.givenName)
    }, {
      el: familyName,
      val: utils.extractValue(contact.familyName)
    }, {
      el: company,
      val: utils.extractValue(contact.org)
    }]);

    if (nonEditableValues[company.value]) {
      var nodeClass = company.parentNode.classList;
      nodeClass.add(FB_CLASS);
    }

    fillDates(contact);
    if (params) {
      contact = mergeContactWithParams(contact, params);
    }
    formFields.forEach(function (field) {
      renderTemplate(field, contact[field]); //edit mode hz
    });
    renderRingtone(contact.ringtone);
    if (ActivityHandler.activityName === 'update') {
      changeFocusIfFieldFilled();
    }
    changeAddDateState();
    checkDisableButton();

    originalContactData = {};
    generateContactData((contactData) => {}, originalContactData);
  };

  function changeFocusIfFieldFilled() {
    if (!ActivityHandler.activityData) {
      return;
    }
    setTimeout(function() {
      var params = ActivityHandler.activityData.params,
          selector = params && params.hasOwnProperty('email') ?
                '.contact-detail-email' : '.contact-detail-phone',
          els = document.querySelectorAll(selector),
          lastItem = els[els.length-1],
          lastItemInput = lastItem.querySelector('input');

      if (lastItemInput && lastItemInput.value) {
        NavigationManager.resetByNode(ITEMS_SELECTOR, lastItem);
        setTimeout(function() {
          lastItem.scrollIntoView();
        }, 0);
      }
    }, 0);
  }

  function mergeContactWithParams(contact, params) {
    formFields.forEach(function (field) {
      if (params[field]) {
        // TODO we can't judge an array like this, should review later
        if (typeof contact[field] === 'array') {
          contact[field].push(params[field]);
        } else {
          contact[field] = [params[field]];
        }
      }
    });
    return contact;
  }

  var showAdd = function showAdd(params) {
    mode = 'add';
    resetForm();
    formView.classList.remove('skin-organic');
    if (params) { //if new contact added with params so we must have save btn enabled
      _isActivityMode = true;
    }
    if (!params || params == -1 || !params.id) {
      currentContact = {};
    }
    changeAddDateState();
    formTitle.setAttribute('data-l10n-id', 'tcl-new-contact');

    params = params || {};
    givenName.value = utils.extractValue(params.givenName);
    familyName.value = utils.extractValue(params.lastName || params.familyName);
    company.value = utils.extractValue(params.company || params.org);
    renderPhoto(params);

    fillDates(params);

    formFields.forEach(function (field) {
      fillForm(field, params[field]);
    });

    originalContactData = {};
    generateContactData((contactData) => {}, originalContactData);
  };

  // template, fields, cont, counter
  /**
   * Render Template
   *
   * @param {string} type Type of template, eg. 'tel'
   * @param {object[]} toRender
   */
  var renderTemplate = function cf_rendTemplate(type, toRender) {
    var toRenderCopy,
      firstVal;
    type = type == 'tel' ? 'phone' : type;
    type = type == 'adr' ? 'address' : type;
    type = type == 'note' ? 'comment' : type;
    if (!toRender || typeof toRender === undefined) {
      return;
    }
    if (!Array.isArray(toRender)) {
      toRender = [{
        value: toRender
      }];
    }
    toRenderCopy = Array.prototype.slice.call(toRender);
    if (toRenderCopy.length < 1) { //throw away empty arrays
      return;
    }
    if (['phone', 'email'].indexOf(type) !== -1) {
      firstVal = toRenderCopy.shift();
      renderFirstValue(type, firstVal);
    }
    toRenderCopy.map(function (value) {
      insertField(type, value);
    });
  };

  var renderFirstValue = function (type, val) {
    var valueArea = contactForm.querySelector('#contact-detail-' + type + '-area'),
      typePlace,
      valuePlace;
    if (!valueArea) {
      console.error('AREA from ' + type + ' doesn\'t find!');
      return;
    }
    typePlace = valueArea.querySelector('span.' + type + '-type');
    valuePlace = valueArea.querySelector('input.textfield');
    if (val.type && val.type[0]) {
      if (type === 'email' &&
          ['personal', 'home', 'work', 'other'].indexOf(val.type[0]) == -1) {
        typePlace.setAttribute('data-value', val.type[0]);
        typePlace.textContent = val.type[0];
        typePlace.removeAttribute('data-l10n-id', '');
      } else {
        typePlace.setAttribute('data-value', val.type[0]);
        typePlace.setAttribute('data-l10n-id', val.type[0]);
      }
    }
    if (val.value) {
      setInputValue({
        el: valuePlace,
        val: val.value
      });
    }
  };

  var renderRingtone = function (value) {
    if (!value) {
      return;
    }

    var field = ringtoneDetail.querySelector('span.ringtone-type');
    var filename;

    field.dataset.key = value;

    filename = getFilename(value) || value;

    field.dataset.value = filename;
    if (filename.indexOf('builtin:ringtone/ringer_' > -1)) {
      field.textContent = filename.replace('builtin:ringtone/ringer_', '');
      field.textContent = field.textContent.substring(0, 1).toUpperCase() +
          field.textContent.substring(1);
    } else {
      field.textContent = filename;
    }

    showRingtone();
  };

  function getFilename(value) {
    var re = /.+\/+(.+\..+)/;
    var match = re.exec(value);

    return match && match[1];
  }

  var fillForm = function cf_fillForm(type, toRender) {
    if (!Array.isArray(toRender)) {
      toRender = [{
        value: toRender
      }];
    }
    for (var i = 0; i < toRender.length; i++) {
      fillFormInput(type, toRender[i] || {});
    }
  };

  function checkAddDateButton() {
  }

  var onNewFieldClicked = function onNewFieldClicked(evt) {
    var type = evt.target.dataset.fieldType;
    evt.preventDefault();
    contacts.Form.insertField(type, null, [
      'inserted',
      'displayed'
    ]);
    textFieldsCache.clear();
    // For dates only two instances
    if (type === 'date') {
      // Disable the add date button if necessary
      checkAddDateButton();
    }
    return false;
  };

  var fillFormInput = function fillFormInput(type, object, targetClasses) {
    if (type === 'tel' || type === 'email') {
      var obj = object || {};
      var input = document.querySelector('input[name="' + type + '"]');
      if (input && obj.value) {
        input.value = obj.value;
      }
    }
  };

  var insertField = function insertField(type, object, targetClasses) {
    var insertArea = contactForm.querySelector('#contact-detail-' + type + '-area'),
      typeVal,
      val,
      node,
      template = document.getElementById('add-' + type + '-template');
    if (!insertArea) {
      console.error('insert area for ' + type + ' is not found!');
      return;
    }
    if (!template) {
      console.error('template for ' + type + ' is not found!');
      return;
    }
    if (type === 'date') {
      typeVal = object.type;
    } else {
      typeVal = object.type && object.type[0];
    }
    if (type !== 'address') {
      val = Object.prototype.toString.call(object) === '[object String]' ? object : object.value;
      if (!val) {
        return;
      }
      node = fillAndRender(typeVal, val, template);
    } else {
      node = fillAndRenderAddress(typeVal, object, template); //todo don't forget change setVAlue method
    }
    insertArea.appendChild(node);
  };

  var fillAndRender = function (type, value, template) {
    var result = document.importNode(template.content, true),
      typePlace = result.querySelector('label > span'),
      valuePlace = result.querySelector('input.textfield');
    if (type) {
      typePlace.setAttribute('data-value', type);
      typePlace.setAttribute('data-l10n-id', type);
    }
    setInputValue({
      el: valuePlace,
      val: value
    });
    //valuePlace.value = value;
    return result;
  };

  var fillAndRenderAddress = function (type, values, template) {
    var result = document.importNode(template.content, true),
      typePlace = result.querySelector('label > span'),
      valuesPlace = Array.prototype.slice.call(result.querySelectorAll('input[type="text"]'));
    if (type && ['current', 'home', 'work'].indexOf(type) > -1) {
      typePlace.setAttribute('data-value', type);
      typePlace.setAttribute('data-l10n-id', type);
    } else {
      typePlace.setAttribute('data-value', type);
      typePlace.textContent = type;
    }
    values.streetAddress && setInputValue({
      el: valuesPlace[0],
      val: values.streetAddress
    });
    values.locality && setInputValue({
      el: valuesPlace[1],
      val: values.locality
    });
    values.countryName && setInputValue({
      el: valuesPlace[2],
      val: values.countryName
    });
    values.postalCode && setInputValue({
      el: valuesPlace[3],
      val: values.postalCode
    });
    return result;
  };

  var CATEGORY_WHITE_LIST = ['gmail', 'live'];

  function updateCategoryForImported(contact) {
    if (Array.isArray(contact.category)) {
      var total = CATEGORY_WHITE_LIST.length;
      var idx = -1;
      for (var i = 0; i < total; i++) {
        idx = contact.category.indexOf(CATEGORY_WHITE_LIST[i]);
        if (idx !== -1) {
          break;
        }
      }
      if (idx !== -1) {
        contact.category[idx] = contact.category[idx] + '/updated';
      }
    }
  }

  var fillContact = function (contact, done) {
    createName(contact);

    getPhones(contact);
    getEmails(contact);
    getAddresses(contact);
    getNotes(contact);
    getDates(contact);
    getPhoto(contact);
    getRingtones(contact);
    done(contact);
  };

  var saveContact = function saveContact() {
    showThrobber();
    continueSavingContact();
  };

  function continueSavingContact(onlyGenDataCallback, fillContactData) {
    currentContact = currentContact || {};
    currentContact = deviceContact || currentContact;
    var deviceGivenName = currentContact.givenName || [''];
    var deviceFamilyName = currentContact.familyName || [''];

    var myContact = fillContactData || {
      id: document.getElementById('contact-form-id').value,
      additionalName: [''],
      name: ['']
    };

    var inputs = {
      givenName, familyName
    };

    for (var field in inputs) {
      var value = inputs[field].value;
      if (value && value.length > 0) {
        myContact[field] = [value];
      } else {
        myContact[field] = null;
      }
    }

    if (company.value && company.value.length > 0) {
      myContact.org = [company.value];
    }

    if (currentContact.category) {
      myContact.category = currentContact.category;
    }

    fillContact(myContact, function contactFilled(myContact) {
      // Use the isEmpty function to check fields but address
      // and inspect address by it self.
      if (onlyGenDataCallback) {
        if (myContact.note) {
          delete myContact.note;
        }
        if (myContact.ringtone) {
          delete myContact.ringtone;
        }
        onlyGenDataCallback(myContact);
        return;
      }

      var contact;
      if (myContact.id) { //Editing a contact
        currentContact.tel = [];
        currentContact.email = [];
        currentContact.org = [];
        currentContact.adr = [];
        currentContact.note = [];
        currentContact.photo = [];
        currentContact.bday = null;
        currentContact.anniversary = null;
        currentContact.ringtone = null;
        var readOnly = ['id', 'updated', 'published'];
        for (var field in myContact) {
          if (readOnly.indexOf(field) == -1) {
            currentContact[field] = myContact[field];
          }
        }
        contact = currentContact;

        if (fb.isFbContact(contact)) {
          // If it is a FB Contact not linked it will be automatically linked
          // As now there is additional contact data entered by the user
          if (!fb.isFbLinked(contact)) {
            var fbContact = new fb.Contact(contact);
            // Here the contact has been promoted to linked but not saved yet
            fbContact.promoteToLinked();
          }

          setPropagatedFlag('givenName', deviceGivenName[0], contact);
          setPropagatedFlag('familyName', deviceFamilyName[0], contact);
          createName(contact);
        }
      } else {
        contact = utils.misc.toMozContact(myContact);
      }

      updateCategoryForImported(contact);
      var callbacks = cookMatchingCallbacks(contact);
      cancelHandler = doCancel.bind(callbacks);
      formHeader.addEventListener('action', cancelHandler);
      doMatch(contact, callbacks);
    });
  }

  function generateContactData(callback, fillContactData) {
    if (fillContactData && !fillContactData.id) {
      fillContactData.id = document.getElementById('contact-form-id').value;
      fillContactData.additionalName = [''];
      fillContactData.name =[''];
    }
    continueSavingContact(callback, fillContactData);
  }

  var hideSoftKeyPanel = function cf_hideSoftKeyPanel() {
    document.getElementById('softkeyPanel').style.visibility = 'hidden';
    document.querySelector('#view-contact-form .view-body')
        .classList.add('fullscreen');
  };

  var showSoftKeyPanel = function cf_hideSoftKeyPanel() {
    document.getElementById('softkeyPanel').style.visibility = 'visible';
    document.querySelector('#view-contact-form .view-body')
        .classList.remove('fullscreen');
  };

  var cookMatchingCallbacks = function cookMatchingCallbacks(contact) {
    return {
      onmatch: function (results) {
        Contacts.extServices.showDuplicateContacts();
        hideSoftKeyPanel(); //because of our soft key is in iframe contacts one is above than ours.
        mergeHandler = function mergeHandler(e) {
          if (e.origin !== fb.CONTACTS_APP_ORIGIN) {
            return;
          }
          var data = e.data;
          var details;
          switch (data.type) {
          case 'duplicate_contacts_loaded':
            // UI ready, passing duplicate contacts
            var duplicateContacts = {};
            Object.keys(results).forEach(function (id) {
              duplicateContacts[id] = {
                matchingContactId: id,
                matchings: results[id].matchings
              };
            });
            window.postMessage({
              type: 'show_duplicate_contacts',
              data: {
                name: getCompleteName(getDisplayName(contact)),
                duplicateContacts: duplicateContacts
              }
            }, fb.CONTACTS_APP_ORIGIN);
            break;
          case 'merge_duplicate_contacts':
            window.removeEventListener('message', mergeHandler);
            showSoftKeyPanel();
            hideFrames(['curtain', 'extensions']);
            setFocusTo(document.body);
            var list = [];
            var ids = data.data;
            Object.keys(ids).forEach(id => {
              list.push(results[id]);
            });
            doMerge(contact, list, function finished() {
              // Contacts merged goes to contact list automatically without
              // saving, the merger does the live better to us
              if (ActivityHandler.currentlyHandling) {
                ActivityHandler.postNewSuccess(contact);
              }
              window.postMessage({
                type: 'duplicate_contacts_merged',
                data: ids
              }, fb.CONTACTS_APP_ORIGIN);
            });
            // List of duplicate contacts to merge (identifiers)
            break;
          case 'ready':
            // The list of duplicate contacts has been loaded
            formHeader.removeEventListener('action', cancelHandler);
            hideThrobber();
            if (Contacts.navigation.isCurrentView('view-contact-form')) {
              contacts.Form.goBack(true);
            }
            Contacts.setFocusToExtension();
            break;
          case 'window_close':
            // If user igonores duplicate contacts we save the contact
            window.removeEventListener('message', mergeHandler);
            doSave(contact, true);
            showSoftKeyPanel();
            window.focus();
            if ((details = data.data) && details.merged) {
              Toaster.showToast({
                message: navigator.mozL10n.get('tcl-success-merged', {
                  number: details.count
                }),
                latency: 2000,
              });
            }
            break;
          }
        };
        window.addEventListener('message', mergeHandler);
      },
      onmismatch: function () {
        // Saving because there aren't duplicate contacts
        doSave(contact);
        formHeader.removeEventListener('action', cancelHandler);
      }
    };
  };

  var hideFrames = function (frames) {
    var frame;
    if (Object.prototype.toString.call(frames) === '[object Array]') {
      frames.map((item) => hideFrames(item));
    } else {
      frame = document.getElementById('fb-' + frames);
      if (frame) {
        frame.className = '';
      }
    }
  };

  var setFocusTo = function (elId) {
    var el = Object.prototype.toString.call(elId) === '[object String]' ? document.getElementById(elId) : elId;
    if (el) {
      document.activeElement.blur();
      el.focus();
      if (document.activeElement !== el) {
        window.requestAnimationFrame(() => setFocusTo(el));
      }
    }
  };

  function getCompleteName(contact) {
    var givenName = Array.isArray(contact.givenName) ?
      contact.givenName[0] : '';

    var familyName = Array.isArray(contact.familyName) ?
      contact.familyName[0] : '';

    var completeName = givenName && familyName ?
      givenName + ' ' + familyName :
      givenName || familyName;
    return completeName;
  }

  // Fills the contact data to display if no givenName and familyName
  function getDisplayName(contact) {
    if (hasName(contact)) {
      return {
        givenName: contact.givenName,
        familyName: contact.familyName
      };
    }
    var givenName = [];
    if (Array.isArray(contact.name) && contact.name.length > 0) {
      givenName.push(contact.name[0]);
    } else if (contact.org && contact.org.length > 0) {
      givenName.push(contact.org[0]);
    } else if (contact.tel && contact.tel.length > 0) {
      givenName.push(contact.tel[0].value);
    } else if (contact.email && contact.email.length > 0) {
      givenName.push(contact.email[0].value);
    } else {
      givenName.push(_('noName'));
    }
    return {
      givenName: givenName,
      modified: true
    };
  }

  function hasName(contact) {
    return (Array.isArray(contact.givenName) && contact.givenName[0] &&
        contact.givenName[0].trim()) ||
      (Array.isArray(contact.familyName) && contact.familyName[0] &&
        contact.familyName[0].trim());
  }

  var doMerge = function doMerge(contact, list, cb) {
    var callbacks = {
      success: cb,
      error: function (e) {
        console.error('Failed merging duplicate contacts: ', e.name);
        cb();
      }
    };
    LazyLoader.load('/contacts/js/utilities/merge_helper.js', function () {
      MergeHelper.merge(contact, list).then(callbacks.success, callbacks.error);
    });
  };

  var doCancel = function doCancel() {
    formHeader.removeEventListener('action', cancelHandler);
    window.removeEventListener('message', mergeHandler);
    this.onmatch = this.onmismatch = null;
    window.postMessage({
      type: 'abort',
      data: ''
    }, fb.CONTACTS_APP_ORIGIN);
    hideThrobber();
  };

  var doMatch = function doMatch(contact, callbacks) {
    LazyLoader.load(['/shared/js/text_normalizer.js',
      '/shared/js/simple_phone_matcher.js',
      '/shared/js/contacts/contacts_matcher.js'
    ], function () {
      contacts.Matcher.match(contact, 'active', callbacks);
    });
  };

  var doSave = function doSave(contact, noTransition) {
    // Deleting auxiliary objects created for dates
    delete contact.date;
    // When we add new contact, it has no id at the beginning. We have one, if
    // we edit current contact. We will use this information below.
    var isNew = contact.id !== 'undefined';
    var request = navigator.mozContacts.save(utils.misc.toMozContact(contact));
    request.onsuccess = function onsuccess() {
      _needConfirm = false;
      hideThrobber();
      // Reloading contact, as it only allows to be updated once
      if (ActivityHandler.currentlyHandling) {
        navigation.evtprevent = true;
        ActivityHandler.postNewSuccess(contact);
        return;
      }
      if (!noTransition && !_inDialogue) {
        Contacts.cancel();
      }
      // Since editing current contact returns to the details view, and adding
      // the new one to the contacts list, we call setCurrent() only in the
      // first case, so NFC listeners are not set on the Contact List
      // (Bug 1041455).
      if (isNew) {
        Contacts.setCurrent(contact);
      }
      closeCb();
    };
    request.onerror = function onerror() {
      hideThrobber();
      console.error('Error saving contact', request.error.name);
      closeCb();
    };
  };

  var showThrobber = function showThrobber() {
    throbber.classList.remove('hide');
  };

  var hideThrobber = function hideThrobber() {
    throbber.classList.add('hide');
  };

  /**
   * Creates a complete name from the received contact's `givenName` and
   * `familyName` fields.
   *
   * @param {object} contact MozContactObject to process
   */
  var createName = function createName(contact) {
    var givenName = '',
      familyName = '';
    if (Array.isArray(contact.givenName)) {
      givenName = contact.givenName[0].trim();
    }
    if (Array.isArray(contact.familyName)) {
      familyName = contact.familyName[0].trim();
    }
    var completeName = (givenName + ' ' + familyName).trim();
    contact.name = completeName ? [completeName] : [];
  };

  var setPropagatedFlag = function setPropagatedFlag(field, value, contact) {
    if (!Array.isArray(contact[field]) || !contact[field][0] ||
      !contact[field][0].trim()) {
      // Here the user is deleting completely the field then we get the
      // original facebook field value
      fb.setPropagatedFlag(field, contact);
      contact[field] = fbContact[field];
    } else if (contact[field][0] !== value) {
      // The user is changing the value of the field then we have a local field.
      // It implies not propagation
      fb.removePropagatedFlag(field, contact);
    }
  };

  var getPhones = function getPhones(contact) {
    var phones = Array.prototype.slice.call(phonesArea.querySelectorAll(ITEMS_SELECTOR));
    (phones.length > 0) && phones.map((currentPhone) => {
      var numberField = currentPhone.querySelector('input[data-field="tel"]'),
        value = (numberField.value || '').trim(),
        typeEl = currentPhone.querySelector('.phone-type'),
        type = typeEl ? [typeEl.getAttribute('data-value')] : [''],
        carrier = '';
      if (!value) {
        return;
      }

      contact.tel = contact.tel || [];
      contact.tel.push({
        value, type, carrier
      });
    });
  };

  var getEmails = function getEmails(contact) {
    var emails = Array.prototype.slice.call(emailsArea.querySelectorAll(ITEMS_SELECTOR));
    (emails.length > 0) && emails.map((currentEmail) => {
      var emailField = currentEmail.querySelector('input[data-field="email"]'),
        value = (emailField.value || '').trim(),
        typeEl = currentEmail.querySelector('.email-type'),
        type = typeEl ? [typeEl.getAttribute('data-value')] : [''];
      if (!value) {
        return;
      }
      contact.email = contact.email || [];
      contact.email.push({
        value, type
      });
    });
  };

  var getDates = function getDate(contact) {
    var selector = '#contact-detail-date-area p';
    var dates = dom.querySelectorAll(selector);
    var bdayVal = null,
      anniversaryVal = null;

    for (var i = 0; i < dates.length; i++) {
      var currentDate = dates[i];

      if (dates[i].classList.contains(FB_CLASS)) {
        continue;
      }

      var dateField = currentDate.querySelector('input');
      var dateValue = dateField.valueAsDate;

      selector = '.date-type';
      var type = currentDate.querySelector(selector).dataset.value || '';
      if (!dateValue || !type) {
        continue;
      }

      // Date value is referred to current TZ but it is not needed to normalize
      // as that will be done only when the date is presented to the user
      // by calculating the corresponding offset
      switch (type) {
      case 'birthday':
        bdayVal = dateValue;
        break;
      case 'anniversary':
        anniversaryVal = dateValue;
        break;
      }
    }

    contact.bday = bdayVal;
    contact.anniversary = anniversaryVal;
  };

  var getAddresses = function getAddresses(contact) {
    var addresses = Array.prototype.slice.call(addressesArea.querySelectorAll('.contact-detail-address'));
    (addresses.length > 0) && addresses.map((currentAddress) => {
      var addressField = currentAddress.querySelector('input[data-field="street"]'),
        addressValue = (addressField.value || '').trim(),
        typeEl = currentAddress.querySelector('.address-type'),
        typeField = (typeEl ? typeEl.getAttribute('data-value') : '').trim(),
        locality = (currentAddress.querySelector('input[data-field="locality"]').value || '').trim(),
        postalCode = (currentAddress.querySelector('input[data-field="postal"]').value || '').trim(),
        countryName = (currentAddress.querySelector('input[data-field="country"]').value || '').trim();
      // Sanity check for pameters, check all params but the typeField
      if (addressValue === '' && locality === '' &&
        postalCode === '' && countryName === '') {
        return;
      }
      contact.adr = contact.adr || [];
      contact.adr.push({
        streetAddress: addressValue,
        postalCode: postalCode,
        locality: locality,
        countryName: countryName,
        type: [typeField]
      });
    });
  };

  var getNotes = function getNotes(contact) {
    var notes = Array.prototype.slice.call(notesArea.querySelectorAll(ITEMS_SELECTOR));
    (notes.length > 0) && notes.map((currentNote) => {
      var noteValue = (currentNote.querySelector('input[data-field="comment"]').value || '').trim();
      if (!noteValue) {
        return;
      }
      contact.note = contact.note || [];
      contact.note.push(noteValue);
    });
  };

  var getRingtones = function getRingtones(contact) {
    var el = ringtoneDetail.querySelector('.ringtone-type');

    if (el && el.dataset.key) {
      contact.ringtone = el.dataset.key;
    }
  };

  var getPhoto = function cf_getPhoto(contact) {
    if (!currentPhoto) {
      return;
    }
    contact.photo = [currentPhoto];
  };

  var resetForm = function resetForm() {
    try {
      _needConfirm = true;
      _inDialogue = false;
      _isActivityMode = false; //default we set that is not activity
      deletedTelNumber = false;

      resetRemoved();
      currentContactId.value = '';
      currentContact = {};
      currentPhoto = null;
      setInputValue([{
        el: givenName,
        val: ''
      }, {
        el: familyName,
        val: ''
      }, {
        el: company,
        val: ''
      }]); //clear input values also old-values
      removePhones();
      removeEmails();
      removeAddresses();
      removeDates();
      removeComments();
      hideRingtone();
      photoAreaHide();
    } catch (err) {
      console.log(err);
    }

    counters = {
      'tel': 0,
      'email': 0,
      'adr': 0,
      'date': 0,
      'note': 0
    };
    textFieldsCache.clear();

    formView.scrollTop = 0;
  };

  var removePhones = function cf_removePhones() {
    var phones = Array.prototype.slice.call(phonesArea.querySelectorAll(ITEMS_SELECTOR)),
      first = false,
      doEmptyPhone = function (phoneNode) {
        var phoneType = phoneNode.querySelector('.phone-type');
        phoneType.setAttribute('data-l10n-id', 'mobile');
        phoneType.setAttribute('data-value', 'mobile');
        setInputValue({
          el: phoneNode.querySelector('input[data-field="tel"]'),
          val: ''
        });
      };
    (phones.length > 0) && phones.map((currentPhone) => {
      if (!first) {
        first = true;
        doEmptyPhone(currentPhone);
      } else {
        phonesArea.removeChild(currentPhone);
      }
    });
  };

  var removeEmails = function cf_removeEmails() {
    var emails = Array.prototype.slice.call(emailsArea.querySelectorAll(ITEMS_SELECTOR)),
      first = false,
      doEmptyEmail = function (phoneNode) {
        var phoneType = phoneNode.querySelector('.email-type');
        phoneType.setAttribute('data-l10n-id', 'personal');
        phoneType.setAttribute('data-value', 'personal');
        setInputValue({
          el: phoneNode.querySelector('input[data-field="email"]'),
          val: ''
        });
      };
    (emails.length > 0) && emails.map((currentPhone) => {
      if (!first) {
        first = true;
        doEmptyEmail(currentPhone);
      } else {
        emailsArea.removeChild(currentPhone);
      }
    });
  };

  var removeAddresses = function cf_removeAddresses() {
    addressesArea.innerHTML = '';
  };

  var removeDates = function cf_removeDates() {
    datesArea.innerHTML = '';
  };

  var removeComments = function cf_removeComments() {
    notesArea.innerHTML = '';
  };

  var hideRingtone = function cf_removeRingtone() {
    ringtoneDetail.querySelector('.input-container').classList.add('hide');
    ringtoneDetail.querySelector('.ringtone-type')
        .setAttribute('data-value', '');
    ringtoneDetail.querySelector('.ringtone-type')
        .setAttribute('data-key', '');
    ringtoneButton.hidden = false;
  };

  var showRingtone = function cf_hideRingtoneButton() {
    ringtoneDetail.querySelector('.input-container').classList.remove('hide');
    ringtoneButton.hidden = true;
  };

  var changeSaveBtnState = function (state, init) {
    if (Contacts.navigation.isWidgetShown(function () { //after hide mnu we hide save btn
      changeSaveBtnState(state, init);
    })) {
      return;
    }
    if (state === 'enabled') {
      (formShow === true) && !init;
    } else {
      if (formShow === false && !init &&
        window.location.search !='?new') {
        return;
      }
    }
    var focusEl = NavigationManager.getFocusedEl();
    checkCurOptionName(focusEl.dataset.optionName);
  };

  var changeAddDateState = function () {
    var addDateInputs = document.querySelectorAll('[data-option-name ^= date-type-options]:not(.hide)');
    if (addDateInputs.length > 1) {
      disableAddDate();
    } else {
      enableAddDate();
    }
  };

  var disableAddDate = function () {
    var dateInputs = document.querySelectorAll('[data-option-name="date-type-options"]'),
      addButton = document.querySelector('[data-option-name="add-date-button"]');
    for (var i = 0; i < dateInputs.length; i++) { //very stpd not optimized loop on dom
      dateInputs[i].setAttribute('data-option-name', 'date-type-options-add-off');
    }
    if (addButton) {
      addButton.setAttribute('hidden', true);
    }
  };

  var enableAddDate = function () {
    var dateInputs = document.querySelectorAll('[data-option-name="date-type-options-add-off"]'),
      addButton = document.querySelector('[data-option-name="add-date-button"]');
    for (var i = 0; i < dateInputs.length; i++) {
      dateInputs[i].setAttribute('data-option-name', 'date-type-options');
    }
    if (addButton) {
      addButton.removeAttribute('hidden');
    }
  };

  var resetRemoved = function cf_resetRemoved() {
    var removedFields = dom.querySelectorAll('.facebook');
    for (var i = 0; i < removedFields.length; i++) {
      removedFields[i].classList.remove(FB_CLASS);
    }
  };

  var checkDisableButton = function checkDisableButton() {
    if (emptyForm()) {
      changeSaveBtnState('disabled');
    } else {
      changeSaveBtnState('enabled');
    }
  };

  var emptyForm = function emptyForm() {
    var textFields = textFieldsCache.get();
    return !textFields.some(function (item) {
      return item.value && item.value.trim();
    });
  };

  function photoAction() {
    pickImage();
  }

  var photoAreaShow = function () {
    photoInsertArea.querySelector('p').classList.remove('hide');
    photoAddBtn.classList.add('hide');
  };

  var photoAreaHide = function (resetNavigation) {
    var doRemove = function() {
      var photoNavEl = photoInsertArea.querySelector('p');
      photoNavEl.classList.add('hide');
      photoAddBtn.classList.remove('hide');
      photoNavEl.innerHTML = '';
      resetNavigation && window.NavigationManager.reset(ITEMS_SELECTOR, null);
      currentPhoto = null;
    };
    if (resetNavigation) {
      showDeleteConfirmDialog(doRemove,'deleting-messages-picture','remove');
    } else {
      doRemove();
    }
  };

  var renderPhotoFromBlob = function cf_renderPhoto(blob, newBlob) {
    if (!blob || !blob.type || !blob.size) {
      return;
    }
    photoAreaHide();
    var photoField = document.createElement('img');
    photoField.style.backgroundImage =
        'url(' + URL.createObjectURL(blob) + ')';
    photoInsertArea.querySelector('p').appendChild(photoField);
    photoAreaShow();
    currentPhoto = blob;
    window.NavigationManager.reset(ITEMS_SELECTOR, null);
    contactForm.scrollTop = 0;
    hideThrobber();
    newBlob && changeSaveBtnState('enabled');
  };

  var pickImage = function cf_pickImage() {
    var activity = new MozActivity({
      name: 'pick',
      data: {
        type: 'image/jpeg',
        maxFileSizeBytes: MAX_PHOTO_SIZE
      }
    });
    activity.onsuccess = function success() {
      showThrobber();
      resizeBlob(this.result.blob, PHOTO_WIDTH, PHOTO_HEIGHT,
        function (resized) {
          renderPhotoFromBlob(resized, true);
          currentPhoto = resized;
        }
      );
    };
    activity.onerror = function () {
      window.console.log('Error in the activity', activity.error);
      //if user set cancel this will be activity.error.name = ActivityCanceled and it can be handled by UI spec ))
    };
    return false;
  };

  function resizeBlob(blob, target_width, target_height, callback) {
    var img = document.createElement('img');
    var url = URL.createObjectURL(blob);
    img.src = url;

    function cleanupImg() {
      img.src = '';
      URL.revokeObjectURL(url);
    }

    img.onerror = cleanupImg;

    img.onload = function () {
      var image_width = img.width;
      var image_height = img.height;
      var scalex = image_width / target_width;
      var scaley = image_height / target_height;
      var scale = Math.min(scalex, scaley);

      var w = target_width * scale;
      var h = target_height * scale;
      var x = (image_width - w) / 2;
      var y = (image_height - h) / 2;

      var canvas = document.createElement('canvas');
      canvas.width = target_width;
      canvas.height = target_height;
      var context = canvas.getContext('2d', {
        willReadFrequently: true
      });

      context.drawImage(img, x, y, w, h, 0, 0, target_width, target_height);
      cleanupImg();
      canvas.toBlob(function (resized) {
        context = null;
        canvas.width = canvas.height = 0;
        canvas = null;
        callback(resized);
      }, 'image/jpeg');
    };
  }

  var doAccepted = function cf_doAccepted(e) {
    var el = e.detail.acceptedEl,
      actionEl,
      action;
    if (Contacts.navigation.currentView() === 'view-contact-form' &&
        el.classList.contains('contacts-detail-action-item')) {
      actionEl = el.children[0];
      if (actionEl && (action = actionEl.getAttribute('data-action-name'))) {
        if (action in availableActions) {
          availableActions[action](e);
        }
      }
    }
  };

  var addCommentField = function () {
    var clone = document.importNode(notesTemplate.content, true);
    notesArea.appendChild(clone);
    var currentSelector = Contacts.navigation.getNavigationSelector('view-contact-form');
    NavigationManager.update(currentSelector);
    NavigationManager.switchContext(currentSelector, notesArea.lastElementChild.dataset.navId);
    NavigationManager.getFocusedEl().scrollIntoView();
  };

  var deleteField = (focusedElement) => {
    var callback = () => {
      var prevId = getPreviousItem(focusedElement);
      focusedElement.remove();
      if (isDateField(focusedElement)) {
        changeAddDateState();
      }
      focusItem(prevId);
      textFieldsCache.clear();
    };
    if (isCommentField(focusedElement)) {
      deleteConfirm(callback);
    } else {
      callback();
    }
  };

  var deleteConfirm = (callback) => {
    var deleteDialogConfig = {
      title: {id: 'confirm-dialog-title-default', args: {}},
      body: {id: 'delete-comment-warning', args: {}},
      backcallback: function() {},
      cancel: {
        l10nId: 'cancel',
        callback: function() {}
      },
      confirm: {
        l10nId: 'delete',
        callback: function() {
          callback();
        }
      }
    };
    var dialog = new ConfirmDialogHelper(deleteDialogConfig);
    dialog.show(document.getElementById('app-dialog'));
  };

  function getPreviousItem(focusedElement) {
    var prevId = focusedElement.style.getPropertyValue('--nav-down');
    if (!prevId) {
      prevId = focusedElement.lastElementChild.style.getPropertyValue('--nav-down');
    }

    return prevId;
  }

  function focusItem(id) {
    if (!id) {
      return;
    }
    var inputContainer = document.querySelector('.input-container[data-nav-id="' + id + '"]'),
        inputElem;

    NavigationManager.switchContext(ITEMS_SELECTOR, id);
    inputElem = inputContainer.querySelector('input:not([type="date"])');
    if (inputElem) {
      inputElem.focus();
    }
  }

  var doAddPhoto = function cf_doAddPhoto() {
    addPhotoBtn.click();
  };

  var isNewContact = function cf_isNewContact() {
    return mode == 'add';
  };

  var deleteRingtone = function cf_deleteRingtone() {
    showDeleteConfirmDialog(() => {
      var ringtone = ringtoneDetail.querySelector('span.ringtone-type'),
      prevId = getPreviousItem(ringtoneDetail);
      if (ringtone) {
        ringtone.dataset.key = ringtone.dataset.value = '';
        hideRingtone();
        focusItem(prevId);
        toastNotification('tcl-deleting-notification-ringtone');
      }
    }, 'deleting-messages-ringtone', 'delete');
  };

  function showDeleteConfirmDialog(deleteCallback, bodyL10nId, rskL10nId) {
    var dialogConfig = {
      title: {id: 'confirm-dialog-title-default', args: {}},
      body: {id: bodyL10nId, args: {}},
      backcallback: function() {},
      cancel: {
        l10nId: 'cancel',
        callback: function() {}
      },
      confirm: {
        l10nId: rskL10nId,
        callback: function () {
          deleteCallback && deleteCallback();
        }
      }
    };
    var dialog = new ConfirmDialogHelper(dialogConfig);
    dialog.show(document.getElementById('app-dialog'));
  }

  function valueEquals(value1, value2) {
    return (value1 instanceof Object) ? objectEquals(value1, value2)
                                      : (value1 === value2);
  }

  function objectEquals(object1, object2) {
    if (ActivityHandler &&
        ['update','new'].indexOf(ActivityHandler.activityName) > -1) {
      return false;
    }
    if (!(object1 instanceof Object) || !(object2 instanceof Object) ||
        Object.keys(object1).length !== Object.keys(object2).length) {
      return false;
    }

    for (var propName in object1) {
      var propValue1 = object1[propName];
      var propValue2 = object2[propName];
      if (propValue1 instanceof Array) {
        if (propValue1.length !== propValue2.length) {
          return false;
        }
        for (var i in propValue1) {
          if (!valueEquals(propValue1[i], propValue2[i])) {
            return false;
          }
        }
      } else {
        if (!valueEquals(propValue1, propValue2)) {
          return false;
        }
      }
    }
    return true;
  }

  function toastNotification(l10nId) {
    Toaster.showToast({
      messageL10nId: l10nId,
      latency: 2000,
    });
  }

  function isCommentField(element) {
    if (element.querySelector('[data-l10n-id="note"]')) {
      return true;
    }
    return false;
  }

  function isDateField(element) {
    if (element.querySelector('input[type="date"]')) {
      return true;
    }
    return false;
  }

  var checkFieldsExist = function (fields) {
    if (Object.prototype.toString.call(fields) === '[object Array]') {
      fields.map(checkFieldsExist);
    } else {
      + function () {
        var area = fields == 'phone' ? phonesArea :
          fields == 'email' ? emailsArea : false; //if you wanna check your set here condition
        if (area && !area.querySelector(ITEMS_SELECTOR)) {
          area.appendChild(document.importNode(dom.getElementById('add-' + fields + '-template').content, true));
        }
      }();
    }
  };

  return {
    'init': init,
    'render': render,
    'insertField': insertField,
    'saveContact': saveContact,
    'onNewFieldClicked': onNewFieldClicked,
    'addCommentField': addCommentField,
    'deleteField': deleteField,
    'updateLabels': prpareFormLabels,
    'changeAddDateState': changeAddDateState,
    'doBeforeExit': beforeExit,
    'isDataChanged': isDataChanged,
    'addPhoto': doAddPhoto,
    'clearTextFieldCache': textFieldsCache.clear.bind(textFieldsCache),
    'checkDisableButton': checkDisableButton,
    'isNewContact': isNewContact,
    'removePhoto': photoAreaHide,
    'deleteRingtone': deleteRingtone,
    'doClose': doClose,
    'hideRingtone': hideRingtone,
    'showRingtone': showRingtone,
    'goBack': goBack,
    get navigationSelector() {
      return ITEMS_SELECTOR;
    },
  };
})();
