/* global Contacts */
/* global ICEData */
/* global TabNavigation */
/* global navigation, NavigationManager, Toaster, ContactsTag, OptionHelper*/

/**
 * ICE Settings view. In charge of selecting
 * the contacts for emergency and keeping sync
 * the datastore to share those contacts with
 * dialer and lockscreen.
 */

'use strict';

var contacts = window.contacts || {};

contacts.ICE = (function() {
  var iceSelectContactButtons,
    iceContactSwitchButtons,
    iceContactItems = [],
    iceContactCheckboxes = [],
    iceContactButtons = [],
    iceScreenInitialized = false,
    currentICETarget,
    navigationSelector = '#ice-settings ul > li:not(.hide)';

  /**
   * Redraws the ICE contact list. This is not an expensive
   * operation since we have a maximun of 2 contacts.
   * The first time executed will attach listeners for the
   * frame ui.
   */
  var init = function ice_init() {
    if (iceScreenInitialized) {
      return;
    }
    // ICE DOM elements
    iceSelectContactButtons = document.querySelector('#ice-settings ul li:not(.ice-contacts-switch)');
    iceContactSwitchButtons = document.querySelectorAll('#ice-settings ul li.ice-contacts-switch');

    iceContactItems.push(document.getElementById('ice-contacts-1-switch'));
    iceContactItems.push(document.getElementById('ice-contacts-2-switch'));
    iceContactCheckboxes.push(iceContactItems[0]
                          .querySelector('[name="ice-contact-1-enabled"]'));
    iceContactCheckboxes.push(iceContactItems[1]
                          .querySelector('[name="ice-contact-2-enabled"]'));
    iceContactButtons.push(document.getElementById('select-ice-contact-1'));
    iceContactButtons.push(document.getElementById('select-ice-contact-2'));

    iceContactButtons[0].dataset.contactId = '';
    iceContactButtons[1].dataset.contactId = '';
    iceScreenInitialized = true;
  };

  function reloadButtonsState(cb) {
    ICEData.load().then(retrieveContactData.bind(null, cb));
  }

  function retrieveContactData(cb) {
    var iceContactsData = [];
    var iceContactsIds = ICEData.iceContacts;
    var numRetrievedContacts = 0;

    iceContactsIds.forEach(function(iceContact, index) {
      contacts.List.getContactById(iceContact.id, function(cindex, contact) {
        var theContact = {
          active: iceContactsIds[cindex].active,
          mozContact: contact,
          number: iceContactsIds[cindex].number
        };

        iceContactsData[cindex] = theContact;

        numRetrievedContacts++;

        if (numRetrievedContacts === 2) {
          setButtonsState(iceContactsData, cb);
        }
      }.bind(null, index));
    });
  }

  function refresh(done) {
    if (!iceScreenInitialized) {
      init();
    }
    reloadButtonsState(done);
  }

  /**
   * Given an object representing the internal state
   * fills the UI elements.
   * @params iceContactsIds (Array) list of contacts and state
   */
  function setButtonsState(iceContactsData, done) {
    iceContactsData.forEach(setIceButtonState);

    typeof done === 'function' && done();
  }

  function setIceButtonState(iceContactData, index) {
    if (!iceContactData) {
      return;
    }

    if (iceContactData.mozContact) {
      var iceContact = iceContactData.mozContact;

      var givenName = (Array.isArray(iceContact.givenName) &&
                       iceContact.givenName[0]) || '';
      var familyName = (Array.isArray(iceContact.familyName) &&
                        iceContact.familyName[0]) || '';

      var display = [givenName, familyName];
      var iceLabel = display.join(' ').trim();
      // If contact has no name we the first tel number will be used
      if (!iceLabel) {
        if (Array.isArray(iceContact.tel) && iceContact.tel[0]) {
          iceLabel = iceContact.tel[0].value.trim();
        }
      }
      iceContactData.number = !!iceContactData.number ?
          iceContactData.number : '';
      buildIceContactUI(index, iceContactData.number, iceLabel, iceContact.id,
                        iceContactData.active);
    }
    else {
        resetIceGroupState(index);
    }
  }

  function buildIceContactUI(index, number, label, contactId, active) {
    var switcherStatus = iceContactSwitchButtons[index].querySelector('.ice-contact-status');
    if (!active) {
      switcherStatus.setAttribute('data-l10n-id', 'off');
      iceContactSwitchButtons[index].dataset.value = 'off';
      iceContactButtons[index].parentNode.dataset.optionName =
          'select-ice-contact';
    } else {
      switcherStatus.setAttribute('data-l10n-id', 'on');
      iceContactSwitchButtons[index].dataset.value = 'on';
      iceContactButtons[index].parentNode.dataset.optionName =
          'remove-ice-contact';
      navigation.pushOptionMenu('remove-ice-contact', navigation.currentView());
    }
    NavigationManager.update(NavigationManager.currentSelector);

    var bdi = document.createElement('bdi');
    bdi.classList.add('ice-contact');
    bdi.classList.add('p-pri');
    bdi.textContent = label;
    var bdiNumber = document.createElement('bdi');
    bdiNumber.classList.add('ice-number');
    bdiNumber.classList.add('p-sec');
    bdiNumber.textContent = number;
    iceContactButtons[index].innerHTML = '';
    iceContactButtons[index].appendChild(bdi);
    iceContactButtons[index].appendChild(bdiNumber);
    iceContactButtons[index].dataset.contactId = contactId;
    iceContactButtons[index].classList.remove('not-set');
  }

  function resetIceGroupState(index) {
    iceContactButtons[index].parentNode.dataset.optionName =
        'select-ice-contact';
    NavigationManager.switchContext(navigation.getNavigationSelector('ice-settings'));
    NavigationManager.update(NavigationManager.currentSelector);
    iceContactButtons[index].innerHTML = '';
    iceContactButtons[index].dataset.contactId = '';
    iceContactButtons[index].classList.add('not-set');
    var switherStatus = iceContactSwitchButtons[index].querySelector('.ice-contact-status');
    switherStatus.setAttribute('data-l10n-id', 'off');
    iceContactButtons[index].setAttribute('data-l10n-id', 'ICESelectContact');
  }

  function resetIceGroupStates() {
    for(var j = 0; j < iceContactCheckboxes.lenght; j++) {
      resetIceGroupState(j);
    }
  }

  function goBack() {
    contacts.List.clearClickHandlers();
    contacts.List.handleClick(Contacts.showContactDetail);
    Contacts.setNormalHeader();

    var hasICESet = contacts.List.isICEContactsExist();

    if (!hasICESet) {
      resetIceGroupStates();
    }

    contacts.Settings.navigation.back(() => {
      hasICESet && contacts.List.toggleICEGroup(true);
    });
  }

  /**
   * Given a contact id, saves it internally. Also restores the contact
   * list default handler.
   * In case of not valid contact it will display a message on the screen
   * indicating the cause of the error.
   * @param id (string) contact id
   */
  function selectICEHandler(number, id) {
    checkContact(id).then(function() {
      setICEContact(id, number, currentICETarget, true, function(){
        goBack();
        Toaster.showToast({
          messageL10nId: 'tcl-ice-contact-' + (currentICETarget + 1) + '-added',
          latency: 2000,
        });
      });
    }, function error(l10nId) {
      Toaster.showToast({
        messageL10nId: l10nId || 'ICEUnknownError',
        latency: 2000,
      });
    });
  }

  /**
   * Will perform a series of checks to validate the selected
   * contact as a valid ICE contact
   * @param id (string) contact id
   * @return (Promise) fulfilled if contact is valid
   */
  function checkContact(id) {
    return ICEData.load().then(function() {
      return contactNotICE(id).then(contactNotAllowed);
    });
  }

  /**
   * Checks if a contacts is already set as ICE
   * @param id (string) contact id
   * @return (Promise) fulfilled if contact is not repeated,
   *  rejected otherwise
   */
  function contactNotICE(id) {
    return new Promise(function(resolve, reject) {
      var isICE = ICEData.iceContacts.some(function(x) {
        return x.id === id;
      });

      if (isICE) {
        reject('ICERepeatedContact');
      } else {
        resolve(id);
      }
    });
  }

  /**
   * Filter to avoid selecting contacts as ICE if they don't have a phone number
   * or they are a Facebook contact
   * @param id (String) contact id
   * @returns (Promise) Fulfilled if contact has phone
   */
  function contactNotAllowed(id) {
    return new Promise(function(resolve, reject) {
      contacts.List.getContactById(id, function(contact, isFBContact) {
        if(Array.isArray(contact.tel) && contact.tel[0] &&
         contact.tel[0].value && contact.tel[0].value.trim()) {
          resolve(id);
        }
        else if (isFBContact) {
          reject('ICEFacebookContactNotAllowed');
        } else {
          reject('ICEContactNoNumber');
        }
      });
    });
  }

  /**
   * We are using the contact list to choose a contact as ICE. For doing
   * this, we need to setup our own click handler.
   * @para target (HTMLButton) Button click to select an ICE contact
   */
  function showSelectList(target) {
    Contacts.selectionMode = true;
    Contacts.appTitleElement.dataset.l10nId = 'select-a-contact-title';
    TabNavigation.hideTab('speed-dial');
    contacts.List.toggleICEGroup(false);
    Contacts.hideTabNavigation();
    // Contacts.setCancelableHeader(goBack, 'selectContact');
    contacts.Settings.navigation.go('view-contacts-list', 'right-left');
    currentICETarget = target === 'select-ice-contact-1' ? 0 : 1;
    // contacts.List.clearClickHandlers();
    // contacts.List.handleClick(selectICEHandler);
    Contacts.navigation.pushOptionMenu('save-ice-contact', 'view-contacts-list');
  }

  /**
   * Set the values for ICE contacts, both in local and in the
   * datastore
   * @param id (string) contact id
   * @param pos (int) current position (0,1)
   * @param active (boolean) ice contact is active or not
   * @param cb (function) callback when ready
   */
  function setICEContact(id, number, pos, active, cb) {
    ICEData.setICEContact(id, number, pos, active).then(function() {
      // Only reload contact info in case there is a change in the contact
      if (id === iceContactButtons[pos].dataset.contactId) {
        return;
      }

      contacts.List.getContactById(id, function(contact) {
        var theContact = {
          active: active,
          mozContact: contact,
          number: number
        };
        var iceContactData = [];
        if (pos === 0) {
          iceContactData[1] = null;
        }
        else {
          iceContactData[0] = null;
        }
        iceContactData[pos] = theContact;

        setButtonsState(iceContactData);

        typeof cb === 'function' && cb();
      });
    });
  }

  function reset() {
    iceScreenInitialized = false;
    iceContactItems = [];
    iceContactCheckboxes = [];
    iceContactButtons = [];
    currentICETarget = null;
  }

  function setChosenTag(element){
    if (element.getAttribute('data-l10n-id') === 'on'){
      ContactsTag.selectTag(document.querySelector('input[data-value="on"]'));
    } else {
      ContactsTag.selectTag(document.querySelector('input[data-value="off"]'));
    }
  } 

  function changeSwitchStatus(index, status){
    var wasActive;
    var localIceContacts = ICEData.iceContacts;

    if (status === 'on') {
      wasActive = false;
    } else if (status === 'off'){
      wasActive = true;
    } else {
      console.error('wrong status');
      return;
    }

    if (wasActive) {
      resetIceGroupState(index);
      if (localIceContacts[index] && localIceContacts[index].id) {
        setICEContact(null, 0, index, !wasActive);
        if (!contacts.List.isICEContactsExist()) {
          contacts.List.toggleICEGroup(false);
        }
      }
    } else {
      iceContactButtons[index].parentNode.dataset.optionName =
          'remove-ice-contact';
      NavigationManager.update(NavigationManager.currentSelector);
    }
  }

  function iceSettingsHandler() {
    var target = NavigationManager.getFocusedEl();
    if (!target) {
      return;
    }
    var action = target.getAttribute('action');
    if (action === 'selectContact') {
      showSelectList(target.children[0].id);
    } else if (action === 'switchSelectContact') {
      Contacts.goToSelectTag(target);
      var switchL10nId = target.querySelector('.switch-title').getAttribute('data-l10n-id');
      document.getElementById('dialog-title').setAttribute('data-l10n-id', switchL10nId);
      setTimeout( function() {
        setChosenTag(target.querySelector('.ice-contact-status'));
      }, 0);
      OptionHelper.show('contact-ordering-settings');
    }
  }

  return {
    init: init,
    refresh: refresh,
    reset: reset,
    iceSettingsHandler: iceSettingsHandler,
    changeSwitchStatus: changeSwitchStatus,
    selectICEHandler: selectICEHandler,
    get initialized() { return iceScreenInitialized; },
    get navigationSelector() { return navigationSelector; },
    showSelectList: showSelectList
  };
})();
