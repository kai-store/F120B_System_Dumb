'use strict';
/* global Contacts, utils, Toaster */

var contacts = window.contacts || {};

contacts.VoiceMail = (function () {

  const VIEW = 'view-voice-mail';
  const VIEW_ID = '#' + VIEW;
  const NAV_SELECTOR = VIEW_ID + ' .input-container';

  var voiceMailInput;
  var oldValue;

  var init = function init(callback) {
    voiceMailInput = document.getElementById('voice-mail-input');

    document.addEventListener('focusChanged', function (e) {
      if (Contacts.navigation.isCurrentView(VIEW)) {
        var focused = e.detail.focusedElement,
            input;

        if (focused && (input = focused.querySelector('input'))) {
          console.log('Voice mail focus');
          input.focus();
        }
      }
    });

    callback();
  };

  var show = function show(callback) {
    var promise = utils.VoiceMail.getVoiceMail();
    promise.then(
      function (number) {
        setVoiceMailInput(number);
      },
      function (reason) {
        setVoiceMailInput();
      }
    ).then(function() {
      goToVoiceMail();
    });
  };

  function setVoiceMailInput(phone) {
    oldValue = (phone && phone.trim()) || '';
    voiceMailInput && (voiceMailInput.value = oldValue);
  }

  function getVoiceMailInput() {
    return voiceMailInput.value.trim();
  }

  var goToVoiceMail = function goToVoiceMail() {
    Contacts.navigation.go(VIEW, 'fade-in');
  };

  var doCancel = function doCancel() {
    Contacts.navigation.back();
  };

  var doSave = function doSave() {
    var newValue = getVoiceMailInput();

    if (newValue !== oldValue) {
      utils.VoiceMail.setVoiceMail(newValue).then(function() {
        postSave(true);
      }, function() {
        postSave(false);
      });
    } else {
      Contacts.navigation.back();
    }
  };

  function postSave(isUpdated) {
    if (isUpdated) {
      showNotification('tcl-notification-voice-mail-updated');
    }
    Contacts.navigation.back();
  }

  function showNotification(messageL10nId) {
    Toaster.showToast({
      messageL10nId: messageL10nId,
      latency: 2000,
    });
  }

  return {
    'init': init,
    'show': show,
    'goToVoiceMail': goToVoiceMail,
    'doCancel': doCancel,
    'doSave': doSave,
    get navigationSelector() {
      return NAV_SELECTOR;
    }
  };
})();
