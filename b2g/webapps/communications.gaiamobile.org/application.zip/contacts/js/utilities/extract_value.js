'use strict';

var utils = window.utils || {};


utils.extractValue = function extractValue(value) {
  if (value) {
    if (Array.isArray(value) && value.length > 0 && value[0]) {
      if (Object.prototype.toString(value[0]) === '[object Object]' && value[0].value) {
        return value[0].value.trim();
      }
      return value[0].trim();
    } else if (!Array.isArray(value)) {
        return value.trim();
    }
  }

  return '';
// The last statement allows to return the value in case we are getting
// just params from an activity and not a mozContact.
};
