'use strict';

(function() {
  var utils = window.utils = window.utils || {};

  var FileWrapper = function (file) {
    var innerFile = file;

    var re = /^.+\/(.+\.(.+))$/;

    return {
      getFile: function() { return innerFile; },
      getFilename: function() {
        var m = re.exec(innerFile.name);
        return m && m[1];
      },
      getExtension: function() {
        var m = re.exec(innerFile.name);
        return m && m[2];
      },
      getFullname: function() {
        return innerFile.name;
      },
      getLastModified: function() {
        return innerFile.lastModified;
      },
    };

  };

  utils.RingtoneHelper = (function() {

    const DEBUG = false;

    var storageName = 'sdcard';
    var storages = navigator.getDeviceStorages(storageName);

    logStorages(storages);

    var mimeTypes = {
      'ringtone': ['mp3', 'mp4', 'm4a', 'wav', 'ogg', 'webm'],
    };

    var getPlayer = function getPlayer() {
      if (ringtonePlayer) {
        return ringtonePlayer;
      }

      ringtonePlayer = new Audio();
      ringtonePlayer.mozAudioChannelType = 'normal';
      ringtonePlayer.preload = 'metadata';
      ringtonePlayer.loop = true;

      return ringtonePlayer;
    };

    var ringtones = Object.create(null);
    var ringtonePlayer = getPlayer();
    var currentRingtone = '';

    var play = function play(filePath) {
      if ((!filePath || currentRingtone === filePath) && ringtonePlayer.paused) {
        ringtonePlayer.play();

        return;
      }

      if (!ringtones[filePath]) {
        return;
      }

      ringtonePlayer.pause();

      var blob = ringtones[filePath].getFile();
      ringtonePlayer.src = URL.createObjectURL(blob);
      ringtonePlayer.play();

      currentRingtone = filePath;
    };

    var stop = function stop() {
      if (!ringtonePlayer.paused && ringtonePlayer.currentTime > 0) {
        ringtonePlayer.currentTime = 0;
        ringtonePlayer.pause();
      }
    };

    var scan = function scan(mimeTypes, path, options) {
      var newFile, ext,
          cursor,
          files = [],
          hash = Object.create(null),
          lastModified = 0,
          scanners = [];

      path = path || '';
      options = options || {};

      storages.forEach(function (storage) {
        scanners.push(new Promise(function (resolve, reject) {
          cursor = storage.enumerate(path, options);

          cursor.onsuccess = function onsuccess() {
            if (this.result) {
              newFile = FileWrapper(this.result);

              if (!hash[newFile.getFullname()]) {
                ext = newFile.getExtension();

                if (ext && mimeTypes.indexOf(ext) >= 0) {
                  hash[newFile.getFullname()] = newFile;
                  files.push(newFile);

                  if (newFile.getLastModified() > lastModified) {
                    lastModified = newFile.getLastModified();
                  }
                }
              }

              this.continue();
            } else {
              ringtones = hash;
              resolve();
            }
          };

          cursor.onerror = function onerror(err) {
            reject(err);
          };
        }));
      });

      return new Promise(function (resolve, reject) {
        Promise.all(scanners)
          .then(function() {
            resolve(files);
          })
          .catch(function (ex) {
            console.warn(ex);
          });
      });
    };

    var getRingtones = function getRingtones(path) {
      path = path || '';
      /* jshint -W069 */
      return scan(mimeTypes['ringtone'], path);
      /* jshint +W069 */
    };

    function logStorages(storages) {
      if (!DEBUG) {
        return;
      }

      var len = storages.length;

      console.log('Ringtone Helper: ' + len + ' storages is found');
      for (var i = 0; i < len; i++) {
        console.log(storages[i].storageName);
      }
    }

    return {
      'scan': scan,
      'getRingtones': getRingtones,
      'getPlayer': getPlayer,
      'play': play,
      'stop': stop,
    };

  }());

}());
