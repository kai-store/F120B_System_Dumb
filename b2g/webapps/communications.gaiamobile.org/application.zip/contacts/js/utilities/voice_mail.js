'use strict';

(function() {
  var utils = window.utils = window.utils || {};

  const RIL_SETTINGS = 'ril.iccInfo.mbdn';

  var settings = navigator.mozSettings,
      numbers;

  function getRilSettings() {
    if (!settings) {
      return;
    }

    return settings.createLock().get(RIL_SETTINGS);
  }

  utils.VoiceMail = {
    // returns Promise
    getVoiceMail: function getVoiceMail() {
      var promise = Promise.resolve();
      promise = utils.VoiceMail.getVoiceMailForCard(0);

      return promise;
    },

    // returns Promise
    setVoiceMail: function setVoiceMail(number) {
      return utils.VoiceMail.setVoiceMailForCard(0, number);
    },

    getVoiceMailForCard: function getVoiceMailForCard(cardIndex) {
      return new Promise(function (resolve, reject) {
        if (numbers && numbers[cardIndex]) {
          resolve(numbers[cardIndex]);
          return;
        }

        var request = getRilSettings();

        request.onsuccess = function() {
          numbers = request.result[RIL_SETTINGS] || [];
          var number;
          if (typeof numbers == 'string') {
            number = numbers;
            numbers = [];
            numbers[cardIndex] = number;
          } else {
            number = numbers && numbers[cardIndex];
          }
          var voicemail = navigator.mozVoicemail;
          if (!number && voicemail) {
            number = voicemail.getNumber(cardIndex);

            utils.VoiceMail.setVoiceMailForCard(cardIndex, number);
          }

          resolve(number);
        };

        request.onerror = function(err) {
          console.error(err);
          reject(err);
        };
      });
    },

    setVoiceMailForCard: function setVoiceMailForCard(cardIndex, number) {
      var promise = new Promise(function (resolve, reject) {
        if (numbers) {
          numbers[cardIndex] = number;
          resolve(numbers);
        }

        var request = getRilSettings();

        request.onsuccess = function() {
          var numbers = request.result[RIL_SETTINGS] || [];
          numbers[cardIndex] = number;

          resolve(numbers);
        };

        request.onerror = function(err) {
          console.error(err);
          reject(err);
        };
      });

      return promise.then(function(numbers) {
        var value = {};
        value[RIL_SETTINGS] = numbers;

        return new Promise(function (resolve, reject) {
          var request = settings.createLock().set(value);

          request.onsuccess = function() {
            resolve();
          };

          request.onerror = function(err) {
            console.error(err);
            reject(err);
          };
        });
      });
    }
  };

})();
