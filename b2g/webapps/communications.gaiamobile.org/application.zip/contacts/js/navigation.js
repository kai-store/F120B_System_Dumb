/* global LazyLoader, CustomDialog, Contacts, NavigationMap, ContactsTag,
   ActivityHandler, OptionHelper, contacts, navigation */
/* exported navigationStack */
/*jshint esnext:true */

function navigationStack(currentView) {
  'use strict';
  /* jshint validthis:true */
  // Each transition entry includes a 'forwards' property including the
  //  classes which will be added to the 'current' and 'next' view when the
  //  transition goes forwards, as well as a 'backwards' property including the
  //  classes which will be added to the 'current' and 'next' view when the
  //  transition goes backwards.
  var self = this,
    isFunction = function (obj) {
      return Object.prototype.toString.call(obj) === '[object Function]';
    },
    isArray = function (obj) {
      return Object.prototype.toString.call(obj) === '[object Array]';
    },
    visibilityState = {
      confirm: {
        visibility: false,
        handler: () => {}
      },
      menu: {
        visibility: false,
        handler: () => {}
      },
      action: {
        visibility: false,
        handler: () => {}
      },
      custom: {
        visibility: false,
        handler: () => {
          CustomDialog && CustomDialog.runCancel();
        }
      },
      onShow: null,
      onHide: null,

      setHandler: function (event, handler) {
        if (isFunction(handler)) {
          (this[event] || (this[event] = [])).push(handler);
        }
      },

      changeState: function (item, state) {
        var callFn;

        this[item] &&
          (this[item].visibility = state) &&
          (console.log('Contacts Navigation state changed ' + this[item].visibility));

        callFn = this.isOneVisible() ? 'onShow' : 'onHide';

        // onShow is called only if there is at least one displayed widget; othercase we call onHide
        // after calling we clear callback because of single running
        if (this[callFn]) {
          this[callFn].map((item) => item());
          this[callFn] = null;
        }
      },
      handle: function (item) {
        var el = this[item],
          result = true;
        if (!el || !el.visibility) {
          result = false;
        } else {
          el.handler();
        }
        return result;
      },
      isVissible: function (item) {
        if (isArray(item)) {
          return item.some((el) => this.isVissible(el));
        }
        return this[item] && this[item].visibility;
      },
      isOneVisible: function (call) {
        var result = ['confirm', 'custom', 'menu', 'action'].some((item) => this.isVissible(item));
        if (result && call) {
          //(!this.onHide && (this.onHide = [call])) || this.onHide.push(call);
          this.setHandler('onHide', call);
        }
        return result;
      }
    };
  this.evtprevent = false;
  this.isShown = function (el) {
    return isArray(el) ? el.some((item) => visibilityState.isVissible(item)) : visibilityState.isVissible(el);
  };
  this.lock = false;
  this.cancelTransition = function () {
    this.lock = true;
  };
  this.forceStop = false; //becuse of lock work only one time but we can need to turn off back engine
  this.lockBackEngine = function () {
    this.forceStop = true;
  };
  this.unlockBackEngine = function () {
    this.forceStop = false;
  };
  this.subscribers = {};

  this.subscribe = function (event, handler) {
    if (isFunction(handler)) {
      (this.subscribers[event] || (this.subscribers[event] = [])).push(handler);
    }
  };

  this.publish = function (event, details) {
    this.subscribers[event] && this.subscribers[event].forEach((item) => {
      details.scope = self;
      item(details);
    });
  };

  this.transitions = {
    'none': {
      forwards: {},
      backwards: {}
    },
    'right-left': {
      forwards: {
        next: 'app-go-left-in'
      },
      backwards: {
        current: 'app-go-left-back-out'
      }
    },
    'popup': {
      forwards: {
        next: 'app-go-up-in'
      },
      backwards: {
        current: 'app-go-up-back-out'
      }
    },
    'activity-popup': {
      forwards: {
        next: 'fade-in'
      },
      backwards: {}
    },
    'fade-in': {
      forwards: {
        next: 'fade-in'
      },
      backwards: {
        current: 'fade-out'
      }
    },
    'go-deeper': {
      forwards: {
        current: 'app-go-deeper-out',
        next: 'app-go-deeper-in'
      },
      backwards: {
        current: 'app-go-deeper-back-out',
        next: 'app-go-deeper-back-in'
      }
    },
    'go-deeper-search': {
      forwards: {
        current: 'move-left-out',
        next: 'move-left-in'
      },
      backwards: {
        current: 'move-right-out',
        next: 'move-right-in'
      }
    }
  };

  var COMMS_APP_ORIGIN = location.origin;
  var screenshotViewId = 'view-screenshot';
  var _currentView = currentView;
  var optionVasChanged = false;
  document.getElementById(currentView).classList.add('current');
  this.stack = [];
  this.optionsMenuStack = [];

  navigationStack._zIndex = navigationStack._zIndex || 0;

  this.stack.push({
    view: _currentView,
    transition: 'popup',
    zIndex: ++navigationStack._zIndex
  });

  var waitForAnimation = function ng_waitForAnimation(view, callback) {
    if (!callback) {
      return;
    }

    view.addEventListener('animationend', function ng_onAnimationEnd() {
      view.removeEventListener('animationend', ng_onAnimationEnd);
      setTimeout(callback, 0);
    });
  };

  var navigationElementsExist = () => {
    if (document.querySelector('#' + this.currentView() + ' [data-nav-id]')) {
      return true;
    }
    return false;
  };

  this.dispatchChangedViewEvent = function dispatchChangedViewEvent(forward) {
    var view = this.currentView(),
      selector = this.getNavigationSelector(view);
    window.NavigationManager.doUpdateCb = this.getNavDataUpdateCb(view);
    Contacts.resetFocusedMnu();
    optionVasChanged = false;
    if (selector) {
      this.showOptionsMenu(view);
      if (forward) {
        if ('view-contacts-list' === view &&
            Contacts.selectionMode) {
          contacts.List.resetListContextToFirstContact().then((nodes) => {
            window.NavigationManager.resetByNode(contacts.List.contactsSelector,
                nodes[0]);
            nodes[1] && nodes[1].scrollIntoView();
          });
        } else {
          window.NavigationManager.delNavId(selector);
          window.NavigationManager.reset(selector, null);
        }
      } else {
        var previousNavId = 0;
        if ('view-contacts-list' === view && Contacts.previousUUId) {
          var previousItem = document
              .querySelector('[data-uuid="' + Contacts.previousUUId + '"]');
          if (previousItem && !previousItem.dataset.navId) {
            previousItem.dataset.navId = window.NavigationManager.nextId();
            previousNavId = previousItem.dataset.navId;
          }
          Contacts.previousUUId = '';
        }
        window.NavigationManager.switchContext(selector, previousNavId);
      }
    }

    window.dispatchEvent(new CustomEvent('changedView', {
      detail: {
        currentView: this.currentView()
      }
    }));
  };

  this.isCurrentView = function (viewName) {
    return this.currentView() === viewName;
  };

  this.getView = function (deeps) {
    var result = null,
      viewsStack = this.stack;
    deeps = deeps - 1;
    if (deeps < 0 && viewsStack.length + deeps >= 0) {
      result = viewsStack[viewsStack.length + deeps];
      result = result.view ? result.view : result;
    }
    return result;
  };

  this.go = function go(nextView, transition, callback) {
    var fromView = this.currentView();

    var lastViewBody = document.querySelector('.view-body-visible');
    lastViewBody && lastViewBody.classList.remove('view-body-visible');
    document.querySelector('#' + nextView + ' .view-body')
        .classList.add('view-body-visible');
    this.publish('beforeTransition', {
      fromView: fromView,
      toView: nextView
    });
    if (!this.lock) {
      this.goInner(nextView, transition, callback);
      this.publish('afterTransition', {
        fromView: fromView,
        toView: this.getView(0)
      });
    }
    this.lock = false;
    console.log('Contacts Navigation: go from ' + fromView + ' to ' + nextView);
  };

  this.goInner = function (nextView, transition, callback) {
    if (_currentView === nextView) {
      if (callback) {
        callback();
      }
      return;
    }

    var parent = window.parent;
    if (nextView == 'view-contact-form') {
      parent.postMessage({
        type: 'hide-navbar'
      }, COMMS_APP_ORIGIN);
    }

    // Remove items that match nextView from the stack to prevent duplicates.
    // this.stack = this.stack.filter(function (item) {
    //   return item.view != nextView;
    // });

    var current;
    var currentClassList;
    // Performance is very bad when there are too many contacts so we use
    // -moz-element and animate this 'screenshot" element.
    if (transition.indexOf('go-deeper') === 0) {
      current = document.getElementById(screenshotViewId);
      // Load the screenshot dom content
      LazyLoader.load([current]);
      current.style.zIndex = this.stack[this.stack.length - 1].zIndex;
      currentClassList = current.classList;
      if (transition.indexOf('search') !== -1) {
        currentClassList.add('search');
      } else {
        currentClassList.add('contact-list');
      }
      currentClassList.remove('hide');
    } else {
      current = document.getElementById(_currentView);
      currentClassList = current.classList;
    }

    var forwardsClasses = this.transitions[transition].forwards;
    // Add forwards class to current view.
    currentClassList.add('block-item');
    if (forwardsClasses.current) {
      currentClassList.add(forwardsClasses.current);
    }

    var next = document.getElementById(nextView);
    // Add forwards class to next view.
    if (forwardsClasses.next) {
      next.classList.add('block-item');
      next.classList.add(forwardsClasses.next);
      NavigationMap.currentActivatedLength++;
      next.addEventListener('animationend', function ng_onNextBackwards(ev) {
        next.removeEventListener('animationend', ng_onNextBackwards);
        NavigationMap.currentActivatedLength--;
        next.classList.remove('block-item');
      });
    }

    if (next.id !== 'view-contact-details') {
      next.classList.add('current');
    }
    var realCurrentView = document.getElementById(_currentView);
    var _callbackInner = function _callback() {
      next.classList.add('current');
      realCurrentView.classList.remove('current');
      if (callback) {
        callback();
      }
    };

    // Add focus element in stack
    var currentFocus = realCurrentView.querySelector('.focus');
    this.stack[this.stack.length - 1].focus = currentFocus;

    if (transition === 'none') {
      setTimeout(_callbackInner, 0);
    } else {
      waitForAnimation(next, _callbackInner);
    }

    var zIndex = ++navigationStack._zIndex;
    this.stack.push({
      view: nextView,
      transition: transition,
      zIndex: zIndex
    });
    next.style.zIndex = zIndex;
    _currentView = nextView;
    this.dispatchChangedViewEvent(true);
  };

  this.isFinallyView = function () {
    if (['add-speed-dial', 'save-speed-dial']
        .indexOf(OptionHelper.getLastParamName()) > -1) {
      return false;
    } else {
      return this.stack.length < 2;
    }
  };

  this.back = function back(callback) {
    ContactsTag.customTagVisible &&
        ContactsTag.toggleCustomTag();
    contacts.List.toggleICEGroup(true);
    var fromView = this.currentView();
    var promise = Promise.resolve();
    this.publish('beforeTransition', {
      fromView: fromView,
      toView: this.getView(-1)
    });
    // set timeout for animation transition
    if ('view-select-tag' === fromView) {
      NavigationMap.currentActivatedLength++;
      setTimeout(() => {
        NavigationMap.currentActivatedLength--;
      }, 700);
    }
    if (!this.lock) {
      promise = this.backInner().then(() => {
        this.publish('afterTransition', {
          fromView: fromView,
          toView: this.getView(0)
        });
        if (callback && typeof callback === 'function') {
          callback();
        }
      });
    }
    this.lock = false;
    return promise;
  };

  this.backInner = function () {
    return new Promise((resolve) => {
      if (this.isFinallyView()) {
        resolve();
        return;
      }
      var currentView = this.stack.pop();
      var current = document.getElementById(currentView.view);
      var currentClassList = current.classList;

      var nextView = this.stack[this.stack.length - 1];
      var transition = currentView.transition;

      var next = document.getElementById(nextView.view);
      var nextClassList;
      // Performance is very bad when there are too many contacts so we use
      // -moz-element and animate this 'screenshot" element.
      if (transition.indexOf('go-deeper') === 0) {
        next = document.getElementById(screenshotViewId);
      } else {
        next = document.getElementById(nextView.view);
      }
      nextClassList = next.classList;

      var forwardsClasses = this.transitions[transition].forwards;
      var backwardsClasses = this.transitions[transition].backwards;

      if (currentView.view == 'view-contact-form') {
        parent.postMessage({
          type: 'show-navbar'
        }, COMMS_APP_ORIGIN);
      }

      // Add backwards class to current view.
      if (backwardsClasses.current) {
        currentClassList.add('block-item');
        currentClassList.add(backwardsClasses.current);
        current.addEventListener('animationend',
          function ng_onCurrentBackwards() {
            current.removeEventListener('animationend', ng_onCurrentBackwards);
            // Once the backwards animation completes, delete the added classes
            // to restore the elements to their initial state.
            currentClassList.remove(forwardsClasses.next);
            currentClassList.remove(backwardsClasses.current);
            current.style.zIndex = null;
            currentClassList.remove('block-item');
            if (!backwardsClasses.next) {
              nextClassList.remove('block-item');
            }
          }
        );
      } else {
        current.style.zIndex = null;
        currentClassList.remove('block-item');
        if (!backwardsClasses.next) {
          nextClassList.remove('block-item');
        }
      }

      next.style.zIndex = nextView.zIndex;

      // Add backwards class to next view.
      if (backwardsClasses.next) {
        nextClassList.add(backwardsClasses.next);
        next.addEventListener('animationend', function ng_onNextBackwards() {
          next.removeEventListener('animationend', ng_onNextBackwards);
          // Once the backwards animation completes, delete the added classes
          // to restore the elements to their initial state.
          nextClassList.remove(forwardsClasses.current);
          nextClassList.remove(backwardsClasses.next);
          if (transition.indexOf('go-deeper') === 0) {
            // Hide the -moz-element element once the animation completes.
            nextClassList.add('hide');
            nextClassList.remove('search');
            nextClassList.remove('contact-list');
          }
          nextClassList.remove('block-item');
        });
      }

      document.getElementById(nextView.view).classList.add('current');
      var _callbackInner = function _callbackInner() {
        document.getElementById(nextView.view).classList.add('current');
        currentClassList.remove('current');
        resolve();
      };


      if ((!backwardsClasses.current && !backwardsClasses.next) ||
        transition === 'none') {
        setTimeout(_callbackInner, 0);
      } else {
        waitForAnimation(current, _callbackInner);
      }
      _currentView = nextView.view;
      navigationStack._zIndex = nextView.zIndex;
      this.dispatchChangedViewEvent();
      document.dispatchEvent(new CustomEvent('focusChanged', {
        detail: {
          focusedElement: document.querySelector('.focus')
        }
      }));
    });
  };

  this.home = function home(callback) {
    if (this.stack.length < 2) {
      if (typeof callback === 'function') {
        setTimeout(callback, 0);
      }
      return;
    }
    var stackLength = this.stack.length-1;
    var promise = this.back(callback);
    while (stackLength > 1) {
      promise.then(() => {
        this.back(callback);
      });
      stackLength--;
    }
  };

  this.currentView = function currentView() {
    return _currentView !== null ? _currentView : '';
  };

  this.changePageElFocus = function changePageElFocus(e) {
    var optionId,
      focusElement = e.detail.focusedElement;
    if (self.forceStop) {
      return;
    }
    if (!focusElement || !navigationElementsExist() || visibilityState.isOneVisible(
      () => {
        if (focusElement && (optionId = focusElement.getAttribute('data-option-name'))) {
          OptionHelper.show(optionId);
          optionVasChanged = true;
        }
      }
    )) { //endif
      return;
    }

    optionId = focusElement.getAttribute('data-option-name');
    if (optionId) {
      try {
        if (!Contacts.contactsImporting) {
          OptionHelper.show(optionId);
          optionVasChanged = true;
        }
      } catch (err) {
        console.log(err);
      }
    } else if (optionVasChanged === true &&
        !document.querySelector('.group-menu.visible') &&
        (!document.getElementById('progress-element') ||
          Contacts.importBatchContacts)) {
      this.showOptionsMenu();
    }
  };

  this.showOptionsMenu = function showOptionsMenu(viewId) {
    var optionId;
    viewId = viewId || this.currentView();
    optionId = this.optionsMenuStack.find((item) => item.viewId === viewId);
    if (visibilityState.isVissible(['custom', 'confirm', 'action'])) {
      visibilityState.isVissible('custom') && OptionHelper.setLast(optionId.optionId);
      return;
    }
    if (optionId) {
      OptionHelper.show(optionId.optionId);
      optionVasChanged = true;
    } else {
      optionVasChanged = false;
    }
  };

  this.pushOptionMenu = function pushOptionMenu(optionId, viewId, hideAtInit) {
    viewId = viewId;
    var optionviewHash = this.optionsMenuStack.find((item) => item.viewId == viewId);
    if (!optionviewHash) {
      this.optionsMenuStack.push({
        viewId: viewId,
        optionId: optionId
      });
    } else {
      optionviewHash.optionId = optionId;
    }
    try {
      (viewId === this.currentView()) && OptionHelper.show(optionId);
      if (hideAtInit) {
        OptionHelper.hideMenu();
      }
    } catch (err) {
      console.log(err);
    }
  };

  this.getNavigationSelector = function getNavigationSelector(viewId, tab) {
    var selector = false;
    viewId = viewId || this.currentView();
    switch (viewId) {
    case 'view-contacts-list':
      selector = Contacts.isSearchMode() && !Contacts.isSelectedSpeedDial ?
                 contacts.Search.navigationSelector : contacts.List.navigationSelector;
      break;
    case 'view-contact-form':
      selector = contacts.Form.navigationSelector;
      break;
    case 'view-contact-details':
      selector = contacts.Details.navigationSelector;
      break;
      /*case 'view-select-tag':
          selector = '.tagContainer';
          break;*/
    case 'view-contacts-settings': //todo please set into views/settings as getter
      selector = contacts.Settings.navigationSelectorMainPage;
      break;

    case 'import-settings': //todo please set getting selector logic into your view!!!
      selector = contacts.Settings.navigationSelector;
      break;

    case 'ice-settings':
      selector = contacts.ICE.navigationSelector;
      break;

    case 'ice-view':
      selector = contacts.ICEView.navigationSelector;
      break;

    case 'view-voice-mail':
      selector = contacts.VoiceMail.navigationSelector;
      break;

    default:
      break;
    }
    return selector;
  };

  this.getNavDataUpdateCb = function getNavDataUpdateCb(viewId) {
    var cb = null;
    viewId = viewId || this.currentView();
    if (this.isCurrentView('view-contact-details')) {
      cb = contacts.Details.setNavigationData;
    }
    return cb;
  };

  this.isWidgetShown = function (onWidgetHide) {
    return visibilityState.isOneVisible(onWidgetHide);
  };

  this.onWidgetStateChanged = function (state, callback) {
    if (self.evtprevent) {
      return;
    }
    var isVisible = visibilityState.isOneVisible();

    switch (state) {
    case 'hide':
      isVisible ?
        visibilityState.setHandler('onHide', callback) :
        callback();
      break;

    case 'show':
      !isVisible ?
        visibilityState.setHandler('onShow', callback) :
        callback();
      break;
    }
  };

  var onKeyDown = function (evt) {
    var key = evt.key,
      notHandle = false;
    if (self.forceStop) {
      return;
    }
    if (key === 'BrowserBack' || key === 'Backspace') {
      if (OptionHelper.softkeyPanel.menuVisible ||
          ContactsTag.customTagVisible) {
        evt.preventDefault();
        ContactsTag.customTagVisible &&
            ContactsTag.toggleCustomTag(true);
        return;
      }
      if (navigation.isCurrentView('view-contact-form') &&
          !OptionHelper.softkeyPanel.menuVisible) {
        evt.preventDefault();
        if (!NavigationMap.currentActivatedLength) {
          contacts.Form.goBack(false);
        }
        return;
      }
      if (contacts.Search.isInSearchMode()) {
        evt.preventDefault();
        contacts.Search.resetSearch();
      }
      if (ActivityHandler && ActivityHandler.currentlyHandling) {
        if (!Contacts.importBatchContacts
            && ActivityHandler.currentActivityIs('import')) {
          return;
        }
        evt.preventDefault();
      }

      notHandle = Object.keys(visibilityState).some(function (item) {
        return visibilityState.handle(item);
      });
      if (!notHandle) {
        if (!self.isFinallyView()) {
          evt.preventDefault();
          evt.stopPropagation();
        }
        self.back();
      }
    }
  };

  var changeWidgetState = function (item, state) {
    if (self.evtprevent) {
      return;
    }
    visibilityState.changeState(item, state);

    self.publish('widgetStateChanged', {
      item: item,
      visibility: state
    });
  };

  this.isDialogVisible = function () {
    return visibilityState.isVissible(['custom', 'confirm']);
  };

  var initHandlers = function () {
    // change this.notHandleBack status when shown or hide
    // custom dialog
    // confirmation dialog
    // action list
    // soft key panel options
    /* confirm: {
        visibility: false,
        handler: () => {}
    },
    menu: {
        visibility: false,
        handler: () => {}
    },
    action: {
        visibility: false,
        handler: () => {}
    },
    custom: {
        visibility: false,
        handler: () => {}
    }*/

    window.addEventListener('customDialogEvent', (e) => {
      changeWidgetState('custom', e.detail.visibility);
      console.log('Navigation: custom dialog change notBackHandle state to ' + e.detail.visibility);
    });
    window.addEventListener('confirmDialogEvent', (e) => {
      changeWidgetState('confirm', e.detail.visibility);
      console.log('Navigation: confirm dialog change notBackHandle state to ' + e.detail.visibility);
    });
    window.addEventListener('menuEvent', (e) => {
      changeWidgetState('menu', e.detail.menuVisible);
      console.log('Navigation: menu change notBackHandle state to ' + e.detail.menuVisible);
    });
    window.addEventListener('actionListVisibilityChanged', (e) => {
      changeWidgetState('action', e.detail.visibility);
      console.log('Navigation: action list change notBackHandle state to ' + e.detail.visibility);
    });
    window.addEventListener('keydown', onKeyDown);
  };

  document.addEventListener('focusChanged', this.changePageElFocus.bind(this));
  initHandlers();
}
