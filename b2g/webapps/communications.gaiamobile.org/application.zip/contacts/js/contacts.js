/* global ActivityHandler, Cache, ConfirmDialog, contacts,
  ContactsTag, DeferredActions, fb, fbLoader, LazyLoader,
  MozActivity, navigationStack, SmsIntegration, TAG_OPTIONS,
  utils, TabNavigation, contactsRemover, CustomDialog,
  NavigationManager, Toaster, OptionHelper, EditTypeField,
  SettingsListener, ConfirmDialogHelper, NavigationMap, RingtoneField */

/* exported COMMS_APP_ORIGIN, SCALE_RATIO */

/* jshint nonew: false */

'use strict';
var COMMS_APP_ORIGIN = location.origin;

// Scale ratio for different devices
var SCALE_RATIO = window.devicePixelRatio || 1;
var default_ring_tone = '';
var Contacts = (function () {
  var SHARED = 'shared';
  var SHARED_PATH = '/' + SHARED + '/' + 'js';

  var SHARED_UTILS = 'sharedUtilities';
  var SHARED_UTILS_PATH = SHARED_PATH + '/contacts/import/utilities';

  var SHARED_CONTACTS = 'sharedContacts';
  var SHARED_CONTACTS_PATH = SHARED_PATH + '/' + 'contacts';

  const SELECT_MODE_CLASS = {
    'pick': {
      'text/vcard': ['disable-fb-items']
    }
  };
  var navigation = initNavigationStack();
  window.navigation = navigation;
  var goToForm = function edit() {
    if (navigation.currentView() === 'view-contact-form') {
      return;
    }
    var transition = ActivityHandler.currentlyHandling ?
              'activity-popup' : 'fade-in';
    navigation.go('view-contact-form', transition);
  };

  var contactTag,
    settings,
    settingsButton,
    header,
    addButton,
    appTitleElement,
    editModeTitleElement,
    contactsListOptionSwitched = false;

  var loadAsyncScriptsDeferred = {};
  loadAsyncScriptsDeferred.promise = new Promise((resolve) => {
    loadAsyncScriptsDeferred.resolve = resolve;
  });

  var settingsReady = false;
  var detailsReady = false;
  var formReady = false;
  var voiceMailReady = false;
  var isInputing = false;
  var lastCompose = false;
  var endInput = null;
  var currentContact = {},
    currentFbContact;

  var contactsList;
  var contactsDetails;
  var contactsForm;

  var typeChanged, lazyLoadedTagsDom = false;

  var showNoContacts, isAddTypePage;

  var replacementMode = null;
  var viewdetailMode = false;
  var selectedSpeedDial;
  var speedDialPhone;
  var searchEnable = false;
  var menuVisible = false;
  var sdLoader; // Promise loading all speed dials

  var selectedContact = false;

  var searchInput;

  var selectionMode = false;
  var stateBeforeExitSelectMode = false;

  var currentHeaderCb = handleBack;
  var assignPhone = false;
  var assignSpeedDial = false;
  var previousUUId = '';
  var addToExistingCallback = null;
  var globalParams = null;
  var currentTab = 'contacts';
  var currentItem = null;
  var firstChunkRendered = false;
  var importBatchContacts = false;
  var contactsImporting = false;

  var deferredLoad = {};
  deferredLoad.promise = new Promise(resolve => {
    deferredLoad.start = resolve;
  });

  // Shows the edit form for the current contact being in an update activity
  // It receives an array of two elements with the facebook data && values
  function showEditForm(facebookData, params) {
    contactsForm.render(currentContact, goToForm,
      facebookData, params);
  }

  function initNavigationStack() {
    var viewName;
    if (window.location.search === '?new') {
      viewName = 'view-contact-form';
      document.getElementById(viewName).classList.remove('view-bottom');
    } else if (window.location.search === '?open') {
      viewName = 'view-contact-details';
      document.getElementById(viewName).classList.remove('view-bottom');
    } else {
      viewName = 'view-contacts-list';
    }
    return new navigationStack(viewName);
  }

  var goToSettings = function goToSettings() {
    currentTab = TabNavigation.getCurrentTab();
    LazyLoader.load(['js/views/settings.js',
      //'js/contact_edit_helper.js',
      document.querySelector('#view-settings')
    ]);

    initDetails(function () {
      showSettings();
    });
  };



  var checkUrl = function checkUrl() {
    var hasParams = window.location.hash.split('?');
    var hash = hasParams[0];
    var sectionId = hash.substr(1, hash.length) || '';
    var cList = contacts.List;
    var params = hasParams.length > 1 ?
      utils.extractParams(hasParams[1]) : -1;
    latestSelector = null;
    switch (sectionId) {
    case 'view-contact-list':
      initContactsList();
      break;
    case 'view-speed-dial-list':
      sdLoader && sdLoader.then(function() {
        if (params.number) {
          document.addEventListener('focusChanged', function onfocuschange() {
            document.removeEventListener('focusChanged', onfocuschange);
            var selector = navigation
                .getNavigationSelector('view-contacts-list');
            var speedDials = document.querySelectorAll(selector);
            if (speedDials[params.number - 1] &&
                speedDials[params.number - 1].dataset.navId) {
              var navFocusId = speedDials[params.number - 1].dataset.navId;
              window.NavigationManager.context[selector] = navFocusId;
              window.NavigationManager.switchContext(selector);
            }
          });
        }
        TabNavigation.selectTab('speed-dial');
        TabNavigation.disabled(true);
      });
      break;
    case 'view-add-speed-dial':
      assignPhone = assignSpeedDial = false;
      if (params) {
        if (params.tel) {
          assignPhone = true;
          assignSpeedDial = true;
          sdLoader && sdLoader.then(function() {
            speedDialPhone = params.tel;

            contacts.List.enableSpeedDial(1, false);
            setReplacementMode(null, 'tel');
          });
        } else if (params.speedDial) {
          assignSpeedDial = true;
          sdLoader && sdLoader.then(function() {
            selectedSpeedDial = params.speedDial;
            setReplacementMode('add-speed-dial', 'contact');
          });
        }
      }
      break;
    case 'view-contact-details':
      initContactsList();
      initDetails(function onInitDetails() {
        // At this point, a parameter is required.
        if (params == -1) {
          console.error('Param missing');
          return;
        }

        // If the parameter is an id, the corresponding contact is loaded
        // from the device.
        if ('id' in params) {
          var id = params.id;
          cList.getContactById(id, function onSuccess(savedContact) {
            currentContact = savedContact;

            // Enable NFC listening is available
            if ('mozNfc' in navigator) {
              contacts.NFC.startListening(currentContact);
            }

            contactsDetails.render(currentContact);

            navigation.go(sectionId, 'right-left');
          }, function onError() {
            console.error('Error retrieving contact');
          });
          // If mozContactParam is true, we know there is a mozContact
          // attached to the activity, so we render it using contacts details'
          // read only mode. This is used when we receive an activity to open
          // a given contact with allowSave set to false.
        } else if (params.mozContactParam) {
          var contact = ActivityHandler.mozContactParam;
          contactsDetails.render(contact, null, true);
          navigation.go(sectionId, 'activity-popup');
        }
      });
      break;
    case 'view-contact-form':
      initForm(function onInitForm() {
        if (params.mozContactParam) {
          contactsForm.render(ActivityHandler.mozContactParam, goToForm);
          ActivityHandler.mozContactParam = null;
        } else if (params == -1 || !(params.id)) {
          contactsForm.render(params, function() {
            if (!ActivityHandler.currentlyHandling) {
              goToForm();
            } else {
              NavigationManager.reset(navigation.getNavigationSelector());
            }
          });
        } else {
          // Editing existing contact
          if (params.id) {
            var id = params.id;
            cList.getContactById(id, function onSuccess(savedContact) {
              currentContact = savedContact;
              // Check if we have extra parameters to render
              if ('extras' in params) {
                addExtrasToContact(params.extras);
              }
              if (fb.isFbContact(savedContact)) {
                var fbContact = new fb.Contact(savedContact);
                var req = fbContact.getDataAndValues();
                req.onsuccess = function () {
                  showEditForm(req.result, params);
                };
                req.onerror = function () {
                  console.error('Error retrieving FB information');
                  showEditForm(null, params);
                };
              } else {
                showEditForm(null, params);
              }
            }, function onError() {
              console.error('Error retrieving contact to be edited');
              contactsForm.render(null, goToForm);
            });
          }
        }
      });
      break;

    case 'view-edit-phone-type':
      navigation.go('view-edit-phone-type', 'fade-in');
      break;
    case 'add-parameters':
      contacts.List.toggleICEGroup(false);
      initContactsList();
      selectionMode = true;
      TabNavigation.hideTab('speed-dial');
      addToExistingContact(params, true);
      initForm(function onInitForm() {
        navigation.home();
      });
      break;
    case 'add-to-call':
      contacts.List.toggleICEGroup(false);
      initContactsList();
      selectionMode = true;
      TabNavigation.hideTab('speed-dial');
      navigation.pushOptionMenu('contact-add-to-call', navigation.currentView());
      break;
    case 'home':
      navigation.home();
      break;
    }
  };

  var getSearchInput = function () {
    return searchInput ||
      (searchInput = document.getElementById('contacts-list-search-input'));
  };

  var addExtrasToContact = function addExtrasToContact(extrasString) {
    try {
      var extras = JSON.parse(decodeURIComponent(extrasString));
      for (var type in extras) {
        var extra = extras[type];
        if (currentContact[type]) {
          if (Array.isArray(currentContact[type])) {
            var joinArray = currentContact[type].concat(extra);
            currentContact[type] = joinArray;
          } else {
            currentContact[type] = extra;
          }
        } else {
          currentContact[type] = Array.isArray(extra) ? extra : [extra];
        }
      }
    } catch (e) {
      console.error('Extras malformed');
      return null;
    }
  };

  var initContainers = function initContainers() {
    settings = document.getElementById('view-contacts-settings');
    settingsButton = document.getElementById('settings-button');
    header = document.getElementById('contacts-list-header');
    addButton = document.getElementById('add-contact-button');
    editModeTitleElement = document.getElementById('edit-title');
    appTitleElement = document.getElementById('app-title');
  };

  var onLocalized = function onLocalized() {
    init();

    // We need to return the promise here for testing purposes
    return addAsyncScripts().then(() => {
      checkUrl();
      if (!ActivityHandler.currentlyHandling ||
        ActivityHandler.currentActivityIs(['pick', 'update'])) {
        initContactsList();
      } else {
        // Unregister here to avoid un-necessary list operations.
        navigator.mozContacts.oncontactchange = null;
      }

      /*if (contactsList) {
        contactsList.initAlphaScroll();
      }*/
    });
  };

  var loadDeferredActions = function loadDeferredActions() {
    return new Promise(function(resolve, reject) {
      window.removeEventListener('listRendered', loadDeferredActions);

      LazyLoader.load([
        'js/deferred_actions.js',
        'js/contact_edit_helper.js'
      ], function () {
        DeferredActions.execute();
        try {
          resolve();
        } catch (e) {
          console.error(e);
        }
      });
    });
  };
  var latestSelector;

  var resetLatestSelector = function () {
    latestSelector = null;
  };

  var init = function init() {
    window.NavigationManager.resetContactList = function(selectedElement) {
      var selector = contacts.List.navigationSelector;
      window.NavigationManager.delNavId(selector);
      //TODO navigation is not full.
      window.NavigationManager.resetByNode(selector, selectedElement);
    };

    CustomDialog.setVersion(2);

    window.addEventListener('hashchange', checkUrl);
    document.addEventListener('input', function(e) {
      if (e.target.id !== 'contacts-list-input') {
        return;
      }
      lastCompose = e.isComposing;
      if (!e.isComposing) {
        var v = e.target.value.trim();
        if ( v !== '' && (!isInputing || !lastCompose)) {
          contacts.Search.init(contacts.List.searchSource, true);
          var searchInput = document
              .querySelector('#groups-list-search #contacts-search-input');
          searchInput.value = v;
          window.dispatchEvent(new CustomEvent('input', {
            detail: {
              custom: true,
              target: searchInput,
              isComposing: false
            }
          }));
          e.target.value = '';
        } else if (v === '') {
          e.target.value = '';
        }
      } else {
        isInputing = true;
        endInput && clearTimeout(endInput);
        endInput = setTimeout(() => {
          isInputing = false;
        }, 400);
      }
    });
    window.addEventListener('listRendered', function (event) {
      if (ActivityHandler && ActivityHandler.activityName) {
        switch(ActivityHandler.activityName) {
          case 'open':
            return;
        }
      }
      loadDeferredActions().then(function() {
        filterByEmailOrPhone();
        var targetView = (!!contacts.Settings && contacts.Settings.isSettings()) ?
            navigation.currentView() : 'view-contacts-list';
        if (!!contacts.Settings && contacts.Settings.isSettings() &&
            OptionHelper.getLastParamName() === 'none' &&
            navigation.currentView() === 'view-contacts-list') {
          navigation.pushOptionMenu('contact-notSelected-selectAll',
            'view-contacts-list');
        }
        if (navigation.isCurrentView('view-contacts-list') &&
            !firstChunkRendered &&
            'contacts' === TabNavigation.getCurrentTab() &&
            !OptionHelper.softkeyPanel.menuVisible) {
          contacts.List.resetListContextToFirstContact().then((nodes) => {
            NavigationManager.resetByNode(
              navigation.getNavigationSelector(targetView), nodes[0]);
          });
        } else if (navigation.isCurrentView('view-contacts-list') &&
            'contacts' === TabNavigation.getCurrentTab() &&
            !OptionHelper.softkeyPanel.menuVisible) {
          NavigationManager.switchContext(
              navigation.getNavigationSelector(targetView), null, null, true);
        }
      });
      var searchinput = document.getElementById('contacts-list-search-input');
      if (searchinput) {
        searchinput.addEventListener('blur', function() {
          document.getElementById('groups-container').setAttribute('role', 'heading');
          document.getElementById('groups-container').setAttribute('aria-labelledby', 'app-title contacts-all');
          document.getElementById('article-view').removeAttribute('role');
          document.getElementById('speed-dial-container').setAttribute('aria-labelledby', 'speed-dial-button-list');
        });
      }
    });

    window.addEventListener('firstChunkRendered', function() {
      firstChunkRendered = true;
      if (ActivityHandler && ['import', 'open', 'new', 'add-speed-dial', 'speed-dial-list']
          .indexOf(ActivityHandler.activityName) > -1) {
        NavigationManager.switchContext(
            navigation.getNavigationSelector('view-contacts-list'), null, null, true);
        setContactSoftkey(false);
      } else {
        if (navigation.isCurrentView('view-contacts-list') && !navigation.isWidgetShown()) {
          contacts.List.resetListContextToFirstContact().then((nodes) => {
            NavigationManager.resetByNode(navigation.getNavigationSelector(), nodes[0]);
          });
        }
      }
    });

    window.cachePromise.then(function () {
      filterByEmailOrPhone();
      setContactSoftkey(!Cache.length);

      deferredLoad.start();
    });

    window.addEventListener('changeContactListMenu', pushContactListOptionMenu);

    window.addEventListener('BackspaceDeleteContact', () => {
      if (isContactListTab() && getSearchInput().value.length === 0) {
        removeContactClickHandler();
      }
      /*else if (doSearch._isSearched) {
                     setTimeout(() => doSearch({key: '_back'}), 100);
                 }*/
    });

    window.addEventListener('tabChanged', tabChangedHandler);

    if (window.location.search !== '?open') {
      navigation.pushOptionMenu('contact-details', 'view-contact-details');
    }
    navigation.pushOptionMenu('contact-details-edit', 'view-contact-form');

    document.addEventListener('menuEvent', onMenuEvent);
    document.addEventListener('focusChanged', onFocusChanged);

    var confirmDialog = document.getElementById('confirmation-message');
    confirmDialog.addEventListener('animationend', function () {
       //because of animation, change view event can run earlier than this
      // window.focus();
      // confirmDialog.focus();
      OptionHelper.show('no-contacts');
    });

    window.addEventListener('changedView', onViewChanged);
    window.addEventListener('message', receiveMessage, false);

    initTransitionHandlers();

    navigation.subscribe('widgetStateChanged', function (details) {
      if (ActivityHandler.currentlyHandling) {
        details.visibility ?
          header.removeEventListener('action', currentHeaderCb) :
          header.addEventListener('action', currentHeaderCb);
      }
    });
    //window.addEventListener('input', onInput);
    /* XXX: Don't specify a defadocumentult volume control channel as we want to stick
     * with the default one as a workaround for bug 1092346. Once that bug is
     * fixed please add back the following line:
     *
     * navigator.mozAudioChannelManager.volumeControlChannel = 'notification';
     */
    window.addEventListener('largetextenabledchanged', () => {
      document.body.classList.toggle('large-text', navigator.largeTextEnabled);
    });
    LazyLoader.load('/shared/js/settings_listener.js', () => {
      SettingsListener.observe('dialer.ringtone.name', false, (value) => {
        default_ring_tone = 'builtin:ringtone/' + value.l10nID;
      });
    });
  };

  var receiveMessage = function (event) {
    if (event.data === 'net-error') {
      var active = document.activeElement;
      if (active.tagName.toLowerCase() === 'iframe') {
        //if after the error focus still in iframe we need to return focus to window
        active.blur();
      }
    }
  };

  var initTransitionHandlers = function () {
    navigation.subscribe('beforeTransition', function (details) {

      var fromView = details.fromView,
        toView = details.toView;
      if (toView === 'view-contacts-list') {
        if (!selectionMode) {
          showTabNavigation();
        }
      } else if (fromView === 'view-contacts-list') {
        if (!toView) {
          if (!ActivityHandler.currentlyHandling) {
            if (replacementMode) {
              appTitleElement.setAttribute('data-l10n-id', 'contacts');
              Contacts.resetReplacementMode();
            } else {
              // do nothing
            }
          } else {
            ActivityHandler.postCancel();
          }
        } else if (fromView !== toView) {
          TabNavigation.disabled(true);
        }
      }
      if (toView === 'view-contacts-list') {
        if (TabNavigation.getCurrentTab() !== currentTab &&
            currentItem &&
            'view-contacts-settings' === fromView) {
          TabNavigation.selectTab(currentTab);
        }
      }
      if (fromView === 'view-select-tag') {
        var tag = getTagType(contactTag);

        if (tag === 'ringtone') {
          stopPlayer();
        }
      }

      if (fromView === 'view-contact-details' && !toView) {
        if (!ActivityHandler.currentlyHandling) {
            // do nothing
          } else {
            ActivityHandler.postCancel();
          }
      }
    });

    navigation.subscribe('afterTransition', function (details) {
      var toView = details.toView, fromView = details.fromView;

      if (toView === 'view-contacts-list' && !selectionMode) {
        TabNavigation.enabled(true);
        document.querySelector('section#view-contacts-list .info').focus();
        searchEnable = false;
      }

      if (toView === 'view-select-tag') {
        var tag = getTagType(contactTag);

        if (tag === 'ringtone') {
          document.addEventListener('focusChanged', selectRingtone);
        }
      }
      if ('view-contacts-list' === fromView) {
        switch(toView) {
          case 'ice-settings':
          case 'view-contacts-settings':
            appTitleElement.setAttribute('data-l10n-id', 'contacts');
            break;
        }
      }

    });
  };

  var onViewChanged = function (evt) {
    if (!navigation.isCurrentView('view-contacts-list')) {
      if (stateBeforeExitSelectMode === navigation.stack.length) {
        stateBeforeExitSelectMode = false;
        contacts.List.exitSelectMode();
      }
    }
    if (isSearchMode()) {
      contacts.Search.resetSearchHidenView();
    }
  };

  var doCloseApp = function (closeApp) {
    if (ActivityHandler.currentlyHandling) {
      ActivityHandler.postCancel();
    }

    ActivityHandler._handlingEnabled = false;
    if (window.navigator.mozSetMessageHandler) {
      window.navigator.mozSetMessageHandler('activity', null);
    }

    // XXX: Do we really need this?
    // Maybe it's fine to let the user to press end call again.
    closeApp && window.close();
  };

  window.addEventListener('keydown', function(evt) {
    if (evt.key === 'EndCall') {
      if (contacts.Form && !navigation.isDialogVisible()) {
        contacts.Form.isDataChanged((changed) => {
	  if (changed) {
            evt.preventDefault();
            contacts.Form.doClose().then(() => doCloseApp(true));
	  } else {
	    doCloseApp(false);
	  }
        });
      } else {
        doCloseApp(false);
      }
    }
  });

  function isSpeedDialTab() {
    return navigation.currentView() === 'view-contacts-list' &&
      TabNavigation.getCurrentTab() === 'speed-dial';
  }

  function isContactListTab() {
    return navigation.currentView() === 'view-contacts-list' &&
      TabNavigation.getCurrentTab() === 'contacts';
  }

  function isContactDetailsPage() {
    return navigation.currentView() === 'view-contact-details';
  }

  function isSettingsPage() {
    return contacts.Settings && contacts.Settings.isSettings();
  }

  var onMenuEvent = function (e) {
    navigation.onWidgetStateChanged('hide', function () {

      menuVisible = e.detail.menuVisible;

      var isContactList = navigation.isCurrentView('view-contacts-list');

      if (e.detail.menuVisible) {
        isContactList && TabNavigation.disabled(true);

        latestSelector = NavigationManager.currentSelector;
        NavigationManager.switchContext('.' + e.detail.menuName);

      } else {
        isContactList && TabNavigation.enabled(true);

        if (latestSelector) {
          NavigationManager.switchContext(latestSelector);
        }
      }
    });
  };

  var onFocusChanged = function (evt) {
    if (evt.detail.focusedElement) {
      updateOptions(evt.detail.focusedElement);
    }
  };

  function swapListOptionParams(show) {
    var switchableParams = ['ShowContact', 'EditContact',
        'ShowContact', 'SendMessage', 'Call', 'Share', 'DeleteContact'];
    switchableParams.forEach((value) => {
      OptionHelper.safeSetVisibility(show, 'contact-list', value, true);
    });
  }

  function updateOptions(focusedEl) {
    if (!focusedEl) {
      return;
    }

    var currentView = navigation.currentView();
    var inputEl = null;

    if ('view-contact-details' === currentView) {
      try {
        inputEl = focusedEl.querySelector('input[type^=t], input[type^=e]');
        inputEl.focus();
        var inputLength = inputEl.value.length;
        if (inputLength) {
          inputEl.setSelectionRange(inputLength, inputLength);
        }
      } catch (e) {
        (focusedEl = document.querySelector('input:focus')) && focusedEl.blur();
      }
      return;
    } else if ('view-contacts-list' === currentView) {
      inputEl = focusedEl.querySelector('input[type="search"]');
      if (selectionMode) {
        focusedEl.focus();
      } else if (focusedEl.classList.contains('contact-item')) {
        currentItem = focusedEl;
      }
      inputEl && inputEl.focus();
      if (OptionHelper.getLastParamName() === 'contact-list') {
        if (inputEl) {
          inputEl.focus();
          if (!contactsListOptionSwitched  &&
              'contacts' === TabNavigation.getCurrentTab()) {
            swapListOptionParams(false);
            OptionHelper.safeSetVisibility(false,
                'contact-list', 'Call', true);
            OptionHelper.safeSetVisibility(false,
                'contact-list', 'SendMessage', true);
            OptionHelper.safeSetVisibility(false,
                'contact-list', 'SendEmail', true);
            contactsListOptionSwitched = true;
          }
        } else {
          focusedEl.focus();
          if (!menuVisible) {
            if (contactsListOptionSwitched) {
              swapListOptionParams(true);
              contactsListOptionSwitched = false;
            }
            var noTel = focusedEl.classList.contains('no-tel');
            OptionHelper.safeSetVisibility(!noTel,
                'contact-list', 'Call', true);
            OptionHelper.safeSetVisibility(!noTel,
                'contact-list', 'SendMessage', true);
            var noEmail = focusedEl.classList.contains('no-email');
            OptionHelper.safeSetVisibility(!noEmail,
                'contact-list', 'SendEmail', true);
          }
        }
      } else if (OptionHelper.getLastParamName() === 'contact-list-empty') {
        (contacts.List.isICEContactsExist() ||
            focusedEl.dataset.group === 'ice') ?
            OptionHelper.safeSetVisibility(true,
                'contact-list-empty', 'ICESelect', true) :
            OptionHelper.safeSetVisibility(false,
                'contact-list-empty', 'ICESelect', true);
      } else if (['add-speed-dial','save-speed-dial', 'save-ice-contact']
          .indexOf(OptionHelper.getLastParamName()) > -1) {
        if (inputEl) {
          OptionHelper.safeSetVisibility(false,
                OptionHelper.getLastParamName(), 'View', true);
          OptionHelper.safeSetVisibility(false,
                OptionHelper.getLastParamName(), 'Select', true);
        } else {
          OptionHelper.safeSetVisibility(true,
                OptionHelper.getLastParamName(), 'View', true);
          OptionHelper.safeSetVisibility(true,
                OptionHelper.getLastParamName(), 'Select', true);
        }
      } else if (OptionHelper.getLastParamName() ===
          'contact-list-select-phone') {
        if (inputEl) {
          OptionHelper.hideMenu();
        } else {
          OptionHelper.showMenu();
          OptionHelper.safeSetVisibility(true,
              OptionHelper.getLastParamName(), 'Select', true);
          OptionHelper.safeSetVisibility(true,
              OptionHelper.getLastParamName(), 'View', true);
        }
      } else if (OptionHelper.getLastParamName() ===
          'contact-add-to-existing') {
        if (inputEl) {
          OptionHelper.safeSetVisibility(false,
              OptionHelper.getLastParamName(), 'Select', true);
          OptionHelper.safeSetVisibility(false,
              OptionHelper.getLastParamName(), 'View', true);
        } else {
          OptionHelper.safeSetVisibility(true,
              OptionHelper.getLastParamName(), 'Select', true);
          OptionHelper.safeSetVisibility(true,
              OptionHelper.getLastParamName(), 'View', true);
        }
      }
    }

    if (isSpeedDialTab() && !menuVisible) {
      selectedSpeedDial = contactsList.getSelectedSpeedDial();
      setSpeedDialSoftkey(focusedEl);
    }

    if (isContactListTab() && !menuVisible) {
      selectedContact = focusedEl;

      var id = selectedContact && selectedContact.getAttribute('data-uuid');
      if (!id) {
        return;
      }
      contacts.List.getContactById(id, function findCb(contact, fbContact) {
        currentContact = contact;
        currentFbContact = fbContact;
      });
    }
  }

  var initContactsList = function initContactsList() {
    if (contactsList) {
      if (!contactsImporting && importBatchContacts) {
        navigation.pushOptionMenu('contact-list', 'view-contacts-list');
        NavigationManager.reset(NavigationManager.currentSelector);
      }
      return;
    }
    contactsList = contactsList || contacts.List;
    var list = document.getElementById('groups-list');
    contactsList.init(list);
    getFirstContacts();
    sdLoader = contactsList.getAllSpeedDials();
    contactsList.initAlphaScroll();
    checkCancelableActivity();
    document.querySelector('#view-contacts-list article')
        .classList.add('view-body-visible');
  };

  function pushContactListOptionMenu(e) {
    showNoContacts = e.detail.showNoContacts;
    if (isSpeedDialTab() ||
        replacementMode ||
        CustomDialog.isVisible ||
        importBatchContacts ||
        (contacts.BulkDelete && contacts.BulkDelete.isDeleting)) {
      return;
    }

    setContactSoftkey(showNoContacts);
  }

  function setContactSoftkey(showNoContacts) {
    searchEnable = true;
    if (!showNoContacts) {
      if (ActivityHandler && ActivityHandler._currentActivity) {
        return;
      }
      navigation.pushOptionMenu('contact-list', 'view-contacts-list');
      if (!(selectionMode || contacts.List.isSelecting) && contacts.List.isIceContactFocused()){
        OptionHelper.show('contact-list-empty');
        searchEnable = false;
      }
    } else {
      navigation.pushOptionMenu('contact-list-empty', 'view-contacts-list');
      searchEnable = false;
      document.querySelector('section#view-contacts-list .info').focus();
    }

  }

  function setSpeedDialSoftkey(focusedEl) {
    if (replacementMode === 'tel') {
      if (focusedEl) {
        if (focusedEl.querySelector('[data-l10n-id="empty"]')) {
          navigation.pushOptionMenu('add-speed-dial', 'view-contacts-list');
        } else {
          navigation.pushOptionMenu('replace-speed-dial',
              'view-contacts-list');
          if (focusedEl.querySelector('p .p-sec')) {
            OptionHelper.safeSetVisibility(true,
                'replace-speed-dial', 'View', true);
          } else {
            OptionHelper.safeSetVisibility(false,
                'replace-speed-dial', 'View', true);
          }
        }
      }
      return;
    }

    var viewId = 'view-contacts-list';
    if (contacts.List.isVoiceMailFocused()) {
      navigation.pushOptionMenu('voice-mail', viewId);
    } else if (contactsList.isNotSelected()) {
      navigation.pushOptionMenu('not-selected', viewId);
    } else {
      navigation.pushOptionMenu('speed-dial-list', viewId);
    }
  }

  function tabChangedHandler(evt) {
    var tabName = evt.detail.tabName;
    var selector = navigation.getNavigationSelector('view-contacts-list');

    switch (tabName) {
    case 'contacts':
      document.getElementById('groups-container').setAttribute('role', 'heading');
      document.getElementById('speed-dial-container').removeAttribute('role');
      if (!replacementMode) {
        navigation.pushOptionMenu(showNoContacts ? 'contact-list-empty' : 'contact-list', 'view-contacts-list');
      }
      window.NavigationManager.switchContext(selector);
      break;

    case 'speed-dial':
      document.getElementById('speed-dial-container').setAttribute('role', 'heading');
      document.getElementById('groups-container').removeAttribute('role');
      window.NavigationManager.switchContext(selector);
      setSpeedDialSoftkey();
      break;
    }
  }

  var setReplacementMode = function setReplacementMode(optionId, mode) {
    if (replacementMode) {
      return;
    }
    replacementMode = mode;

    switch (replacementMode) {
    case 'contact':
      if (!selectedSpeedDial) {
        return;
      }
      if (!contacts.List.isContactsExist()) {
        TabNavigation.disabled(true);

        var deleteDialogConfig = {
          title: {id: 'tcl-attention', args: {}},
          body: {id: 'tcl-speed-dial-add-contact', args: {}},
          backcallback: function() {},
          accept: {
            l10nId: 'ok',
            callback: function() {
              TabNavigation.enabled(true);
              CustomDialog.hide();
              if (ActivityHandler.currentlyHandling) {
                var activityName = ActivityHandler.activityName;
                if (activityName === 'add-speed-dial') {
                  ActivityHandler.postCancel();
                }
              }
            }
          }
        };
        var dialog = new ConfirmDialogHelper(deleteDialogConfig);
        dialog.show(document.getElementById('app-dialog'));
        replacementMode = null;

        return;
      }
      appTitleElement.dataset.l10nId = 'select-a-contact-title';
      contacts.List.toggleICEGroup(false);
      TabNavigation.hideTab('speed-dial');
      var selector = navigation.getNavigationSelector('view-contacts-list', 'contacts');

      navigation.pushOptionMenu(optionId, 'view-contacts-list');
      contacts.List.resetListContextToFirstContact().then((nodes) => {
        NavigationManager.resetByNode(selector, nodes[0]);
        resetLatestSelector();
      });
      break;

    case 'tel':
      TabNavigation.hideTab('contacts');
      resetLatestSelector();
      break;
    }
  };

  var resetReplacementMode = function resetReplacementMode() {
    var mode = replacementMode;
    replacementMode = null;

    switch (mode) {
    case 'contact':
      TabNavigation.showTab('speed-dial');
      TabNavigation.selectTab('speed-dial');
      break;

    case 'tel':
      speedDialPhone = null;

      var focusedEl = NavigationManager.getFocusedEl();
      updateOptions(focusedEl);
      break;
    }
  };

  var setSpeedDial = function setSpeedDial(callback) {
    if (!selectedSpeedDial || document.activeElement.name == 'search') {
      return;
    }
    var speedDial = selectedSpeedDial;
    contactsList.setSpeedDial(speedDial, speedDialPhone, function (changed) {
      if (assignSpeedDial) {
        showNotification('tcl-notification-contact-assigned');
      } else {
        changed &&  showNotification('tcl-notification-speed-dial-' + changed);
      }
      appTitleElement.setAttribute('data-l10n-id', 'contacts');
      contacts.List.toggleICEGroup(true);
      Contacts.resetReplacementMode();
      if (Contacts.isSearchMode() || contacts.Search.isInSearchMode()) {
        contacts.Search.resetSearchHidenView();
      }
      if (assignSpeedDial && ActivityHandler.currentlyHandling) {
        var activityName = ActivityHandler.activityName;
        if (activityName === 'add-speed-dial') {
          ActivityHandler.postPickSuccess(contacts.List.getSpeedDial(speedDial));
        }
      }
    });
  };

  var removeSpeedDial = function removeSpeedDial() {
    if (!selectedSpeedDial) {
      return;
    }

    contactsList.removeSpeedDial(selectedSpeedDial, function (isRemoved) {

      isRemoved && showNotification('tcl-notification-speed-dial-removed');
      // we have to refresh softkey panel for replaced item
      var focused = NavigationManager.getFocusedEl();

      updateOptions(focused);
    });
  };

  function showNotification(messageL10nId) {
    Toaster.showToast({
      messageL10nId: messageL10nId,
      latency: 2000,
    });
  }

  function setupCancelableHeader(alternativeTitle) {
    settingsButton && (settingsButton.hidden = true);
    addButton && (addButton.hidden = true);
    if (alternativeTitle) {
      appTitleElement.setAttribute('data-l10n-id', alternativeTitle);
    }
    // Trigger the title to re-run font-fit/centering logic
    appTitleElement.textContent = appTitleElement.textContent;
  }

  function setupActionableHeader() {
    header.removeAttribute('action');
    if (settingsButton && addButton) {
      settingsButton.hidden = false;
      addButton.hidden = false;
    }

    appTitleElement.setAttribute('data-l10n-id', 'contacts');
  }

  var setCancelableHeader = function setCancelableHeader(cb, titleId) {
    setupCancelableHeader(titleId);
    setHeaderCallback(cb);
  };

  var setNormalHeader = function setNormalHeader() {
    setupActionableHeader();
    setHeaderCallback(handleBack);
  };

  function setHeaderCallback(cb) {
    header.removeEventListener('action', currentHeaderCb);
    currentHeaderCb = cb;
    header.addEventListener('action', currentHeaderCb);
  }

  var setSelectModeClass = function (element, activityName, activityType) {
    var classesByType = SELECT_MODE_CLASS[activityName] || {};
    activityType = Array.isArray(activityType) ? activityType : [activityType];
    activityType.forEach(function (type) {
      var classesToAdd = classesByType[type];
      if (classesToAdd) {
        element.classList.add.apply(element.classList, classesToAdd);
      }
    });
  };

  var checkCancelableActivity = function cancelableActivity() {
    if (ActivityHandler.currentlyHandling) {
      // var alternativeTitle = null;
      var activityName = ActivityHandler.activityName;
      if (activityName === 'pick') {
        selectionMode = true;
        navigation.pushOptionMenu('contact-list-select-phone',
          navigation.currentView(), true);
        TabNavigation.hideTab('speed-dial');
        appTitleElement.dataset.l10nId = 'select-a-contact-title';
        hideTabNavigation();
        if ('webcontacts/email' === ActivityHandler.activityDataType) {
          var actionListContainer = contacts.List.phoneSelectionList.getContainer();
          if (actionListContainer) {
            actionListContainer.querySelector('.header')
                .setAttribute('data-l10n-id', 'select-email');
          }
        }
      } else if (activityName === 'update') {
        TabNavigation.hideTab('speed-dial');
        appTitleElement.dataset.l10nId = 'select-a-contact-title';
        hideTabNavigation();
      } else if (activityName === 'speed-dial-list') {
        var activityParams = ActivityHandler.activityData.params;
        if (!activityParams || !activityParams.hasOwnProperty('number')) {
          appTitleElement.dataset.l10nId = 'select-a-number-title';
          hideTabNavigation();
        }
      }
      var groupsList = document.getElementById('groups-list');
      setSelectModeClass(groupsList, activityName,
        ActivityHandler.activityDataType);
      // setupCancelableHeader(alternativeTitle);
    } else {
      setupActionableHeader();
    }
  };

  function hideTabNavigation() {
    var viewBody = document.querySelector('#view-contacts-list > .view-body');
    viewBody.classList.add('hide-tab');
  }

  function showTabNavigation() {
    var viewBody = document.querySelector('#view-contacts-list > .view-body');
    viewBody.classList.remove('hide-tab');
  }

  function removeContactClickHandler(e) {
    if (navigation.currentView() === 'view-contacts-list' && !selectionMode) {
      var dialogs = document.querySelectorAll('form[role="dialog"].visible');
      if (dialogs.length < 1) {
        removeContactFormList();
      }

    }
  }
  var removeContactFormList = function removeContactFormList(id) {
    if (replacementMode || showNoContacts) {
      return;
    }
    if (!id) {
      id = selectedContact && selectedContact.getAttribute('data-uuid');
      if (!id) {
        return;
      }
    }
    var contactsRemoverObj = new contactsRemover();
    contacts.List.getContactById(id, function onSuccess(currentContact) {
      getDisplayContactName(currentContact, function (type) {
        var deleteMsgId = 'view-contacts-list' === navigation.currentView() ?
            'delecting-this-contact' : 'delecting-messages-contact';
        var deleteDialogConfig = {
          title: {id: 'confirm-dialog-title-default', args: {}},
          body: {id: deleteMsgId, args: {
            'type_name': type
          }},
          backcallback: function() {},
          cancel: {
            l10nId: 'cancel',
            callback: function() {}
          },
          confirm: {
            l10nId: 'delete',
            callback: function() {
              contactsRemoverObj.init([id], function onInitDone() {
                contactsRemoverObj.start();
              });
            }
          }
        };
        var dialog = new ConfirmDialogHelper(deleteDialogConfig);
        dialog.show(document.getElementById('app-dialog'));

      });

    }, function onError() {
      console.error('Error retrieving contact');
    });

    contactsRemoverObj.onDeleted = function onDeleted(currentId) {
      Toaster.showToast({
        messageL10nId: 'tcl-contact-removed',
        latency: 2000,
      });
    };

    contactsRemoverObj.onError = function onError(currentId) {
      Toaster.showToast({
        messageL10nId: 'tcl-contact-removed',
        latency: 2000,
      });
    };
  };

  var getDisplayContactName = function getDisplayContactName(contact, callback) {
    var result = utils.extractValue(contact.name) ||
      utils.extractValue(contact.tel) ||
      utils.extractValue(contact.email) || '';
    if (typeof callback === 'function') {
      callback(result);
    }
    return result ? result : null;
  };

  var contactListClickHandler = function originalHandler(id) {
    if (replacementMode || selectionMode) {
      return;
    }

    if (!id) {
      id = selectedContact && selectedContact.getAttribute('data-uuid');
      if (!id) {
        return;
      }
    }
    initDetails(function onDetailsReady() {
      console.log('try to find contact by id - ' + id);
      contacts.List.getContactById(id, function findCb(contact, fbContact) {
        // Enable NFC listening is available
        if ('mozNfc' in navigator) {
          contacts.NFC.startListening(contact);
        }
        currentContact = contact;
        currentFbContact = fbContact;

        if (ActivityHandler.currentActivityIsNot(['import']) &&
            ActivityHandler.currentActivityIsNot(['list'])) {
          if (ActivityHandler.currentActivityIs(['pick'])) {
            ActivityHandler.dataPickHandler(currentFbContact || currentContact);
          }
          return;
        }
        contactsDetails.render(currentContact, currentFbContact);
        navigation.go('view-contact-details', 'fade-in');
        if (Contacts.viewdetailMode) {
          OptionHelper.show('replace-speed-dial-detail');
          Contacts.viewdetailMode = false;
        }
        /*
        //todo show form edi mode here
        if (contacts.Search && contacts.Search.isInSearchMode()) {
          navigation.go('view-contact-details', 'fade-in');//'go-deeper-search');
        } else {
          navigation.go('view-contact-details', 'fade-in');//'go-deeper');
        }*/
      });
    });
  };

  var sendMessageFromContactList = function sendMessageFromContactList() {
    contactsList.selectPhoneNumberMenu(selectedContact, 'send');
  };

  var sendEmailFromContactList = function sendEmailFromContactList() {
    if (selectedContact.dataset.uuid) {
      contactsList.selectPhoneNumberMenu(selectedContact, 'email');
    }
  };

  var callNumberFromContactList = function callNumberFromContactList() {
    if (isSpeedDialTab()) {
      contactsList.callNumber();
    } else {
      contactsList.selectPhoneNumberMenu(selectedContact, 'call');
    }
  };

  var shareContactFromContactList = function shareContactFromContactList() {
    loadDetailsForShare(function() {
      var data = ActivityHandler.activityData,
          uuid = data && data.params && data.params.id ?
          data.params.id : selectedContact.dataset.uuid;
      contactsList.getContactById(uuid, function (contact) {
        contacts.Details.setContact(contact);
        contacts.Details.shareContact();
      });
    });
  };

  var loadDetailsForShare = function loadDetailsForShare(callback) {
    if (!contacts.Details) {
      LazyLoader.load([
        '/contacts/js/views/details.js',
        ], () => {
          callback();
        });
    } else {
      callback();
    }
  };

  var isContactMainPage = function isContactMainPage() {
    if (Contacts.navigation.currentView() === 'view-contacts-list') {
      return true;
    }
    return false;
  };

  var updateContactDetail = function updateContactDetail(id) {
    contactsList.getContactById(id, function findCallback(contact) {
      currentContact = contact;
      contactsDetails.render(currentContact);
    });
  };

  var getContactForAnotherActivity = function getContactForAnotherActivity() {
    ActivityHandler.dataPickHandler(currentContact);
  };

  var addToExistingContact =
      function addToExistingContact(params, fromUpdateActivity) {
    contactsList.clearClickHandlers();
    // contactsList.handleClick(addToContactHandler);
    addToExistingCallback = addToContactHandler;
    globalParams = params;
    navigation.pushOptionMenu('contact-add-to-existing',
      navigation.currentView());
  };

  var addToContactHandler = function addToContactHandler() {
    var params = globalParams;
    var fromUpdateActivity = ActivityHandler.currentActivityIs('update');
    var data = {};
    if (params.hasOwnProperty('tel')) {
      var phoneNumber = params.tel;
      data.tel = [{
        'value': phoneNumber,
        'carrier': null,
        'type': [TAG_OPTIONS['phone-type'][0].type]
      }];
    }
    if (params.hasOwnProperty('email')) {
      var email = params.email;
      data.email = [{
        'value': email,
        'type': [TAG_OPTIONS['email-type'][0].type]
      }];
    }
    var hash = '#view-contact-form?extras=' +
    encodeURIComponent(JSON.stringify(data)) + '&id=' +
    selectedContact.dataset.uuid;
    if (fromUpdateActivity) {
      hash += '&fromUpdateActivity=1';
    }
    window.location.hash = null;
    window.location.hash = hash;
  };

  var getLength = function getLength(prop) {
    if (!prop || !prop.length) {
      return 0;
    }
    return prop.length;
  };

  var updatePhoto = function updatePhoto(photo, dest) {
    var background = '';
    if (photo != null) {
      background = 'url(' + URL.createObjectURL(photo) + ')';
    }
    /*dest.style.backgroundImage = background;
    // Only for testing purposes
    dest.dataset.photoReady = 'true';*/
  };

  // Checks if an object fields are empty, by empty means
  // field is null and if it's an array it's length is 0
  var isEmpty = function isEmpty(obj, fields) {
    if (obj == null || typeof (obj) != 'object' ||
      !fields || !fields.length) {
      return true;
    }
    var attr;
    for (var i = 0; i < fields.length; i++) {
      attr = fields[i];
      if (obj[attr]) {
        if (Array.isArray(obj[attr])) {
          if (obj[attr].length > 0) {
            return false;
          }
        } else {
          return false;
        }
      }
    }
    return true;
  };

  function getTagType(contactTag) {
    var tagList = contactTag && contactTag.dataset.taglist;
    return tagList && tagList.split('-')[0];
  }

  function showSelectTag(callback) {
    var tagsList = document.getElementById('tags-list');
    var type = getTagType(contactTag);
    if (NavigationMap.currentActivatedLength > 0) {
      return;
    }
    var options = [];

    var promise = Promise.resolve();
    if (type === 'ringtone') {
      promise = utils.RingtoneHelper.getRingtones().then(function (files) {
        options = files.map(i => {
          return {
            'value': i.getFilename(),
            'key': i.getFullname(),
          };
        })
        .sort((item1, item2) =>
          item1.value > item2.value ? 1 :
            (item1.value < item2.value ? -1 : 0)
        );

      });
    } else {
      promise.then(function () {
        options = TAG_OPTIONS[contactTag.dataset.taglist].slice();
      });
    }

    promise.then(function () {

      if (type === 'date') {
        options = changeDateOptions(options);
      }

      if (type === 'ringtone' && contactTag && !contactTag.dataset.value) {
        contactTag.dataset.value = (options[0] && options[0].value) || '';
      }

      options = ContactsTag.filterTags(type, contactTag, options);

      ContactsTag.fillTagOptions(tagsList, contactTag, options);

      if (!typeChanged) {
        typeChanged = document.getElementById('tags-list');
        typeChanged.addEventListener('type-changed', handleSelectTagDone);
      }

      navigation.go('view-select-tag', 'right-left');
      if (document.activeElement) {
        document.activeElement.blur();
      }

      NavigationManager.resetByNode('.tagContainer', ContactsTag.defaultFocused);
      NavigationManager.getFocusedEl().scrollIntoView();

      callback && callback();
    });
  }

  function selectRingtone(evt) {
    var el = evt.detail.focusedElement;
    var item = el && el.getElementsByClassName('tagItem');
    if (item && item[0]) {
      var ringtone = item[0].dataset.key;
      utils.RingtoneHelper.play(ringtone);
    }
  }

  function changeDateOptions(options) {
    var dateInputs = document.querySelectorAll('[data-option-name^="date-type-options"]:not([hidden])'),
      dataValue;

    function changeOptions(inputsLength) {
      var i = 0;
      if (inputsLength) {
        if (isAddTypePage) {
          dataValue = dateInputs[0].querySelector('span.date-type').dataset.value;
        } else {
          var focusField = NavigationManager.getElementByNavId(
              NavigationManager.context[navigation.getNavigationSelector('view-contact-form')]);
          for (i = 0; i < inputsLength; i++) {
            if (dateInputs[i] != focusField) {
              dataValue = dateInputs[i].querySelector('span.date-type').dataset.value;
              break;
            }
          }
        }
        for (i = 0; i < options.length; i++) {
          if (options[i].type == dataValue) {
            options.splice(i, 1);
            break;
          }
        }
      }
    }

    if (isAddTypePage) {
      changeOptions(dateInputs.length);
    } else {
      if (dateInputs.length == 2) {
        changeOptions(dateInputs.length);
      }
    }
    return options;
  }

  var goToSelectTag = function goToSelectTag(field, addTypePage, callback) {
    contactTag = field;
    isAddTypePage = addTypePage;

    var tagViewElement = document.getElementById('view-select-tag');
    if (!lazyLoadedTagsDom) {
      LazyLoader.load(tagViewElement, function () {
        showSelectTag(callback);
        lazyLoadedTagsDom = true;
      });
    } else {
      showSelectTag(callback);
    }
  };

  var sendSms = function sendSms(number) {
    if (!ActivityHandler.currentlyHandling ||
      ActivityHandler.currentActivityIs(['open']) ||
      ActivityHandler.currentActivityIs(['list'])) {
      SmsIntegration.sendSms(number);
    }
  };

  var sendMsg = function sendMsg(number) {
    LazyLoader.load(
      [SHARED_UTILS_PATH + '/misc.js',
       '/shared/js/dialer/telephony_helper.js',
       '/shared/js/contacts/sms_integration.js',
       '/shared/js/contacts/contacts_buttons.js'
      ],
      function () {
        SmsIntegration.sendSms(number);
      });
  };

  function handleBack(cb) {
    navigation.back(cb);
  }

  var handleCancel = function handleCancel() {
    //If in an activity, cancel it

    var dialogs = document.querySelectorAll('form[role="dialog"].visible');

    if (ActivityHandler.currentlyHandling) {
      ActivityHandler.postCancel();
      navigation.home();
    } else if (dialogs.length > 0) {
      CustomDialog.hide();
      OptionHelper._initSoftKeyPanel();
      OptionHelper.softkeyPanel.show();
    }
    /*else if (navigation.stack.length == 1 &&
      navigation.stack[0].view == "view-contacts-list") {
      //window.close();
    } */
    else {
      handleBack();
    }
  };

  var stopPlayer = function () {
    document.removeEventListener('focusChanged', selectRingtone);
    utils.RingtoneHelper.stop();
  };

  var renderRingtone = function (filename, value) {
    if (!value) {
      return;
    }
    var ringtoneDetail = document.getElementById('contact-detail-ringtone-area');
    var field = ringtoneDetail.querySelector('span.ringtone-type');

    field.dataset.value = value;
    field.dataset.key = value;
    field.textContent = filename;

    contacts.Form.showRingtone();
  };

  var handleSelectTagDone = function handleSelectTagDone(event) {
    var tag = document.querySelector('.focus span');
    var viewName = navigation.stack[navigation.stack.length - 2].view;
    var navigationSelector = navigation.getNavigationSelector(viewName);
    ContactsTag.selectTag(tag);
    ContactsTag.clickDone(function () {
      var type = getTagType(contactTag);
      var dateField;

      if (type === 'date') {
        contacts.Form.changeAddDateState();
      }
      if (type === 'ringselect') {
        handleBack();
        if (tag.dataset.l10nId === 'moremusic') {
          RingtoneField.selectRing();
        } else {
          var toneId;
          var toneSpan = document.querySelector('.ringtone-type');
          var detailRingtone = document.querySelector('.contact-detail-ringtone');
          if (toneSpan &&
              toneSpan.dataset &&
              toneSpan.dataset.value !== '' &&
              !detailRingtone.classList.contains('hide') &&
              toneSpan.dataset.value.indexOf('builtin:ringtone') > -1) {
            toneId = toneSpan.dataset.value;
          } else {
            toneId = default_ring_tone;
          }
          var activity = new MozActivity({
            name: 'pick',
            data: {
              type: 'ringtone',
              allowNone: false,
              currentToneID: toneId
            }
          });
          activity.onsuccess = function() {
            var result = activity.result;
            if (result.blob) {
              Contacts.renderRingtone(result.name, result.id);
              var ringToneField = document.querySelector('.input-container.contact-detail-ringtone');
              NavigationManager.reset(NavigationManager.currentSelector);
              if (ringToneField) {
                NavigationManager.reset(NavigationManager.currentSelector, ringToneField.dataset.navId);
                NavigationManager.getFocusedEl().scrollIntoView();
              }
              contacts.Form.clearTextFieldCache();
              contacts.Form.checkDisableButton();
            }
          };
        return;
        }
      }
      if (type === 'ringtone') {
        contacts.Form.showRingtone();
      }
      var inputContainer = contactTag.closest(navigationSelector);
      if (!inputContainer) {
        inputContainer = contactTag.closest('[class ^= contact-detail]').querySelector(navigationSelector);
      }
      NavigationManager.update(navigationSelector);
      var navId = inputContainer && inputContainer.dataset.navId;
      var oldNavId = NavigationManager.context[navigationSelector];
      NavigationManager.context[navigationSelector] = navId;
      inputContainer.scrollIntoView();
      if (inputContainer.querySelector('input[type="date"]')) {
        contacts.Form.changeAddDateState();
      }
      if (EditTypeField.returnIsEdit() || isSettingsPage()) {

        handleBack();
      } else {
        if (type === 'date') {
          dateField = inputContainer.querySelector('input[type="date"]');
          window.addEventListener('keyup', function keyupHandler(e) {
            switch (e.key) {
            case 'BrowserBack':
            case 'Backspace':
            case 'SoftLeft':
              window.removeEventListener('keyup', keyupHandler);
              inputContainer.remove();
              contacts.Form.changeAddDateState();
              NavigationManager.reset(NavigationManager.currentSelector, oldNavId);
              NavigationManager.getFocusedEl().scrollIntoView();
              break;
            case 'Enter': //keyboard key
            case 'Accept': //emulator key
              if (dateField.value) {
                window.removeEventListener('keyup', keyupHandler);
              }
              break;
            case 'F5':
              window.removeEventListener('keyup', keyupHandler);
              break;
            }
          });
        }
        handleBack(function () {
          contacts.Form.clearTextFieldCache();
          contacts.Form.checkDisableButton();
          if (dateField) {
            dateField.focus();
          }
        });
      }

    });
  };

  var sendEmailOrPick = function sendEmailOrPick(address) {
    try {
      // We don't check the email format, lets the email
      // app do that
      new MozActivity({
        name: 'new',
        data: {
          type: 'mail',
          URI: 'mailto:' + address
        }
      });
    } catch (e) {
      console.error('WebActivities unavailable? : ' + e);
    }
  };

  var showAddContact = function showAddContact() {
    showForm();
  };

  var loadFacebook = function loadFacebook(callback) {
    LazyLoader.load([
      '/contacts/js/fb_loader.js',
      '/contacts/js/fb/fb_init.js'
    ], () => {
      if (!fbLoader.loaded) {
        fb.init(function onInitFb() {
          window.addEventListener('facebookLoaded', function onFbLoaded() {
            window.removeEventListener('facebookLoaded', onFbLoaded);
            callback();
          });
          fbLoader.load();
        });
      } else {
        callback();
      }
    });
  };

  var initForm = function c_initForm(callback) {
    if (formReady) {
      callback();
    } else {
      initDetails(function onDetails() {
        LazyLoader.load([
            SHARED_UTILS_PATH + '/misc.js',
            '/shared/js/contacts/utilities/image_thumbnail.js'
          ],
          function () {
            Contacts.view('Form', function viewLoaded() {
              formReady = true;
              contactsForm = contacts.Form;
              contactsForm.init(TAG_OPTIONS);
              callback();
            });
          });
      });
    }
  };

  var initSettings = function c_initSettings(callback) {
    if (settingsReady) {
      callback();
    } else {
      Contacts.view('Settings', function viewLoaded() {
        LazyLoader.load(['/contacts/js/utilities/sim_dom_generator.js',
          '/contacts/js/utilities/normalizer.js',
          SHARED_UTILS_PATH + '/misc.js',
          '/shared/js/mime_mapper.js',
          SHARED_UTILS_PATH + '/vcard_parser.js',
          '/contacts/js/utilities/icc_handler.js',
          SHARED_UTILS_PATH + '/sdcard.js',
          '/shared/js/date_time_helper.js'
        ], function () {
          settingsReady = true;
          contacts.Settings.init();
          callback();
        });
      });
    }
  };

  var initDetails = function c_initDetails(callback) {
    if (detailsReady) {
      callback();
    } else {
      Contacts.view('Details', function viewLoaded() {
        LazyLoader.load(
          [SHARED_UTILS_PATH + '/misc.js',
            '/shared/js/dialer/telephony_helper.js',
            '/shared/js/contacts/sms_integration.js',
            '/shared/js/contacts/contacts_buttons.js'
          ],
          function () {
            detailsReady = true;
            contactsDetails = contacts.Details;
            contactsDetails.init();
            callback();
          });
      });
    }
  };

  var showForm = function c_showForm(edit, contact) {
    currentContact = contact || currentContact;
    initForm(function onInit() {
      doShowForm(edit);
    });
  };

  var doShowForm = function c_doShowForm(edit) {
    var contact = edit ? currentContact : null;
    if (contact && fb.isFbContact(contact)) {
      var fbContact = new fb.Contact(contact);
      var req = fbContact.getDataAndValues();

      req.onsuccess = function () {
        contactsForm.render(contact, goToForm, req.result);
      };

      req.onerror = function () {
        contactsForm.render(contact, goToForm);
      };
    } else {
      contactsForm.render(contact, goToForm);
    }
  };

  var setCurrent = function c_setCurrent(contact) {
    currentContact = contact;
    if ('mozNfc' in navigator && contacts.NFC) {
      contacts.NFC.startListening(contact);
    }
    if (contacts.Details) {
      contacts.Details.setContact(contact);
    }
  };

  var showOverlay = function c_showOverlay(messageId, progressClass, textId) {
    var out = utils.overlay.show(messageId, progressClass, textId);
    // When we are showing the overlay we are often performing other
    // significant work, such as importing.  While performing this work
    // it would be nice to avoid the overhead of any accidental reflows
    // due to touching the list DOM.  For example, importing incrementally
    // adds contacts to the list which triggers many reflows.  Therefore,
    // minimize this impact by hiding the list while we are showing the
    // overlay.
    contacts.List.hide();
    return out;
  };

  var hideOverlay = function c_hideOverlay() {
    Contacts.utility('Overlay', function _loaded() {
      contacts.List.show();
      utils.overlay.hide();
    }, SHARED_UTILS);
  };

  var showStatus = function c_showStatus(messageId, additionalId) {

    Toaster.showToast(messageId);

    if (additionalId) {
      setTimeout(() => {
        Toaster.showToast(additionalId);
      }, 2500);
    }

  };

  var showSettings = function showSettings() {
    initSettings(function onSettingsReady() {
      // The number of FB Friends has to be recalculated
      contacts.Settings.refresh().then(function() {
        navigation.go('view-contacts-settings', 'right-left');
        NavigationManager.getFocusedEl().scrollIntoView();
      });
    });
  };

  var stopPropagation = function stopPropagation(evt) {
    evt.preventDefault();
  };
  /*
  var enterSearchMode = function enterSearchMode(evt, initVal) {
      console.log('search activated');
      !searchActivated && Contacts.view('Search', function viewLoaded() {k
          console.log(contacts.Search);
          searchActivated = true;
          contacts.Search.onInput(evt, true);
          contacts.List.initSearch(function onInit() {
              var searchList = document.getElementById('search-list'),
                  activityName = ActivityHandler.activityName,
                  activityType = ActivityHandler.activityDataType;
              setSelectModeClass(searchList, activityName, activityType);
              contacts.Search.enterSearchMode(evt, initVal);
          });
      }, SHARED_CONTACTS);
      searchActivated && contacts.Search.onInput(evt, true);
  };*/

  var initEventListeners = function initEventListener() {
    // Definition of elements and handlers
    utils.listeners.add({
      '#contacts-list-header': [{
        event: 'action',
        handler: currentHeaderCb // Activity (any) cancellation
      }],
      '#add-contact-button': showAddContact,
      '#settings-button': showSettings, // Settings related
      /*'#search-start': [{
          event: 'click',
          handler: enterSearchMode
      }],
      // For screen reader users
      '#search-start > input': [{
          event: 'focus',
          handler: enterSearchMode
      }],*/
      'button[type="reset"]': stopPropagation
    });
  };

  var getFirstContacts = function c_getFirstContacts() {
    var onerror = function () {
      console.error('Error getting first contacts');
    };
    contactsList = contactsList || contacts.List;
    deferredLoad.promise.then(function() {
      contactsList.getAllContacts(onerror);
    });
  };

  var addAsyncScripts = function addAsyncScripts() {
    var lazyLoadFiles = [
      '/shared/js/contacts/utilities/templates.js',
      '/shared/js/contacts/contacts_shortcuts.js',
      '/contacts/js/contacts_tag.js',
      '/contacts/js/tag_options.js',
      '/shared/js/text_normalizer.js',
      SHARED_UTILS_PATH + '/status.js',
      '/shared/js/contacts/utilities/dom.js'
    ];

    // Lazyload nfc.js if NFC is available
    if ('mozNfc' in navigator) {
      lazyLoadFiles.push('/contacts/js/nfc.js');
    }

    LazyLoader.load(lazyLoadFiles, function () {
      loadAsyncScriptsDeferred.resolve();
    });
    return loadAsyncScriptsDeferred.promise;
  };

  var pendingChanges = {};

  // This function is called when we finish a oncontactchange operation to
  // remove the op of the pending changes and check if we need to apply more
  // changes request over the same id.
  var checkPendingChanges = function checkPendingChanges(id) {
    var changes = pendingChanges[id];

    if (!changes) {
      return;
    }

    pendingChanges[id].shift();

    if (pendingChanges[id].length >= 1) {
      performOnContactChange(pendingChanges[id][0]);
    }
  };

  navigator.mozContacts.oncontactchange = function oncontactchange(event) {
    if (typeof pendingChanges[event.contactID] !== 'undefined') {
      pendingChanges[event.contactID].push({
        contactID: event.contactID,
        reason: event.reason
      });
    } else {
      pendingChanges[event.contactID] = [{
        contactID: event.contactID,
        reason: event.reason
      }];
    }

    // If there is already a pending request, don't do anything,
    // just wait to finish it in order
    if (pendingChanges[event.contactID].length > 1) {
      return;
    }

    performOnContactChange(event);
  };

  var performOnContactChange = function performOnContactChange(event) {
    var currView = navigation.currentView();
    // To be on the safe side for now we evict the cache everytime a
    // contact change event is received. In the future, we may want to check
    // if the change affects the cache or not, so we avoid evicting it when
    // is not needed.
    Cache.evict();
    initContactsList();
    switch (event.reason) {
    case 'update':
      if (currView != 'import-settings' && !importBatchContacts) {
        showNotification('changes-saved-notification');
      }
      if (currView == 'view-contact-details' && currentContact != null &&
        currentContact.id == event.contactID) {
        contactsList.getContactById(event.contactID,
          function success(contact, enrichedContact) {
            currentContact = contact;
            if (contactsDetails) {
              contactsDetails.setContact(currentContact);
              contactsDetails.update();
            }
            if (contactsList) {
              contactsList.refresh(enrichedContact || currentContact,
                checkPendingChanges, event.reason);
            }
            notifyContactChanged(event.contactID, event.reason);
          });
      } else {
        refreshContactInList(event.contactID);
      }

      if (!isOverlay()) {
        window.dispatchEvent(new CustomEvent('changeContactListMenu', {
          detail: {
            'showNoContacts': false
          }
        }));
      }
      break;
    case 'create':
      if (currView != 'import-settings' && !importBatchContacts) {
        showNotification('tcl-contact-added');
      }
      refreshContactInList(event.contactID, function() {
        window.dispatchEvent(new CustomEvent('changeContactListMenu', {
          detail: {
            'showNoContacts': false
          }
        }));
      });
      break;
    case 'remove':
      if (currentContact != null && currentContact.id == event.contactID &&
        (currView == 'view-contact-details' ||
          currView == 'view-contact-form')) {
        navigation.home();
      }
      contactsList.remove(event.contactID, event.reason);
      contactsList.removeAssignedSpeedDials(event.contactID);
      currentContact = {};
      notifyContactChanged(event.contactID, event.reason);
      if (!contactsList.isContactsExist()) {
        window.dispatchEvent(new CustomEvent('changeContactListMenu', {
          detail: {
            'showNoContacts': true
          }
        }));
      }
      checkPendingChanges(event.contactID);
      break;
    }
    contacts.Search.removeContact(event.contactID);
    if(contacts.Search && contacts.Search.isSearchActive()) {
      contacts.Search.checkEmptySearchSet();
    }
  };

  // Refresh a contact in the list, and notifies of contact
  // changed to possible listeners.
  function refreshContactInList(id, callback) {
    contactsList.refresh(id, function () {
      notifyContactChanged(id);
      callback && callback();
      checkPendingChanges(id);
    });
  }

  // Send a custom event when we know that a contact changed and
  // the contact list was updated.
  // Used internally in places where the contact list is a reference
  function notifyContactChanged(id, reason) {
    document.dispatchEvent(new CustomEvent('contactChanged', {
      detail: {
        contactID: id,
        reason: reason
      }
    }));
  }

  var close = function close() {
    window.removeEventListener('localized', initContacts);
  };

  var initContacts = function initContacts(evt) {
    initContainers();
    initEventListeners();
    utils.PerformanceHelper.contentInteractive();
    utils.PerformanceHelper.chromeInteractive();
    window.setTimeout(Contacts && Contacts.onLocalized);
    if (window.navigator.mozSetMessageHandler && window.self == window.top) {
      LazyLoader.load([SHARED_UTILS_PATH + '/misc.js',
          SHARED_UTILS_PATH + '/vcard_reader.js',
          SHARED_UTILS_PATH + '/vcard_parser.js'
        ],
        function () {
          var actHandler = ActivityHandler.handle.bind(ActivityHandler);
          ActivityHandler._handlingEnabled = true;
          ActivityHandler.initKillReq();
          window.navigator.mozSetMessageHandler('activity', actHandler);
        });
    }

    document.addEventListener('visibilitychange', function visibility(e) {
      if (document.hidden === false &&
        navigation.currentView() === 'view-contacts-settings') {
        Contacts.view('Settings', function viewLoaded() {
          contacts.Settings.updateTimestamps();
        });
      }
    });
  };

  LazyLoader.load('/shared/js/l10n.js', () => {
    navigator.mozL10n.once(() => {
      initContacts();
    });
    navigator.mozL10n.ready(() => {
      Cache.maybeEvict();
    });
    LazyLoader.load('/shared/js/l10n_date.js');
  });

  function loadConfirmDialog() {
    var args = Array.slice(arguments);
    Contacts.utility('Confirm', function viewLoaded() {
      ConfirmDialog.show.apply(ConfirmDialog, args);
    }, SHARED);
  }

  /**
   * Specifies dependencies for resources
   * E.g., mapping Facebook as a dependency of views
   */
  var dependencies = {
    views: {
      Settings: loadFacebook,
      Details: loadFacebook,
      Form: loadFacebook
    },
    utilities: {},
    sharedUtilities: {}
  };

  // Mapping of view names to element IDs
  // TODO: Having a more standardized way of specifying this would be nice.
  // Then we could get rid of this mapping entirely
  // E.g., #details-view, #list-view, #form-view
  var elementMapping = {
    details: 'view-contact-details',
    form: 'view-contact-form',
    settings: 'settings-wrapper',
    search: 'search-view',
    overlay: 'loading-overlay',
    confirm: 'confirmation-message',
    ice: 'ice-view',
    voice_mail: 'view-voice-mail'
  };

  function load(type, file, callback, path) {
    /**
     * Performs the actual lazy loading
     * Called once all dependencies are met
     */
    function doLoad() {
      var name = file.toLowerCase();
      var finalPath = 'js' + '/' + type;

      switch (path) {
      case SHARED:
        finalPath = SHARED_PATH;
        break;
      case SHARED_UTILS:
        finalPath = SHARED_UTILS_PATH;
        break;
      case SHARED_CONTACTS:
        finalPath = SHARED_CONTACTS_PATH;
        break;
      default:
        finalPath = 'js' + '/' + type;
      }

      var toLoad = [finalPath + '/' + name + '.js'];
      var node = document.getElementById(elementMapping[name]);
      if (node) {
        toLoad.unshift(node);
      }

      LazyLoader.load(toLoad, function () {
        if (callback) {
          callback();
        }
      });
    }

    if (dependencies[type][file]) {
      return dependencies[type][file](doLoad);
    }

    doLoad();
  }

  /**
   * Loads a view from the views/ folder
   * @param {String} view name.
   * @param {Function} callback.
   */
  function loadView(view, callback, type) {
    load('views', view, callback, type);
  }

  /**
   * Loads a utility from the utilities/ folder
   * @param {String} utility name.
   * @param {Function} callback.
   */
  function loadUtility(utility, callback, type) {
    load('utilities', utility, callback, type);
  }

  function filterByEmailOrPhone () {
    if (ActivityHandler.activityName === 'pick') {
      var aDataType = ActivityHandler.activityDataType;
      if (aDataType.indexOf('text/vcard') === -1 &&
          aDataType.indexOf('text/x-vcard') === -1 &&
          aDataType.indexOf('webcontacts/select') === -1) {
        var className = aDataType === 'webcontacts/email' ?
            'no-email' : 'no-tel';
        var listGeneral = document.getElementById('groups-list');
        var elements = listGeneral.getElementsByClassName(className);
        for (var i=0; i<elements.length; i++) {
          elements[i].classList.add('hide');
        }
      }
      if (!contacts.List.isContactsExist()) {
        contacts.List.showNoContactsAlert(className);
      }
    }
  }

  var updateSelectCountTitle = function updateSelectCountTitle(count) {
    navigator.mozL10n.setAttributes(editModeTitleElement,
      'SelectedTxt', {
        n: count
      });
  };

  window.addEventListener('DOMContentLoaded', function onLoad() {
    window.removeEventListener('DOMContentLoaded', onLoad);
  });

  var isOverlay = function isOverlay() {
    return !document.getElementById('loading-overlay').classList.contains('hide');
  };

  var isSearchMode = function isSearchMode() {
    return contacts.Search && contacts.Search.isSearchActive();
  };

  var changeVoiceMail = function c_changeVoiceMail() {
    initVoiceMailEditor(function () {
      contacts.VoiceMail.show();
    });
  };

  var initVoiceMailEditor = function c_initVoiceMailEditor(callback) {
    if (voiceMailReady) {
      callback();
    } else {
      Contacts.view('voice_mail', function viewLoaded() {
        voiceMailReady = true;
        contacts.VoiceMail.init(callback);
      });
    }
  };

  var setIceContact = function c_setIceContact() {
    contacts.ICE.selectICEHandler(currentContact.id);
  };

  var getExtensionsFrame = function () {
    !getExtensionsFrame._el && (getExtensionsFrame._el = document.getElementById('fb-extensions'));
    return getExtensionsFrame._el;
  };

  var setExtensionFocus = function () {
    var ext = getExtensionsFrame();
    window.focus();
    if (ext.classList.contains('hidden')) {
      ext.classList.remove('hidden');
      ext.focus();
      setTimeout(() => {
        ext.classList.add('hidden');
      });
    } else {
      ext.focus();
    }
    if (document.activeElement !== ext) {
      window.requestAnimationFrame(setExtensionFocus);
    }
  };

  var setImportBatchContactsMenu = function () {
    navigation.pushOptionMenu('contacts-import-cancel',
        navigation.currentView());
    importBatchContacts = true;
    contactsImporting = true;
  };

  return {
    'goBack': handleBack,
    'cancel': handleCancel,
    'goToSelectTag': goToSelectTag,
    'goToSettings': goToSettings,
    'sendSms': sendSms,
    'navigation': navigation,
    'sendEmailOrPick': sendEmailOrPick,
    'updatePhoto': updatePhoto,
    'checkCancelableActivity': checkCancelableActivity,
    'isEmpty': isEmpty,
    'getLength': getLength,
    'showForm': showForm,
    'setCurrent': setCurrent,
    'onLocalized': onLocalized,
    'init': init,
    'showOverlay': showOverlay,
    'hideOverlay': hideOverlay,
    'showContactDetail': contactListClickHandler,
    'removeContact': removeContactFormList,
    'updateContactDetail': updateContactDetail,
    'showStatus': showStatus,
    'loadFacebook': loadFacebook,
    'confirmDialog': loadConfirmDialog,
    'close': close,
    'view': loadView,
    'utility': loadUtility,
    'updateSelectCountTitle': updateSelectCountTitle,
    'setCancelableHeader': setCancelableHeader,
    'setNormalHeader': setNormalHeader,
    'addNewContact': showAddContact,
    'resetFocusedMnu': resetLatestSelector,
    'setReplacementMode': setReplacementMode,
    'resetReplacementMode': resetReplacementMode,
    'setSpeedDial': setSpeedDial,
    'removeSpeedDial': removeSpeedDial,
    'callNumber': callNumberFromContactList,
    'sendMessage': sendMessageFromContactList,
    'sendMsg': sendMsg,
    'sendEmail': sendEmailFromContactList,
    'shareContact': shareContactFromContactList,
    'isContactMainPage': isContactMainPage,
    'isOverlay': isOverlay,
    'isSpeedDialTab': isSpeedDialTab,
    'isContactListTab': isContactListTab,
    'isContactDetailsPage': isContactDetailsPage,
    'changeVoiceMail': changeVoiceMail,
    'setIceContact': setIceContact,
    'getContactForAnotherActivity': getContactForAnotherActivity,
    'renderRingtone': renderRingtone,
    'hideTabNavigation': hideTabNavigation,
    'setImportBatchContactsMenu': setImportBatchContactsMenu,
    get asyncScriptsLoaded() {
      return loadAsyncScriptsDeferred.promise;
    },
    get previousUUId() {
      return previousUUId;
    },
    set previousUUId(value) {
      previousUUId = value;
    },
    get SHARED_UTILITIES() {
      return SHARED_UTILS;
    },
    get SHARED_CONTACTS() {
      return SHARED_CONTACTS;
    },
    get selectionMode() {
      return selectionMode;
    },
    get replacementMode() {
      return replacementMode;
    },
    set replacementMode(value) {
      replacementMode = value;
    },
    get viewdetailMode() {
      return viewdetailMode;
    },
    set viewdetailMode(value) {
      viewdetailMode = value;
    },
    set selectionMode(flag) {
      selectionMode = flag;
      stateBeforeExitSelectMode = navigation.stack.length;
    },
    get isSelectedSpeedDial() {
      return selectedSpeedDial;
    },
    get appTitleElement() {
      return appTitleElement;
    },
    get addToExistingCallback() {
      return addToExistingCallback;
    },
    get importBatchContacts() {
      return importBatchContacts;
    },
    set importBatchContacts(value) {
      importBatchContacts = value;
    },
    get contactsImporting() {
      return contactsImporting;
    },
    set contactsImporting(value) {
      contactsImporting = value;
    },
    'isSearchMode': isSearchMode,
    'setFocusToExtension': setExtensionFocus
  };
})();
