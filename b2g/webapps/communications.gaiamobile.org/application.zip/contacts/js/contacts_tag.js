'use strict';
/* global utils, contacts, navigation, NavigationManager */
/* exported ContactsTag */

var ContactsTag = (function() {
  var originalTag = null;
  var selectedTag = null;
  var customTag = null;
  var customTagInput = false;
  var defaultFocused = null;

  var setCustomTag = function setCustomTag(element) {
    customTag = element;
  };

  var getSelectedTag = function getSelectedTag() {
    return selectedTag;
  };

  var getSelectedTagItem = function getSelectedTagItem() {
    return selectedTag.parentNode;
  };

  var unMarkTag = function unMarkTag(tag) {
    if (tag) {
      tag.parentNode.querySelector('input[type="radio"]').removeAttribute('checked');
    }
  };

   var markTag = function markTag(tag) {
    if (tag) {
      tag.parentNode.querySelector('input[type="radio"]').setAttribute('checked', 'true');
    }
  };

  var fillTagOptions = function fillTagOptions(target, _originalTag, options) {
    utils.dom.removeChildNodes(target);
    originalTag = _originalTag;
    selectedTag = null;

    var selectedLink;
    var tabIndex = 0;
    var customOption = null;
    /* jshint loopfunc:true */
    for (var option in options) {
      var radioLabel = document.createElement('label');
      radioLabel.dataset.index = option;

      radioLabel.setAttribute('type', 'radio');
      radioLabel.setAttribute('data-value', options[option].type ||
          options[option].value);
      options[option].key && (radioLabel.dataset.key = options[option].key);
      radioLabel.setAttribute('role', 'option');
      radioLabel.classList.add('pack-radio-large');
      radioLabel.classList.add('tagItem');

      var tagText = document.createElement('span');
      var tagRadio = document.createElement('span');
      tagText.classList.add('p-pri');
      tagText.classList.add('tag-text');
      tagRadio.setAttribute('role', 'alert');
      tagRadio.setAttribute('aria-hidden', 'true');
      var value;
      if (options[option].type) {
        value = options[option].type;
        tagText.setAttribute('data-l10n-id', value);
      } else if (options[option].value) {
        value = options[option].value;
        tagText.textContent = value;
      }
      if (typeof options[option].custom !== 'undefined') {
        tagText.setAttribute('data-custom', 'true');
        customOption = radioLabel;
      }

      if (_originalTag.dataset.value) {
        var originalValue = _originalTag.dataset.value;
        if (['sort-by-first-name','sort-by-last-name']
            .indexOf(_originalTag.dataset.value) > -1) {
          var selectIndex = _originalTag
              .getAttribute('aria-checked') == 'true' ? 0 : 1;
          if (parseInt(radioLabel.dataset.index) == selectIndex) {
            selectedLink = radioLabel;
          }
        } else if (originalValue.toLowerCase() ==
            value.toLowerCase()) {
          selectedLink = radioLabel;
        }
      }
      var tagRadioInput = document.createElement('input');
      var tagItem = document.createElement('li');
      tagRadioInput.type = 'radio';
      tagItem.setAttribute('role', 'presentation');
      tagItem.classList.add('tagContainer');
      tagItem.tabIndex = tabIndex++;
      radioLabel.appendChild(tagRadioInput);
      radioLabel.appendChild(tagText);
      radioLabel.appendChild(tagRadio);
      tagItem.appendChild(radioLabel);
      target.appendChild(tagItem);
    }
    if (customOption && !selectedLink) {
      selectedLink = customOption;
    }

    var customTagLi = target.querySelector('input[data-value="customTag"]');
    if (customTagLi !== null) {
      var textArea = '<p>' +
                       '<input class="textfield tagItem" type="text" value="" id="custom-tag" dir="auto">' +
                     '</p>';
      customTagLi.parentNode.insertAdjacentHTML('beforeEnd', textArea);
      customTagLi.closest('form').addEventListener('submit', function(e){
        e.preventDefault();
        return false;
      });
    }
    setCustomTag(document.querySelector('#custom-tag'));
    if (customTag) {
      customTag.value = '';
      if (!selectedLink && originalTag.textContent) {
        customTag.value = originalTag.textContent;
      }
    }
    selectTag(selectedLink);
    if (selectedLink && selectedLink.parentNode) {
      defaultFocused = selectedLink.parentNode;
      selectedLink.parentNode.scrollIntoView();
    } else {
      defaultFocused = null;
    }
  };

  var selectTag = function selectTag(tag) {
    if (tag == null) {
      return;
    }

    unMarkTag(selectedTag);

    markTag(tag);

    selectedTag = tag;
  };

  var clickDone = function clickDone(callback) {
    if (contacts.Settings && contacts.Settings.isSettings()) {
      contacts.Settings.selectionTagHandler(originalTag, selectedTag.getAttribute('data-l10n-id'));
    } else {
      if (customTag && customTag.value) {
        if (originalTag.textContent !== customTag.value) {
          originalTag.textContent = customTag.value;
          originalTag.dataset.value = selectedTag.dataset.l10nId;
        }
      }else if(selectedTag.dataset.custom) {
        if (!customTagInput) {
          toggleCustomTag();
          return;
        } else {
          var customTagValue = document
              .querySelector('.custom-input input').value;
          if (customTagValue) {
            originalTag.textContent = customTagValue;
            originalTag.dataset.value = customTagValue;
          }
        }
      } else  if (originalTag.textContent !== selectedTag.textContent) {
        originalTag.textContent = selectedTag.textContent;

        if (selectedTag.dataset && selectedTag.dataset.l10nId) {
          originalTag.dataset.l10nId = selectedTag.dataset.l10nId;
        }

        var prevSibling = selectedTag.previousSibling;
        var parent_obj = null;
        if (prevSibling.dataset.value != null) {
          originalTag.dataset.value = prevSibling.dataset.value;
        } else {
          parent_obj = selectedTag.parentNode;
          if (parent_obj &&
              parent_obj.dataset.value != null) {
            originalTag.dataset.value =
                parent_obj.dataset.value;
          }
        }

        if (prevSibling.dataset.key) {
          originalTag.dataset.key = prevSibling.dataset.key;
        } else if(parent_obj && parent_obj.dataset.key) {
          originalTag.dataset.key = parent_obj.dataset.key;
        }
      }
      if (originalTag.closest('section').querySelector('[hidden]')) {
        originalTag.closest('section').querySelector('[hidden]').removeAttribute('hidden');

        contacts.Form.updateLabels();
      }
    }

    originalTag = null;

    if (callback !== undefined && typeof callback === 'function') {
      callback();
    }
  };

  function toggleCustomTag(resetFocus) {
    var customInput = document.querySelector('.custom-input');
    if (!customTagInput) {
      customInput.classList.remove('hide');
      navigation.pushOptionMenu('custom-add',
          navigation.currentView());
      document.querySelector('.custom-cover').classList.remove('hide');
      NavigationManager.resetByNode('.tagCustom', null);
      customTagInput = true;
    } else {
      customInput.classList.add('hide');
      navigation.pushOptionMenu('types-add',
          navigation.currentView());
      customInput.querySelector('input').value = '';
      document.querySelector('.custom-cover').classList.add('hide');
      customTagInput = false;
      if (!!resetFocus) {
        NavigationManager.resetByNode('.tagContainer',
            document.querySelector('.tagContainer:last-child'));
        NavigationManager.getFocusedEl().scrollIntoView();
      }
    }
  }

  // Filter tags to be shown when selecting an item type (work, birthday, etc)
  // This is particularly useful for dates as we cannot have multiple instances
  // of them (only one birthday, only one anniversary)
  function filterTags(type, currentNode, tags) {
    var element = document.querySelector(
                          '[data-template]' + '.' + type + '-' + 'template');
    if (!element || !element.dataset.exclusive) {
      return tags;
    }

    // If the type is exclusive the tag options are filtered according to
    // the existing ones
    var newOptions = tags.slice(0);

    var sameType = document.querySelectorAll('.' + type + '-template');
    if (sameType.length > 1) {
      /* jshint loopfunc:true */
      for (var j = 0; j < sameType.length; j++) {
        var itemSame = sameType.item(j);
        var tagNode = itemSame.querySelector('[data-field="type"]');
        if (tagNode !== currentNode &&
            !itemSame.classList.contains('facebook')) {
          newOptions = newOptions.filter(function(ele) {
            return ele.type != tagNode.dataset.value;
          });
        }
      }
    }

    return newOptions;
  }

  return {
    get customTagVisible() {
      return customTagInput;
    },
    get defaultFocused() {
      return defaultFocused;
    },
    'toggleCustomTag': toggleCustomTag,
    'setCustomTag': setCustomTag,
    'fillTagOptions': fillTagOptions,
    'clickDone': clickDone,
    'selectTag': selectTag,
    'filterTags': filterTags,
    'getSelectedTag': getSelectedTag,
    'getSelectedTagItem': getSelectedTagItem
  };
})();
