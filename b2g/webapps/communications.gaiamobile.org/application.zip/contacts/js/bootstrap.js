'use strict';(function(exports){const CACHE_ENABLED=true;const FIRST_CHUNK='firstChunk';const l10nStrings={'title':{query:'gaia-header h1#app-title',container:'textContent'},'search':{query:'input[data-l10n-id="search-contact"]',container:'placeholder'}};var _observers={};function addObserver(aMessage,aCallback){if(typeof aCallback!=='function'){return;}
if(!_observers[aMessage]){_observers[aMessage]=[];}
_observers[aMessage].push(aCallback);}
function notifyObservers(aMessage,aData){var observers=_observers[aMessage];if(!observers){return;}
for(var callback in observers){if(observers[callback]){observers[callback](aData);}}}
var _caches=new Map();_caches.set(FIRST_CHUNK,{containerId:'groups-list',active:false});var _cachedContacts;var _cachedFavorites;var _cachedHeaders;var _cacheEvictionTimer;function setCache(aCache){if(!CACHE_ENABLED||!aCache.id||!aCache.content||!aCache.lastOrderString||!_caches.has(aCache.id)){return;}
var l10n={};Object.keys(l10nStrings).forEach(key=>{var string=l10nStrings[key];var selector=document.querySelector(string.query);if(!selector||!selector[string.container]){return;}
l10n[key]=selector[string.container];});localStorage.setItem(aCache.id,JSON.stringify({content:aCache.content,languageDirection:navigator.mozL10n.language.direction,languageCode:navigator.mozL10n.language.code,lastOrderString:aCache.lastOrderString,updated:Date.now(),l10n:l10n}));}
function deleteCache(aId){if(!CACHE_ENABLED){return;}
localStorage.removeItem(aId);}
function getCachedContacts(aNodeList){if(!CACHE_ENABLED||!aNodeList){return;}
if(!_cachedContacts){_cachedContacts=new Map();}
if(!_cachedFavorites){_cachedFavorites=new Map();}
for(var i=0;i<aNodeList.length;i++){var cacheEntry=aNodeList[i];if(cacheEntry.parentNode.id=='contact-list-ice'){continue;}
if(cacheEntry.parentNode.id=='contacts-list-favorites'){_cachedFavorites.set(cacheEntry.dataset.uuid,cacheEntry.innerHTML);continue;}
_cachedContacts.set(cacheEntry.dataset.uuid,cacheEntry.innerHTML);}}
function appendNodesToContainer(aContainer,aNodeList){if(!CACHE_ENABLED||!aNodeList.length){return Promise.resolve();}
return new Promise((resolve)=>{if(!_cachedHeaders){_cachedHeaders={};}
var resolved=false;var fragment=document.createDocumentFragment();aNodeList.forEach((node)=>{if(!node.elementName){return;}
var child=document.createElement(node.elementName);node.attributes&&node.attributes.forEach((attribute)=>{if(!attribute.name||!attribute.value){return;}
child.setAttribute(attribute.name,attribute.value);});if(node.innerHTML){child.innerHTML=node.innerHTML;if(window.location.search==='?pick'){if(child.id==='section-group-general'){var noTelNodes=child.querySelectorAll('li.no-tel');for(var i=0;i<noTelNodes.length;i++){noTelNodes[i].parentNode.removeChild(noTelNodes[i]);}}}
if(['?pick','?update'].indexOf(window.location.search)>-1&&child.id==='section-group-ice'){child.innerHTML='';}}
fragment.appendChild(child);var headerName=child.id.split('section-group-')[1];_cachedHeaders[headerName]=fragment.querySelector('ol#contacts-list-'+headerName);if(!resolved){resolve();}});getCachedContacts(fragment.querySelectorAll('li[data-cache=true]'));aContainer.appendChild(fragment);var cachedFocus=aContainer.querySelector('.focus');cachedFocus&&cachedFocus.classList.remove('focus');});}
function removeCacheFromContainer(aContainer){if(!CACHE_ENABLED||!_cachedContacts){return;}
for(var id of _cachedContacts.keys()){var items=aContainer.querySelectorAll('li[data-uuid=\"'+id+'\"]');Array.prototype.forEach.call(items,(item)=>{var ol=item.parentNode;ol.removeChild(item);if(ol.children.length<1){var header=_cachedHeaders[ol.dataset.group];if(header){var groupTitle=header.parentNode.children[0];groupTitle.classList.add('hide');}}});}}
exports.applyCache=function applyCache(aCacheId){if(!CACHE_ENABLED||!_caches.has(aCacheId)){return Promise.resolve();}
var _cache=_caches.get(aCacheId);var cache=localStorage.getItem(aCacheId);if(!cache){return Promise.resolve();}
try{cache=JSON.parse(cache);_cache.content=cache.content;_cache.languageDirection=cache.languageDirection;_cache.languageCode=cache.languageCode;_cache.lastOrderString=cache.lastOrderString;_cache.updated=new Date(cache.updated);}catch(e){console.error(e);return Promise.resolve();}
if(!_cache.containerId){return Promise.resolve();}
if(cache.l10n){Object.keys(cache.l10n).forEach(key=>{if(!l10nStrings[key]||cache.l10n[key]==='undefined'){return;}
var string=l10nStrings[key];var selector=document.querySelector(string.query);if(!selector){return;}
selector[string.container]=cache.l10n[key];});}
if(cache.languageDirection){var html=document.querySelector('html');html.setAttribute('dir',cache.languageDirection);}
var container=document.getElementById(_cache.containerId);if(!container){console.warning('Could not apply cached content to '+
_cache.containerId);return Promise.resolve();}
return appendNodesToContainer(container,_cache.content).then(()=>{_cache.content=null;_cache.active=true;_caches.set(aCacheId,_cache);return Promise.resolve();});};function undoCache(aCacheId){if(!CACHE_ENABLED||!_caches.has(aCacheId)){return;}
var _cache=_caches.get(aCacheId);if(!_cache.containerId){return;}
var container=document.getElementById(_cache.containerId);if(!container){console.warning('Could not remove cached content from '+
_cache.containerId);return;}
removeCacheFromContainer(container);}
var Cache={get active(){return CACHE_ENABLED&&_caches.get(FIRST_CHUNK).active;},get enabled(){return CACHE_ENABLED;},get contacts(){return(CACHE_ENABLED&&_cachedContacts)?_cachedContacts.keys():null;},get favorites(){return(CACHE_ENABLED&&_cachedFavorites)?_cachedFavorites.keys():null;},get length(){return(CACHE_ENABLED&&_cachedContacts)?_cachedContacts.size+_cachedFavorites.size:0;},get headers(){return(CACHE_ENABLED&&_cachedHeaders)?_cachedHeaders:{};},get lastOrderString(){return(CACHE_ENABLED&&_caches.get(FIRST_CHUNK).lastOrderString);},get updated(){return(CACHE_ENABLED&&_caches.get(FIRST_CHUNK).updated);},get _rawContent(){return _caches.get(FIRST_CHUNK).content;},set firstChunk(aFirstChunk){if(!CACHE_ENABLED||!aFirstChunk||!aFirstChunk.cache||!aFirstChunk.lastOrderString){return;}
setCache({id:FIRST_CHUNK,content:aFirstChunk.cache,lastOrderString:aFirstChunk.lastOrderString});},set oneviction(aCallback){if(!CACHE_ENABLED){return;}
addObserver('oneviction',aCallback);},hasContact:function(aUuid){if(!CACHE_ENABLED){return;}
return _cachedContacts&&_cachedContacts.has(aUuid);},hasFavorite:function(aUuid){if(!CACHE_ENABLED){return;}
return _cachedFavorites&&_cachedFavorites.has(aUuid);},getContact:function(aUuid){if(!CACHE_ENABLED||!this.hasContact(aUuid)){return;}
var contact=_cachedContacts.get(aUuid);_cachedContacts.delete(aUuid);return contact;},getFavorite:function(aUuid){if(!CACHE_ENABLED||!this.hasFavorite(aUuid)){return;}
var contact=_cachedFavorites.get(aUuid);_cachedFavorites.delete(aUuid);return contact;},removeContact:function(aUuid){if(!CACHE_ENABLED||!this.hasContact(aUuid)||!this.hasFavorite(aUuid)){return;}
if(_cachedContacts.has(aUuid)){_cachedContacts.delete(aUuid);}
if(_cachedFavorites.has(aUuid)){_cachedFavorites.delete(aUuid);}},evict:function(aUndo){if(!CACHE_ENABLED){return;}
if(_cacheEvictionTimer){clearTimeout(_cacheEvictionTimer);}
_cacheEvictionTimer=setTimeout(()=>{_cacheEvictionTimer=null;if(aUndo){undoCache(FIRST_CHUNK);}
deleteCache(FIRST_CHUNK);this.cleanup();notifyObservers('oneviction');},1000);},maybeEvict:function(){if(!CACHE_ENABLED||!this.active){return;}
if((_caches.get(FIRST_CHUNK).languageDirection!=navigator.mozL10n.language.direction)||(_caches.get(FIRST_CHUNK).languageCode!=navigator.mozL10n.language.code)){this.evict(true);}},cleanup:function(){if(!CACHE_ENABLED){return;}
_caches.get(FIRST_CHUNK).active=false;_caches.get(FIRST_CHUNK).content=null;_cachedContacts=null;_cachedFavorites=null;_cachedHeaders=null;}};exports.Cache=Cache;function loadScripts(){var dependencies=['/contacts/js/activities.js','/shared/js/contacts/utilities/event_listeners.js','/contacts/js/navigation.js','/contacts/js/views/list.js','/contacts/js/utilities/extract_value.js',];if(window.location.search!=='?new'){dependencies.push('/contacts/js/tab_navigation.js');}
if(window.location.search==='?pick'){var imgId=document.getElementById('speed-dial-button-list');imgId.style.display='none';}
if(!Cache.active){dependencies.push('/shared/js/l10n.js');dependencies.push('/shared/js/l10n_date.js');}
LazyLoader.load(dependencies,()=>{['/shared/js/async_storage.js','/shared/js/contacts/import/utilities/config.js','/contacts/js/utilities/extract_params.js','/contacts/js/utilities/cookie.js','/contacts/js/utilities/ringtone_helper.js','/contacts/js/utilities/voice_mail.js','/shared/js/contact_photo_helper.js'].forEach((src)=>{var scriptNode=document.createElement('script');scriptNode.src=src;scriptNode.setAttribute('defer',true);document.head.appendChild(scriptNode);});return LazyLoader.load('/contacts/js/contacts.js');});}
window.addEventListener('DOMContentLoaded',function ondomloaded(){document.body.classList.toggle('large-text',navigator.largeTextEnabled);utils.PerformanceHelper.domLoaded();window.removeEventListener('DOMContentLoaded',ondomloaded);window.NavigationManager.init();window.cachePromise=applyCache(FIRST_CHUNK);window.onload=()=>{utils.PerformanceHelper.visuallyComplete();loadScripts();};});})(window);