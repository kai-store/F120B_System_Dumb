/* globals Contacts, utils, contactsRemover, Promise, OptionHelper,
   ConfirmDialogHelper, Toaster  */
'use strict';

var contacts = window.contacts || {};

contacts.BulkDelete = (function() {
  var contactsRemoverObj;
  var cancelled = false;
  var isDeleting = false;

  /**
   * Loads the overlay class before showing
   */
  function requireOverlay(callback) {
    Contacts.utility('Overlay', callback, Contacts.SHARED_UTILITIES);
  }

  // Shows a dialog to confirm the bulk delete
  var showConfirm = function showConfirm(n) {
    return new Promise(function doShowConfirm(resolve, reject) {
      var dialogConfig = {
        title: {id: 'confirm-dialog-title-default', args: {}},
        body: {id: 'ContactConfirmDel' , args: {n:n}},
        backcallback: function() {},
        cancel: {
          l10nId: 'cancel',
          callback: function() {
            OptionHelper.show(lastParamName);
            reject();
          }
        },
        confirm: {
          l10nId: 'delete',
          callback: function () {
            resolve();
          }
        }
      };
      var lastParamName = OptionHelper.getLastParamName();
      OptionHelper.hideMenu();
      var dialog = new ConfirmDialogHelper(dialogConfig);
      dialog.show(document.getElementById('app-dialog')); 
    });
  };
  var doCancel = function doCancel(){
    cancelled = true;
    contactsRemoverObj.finish(cancelled);
  };
  var doDelete = function doDelete(ids, done) {
    cancelled = false;
     document.addEventListener('keydown', contacts.Settings.handleBackInDelete);
    contacts.Settings.setOverlayHeader('bulkDeleteButton');
    OptionHelper.show('contacts-cancel-delete');
    var progress = utils.overlay.show('DeletingContacts', 'progressBar');
    progress.setTotal(ids.length);

    contactsRemoverObj = new contactsRemover();
    contactsRemoverObj.init(ids, function onInitDone() {
      isDeleting = true;
      contactsRemoverObj.start();
    });

    contactsRemoverObj.onDeleted = function onDeleted(currentId) {
      contacts.List.remove(currentId);
      progress.update();
    };

    contactsRemoverObj.onError = function onError() {
      document.removeEventListener('keydown', contacts.Settings.handleBackInDelete);
      Contacts.hideOverlay();
      Toaster.showToast({
        messageL10nId: 'deleteError-general',
        latency: 2000,
      });
      contacts.Settings.refresh();
      isDeleting = false;
    };

    contactsRemoverObj.onFinished = function onFinished() {
      document.removeEventListener('keydown', contacts.Settings.handleBackInDelete);
      Contacts.hideOverlay();
      Toaster.showToast({
        messageL10nId: 'DeletedTxt',
        messageL10nArgs: {'n': contactsRemoverObj.getDeletedCount()},
        latency: 2000,
      });
      contacts.Settings.refresh();

      (cancelled) ? Contacts.navigation.back() : Contacts.navigation.home();
      isDeleting = false;
      window.dispatchEvent(new CustomEvent('changeContactListMenu', {
        detail: {
          'showNoContacts': !contacts.List.isContactsExist()
        }
      }));
    };

    contactsRemoverObj.onCancelled = contactsRemoverObj.onFinished;

  };
  // Start the delete of the contacts
  var performDelete = function performDelete(promise, done) {
    requireOverlay(function onOverlay() {
      promise.onsuccess = function onSuccess(ids) {
        Contacts.hideOverlay();
        showConfirm(ids.length).then(
          contacts.BulkDelete.doDelete.bind(null, ids, done));
      };
      promise.onerror = function onError() {
        Contacts.hideOverlay();
      };
    });
  };

  return {
    'performDelete': performDelete,
    'doDelete': doDelete,
    'doCancel': doCancel,
    get isDeleting() {
      return isDeleting;
    }
  };

})();
