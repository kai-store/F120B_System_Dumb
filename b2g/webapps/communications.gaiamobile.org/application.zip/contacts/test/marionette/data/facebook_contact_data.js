'use strict';

window.wrappedJSObject.data = window.wrappedJSObject.data || {};

window.wrappedJSObject.data.fbContactData = {
  'uid': '100007887283166',
  'name': 'Jander Klander',
  'pic_big': 'https://fbcdn-profile-a.akamaihd.net/static-ak/' +
    'fbrsrc.php/v2/yL/r/HsTZSDw4avx.gif',
  'current_location': null,
  'email': [{
    'type': ['other'],
    'value': 'gtorodelvalle@hotmail.com'
        }],
  'profile_update_time': 1393974966,
  'work': [],
  'hometown_location': null,
  '_idxFriendsArray': 124,
  'familyName': ['Klander'],
  'additionalName': '',
  'givenName': ['Jander'],
  'tel': [{
    'type': ['other'],
    'value': '+34666666666'
          }],
  'email1': 'gtorodelvalle@hotmail.com',
  'contactPictureUri': 'https://graph.facebook.com/100007887283166/' +
    'picture?type=square&width=120&height=120',
  'search': 'JanderKlandergtorodelvalle@hotmail.com',
  'picwidth': 120,
  'picheight': 120,
  '_idx_': 0,
  'fbInfo': {
    'org': [''],
    'adr': [],
    'shortTelephone': ['666666666'],
    'url': [{
      'type': ['fb_profile_photo'],
      'value': 'https://fbcdn-profile-a.akamaihd.net/static-ak/' +
        'rsrc.php/v2/yL/r/HsTZSDw4avx.gif'
    }]
  }
};
