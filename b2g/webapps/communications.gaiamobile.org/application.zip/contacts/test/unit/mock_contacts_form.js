'use strict';
/* exported MockContactsForm */

var MockContactsForm = {
  'init': function init() {}
};
