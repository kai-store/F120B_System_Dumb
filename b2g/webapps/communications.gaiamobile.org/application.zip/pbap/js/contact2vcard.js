
(function(exports){'use strict';var VCARD_MAP={'fax':'FAX','faxoffice':'FAX,WORK','faxhome':'FAX,HOME','faxother':'FAX','home':'HOME','mobile':'CELL','pager':'PAGER','personal':'HOME','pref':'PREF','text':'TEXT','textphone':'TEXTPHONE','voice':'VOICE','work':'WORK'};var CRLF='\r\n';var VCARD_SKIP_FIELD=['fb_profile_photo'];var VCARD_VERSION='3.0';var HEADER='BEGIN:VCARD'+CRLF+'VERSION:'+VCARD_VERSION+CRLF;var FOOTER='END:VCARD'+CRLF;function blobToBase64(blob,cb){var reader=new FileReader();reader.onload=function(){var dataUrl=reader.result;var base64=dataUrl.split(',')[1];cb(base64);};reader.readAsDataURL(blob);}
function ISODateString(d){if(typeof d==='string'){d=new Date(d);}
var str=d.toISOString();return str.slice(0,str.indexOf('.'))+'Z';}
function fromContactField(sourceField,vcardField){if(!sourceField||!sourceField.length){return[];}
return sourceField.map(function(field){var str=vcardField;var skipField=false;var types=[];if(Array.isArray(field.type)){var fieldType=field.type.map(function(aType){var out='';if(aType){aType=aType.trim().toLowerCase();if(VCARD_SKIP_FIELD.indexOf(aType)!==-1){skipField=true;}
out=VCARD_MAP[aType]||aType;}
return out;});types=types.concat(fieldType);}
if(skipField){return;}
if(field.pref&&field.pref===true){types.push('PREF');}
if(types.length){str+=';TYPE='+types.join(',');}
return str+':'+(field.value||'');});}
function fromStringArray(sourceField,vcardField){if(!sourceField){return'';}
return vcardField+':'+sourceField.join(',');}
function joinFields(fields){return fields.filter(function(f){return!!f;}).join(CRLF);}
function toBlob(vcard,type){return new Blob([vcard],{'type':type});}
function ContactToVcardBlob(contacts,callback,options){var targetType=options&&options.type||'text/vcard';if(targetType.indexOf('charset')===-1){targetType+='; charset=utf-8';}
if(typeof callback!=='function'){throw Error('callback() is undefined or not a function');}
var str='';ContactToVcard(contacts,function append(vcards,nCards){str+=vcards;},function success(){str=str?toBlob(str):null;callback(toBlob(str,targetType));});}
function ContactToVcard(contacts,append,success,batchSize,skipPhoto){var vCardsString='';var nextIndex=0;var cardsInBatch=0;batchSize=batchSize||(1024*1024);if(typeof append!=='function'){throw Error('append() is undefined or not a function');}
if(typeof success!=='function'){throw Error('append() is undefined or not a function');}
function appendVCard(vcard){if(vcard.length>0){vCardsString+=HEADER+vcard+CRLF+FOOTER;}
nextIndex++;cardsInBatch++;if((vCardsString.length>batchSize)||(nextIndex===contacts.length)){append(vCardsString,cardsInBatch);cardsInBatch=0;vCardsString='';}
if(nextIndex<contacts.length){processContact(contacts[nextIndex]);}else{success();}}
function processContact(ct){if(navigator.mozContact&&!(ct instanceof navigator.mozContact)){console.error('An instance of mozContact was expected');setImmediate(function(){appendVCard('');});return;}
var n='n:'+([ct.familyName,ct.givenName,ct.additionalName,ct.honorificPrefix,ct.honorificSuffix].map(function(f){f=f||[''];return f.join(',')+';';}).join(''));if(n==='n:;;;;;'&&!ct.name){setImmediate(function(){appendVCard('');});return;}
var allFields=[n,fromStringArray(ct.name,'FN'),fromStringArray(ct.nickname,'NICKNAME'),fromStringArray(ct.category,'CATEGORY'),fromStringArray(ct.org,'ORG'),fromStringArray(ct.jobTitle,'TITLE'),fromStringArray(ct.note,'NOTE'),fromStringArray(ct.key,'KEY')];if(ct.xirmc){allFields.push('X-IRMC-CALL-DATETIME;'+ct.xirmc);}
if(ct.bday){allFields.push('BDAY:'+ISODateString(ct.bday));}
if(ct.anniversary){allFields.push('ANNIVERSARY:'+ISODateString(ct.anniversary));}
allFields.push.apply(allFields,fromContactField(ct.email,'EMAIL'));allFields.push.apply(allFields,fromContactField(ct.url,'URL'));allFields.push.apply(allFields,fromContactField(ct.tel,'TEL'));var adrs=fromContactField(ct.adr,'ADR');allFields.push.apply(allFields,adrs.map(function(adrStr,i){var orig=ct.adr[i];return adrStr+(['','',orig.streetAddress||'',orig.locality||'',orig.region||'',orig.postalCode||'',orig.countryName||''].join(';'));}));if((typeof skipPhoto=='undefined'||skipPhoto===false)&&ct.photo&&ct.photo.length){var photoMeta=['PHOTO','ENCODING=b'];var blob=ct.photo[0];blobToBase64(blob,function(b64){if(blob.type){photoMeta.push('TYPE='+blob.type);}
allFields.push(photoMeta.join(';')+':'+b64);appendVCard(joinFields(allFields));});}else{setImmediate(function(){appendVCard(joinFields(allFields));});}}
processContact(contacts[0]);}
function getVcardFilename(theContact){var out='';var givenName=Array.isArray(theContact.givenName)&&theContact.givenName[0];var familyName=Array.isArray(theContact.familyName)&&theContact.familyName[0];if(givenName){out=givenName;}
if(familyName){if(out){out+='_';}
out+=familyName;}
out=out||(Array.isArray(theContact.org)&&theContact.org[0]);out=out||(Array.isArray(theContact.tel)&&theContact.tel[0]&&('c'+'_'+theContact.tel[0].value));out=out||(Array.isArray(theContact.email)&&theContact.email[0]&&theContact.email[0].value);out=out||navigator.mozL10n.get('noName');out=Normalizer.toAscii(out).replace(/[\s+@#&?\+\$]/g,'');return out+'.vcf';}
exports.ContactToVcard=ContactToVcard;exports.ContactToVcardBlob=ContactToVcardBlob;exports.VcardFilename=getVcardFilename;})(window);