/* globals CallHandler, KeypadManager, SimSettingsHelper */

'use strict';

var KeyboardView = {

  init: function kb_init() {
    var lazyFiles = [
      '/shared/style/action_list.css',
      '/shared/js/action_list.js',
      '/shared/js/custom_dialog.js'
    ];

    var self = this;

    LazyLoader.load(lazyFiles, function resourcesLoaded() {
      self._initSoftkeyPanelWithoutNumber();
      self.actionList = self._initActionList();

      // TODO: remove this code after integration of softkey panel component to system app
      var el;
      if (el = document.querySelector("#softkeyPanel")) {
        self.actionList.getContainer()
          .style.bottom = el.clientHeight + "px";
      }

      self._subscribe();
    });
  },

  _debug: function kb_debug(message) {
    console.log('Dialer App: ' + message);
  },
  isDiallerOpen: function () {
    return location.hash === '#keyboard-view';
  },
  _subscribe: function kb_subscribe() {
    window.addEventListener('keydown', function(event) {
      // TODO: Handler for Send key
      if (event.key === 'Shift' /* Emulator */
        || event.key === 'Call' /* GO flip */
        || event.key === 'F4' /* Pixi */) {
        var bar = document.getElementById('suggestion-bar');
        if (!bar.classList.contains('hide') && bar.classList.contains('focus'))
          this._makeCall(bar.querySelector('.js-tel').textContent);
        else
          this._makeCall(KeypadManager.phoneNumber());
      }
      if (event.key === 'BrowserBack' || event.key === 'Backspace') {
        if (CustomDialog.isVisible) {
          CustomDialog.runCancel();
        } else if (SuggestionBar.overlayIsShown()) {
          SuggestionBar.hideOverlay();
        } else if (this.isDiallerOpen()) {
          var phoneNumber = document.getElementById("phone-number-view").value;
          var len = phoneNumber.length;
          var mmiElement = document.getElementById("mmi-screen");
          if (len == 0 && mmiElement.hidden == true) {
            window.close();
          }
        }
        return;
      }
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault();
      }
    }.bind(this));

    window.addEventListener('speedDialKeyPressed', this._speedDialHandler.bind(this));
    document.addEventListener('screen-insert-front', function(e) {
      var display = e.detail.display;
      var keyPanel = document.getElementById('keypad-panel');
      if (display) {
        KeypadManager.disableKeyPad();
        document.activeElement.blur();
        //backup the foucs item, when the other screen shown
        //to solve the confilc problem
        var focusItem = keyPanel.querySelector('.focus');
        if (focusItem != undefined) {
          focusItem.classList.remove('focus');
          focusItem.classList.add('focus-backup');
        }
      }
      else {
        document.activeElement.blur();
        KeypadManager.enableKeyPad();
        var focusItem = keyPanel.querySelector('.focus-backup');
        var bar = document.getElementById('suggestion-bar');
        //restore the foucs item, when the other screen hide
        if (focusItem != undefined) {
          focusItem.classList.remove('focus-backup');
          focusItem.classList.add('focus');
        }
        if (bar.classList.contains('focus')) {
          OptionHelper.show('suggestionBar-action');
        }
        else if (keyPanel.querySelector('.focus') != undefined) {
          OptionHelper.show('dialer-options');
          keyPanel.querySelector('.focus').focus();
        }
      }
    });
    KeyboardView._getReadoutValue();
  },

  _readOutValue: false,
  _readCallTimer: null,
  _readoutFirstNumber: function kb__readoutFirstNumber(timeout) {
     var numberViewElement = document.getElementById('phone-number-view');
     numberViewElement.value = '';
     KeyboardView._readCallTimer = window.setTimeout( () =>  {
       numberViewElement.value = KeypadManager._phoneNumber;
     }, timeout);
  },
  _getReadoutValue: function kb_getReadoutValue() {
    var lock = navigator.mozSettings.createLock();
    var screenReaderSetting = lock.get('accessibility.screenreader');
    screenReaderSetting.onsuccess = function () {
      KeyboardView._readOutValue = screenReaderSetting.result['accessibility.screenreader'];
      if (KeyboardView._readOutValue == false) {
        var numberViewElement = document.getElementById('phone-number-view');
        numberViewElement.value = KeypadManager._phoneNumber;
        window.clearTimeout(KeyboardView._readCallTimer);
        KeyboardView._readCallTimer = null;
     }
   };
  },

  _initSoftkeyPanelWithNumber: function kb_initSoftkeyPanelWithNumber() {
    var self = this;

    var softkeyActions = {
      items: [{
        name: 'Call Log',
        l10nId: 'tcl-call-log',
        priority: 1,
        method: function() {
          self._launchCallLog();
        }
      }, {
        icon: 'ok',
        priority: 2,
        method: function() {
        }
      }, {
        name: 'Contacts',
        l10nId: 'tcl-contacts',
        priority: 3,
        method: function() {
          self._launchContacts('list');
        }
      }]
    };

    OptionHelper.optionParams['dialer-options'] = softkeyActions;
    OptionHelper.show('dialer-options');
  },

  _initSoftkeyPanelWithoutNumber: function kb_initSoftkeyPanelWithoutNumber() {
    var self = this;

    var softkeyActions = {
      items: [{
        name: 'Call Log',
        l10nId: 'tcl-call-log',
        priority: 1,
        method: function() {
          self._launchCallLog();
        }
      }, {
        name: 'Contacts',
        l10nId: 'tcl-contacts',
        priority: 3,
        method: function() {
          self._launchContacts('list');
        }
      }]
    };

    OptionHelper.optionParams['dialer-options'] = softkeyActions;
    OptionHelper.show('dialer-options');
  },

  _initActionList: function kb_initActionMenu() {

    var self = this;

    var config = {
      contexts: {
        'speed_dial': {
          items: [{
            l10nId: 'tcl-speed-dial',
            method: function() {
              self._launchContacts('speed-dial-list');
            }
          }]
        },
        'dialed_number': {
          items: [{
            l10nId: 'tcl-call',
            method: function() {
              self._makeCall(KeypadManager.phoneNumber());
            }
          }, {
            l10nId: 'tcl-send-message',
            method: function() {
              self._launchSendMessage(KeypadManager.phoneNumber());
            }
          }, {
            l10nId: 'tcl-add-contact',
            method: function() {
              self._launchContacts('update', KeypadManager.phoneNumber());
            }
          }, {
            l10nId: 'tcl-create-contact',
            method: function() {
              self._launchContacts('new', KeypadManager.phoneNumber());
            }
          }, {
            l10nId: 'tcl-add-speed-dial',
            method: function() {
              self._launchContacts('add-speed-dial', KeypadManager.phoneNumber());
            }
          }]
        },
        'search_result_select': {
          items: [{
            l10nId: 'tcl-call',
            method: function() {
              self._makeCall(KeypadManager.phoneNumber());
            }
          }, {
            l10nId: 'tcl-send-message',
            method: function() {
              self._launchSendMessage(KeypadManager.phoneNumber());
            }
          }, {
            l10nId: 'tcl-add-speed-dial',
            method: function() {
              self._launchContacts('add-speed-dial', KeypadManager.phoneNumber());
            }
          }]
        }
      },
      useButtonMethod:true
    };

    var actionList = new ActionList(config);
    actionList.init(document.getElementById('keypad-panel'));
    self._showDialerInfo();
    actionList.hide();
    actionList.switchContext('speed_dial');
    var context = 'speed_dial';
    document.addEventListener('phoneNumberViewChanged', function(event) {
      if (event.detail.value.length > 0) {
        if (context == 'speed_dial') {
          actionList.show();
          self._hideDialerInfo();
          self._initSoftkeyPanelWithNumber();
          actionList.switchContext('dialed_number');
          context = 'dialed_number';
          var dialElementCount = actionList.getContainer().lastElementChild.childNodes[0].childElementCount;
          var dialFirstElement = actionList.getContainer().lastElementChild[0];
          var dialLastElement = actionList.getContainer().lastElementChild[dialElementCount - 1];
          dialFirstElement.setAttribute('list-data-set','first-item');
          dialLastElement.setAttribute('list-data-set','last-item');
          if (KeyboardView._readOutValue == true) {
            KeyboardView._readoutFirstNumber(1500);
          }
          if (NavbarManager.dialerStartedWithNumber == true) {
            NavbarManager.dialerStartedWithNumber = false;
            KeyboardView._readoutFirstNumber(2000);
          }
        }
        else {
          document.querySelector('.focus').classList.remove('focus');
          var focusItem = document.querySelector('.focus-backup');
          if (focusItem != undefined)
            focusItem.classList.remove('focus-backup');
          var firstitem = document.querySelector('[data-nav-id=\"1\"]');
          firstitem.classList.add('focus');
          firstitem.focus();
        }
        if (context == 'search_result_select') {
          actionList.switchContext('dialed_number');
          context = 'dialed_number';
          var listNode = actionList.getContainer().childNodes[1];
          var dialElementCount = listNode.childNodes[0].childElementCount;
          var dialLastElement = listNode[dialElementCount - 1];
          var dialFirstElement = listNode[0];
          self._searchResultSelect(dialFirstElement, dialLastElement, actionList);
        }
      } else {
        if (context == 'dialed_number' || context == 'search_result_select') {
          if (context == 'search_result_select') {
            var listNode = actionList.getContainer().childNodes[1];
            var dialElementCount = listNode.childNodes[0].childElementCount;
            var dialLastElement = listNode[dialElementCount - 1];
            var dialFirstElement = listNode[0];
            self._searchResultSelect(dialFirstElement, dialLastElement, actionList);
          }
          self._showDialerInfo();
          self._initSoftkeyPanelWithoutNumber();
          actionList.hide();
          actionList.switchContext('speed_dial');
          context = 'speed_dial';
        }
      }
    });
    document.addEventListener('search_result_select', function(event) {
      actionList.switchContext('search_result_select');
      context = 'search_result_select';
      var listContainer = actionList.getContainer();
      var dialFirstElement = listContainer.lastElementChild[0]; 
      var dialElementCount = listContainer.lastElementChild.childNodes[0].childElementCount;
      var dialLastElement = listContainer.lastElementChild[dialElementCount - 1];
      self._searchResultSelect(dialFirstElement, dialLastElement, actionList);
    });
    var speedDialElement = actionList.getContainer().firstElementChild[0];
    speedDialElement.style.setProperty('margin-top','1rem');
    return actionList;
  },
  _hideDialerInfo: function kb_showDialerInfo(){
    document.getElementById('dialer-info').classList.remove('display');
    document.getElementById('input-container').classList.remove('display');
  },
  _showDialerInfo: function kb_hideDialerInfo(){
    document.getElementById('dialer-info').classList.add('display');
    document.getElementById('input-container').classList.add('display');
  },
  _searchResultSelect: function kb_searchResultSelect(dialFirstElement, dialLastElement, actionList) {
      dialFirstElement.setAttribute('list-data-set','first-item');
      dialLastElement.setAttribute('list-data-set','last-item');
      var bar = document.getElementById('suggestion-bar');
      bar.style.setProperty('--nav-up', dialLastElement.getAttribute('data-nav-id'));
      bar.style.setProperty('--nav-down', dialFirstElement.getAttribute('data-nav-id'));
      dialFirstElement.style.setProperty('--nav-up', 'bar');
      dialLastElement.style.setProperty('--nav-down', 'bar');
  },
  _launchActivity: function kb_launchActivity(name, type, data) {
    try {
      if (name == 'call-log') {
        type = 'dialer_open_calllog';
      }
      var sendData = {
        type: type
      };

      if (data) {
        for (var key in data) {
          if (data.hasOwnProperty(key)) {
            sendData[key] = data[key];
          }
        }
      }

      new MozActivity({
        name: name,
        data: sendData
      });

    } catch (e) {
      console.error('Error while creating activity ' + type);
    }
  },

  _launchContacts: function kb_launchActivity(name, phoneNumber) {
    if (phoneNumber && phoneNumber.length > 0) {
      var data = {
        params: {
          tel: phoneNumber
        }
      }
    }

    this._launchActivity(name, 'webcontacts/contact', data);
  },

  _launchSendMessage: function kb_launhSendMessage(phoneNumber) {
    if (phoneNumber.length > 0) {
      this._launchActivity('new', 'websms/sms', {
        number: phoneNumber
      });
    }
  },

  _launchCallLog: function kb_launchCallLog() {
    this._launchActivity('call-log');
  },

  _speedDialHandler: function(e) {
    var speedDial = e.detail.speedDial;
    var self = this;

    this._findPhone(speedDial,
      function onFound(phone) {
        if (phone && phone.tel) {
          self._makeCall(phone.tel);
        }
      },
      function onNotFound() {
        self._showDialog(speedDial);
      }
    );
  },

  _findPhone: function(speedDial, foundCb, notFoundCb, errorCb) {
    var request = navigator.mozContacts.getSpeedDials();

    request.onsuccess = function() {
      var result = this.result.find(function(item) {
        return item.speedDial == speedDial;
      });

      if (result) {
        foundCb && foundCb(result);
      } else {
        notFoundCb && notFoundCb();
      }
    };

    request.onerror = function(err) {
      console.error(err);
      errorCb && errorCb(err);
    };
  },

  _showDialog: function(speedDial) {
    var self = this;

    CustomDialog.setVersion(2);

    CustomDialog.show('tcl-confirmation', {
      id: 'tcl-assign-speed-dial',
      args: {
        speedDial: speedDial
      },
    }, {
      title: 'cancel',
      callback: function() {
        CustomDialog.hide();
      }
    }, {
      title: 'tcl-assign',
      callback: function() {
        CustomDialog.hide();

        var activity = new MozActivity({
          name: 'add-speed-dial',
          data: {
            type: 'webcontacts/contact',
            params: {
              speedDial: speedDial
            }
          }
        });

        activity.onsuccess = function() {
          if (this.result && this.result.tel) {
            self._makeCall(this.result.tel);
          }
        };
        activity.onerror = function(err) {
          console.error(err);
        };
      }
    });
  },

  _makeCall: function kb_makeCall(phoneNumber) {
    if (phoneNumber.length > 0) {
      LazyLoader.load([
        '/shared/js/sim_settings_helper.js',
      ], function loaded() {
        SimSettingsHelper.getCardIndexFrom('outgoingCall', function(defaultCardIndex) {
          CallHandler.call(phoneNumber, defaultCardIndex);
        });
      })
    }
  }
};
