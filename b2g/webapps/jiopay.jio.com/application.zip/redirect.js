'use strict';

var Redirect = function Redirect() {
 
   var ORIGIN = document.location.protocol + '//' +
   document.location.host;

  var init = function init() {
	  
     var hash = document.location;
    var parameters = {};

   
      console.log("document.location:: "+document.location);
      $("#locationWindow").html(document.location);

      
      document.dispatchEvent(new CustomEvent("planRecharged", {}));
      window.close();
   
  };

  return {
    'init': init
  };

}();

Redirect.init();