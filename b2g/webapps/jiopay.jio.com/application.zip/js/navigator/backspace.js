document.addEventListener('keydown',(event)=>{const keyName=event.key;if(keyName=="Backspace")
{PressTime=false;Timer=setTimeout(function(){PressTime=true;},4000);event.preventDefault();}},false);document.addEventListener('keyup',(event)=>{const keyName=event.key;if(keyName=="Backspace")
{if($(".mainDiv:visible").attr('id')==="splashDiv"){self.close();return;}
if($(".mainDiv:visible").attr('id')==="progressScreen_splash"){self.close();}
if(!PressTime)
{if($("#AlertPopup:visible").attr('id')==="AlertPopup"){return;}
if($("#usagePage:visible").attr('id')==="usagePage"){resetUsageTabIndex();}
if($(".mainDiv:visible").attr('id')==="landingPage"){if($("#slidemenu").hasClass("slideout")){hideMenu();uiListener.callJepAnalyticsApi(JioAnalyticsConstants.gtmLauncherScreen);}
else{self.close();}}
if($(".mainDiv:visible").attr('id')==="launcherContainer"){self.close();}
if($("#slidemenu").hasClass("slideout")){hideMenu();}else{preScreen();}
clearTimeout(Timer);}
else
{window.close();}}
console.log('Key up ',keyName);},false);function closeApp(){if($(".mainDiv:visible").attr('id')==="landingPage"){$("#landingPage").hide();$(".defaultPageFooter .menuBtn").hide();showAlertPopup("Exit","Are you sure you want to Close App?",closeAppAction,null,"closeAppSub","exitTitleAlert");}}
function closeAppAction(){$("#launcherContainer").show();$(".defaultPageFooter").hide();uiListener.callJepAnalyticsApi(JioAnalyticsConstants.gtmLauncherScreen);}
function resetUsageTabIndex(){$("#usage-custom-li-1").removeClass("active");$("#usage-custom-li-2").removeClass("active");$("#usage-custom-li-3").removeClass("active");$("#usage-custom-li-4").removeClass("active");$("#usage-custom-li-5").removeClass("active");$("#callsUsageDiv").hide();$("#dataUsageDiv").hide();$("#videoUsageDiv").hide();$("#wifiUsageDiv").hide();}