var VL = VL || {};

function setLocale(){
	if(!localStorage.getItem("locale")){
       return "en-IN";
	}
	else{
       return localStorage.getItem("locale")
	}
}


// dev Key - AIzaSyAd7Tah0dlq9K7wozaqXFmmb96p5lIjwUo
function setApiKey(){
	if(!localStorage.getItem("apiKey")){
       return "AIzaSyAIufN_QozE2zqgBIHHZQibxgebbsf850k";
	}
	else{
       return localStorage.getItem("apiKey");
	}
}

function setPttFlag(){
	if(!localStorage.getItem("pttFlag")){
       return false;
	}
	else{
       return localStorage.getItem("pttFlag")
	}
}

VL.locale = setLocale();
VL.apiKey = setApiKey();
VL.talkBackDescLong = "short";
VL.isHindiTalkBack = false;
VL.talkBackClassNamesAgent = {}
VL.talkBackClassNamesAgent["Gecko"] = {
    "parent":'.xpc',
    "long_content":'.xpc ._oot ._H1m._kup',
    "short_content":'.xpc ._LIp',
    "definition":"._Z1m ol>li ._H1m._kup"
}
VL.talkBackClassNamesAgent["Android"] = {
    "parent":'.hp-xpdbox ._o0d>div ._zdb',
    "long_content":'.hp-xpdbox ._tXc span',
    "short_content":'.hp-xpdbox ._o0d>div',
    "definition":'#ires table ol>li'
}

VL.jioApps ={};
VL.jioApps['JioCinema'] = ['jiocinema', 'cinema', 'movies', 'movie', 'film', 'films', 'cinemas'];
VL.jioApps['JioTV'] = ['jiotv', 'tv'];
VL.jioApps['JioMusic'] = ['jiomusic','jio music','gaana','song','songs'];
VL.jioApps['JioVideo'] = ['jiovideo', 'jio video'];
VL.jioApps['JioKisan'] = ['jiokisan'];
VL.jioApps['JioMoney'] = ['jiomoney'];
VL.jioApps['JioXpressNews'] =  ['news', 'samachar','express news','xpress news','jio xpress news','jio express news'];
VL.jioApps['KaiOS Plus'] =  ['app store', 'appstore', 'jiostore', 'jio store'];
VL.jioApps['JioChat'] =  ['jio chat','jio care','jiochat','jiocare'];
VL.jioApps['MyJio'] =  ['myjio','my jio','my geo','mygeo'];


VL.systemApps ={};
VL.systemApps['Net'] = ['net','browser','google','internet'];
VL.systemApps['Namo']=['memo','namo','mann ki baat','pmapp','pm app','nm app','narendra modi app'];
VL.systemApps['Contact'] = ['contact', 'phonebook', 'contacts', 'phone book','addressbook','address book'];
VL.systemApps['Messages']= ['sms', 'message', 'messages', 'messenger','sandes','sandesh','text'];
VL.systemApps['Call'] = ['call','dial','phone'];
VL.systemApps['Camera'] = ['camera', 'selfie', 'self', 'sesley', 'selfi'];
VL.systemApps['Clock']=['clock', 'alarm', 'stopwatch', 'timer','ghada','ghadiyal','ghadiyaal','ghadiyala'];
VL.systemApps['Gallery']=['gallery', 'photo', 'photos'];
VL.systemApps['Browser']= ['browser','internet','net'];
VL.systemApps['Settings']= ['setting','settings'];
VL.systemApps['Facebook']= ['facebook','fb'];
VL.systemApps['Youtube']= ['youtube'];
VL.systemApps['FM Radio']= ['fm','fmradio', 'radio'];
VL.systemApps['Wifi'] = ["wi-fi","wifi","wi fi","wai fai", "vifi", "vai fai"];
VL.systemApps['Volume'] = ["volume","aawaz","awaz","aawaj", "awaaj","awaaz"];
VL.systemApps['Language'] = ["language","bhasha","bhashaa","bhaasha"];
VL.systemApps['Battery'] = ["battery"];
VL.systemApps['Music'] = ["music"];
VL.systemApps['Video'] = ['video player', 'videos player', 'vdo player'];
VL.systemApps['Calculator'] = ["calculator", "calculate"];
VL.systemApps['Calendar'] = ["calendar"];
VL.systemApps['HelpVoice'] = ['help','sahayika','sahayta','udhavi','sahaya','madad'];

VL.openNet = ['Net','Browser','Google','net','browser','google','Internet','internet'];

VL.wifiControlOff=["band","off"];
VL.volControlUp = ["up","badhao","tez","tej","badhaiye","badiye","bado","badha","badhaye"];
VL.volControlDown = ["down","ghatao","ghataiye","kam","guitar","ghataye","ghata","gita"];

VL.lang_key = {
    'hi-IN': {
         launchKeywords: ['launch','chalu','play','chalao','chalo','chalaiye','chalaye','chalae','chali','chale','courier','lagao','open','khole','kholo','kholiye','koliye','kohli','kliye','start','shuru','shuruvat','suruwat','churu','show','dikhao','dikhaiye','dikhaye','cola','kola','kolo','kullam','kollo','collo','colo','on'],
         ignoreWords: ['karo', 'par', 'pe', 'ki', 'mujhe', 'mjhe', 'kare', 'on', 'ka', 'channel', 'karu', 'kariye','my','jio','geo','jeo',''],
         contactIgnoreWords: ['SMS','एसएमएस','को','करे','कीजिये','करो','सन्देश','संदेश','संदेस','भेजे','भेजो','भेजें','कीजिये','करो','करिये','करें','मैसेज','टेक्स्ट','लगाओ',"ko","Kare","kare","kijiye","karo","SMS","message","Message","Sandesh","sms","send","sandesh","sandes","bheje","bhejo","bhejein", "kijiye", 'karu', 'kariye', 'to','a','text','Text'],
         netSearch: ['नेट','खोल','इंटरनेट','ब्राउज़र','सर्च', 'देखो', 'चेक', 'करो', 'पे','पर', 'करिये', 'कीजिये','बताओ','दिखाओ','दिखाइए','दिखाएं','बताएं','दिखा','बता','खोलो','net','internet','google','browser','open']
    },
    'gu-IN': {
         launchKeywords: ['launch','chalu','play','chalao','chalo','chalaiye','chalaye','chalae','chali','chale','courier','lagao','open','khole','kholo','kholiye','koliye','kohli','kliye','start','shuru','shuruvat','suruwat','churu','show','dikhao','dikhaiye','dikhaye','cola','kola','kolo','kullam','kollo','collo','colo','on','chalavo','lagavo','chalawo','lagawo'],
         ignoreWords: ['karo', 'par', 'pe', 'ki', 'mujhe', 'mjhe', 'kare', 'on', 'ka', 'channel', 'karu', 'kariye','my','jio','geo','jeo',''],
         contactIgnoreWords: ['SMS','કો','કર', 'દો', 'સંદેશ', 'મોકલો', 'દુરુપયોગ', 'દો',' ટેક્સ્ટ ',' લાગુ','કરો ','ને','એસએમએસ','કરો','મેસેજ','karo','ne','kar','text','sms','lagao','lagavo','lagawo'],
         netSearch: ['નેટ', 'ઇન્ટરનેટ', 'બ્રાઉઝર',"ગોદો", "ગોતો", "શોધવું", "ખોળવું",  "શોધ", "ખોજ", "તપાસ", 'શોધ', 'જુઓ', 'ચેક', 'ડુ', 'પે', 'ઓન', 'ડુ', 'ગો', 'કહો', 'શો','કહો','પર', 'ઘોડૉ','ઘોટો','net','internet','open','google','browser']
    },
    'mr-IN': {
         launchKeywords: ['launch','chalu','play','chali','chale','courier','lagao','open','khola','start','shuru','suru','were','kara','la','lava','churu','show','cola','kola','colla','cola','on'],
         ignoreWords: ['kar','shodha', 'shodh', 'par','kara','ughda','ughada','ughada','Agra','agra','were','wer','var','ver', 'pe', 'ki','kare', 'on', 'ka', 'channel', 'karu', 'my','jio','geo','jeo','','la','lava'],
         contactIgnoreWords: ['SMS','sms','एसएमएस','को', 'कर', 'संदेश','दो', 'करा','ला','संदेश','मजकूर','लागू','लावा','मेसेज','ko','kar','do','sandesh','sandes','lagu','la','lava','kara'],
         netSearch: ['नेट', 'इंटरनेट','इंटरनेटवर', 'ब्राउझर', 'शोध','शोधा', 'लुक', 'चेक', 'डू', 'पे', 'ऑन', 'ग',' बॉल ',' शो ',' बोट','वर','करा','ला','net','internet','google','browser','open']
    },
    'bn-IN': {
        launchKeywords: ['launch','chalu','bajao','play','chalao','chalo','chale','courier','lagao','open','khole','kholo','start','show','cola','kola','kolo','kullam','kollo','collo','colo','on'],
        ignoreWords: ['karo','koro','ke','k', 'par', 'pe', 'ki', 'korte', 'on', 'ka', 'channel', 'my','jio','geo','jeo','','lo','lagao', 'laagao','pathao','ae','te','de','De','Chola','cholao','chola','chala'],
        contactIgnoreWords: ["sms","SMS","ko","Kare",'koro','ke','k',"kare","karo","kije","এসএমএস", "বার্তা", "বার্তা", "বার্তা", "এসএমএস", "পাঠান", "সেন্ড", "স্যান্ডেস", "ভিজি", "ভিজো", "ভিজিন", "কিজি", 'করু','কারি','টু','এ','টেক্সট','টেক্সট','কে','করো','কারো','পাঠাও','লাগাও','লাগা','কর'],
        netSearch: ['নেট', 'ইন্টারনেট','ইন্টেরনেটে', 'ব্রাউজার', 'উপর','অনুসন্ধান', 'ইন্টারনেট', 'নিট', 'পরীক্ষা', 'শো','চেক','করো','কারো','কর','net','internet','google','browser','open']
	},
    'te-IN': {
        launchKeywords: ['launch','play','courier','open','start','show','on'],
        ignoreWords: ['cheyandi', 'on', 'ka', 'channel', 'my','jio','geo','jeo','','lo','ni','ne','chaiyandi'],
        contactIgnoreWords: ['chandi','Chandi','cheyandi','ke','ka','lo',"బెజో", "భీజీన్", "కిజియ","SMS", "సందేశం", "సందేశం", "సందేశ్", "sms", "పంపు",'కరీ','టూ','ఎ','టెక్స్ట్'],
        netSearch: ['నికర', 'ఇంటర్నెట్', 'బ్రౌజర్', 'search', 'న', 'ఇంటర్నెట్', 'నెట్', 'చెక్', 'షో','లో','వెతకండి','net','internet','google','browser','open']
	},
    'ta-IN': {
        launchKeywords: ['launch','chalu','play','chalao','chalo','chalaiye','chalaye','chalae','chali','chale','courier','lagao','open','khole','kholo','kholiye','koliye','kohli','kliye','start','shuru','shuruvat','suruwat','churu','show','dikhao','dikhaiye','dikhaye','cola','kola','kolo','kullam','kollo','collo','colo','on'],
        ignoreWords: ['cheyandi','koro','ke','k', 'par', 'pe', 'ki', 'mujhe', 'mjhe', 'kare', 'on', 'ka', 'channel', 'karu', 'kariye','my','jio','geo','jeo',''],
        contactIgnoreWords: ["ko","Kare",'cheyandi','koro','ke','k',"kare","kijiye","karo","బెజో", "భీజీన్", "కిజియ","SMS", "సందేశం", "సందేశం", "సందేశ్", "sms", "పంపు", "sandesh", "sandes",'కరీ','టూ','ఎ','టెక్స్ట్'],
        netSearch: ['நிகர', 'இணைய', 'உலாவி', 'தேடல்', 'மீது', 'இணைய', 'நிகர', 'பார்க்கலாம்', 'நிகழ்ச்சி','net','internet','google','browser','open']
	},
    'kn-IN': {
        launchKeywords: ['launch','chalu','annu','play','chalao','chalo','chalaiye','chalaye','chalae','chali','chale','courier','lagao','open','khole','kholo','kholiye','koliye','kohli','kliye','start','shuru','shuruvat','suruwat','churu','show','dikhao','dikhaiye','dikhaye','cola','kola','kolo','kullam','kollo','collo','colo','on'],
        ignoreWords: ['karo', 'par', 'pe', 'ki','haaku','kelisi','nodabakku','keli','naanu','alli','nodabeku','on', 'ka', 'channel', 'my','jio','geo','jeo',''],
        contactIgnoreWords: ["SMS","message","Message","sms","send", 'to','a','text','Text'],
        netSearch: ['ನೆಟ್', 'ಇಂಟರ್ನೆಟ್', 'ಬ್ರೌಸರ್', 'ಹುಡುಕಾಟ', 'ಆನ್', 'ಇಂಟರ್ನೆಟ್', 'ನೆಟ್', 'ಚೆಕ್', 'ಶೋ','net','internet','google','browser','open']
	},
    'ml-IN': {
        launchKeywords: ['launch','chalu','annu','play','thurakoo','thooraku','thuraku','turakoo','tooraku','turaku','thurakkoo','thoorakku','thurakku','turakkoo','toorakku','turakku','open','start','show','on'],
        ignoreWords: ['il','cheeyo','chiyo','cheeyu','cheeyu','on', 'ka', 'channel','ne','ku','cheeyoo','kaanikkoo','kaanikku','kaanikoo','kanikkoo','kaaniku' ,'my','jio','geo','jeo',''],
        contactIgnoreWords: ["SMS","message","Message","sms","send", 'to','a','text','Text','il','മെസേജ്','ഇല്‍'],
        netSearch: ['ഇംടര്‌നെട്', 'നെറ്റ്', 'കാണിക്കൂ', 'ഇല്‍','net','internet','google','browser','open']
	},
    'en-IN': {
        launchKeywords: ['launch','chalu','play','chalao','chalo','chalaiye','chalaye','chalae','chali','chale','courier','lagao','open','khole','kholo','kholiye','koliye','kohli','kliye','start','shuru','shuruvat','suruwat','churu','show','dikhao','dikhaiye','dikhaye','cola','kola','kolo','kullam','kollo','collo','colo','on'],
        ignoreWords: ['karo', 'par', 'pe', 'ki', 'mujhe', 'mjhe', 'kare', 'on', 'ka', 'channel', 'karu', 'kariye','my','jio','geo','jeo',''],
        contactIgnoreWords: ["ko","Kare","kare","kijiye","karo","SMS","message","Message","Sandesh","sms","send","sandesh","sandes","bheje","bhejo","bhejein", "kijiye", 'karu', 'kariye', 'to','a','text','Text'],
        netSearch: ['net','internet','open','browser','search','karo','pe','par','on','ki','kariye','kijiye','Internet','Net','check','show','dikayo']
	}
    
}

VL.toReplaceInCall = ["phone","dial","call","फ़ोन","फोन","डायल","कॉल","ફોન","ડાયલ","કોલ"];

VL.locales = [
  {"lang_str":"en-IN","display_name":"English"},
  {"lang_str":"hi-IN","display_name":"हिन्दी (Hindi)"},
  {"lang_str":"gu-IN","display_name":"ગુજરાતી (Gujarati)"},
  {"lang_str":"mr-IN","display_name":"मराठी (Marathi)"},
  {"lang_str":"bn-IN","display_name":"বাংলা (Bengali)"},
  {"lang_str":"ta-IN","display_name":"தமிழ் (Tamil)"},
  {"lang_str":"te-IN","display_name":"తెలుగు (Telugu)"},
  {"lang_str":"kn-IN","display_name":"ಕನ್ನಡ (Kannada)"},
  {"lang_str":"ml-IN","display_name":"മലയാളം (Malayalam)"}
]

VL.mic_key = {
    'en-IN': {
        how_can_help: ['How can I help you?'],
        listening: ['Listening...'],
        wait: ['Wait'],
        processing: ['Processing...'],
        didnt_catch: ["Sorry didn\'t catch that"],
        speak_now:['Speak now...'],
        didnt_find_contact: ['Sorry couldn’t find that contact'],
        calling: ['Calling...'],
        activate_voice: ['Press Center button to activate voice'],
        battery_perc: ['Battery Percentage'],
        wifi_on: ['Wi-fi On'],
        wifi_off: ['Wi-fi Off'],
        check_internet: ['Please close app & ensure you have internet connectivity'],
        poor_connectivity: ['Poor network connectivity'],
        no_sim: ['Please insert a sim card'],
        push_talk : ["Press and hold centre key to record voice and release once done"],
        retry_msg : ["Press Center Button to try again"],
        retry_msg_ptt : ["Press and hold Center key to try again"]
    },
    'hi-IN': {
        how_can_help: ['मैं आपकी कैसे मदद कर सकता हूं?'],
        listening: ['सुन रहे हैं...'],
        wait: ['रुकिए'],
        processing: ['प्रसंस्करण...'],
        didnt_catch: ["खेद नहीं मिला"],
        speak_now:['अभी बोलिये...'],
        didnt_find_contact: ['खेद है संपर्क नहीं मिला'],
        calling: ['प्रसंस्करण...'],
        activate_voice: ['बोलने के लिए मध्य बटन दबाये'],
        battery_perc: ['बैटरी प्रतिशत'],
        wifi_on: ['वाई - फाई चालू'],
        wifi_off: ['वाई - फाई बंद'],
        check_internet: ['आपके इंटरनेट कनेक्शन मे कुछ समस्या है. कृपया दुबारा कोशिश करे.'],
        poor_connectivity: ['खराब इंटरनेट कनेक्शन'],
        no_sim: ['कृपया सिम कार्ड डालें'],
        push_talk: ["बोलने के लिए मध्य बटन दबाये रखें"],
        retry_msg : ["फिर से प्रयास करने के लिए सेंटर की दबाएं"],
        retry_msg_ptt : ["फिर से प्रयास करने के लिए लंबे समय तक सेंटर की दबाएं"]
    },
    'gu-IN': {
        how_can_help: ['તમારી મદત કેવી રીતે કરુ?'],
        listening: ['સાંભડુ છુ...'],
        wait: ['ઉભા રેજો'],
        processing: ['પ્રોસેસીંગ ...'],
        didnt_catch: ["માફ કરજો, સાંભદાયુ ન"],
        speak_now:['હવે બોલો...'],
        didnt_find_contact: ['માફ કરજો, કૉંટૅક્ટ ન મળ્યો'],
        calling: ['ફોન લાગે ચ્હે...'],
        activate_voice: ['અવાજ રેકૉર્ડ કરવા સેંટર કી દબાઓ'],
        battery_perc: ['બૅટરી દેખાડો'],
        wifi_on: ['Wi-fi ચાલુ કરો'],
        wifi_off: ['Wi-Fi બંધ'],
        check_internet: ['ઇંટરનેટ કનેક્ટિવિટી સાથે કાય સમસ્યા હોયે ટેમ લાગે ચ્હે. મેહેરબાની કરીને ફરી થી પ્રયાસ કરો'],
        poor_connectivity: ['નેટવર્ક કનેક્ટિવિટી સારી નથી'],
        no_sim: ['સિમ કાર્ડ શામેલ કરો'],
        push_talk: ["અવાજ રેકૉર્ડ કરવા સેંટર કી દબાવી રાખો અને રેકૉર્ડિંગ થયા પછી છોડી દો"],
        retry_msg : ["ફરી પ્રયાસ કરવા માટે પ્રેસ સેંટર કી"],
        retry_msg_ptt : ["ફરી પ્રયાસ કરવા માટે સેંટર કી દબાવો અને પકડી રાખો"]
    },
    'mr-IN': {
        how_can_help: ['आपली मदत कशी करू शकतो?'],
        listening: ['ऐकतोय...'],
        wait: ['थांबा'],
        processing: ['प्रोसेसिंग...'],
        didnt_catch: ["समजल नाही"],
        speak_now:['आता बोला...'],
        didnt_find_contact: ['कॉंटॅक्ट सापडला नाही'],
        calling: ['कॉलिंग...'],
        activate_voice: ['सेंटर बटन दाबा ऐकन सुरू करायला'],
        battery_perc: ['बॅटरी %'],
        wifi_on: ['वायफाय सुरू'],
        wifi_off: ['वायफाय बंद'],
        check_internet: ['तुमच्या इंटरनेट मध्ये समस्या आहे. पुन्हा प्रयत्न करा'],
        poor_connectivity: ['नेटवर्क कमी आहे'],
        no_sim: ['कृपया सिम कार्ड टाका'],
        push_talk: ["मधल बटन दाबून बोला आणि झाल्यावर सोडा"],
        retry_msg : ["मधल बटन दाबा परत प्रयत्न करण्यासाठी"],
        retry_msg_ptt : ["मधल बटन दाबून ठेवा परत प्रयत्न करण्यासाठी"]
    },
    'bn-IN': {
        how_can_help: ['কিভাবে আপনা সহায়তা করতে পারি ?'],
        listening: ['শুনছি...'],
        wait: ['অপেক্ষা করুন'],
        processing: ['প্রসেসিং...'],
        didnt_catch: ["দুঃখিত বুঝতে পারলাম না, পুনরায় চেষ্টা করুন"],
        speak_now:['এখন বলুন...'],
        didnt_find_contact: ['দুঃখিত ওই কন্টাক্ট টি খুঁজে পেলাম না '],
        calling: ['কল করা হচ্ছে...'],
        activate_voice: ['আওয়াজ রেকর্ড করার জন্য সেন্টার বাটন টিপুন'],
        battery_perc: ['ব্যাটারী  অবশিষ্ট / ব্যাটারি পার্সেন্টেজ'],
        wifi_on: ['ওয়াইফাই চালু আছে'],
        wifi_off: ['ওয়াইফাই বন্ধ আছে'],
        check_internet: ['মনে হচ্ছে আপনার ইন্টারনেট কানেক্শনে কিছু সমস্যা আছে, দয়া করে পুনরায় চেষ্টা করুন'],
        poor_connectivity: ['খারাপ নেটওয়ার্ক আসছে'],
        no_sim: ['দয়া  করে সিম কার্ড লাগান'],
        push_talk: ['আওয়াজ রেকর্ড করার জন্য সেন্টার বাটন টিপে রাখুন এবং রেকর্ডিং করার পর ছেড়ে দিন'],
        retry_msg : ["পুনরায় প্রচেষ্টা করার জন্য সেন্টার কি টিপুন"],
        retry_msg_ptt : ["পুনরায় প্রচেষ্টা করার জন্য সেন্টার কি টিপে রাখুন"]
    },
    'te-IN': {
        how_can_help: ['నేను ఎలా సహాయపడగలను?'],
        listening: ['వింటున్నాను...'],
        wait: ['వింటున్నాను'],
        processing: ['ప్రాసెసింగ్...'],
        didnt_catch: ["క్షమించండి మరల వివరించండి"],
        speak_now:['ఇప్పుడు మాట్లాడండి...'],
        didnt_find_contact: ['క్షమించండి ఈ కాంటాక్ట్ కనుబడుటలేదు'],
        calling: ['కాలింగ్...'],
        activate_voice: ['వాయిస్ రికార్డ్ చేయటానికి మధ్య బటన్ నొక్కండి'],
        battery_perc: ['బ్యాటరీ పర్సెంటజీ'],
        wifi_on: ['వై ఫై ఆన్'],
        wifi_off: ['వై ఫై ఆఫ్'],
        check_internet: ['మీ ఇంటర్నెట్ సరిగా లేదు. మరల ప్రయత్నించండి.'],
        poor_connectivity: ['నెట్వర్క్ సరిగ్గా లేదు'],
        no_sim: ['దయచేసి సిమ్ కార్డ్ పెట్టండి'],
        push_talk: ['రికార్డ్ చేయుటకు మధ్య బటన్ పట్టుకుని ఉంచండి, అవ్వగానే వదలండి'],
        retry_msg : ["మరల ప్రయత్నించటానికి మథ్య కీ నొక్కండి"],
        retry_msg_ptt : ["మరల ప్రయత్నించటానికి మథ్య కీ నొక్కి ఉంచండి "]
    },
    'kn-IN': {
        how_can_help: ['ನಾವು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾದ ಬಹುದು'],
        listening: ['ಕೇಳಿಸಿಕೊಳ್ಳುತ್ತೈದೀನಿ...'],
        wait: ['ನಿಲ್ಲು'],
        processing: ['ಶರುವಾಗಿಗಿದೆ...'],
        didnt_catch: ["ಕ್ಷಮೀಸೆ ಇದು ಗೊತ್ತಾಗಲ್ಲಿಲ್ಲಾ"],
        speak_now:['ಹೇಳಿ ಇವಾಗಾ...'],
        didnt_find_contact: ['ಕ್ಷಮೀಸೆ ಕಾಂಟ್ಯಾಕ್ಟ್ ಸಿಗಿತುಲ್ಳಿಲ'],
        calling: ['ಕಾಲಿಂಗ್...'],
        activate_voice: ['ಮಧ್ಯದ ಕೀ ಅನ್ನು ಹೊತ್ತಿ  ವಾಯ್ಸ್ ಮೆಸೇಜ್ ರೆಕಾರ್ಡ್ ಮಾಡಿ'],
        battery_perc: ['ಬ್ಯಾಟರೀ %'],
        wifi_on: ['ವಿ-ಫೀ ಒನ್'],
        wifi_off: ['ವಿ-ಫೀ ಆಫ್'],
        check_internet: ['ಇಂಟರ್‌ನೆಟ್ ಕನೆಕ್ಟ್ ಮಾಡುವಾಗ ಏನೋ ತೊಂದರೆ ಇಂದೇ ಅನಿಸುತ್ತಿದೆ .ಸ್ವಲ್ಪ ಸಮಯದ ನಂತರ ಪ್ರಯತ್ನಿಸಿ'],
        poor_connectivity: ['ನೆಟ್‌ವರ್ಕ್ ಇಲ್ಲ ತುಂಭಾ ಕಡಿಮೆ'],
        no_sim: ['ದಯವಿಟ್ಟು SIM ಕಾರ್ಡ್ ಅನ್ನು ಸೇರಿಸಿ'],
        push_talk: ['ಬಟನ್ ಅನ್ನು ಹೊತ್ತಿ ಕೀ ಹೋಲ್ಡ್ ಮಾಡಿ ನಿಮ್ಮ ವಾಯ್ಸ್ ರೆಕಾರ್ಡ್ ಮಾಡಿ ಮತ್ತೆ ಬಿಟ್ಟು ಬಿಡಿ ರೆಕಾರ್ಡ್ ಮಾಡಿದ ನಂತರ'],
        retry_msg : ["ಮತ್ತೊಮ್ಮೆ ಪ್ರಯತ್ನಿಸಲು, ಕೇಂದ್ರದ ಕೀಲಿಯನ್ನು ಒತ್ತಿರಿ"],
        retry_msg_ptt : ["ಮತ್ತೊಮ್ಮೆ ಪ್ರಯತ್ನಿಸಲು, ಸೆಂಟರ್ ಕೀಲಿಯನ್ನು ಒತ್ತಿ ಹಿಡಿದುಕೊಳ್ಳಿ"]
    },
    'ta-IN': {
        how_can_help: ['நான் உங்களுக்கு எப்படி உதவலாம்?'],
        listening: ['கேட்கிறேன்…'],
        wait: ['காத்திரு'],
        processing: ['செயலாக்குகிறது…'],
        didnt_catch: ["மன்னிக்கவும் புரியவில்லை"],
        speak_now:['இப்போது பேசவும்…'],
        didnt_find_contact: ['மன்னிக்கவும் அந்த தொடர்பு கிடைக்கவில்லை'],
        calling: ['காலிங்…'],
        activate_voice: ['குரல் பதிவு செய்ய சென்டர் விசையை அழுத்தவும்'],
        battery_perc: ['பேட்டரி சதவிதம்'],
        wifi_on: ['வைஃபை ஆன்'],
        wifi_off: ['வைஃபை ஆஃப்'],
        check_internet: ['இணைய இணைப்பு பிரச்சினை உள்ளது. தயவு செய்து மீண்டும் முயற்சிக்கவும்.'],
        poor_connectivity: ['மோசமான நெட்வொர்க் இணைப்பு'],
        no_sim: ['சிம் கார்டைச் செருகவும்'],
        push_talk: ['குரல் பதிவு செய்ய சென்டர் விசையை அழுத்தி பிடிக்கவும், முடிந்தவுடன் விசையை விடவும்'],
        retry_msg : ["மீண்டும் முயற்சிக்க மைய விசையை அழுத்தவும்"],
        retry_msg_ptt : ["மீண்டும் முயற்ச்சிக்க மைய விசையை அழுத்தி பிடிக்கவும்"]
    },
    'ml-IN': {
        how_can_help: ['ഞ്ഞജന്‍ നിങ്ങളെ എങ്ങിനെയാണ്‌ സഹായിക്കേണ്ടത്‌'],
        listening: ['കേള്‍ക്കുന്നു…'],
        wait: ['കാത്തിരിക്കൂ'],
        processing: ['പ്രോസെസ് ചെയ്യുന്നു…'],
        didnt_catch: ["ക്ഷമിക്കണം, പറഞ്ഞത് മനസ്സിലായില്ല"],
        speak_now:['ഇപ്പോള്‍, സംസാരിക്കൂ…'],
        didnt_find_contact: ['ക്ഷമിക്കണം, നിങ്ങള്‍ ആവശ്യപെട്ട കാംട്യാക്ട് ലഭ്യമല്ല'],
        calling: ['വിളിക്കുന്നു…'],
        activate_voice: ['ശബ്ദം റെക്കോർഡുചെയ്യുന്നതിന് സെൻട്രൽ കീ അമർത്തുക'],
        battery_perc: ['ബ്യാടരീ ശതമാനം'],
        wifi_on: ['വിഫി ഒന്നാണ്'],
        wifi_off: ['വിഫി ഓഫ്ഫാണ്'],
        check_internet: ['ഇന്റർനെറ്റ് കണക്റ്റിവിറ്റിയിൽ ഒരു പ്രശ്നമുണ്ടെന്ന് തോന്നുന്നു. വീണ്ടും ശ്രമിക്കുക.'],
        poor_connectivity: ['കുറഞ്ഞ നെറ്റ്വർക്ക് കണക്റ്റിവിറ്റി'],
        no_sim: ['ദയവായി ഒരു സിം കാർഡ് ഇടുക'],
        push_talk: ['ശബ്ദം റെക്കോർഡുചെയ്യാൻ സെന്റർ കീ അമർത്തിപ്പിടിക്കുക, ചെയ്തുകഴിഞ്ഞാൽ റിലീസ് ചെയ്യുക'],
        retry_msg : ["വീണ്ടും ശ്രമിക്കാൻ മധ്യഭാഗത്ത് കീ അമർത്തുക"],
        retry_msg_ptt : ["വീണ്ടും ശ്രമിക്കാൻ മധ്യഭാഗത്ത് കീ അമർത്തിപ്പിടിക്കുക"]
    }
}

VL.faq = [
  {"title":"1. How do I change the language?","text":"To change the language, click on the ‘Language’ option on the Right Soft Key and select the desired language."},
  {"title":"2. What are some of the commands I can give my Voice Assistant?","text":"To view a sample list of commands you can give, go to the Menu and select Guide."},
  {"title":"3. When do I give the voice command?","text":"On App launch, you can start speaking when you see the ‘Listening’ screen. Other times, you can press the centre key, when prompted, to activate voice recording."},
  {"title":"4. How do I search something on the internet?","text":"To do this, you simply need to say the word ‘internet’ followed by your question. It’s that simple!"},
  {"title":"5. Why can’t I place calls or send SMS’s using HelloJio Voice Assistant?","text":"If you see the ‘Please insert SIM Card’ error message, it means your SIM card isn’t inserted or is not properly in place. Properly fix the SIM card in its slot and try again.If you see the ‘Poor Network Connectivity’ error message, it means the device is receiving very poor network coverage. Try moving to an area with better network coverage."},
  {"title":"6. I keep seeing the screen ‘Please close app and ensure you have internet connectivity’. Why can’t I use my HelloJio Voice Assistant?","text":"When you see this screen, it means your device does not have an internet connection. You can try the following steps: <br>6.1. Ensure your phone is not on Airplane mode<br>6.2. Ensure your phones data connection is on or the WiFi is connected."},
  {"title":"7. Whenever I speak a voice command, I get the screen ‘Sorry didn’t catch’. Why is that?","text":"If you’re seeing this screen, it means the HelloJio Voice Assistant wasn’t able to properly receive the audio message. Try not being too loud, or speaking too softly."},
]
