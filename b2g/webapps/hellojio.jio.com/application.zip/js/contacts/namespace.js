window.FxContactMgr = {};
window.FxContactMgr.API = {};
window.FxContactMgr.View = {};