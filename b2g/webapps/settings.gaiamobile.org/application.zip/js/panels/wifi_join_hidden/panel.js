
/* global SettingsSoftkey */
define('panels/wifi_join_hidden/panel',['require','shared/toaster','modules/wifi_utils','shared/wifi_helper','modules/wifi_context','modules/settings_panel','modules/settings_service'],function(require) {
  
  var Toaster = require('shared/toaster');
  var WifiUtils = require('modules/wifi_utils');
  var WifiHelper = require('shared/wifi_helper');
  var WifiContext = require('modules/wifi_context');
  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');
  var wifiManager = WifiHelper.getWifiManager();

  return function ctor_joinHiddenWifi() {
    var elements = {};
    var _network = {};

    function _keydownHandler(evt) {
      switch (evt.key) {
        case 'ArrowUp':
        case 'ArrowDown':
          var input = document.querySelector('li.focus input');
          input && input.focus();
          break;
        default:
          break;
      }
    }

    function _enableConnectSoftKey(evt) {
      _updateSoftKey(evt.detail.enabled);
    }

    function _updateSoftKey(enabled) {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Connect',
          l10nId: 'device-option-connect',
          priority: 3,
          method: function() {
            _connectNetwork();
          }
        }]
      };

      SettingsSoftkey.init(softkeyParams);
      if (enabled && elements.ssid.value.length) {
        SettingsSoftkey.show();
      } else {
        SettingsSoftkey.hide();
      }
    }

    function _isNetworkMatch(network) {
      var currentNetworkSSID = elements.ssid.value;
      return currentNetworkSSID === network.ssid;
    }

    function _connectNetwork() {
      // We have to keep these information in network object
      _network.ssid = elements.ssid.value;
      _network.hidden = true;

      var network;
      if (window.MozWifiNetwork !== undefined) {
        network = new window.MozWifiNetwork(_network);
      }

      WifiHelper.setPassword(
        network,
        elements.password.value,
        elements.identity.value,
        elements.eap.value,
        elements.authPhase2.value,
        elements.certificate.value,
        elements.keyIndex.value - 1
      );

      var callback = (result) => {
        if (result !== null && result.name === 'network not found') {
          _showToast('hidden-wifi-not-found');
        }
      };

      WifiContext.associateNetwork(network,callback);
    }

    function _showToast(msgId) {
      var toast = {
        messageL10nId: msgId,
        latency: 2000,
        useTransition: true
      };
      Toaster.showToast(toast);
    }

    function _wifiStatusChangeHandler(evt) {
      if (evt.status === 'connected' &&
        _isNetworkMatch(evt.network)) {
        _showToast('hidden-wifi-connected');
        SettingsService.navigate('wifi-manageNetworks');
      }
    }

    function _openWrongPasswordDialog() {
      var networkEAPMethod = elements.eap.value;
      if (networkEAPMethod === 'PEAP' ||
          networkEAPMethod === 'TTLS') {
        _openBadCredentialsDialog('hidden-wifi-eap-error');
      } else {
        _openBadCredentialsDialog('wifi-authentication-failed');
      }
    }

    function _openConnetingFailedDialog() {
      _openBadCredentialsDialog('wifi-association-reject');
    }

    function _openObtainingIPFailedDialog() {
      _openBadCredentialsDialog('wifi-DHCP-failed');
    }

    function _openBadCredentialsDialog(msgId) {
      var network = WifiContext.currentNetwork;
      var dialogConfig = {
        title: {
          id: 'wifi-bad-credentials-title',
          args: {}
        },
        body: {
          id: msgId,
          args: {
            ssid: network.ssid
          }
        },
        accept: {
          name: 'OK',
          l10nId: 'ok',
          priority: 2,
          callback: function() {
            dialog.destroy();
          }
        }
      };

      var dialog = new ConfirmDialogHelper(dialogConfig);
      dialog.show(document.getElementById('app-confirmation-dialog'));
    }

    function _panelreadyHandler() {
      _updateSoftKey(_checkConnectSoftkeyState());
      elements.ssid.focus();
    }

    function _checkConnectSoftkeyState() {
      var key = elements.security.value;
      var password = elements.password.value;
      var identity = elements.identity.value;
      var eap = elements.eap.value;

      return WifiHelper.isValidInput(key, password, identity, eap);
    }

    function _onSecurityChange(evt) {
      var key = elements.security.value;
      elements.panel.dataset.security = key;

      WifiHelper.setSecurity(_network, [key]);
      WifiUtils.changeDisplay(elements.panel, key);
      WifiUtils.initializeAuthFields(elements.panel, _network);
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function _onSSIDchange(event) {
      // Bug 1082394, during composition, we should not change the input
      // value. Otherwise, the input value will be cleared unexpectedly.
      // Besides, it seems unnecessary to change input value before
      // composition is committed.
      if (event.isComposing) {
        return;
      }
      // Make sure ssid length is no more than 32 bytes.
      var str = elements.ssid.value;
      // Non-ASCII chars in SSID will be encoded by UTF-8, and length of
      // each char might be longer than 1 byte.
      // Use encodeURIComponent() to encode ssid, then calculate correct
      // length.
      var encoder = new TextEncoder('utf-8');
      while (encoder.encode(str).length > 32) {
        str = str.substring(0, str.length - 1);
      }
      if (str !== elements.ssid.value) {
        elements.ssid.value = str;
      }
      _updateSoftKey(_checkConnectSoftkeyState());
    }

    return SettingsPanel({
      onInit: function(panel) {
        elements = {
          panel: panel,
          ssid: panel.querySelector('input[name="ssid"]'),
          security: panel.querySelector('select[name="security"]'),
          identity: panel.querySelector('input[name="identity"]'),
          password: panel.querySelector('input[name="password"]'),
          showPassword: panel.querySelector('input[name=show-pwd]'),
          eap: panel.querySelector('select[name="eap"]'),
          keyIndex: panel.querySelector('li.key-index select'),
          authPhase2: panel.querySelector('li.auth-phase2 select'),
          certificate: panel.querySelector('li.server-certificate select'),
        };
      },

      onBeforeShow: function(panel) {
        _onSecurityChange.call(elements.security);

        window.addEventListener('keydown', _keydownHandler);

        elements.ssid.addEventListener('input', _onSSIDchange);

        elements.security.addEventListener('change', _onSecurityChange);

        window.addEventListener('panelready', _panelreadyHandler);

        window.addEventListener('enable-connect-softkey',
          _enableConnectSoftKey);

        WifiContext.addEventListener('wifiStatusChange',
          _wifiStatusChangeHandler);
        WifiContext.addEventListener('wifiWrongPassword',
          _openWrongPasswordDialog);
        WifiContext.addEventListener('wifiConnectingFailed',
          _openConnetingFailedDialog);
        WifiContext.addEventListener('wifiObtainingIPFailed',
          _openObtainingIPFailedDialog);

        var input = document.querySelector('li.focus input');
        if (input !== null) {
          input && input.focus();
        }
        _updateSoftKey(_checkConnectSoftkeyState());
      },

      onBeforeHide: function() {
        elements.password.value = '';
        elements.identity.value = '';
        elements.showPassword.checked = false;

        SettingsSoftkey.hide();

        window.removeEventListener('keydown', _keydownHandler);

        elements.ssid.removeEventListener('input', _onSSIDchange);

        elements.security.removeEventListener('change', _onSecurityChange);

        window.removeEventListener('panelready', _panelreadyHandler);

        window.removeEventListener('enable-connect-softkey',
          _enableConnectSoftKey);

        WifiContext.removeEventListener('wifiStatusChange',
          _wifiStatusChangeHandler);
        WifiContext.removeEventListener('wifiWrongPassword',
          _openWrongPasswordDialog);
        WifiContext.removeEventListener('wifiConnectingFailed',
          _openConnetingFailedDialog);
        WifiContext.removeEventListener('wifiObtainingIPFailed',
          _openObtainingIPFailedDialog);
      }
    });
  };
});
