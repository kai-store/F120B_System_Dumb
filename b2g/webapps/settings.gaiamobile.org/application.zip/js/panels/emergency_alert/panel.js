/* global SettingsSoftkey */
/**
 * Used to show Emergency alert panel
 */
define(['require','modules/settings_panel'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');

  return function ctor_emergency_alert_panel() {
    var elements = {};

    function _initSoftKey() {
      var params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Select',
          l10nId: 'select',
          priority: 2
        }]
      };
      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function _keyDownHandler(evt) {
      if (evt.key === 'Enter') {
        try {
          new MozActivity({
            name: 'alert_inbox'
          });
        } catch (e) {
          console.error('Failed to create an alert_inbox activity: ' + e);
        }
      }
    }

    function _updateAlertBodyDisplay(panel) {
      var alertBody = panel.querySelector('#receive-alert-body');
      var request = navigator.mozSettings.createLock().get('cmas.settings.show');
      request.onsuccess = () => {
        var val = request.result['cmas.settings.show'];
        if (val === 'undefined') {
          val = true;
        }
        if (alertBody.hidden === val) {
          alertBody.hidden = !val;
          window.dispatchEvent(new CustomEvent('refresh'));
        }
      };
      request.onerror = () => {
        console.error('ERROR: Can not get the receive alert setting.');
      };
    }

    return SettingsPanel({
      onInit: function(panel) {
        elements = {
          alertbox: document.getElementById('alert-inbox')
        };
        _updateAlertBodyDisplay(panel);
      },

      onBeforeShow: function() {
        _initSoftKey();
        elements.alertbox.addEventListener('keydown', _keyDownHandler);
      },

      onBeforeHide: function() {
        SettingsSoftkey.hide();
        elements.alertbox.removeEventListener('keydown', _keyDownHandler);
      }
    });
  };
});
