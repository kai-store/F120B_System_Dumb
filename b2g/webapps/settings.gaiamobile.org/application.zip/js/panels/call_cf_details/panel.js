/* global SettingsSoftkey */
define(['require','modules/settings_service','modules/settings_panel','shared/toaster','shared/settings_listener'],function(require) {
  
  var SettingsService = require('modules/settings_service');
  var SettingsPanel = require('modules/settings_panel');
  var Toaster = require('shared/toaster');
  var SettingsListener = require('shared/settings_listener');

  return function ctor_call_cf_details_panel() {
    var _callForwardingKey,
      _callForwardingNumber;

    var _inputItem,
      _selectItem;

    var _savedValue = false;

    var settingsKey = {'call-cf-unconditionalSettings' : 'ril.cf.unconditional.enabled',
                       'call-cf-mobileBusySettings' : 'ril.cf.mobilebusy.enabled',
                       'call-cf-noReplySettings' : 'ril.cf.noreply.enabled',
                       'call-cf-notReachableSettings' : 'ril.cf.notreachable.enabled'};

    var numbersKey = {'call-cf-unconditionalSettings' : 'ril.cf.unconditional.number',
                      'call-cf-mobileBusySettings' : 'ril.cf.mobilebusy.number',
                      'call-cf-noReplySettings' : 'ril.cf.noreply.number',
                      'call-cf-notReachableSettings' : 'ril.cf.notreachable.number'};

    var paramsForSave = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Cancel',
        l10nId: 'cancel',
        priority: 1,
        method: function() {
          SettingsService.navigate('call-cfSettings');
        }
      },{
        name: 'Select',
        l10nId: 'select',
        priority: 2,
        method: function() {}
      },{
        name: 'Save',
        l10nId: 'save',
        priority: 3,
        method: function() {
          _setCallForwardingOption();
          SettingsService.navigate('call-cfSettings');
        }
      }]
    };

    function _initSoftkey() {
      var params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method: function() {
            SettingsService.navigate('call-cfSettings');
          }
        },{
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method: function() {}
        }]
      };
      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function _updateUI() {
      var request = SettingsListener.getSettingsLock().get(_callForwardingKey);

      request.onsuccess = function() {
        _savedValue = request.result[_callForwardingKey];
        _selectItem.value = request.result[_callForwardingKey];
        _updateInputStatus();
      };

      request.onerror = function() {
        var toast = {
          messageL10nId: 'callForwardingSetError',
          latency: 2000,
          useTransition: true
        };
        Toaster.showToast(toast);
        SettingsService.navigate('call-cfSettings');
      };
    }

    function _updateInputStatus() {
      var enabled = (_selectItem.value === 'true' || false);
      _inputItem.parentNode.hidden = !enabled;
      if (enabled) {
        SettingsListener.getSettingsLock().get(_callForwardingNumber)
          .then((result) => {
            var number = result[_callForwardingNumber];
            _inputItem.setAttribute('value', number);
            _inputItem.focus();
          })
          .catch((error) => console.log('Promise rejects due to ' + error));
      }

      SettingsSoftkey.init(paramsForSave);
      SettingsSoftkey.show();
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function _setCallForwardingOption() {
      var enabled = (_selectItem.value === 'true' || false);
      var option = {};
      option[_callForwardingKey] = enabled;
      SettingsListener.getSettingsLock().set(option);
    }

    function _addFocus(evt) {
      _inputItem.focus();
      SettingsSoftkey.init(paramsForSave);
      SettingsSoftkey.show();
    }

    return SettingsPanel({
      onInit: function(panel) {
        _callForwardingKey = settingsKey[panel.id];
        _callForwardingNumber = numbersKey[panel.id];
        _selectItem = panel.querySelector('div select');
        _inputItem = panel.querySelector('li input');
      },

      onBeforeShow: function() {
        _initSoftkey();
        if (!_callForwardingKey) {
          return;
        }
      },

      onShow: function(panel) {
        _updateUI();
        _selectItem.addEventListener('change', _updateInputStatus);
        _inputItem.parentNode.addEventListener('focus', _addFocus);
      },

      onHide: function() {
        _selectItem.removeEventListener('change', _updateInputStatus);
        _inputItem.parentNode.removeEventListener('focus', _addFocus);
      },

      onBeforeHide: function() {
        SettingsSoftkey.hide();
      }
    });
  };
});
