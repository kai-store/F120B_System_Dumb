/**
 * The apn editor panel
 */
define(['require','shared/toaster','modules/settings_panel','modules/settings_cache','panels/apn_editor/apn_editor','modules/settings_service','modules/apn/apn_settings_manager'],function(require) {
  
  var Toaster = require('shared/toaster');
  var SettingsPanel = require('modules/settings_panel');
  var SettingsCache = require('modules/settings_cache');
  var ApnEditor = require('panels/apn_editor/apn_editor');
  var SettingsService = require('modules/settings_service');
  var ApnSettingsManager = require('modules/apn/apn_settings_manager');

  return function ctor_apnEditorPanel() {
    var _leftApp = false;
    var _apnItem;
    var _apnType;
    var _serviceId;
    var _apnEditor;
    var _editType;
    var _rootElement;
    var _editorSession;
    var _mandatoryItems;

    function _updateSoftKey(enableSaveSoftkey) {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method: function() {
            _openWaringDialog();
          }
        }]
      };

      if (enableSaveSoftkey) {
        softkeyParams.items.push({
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method: function() {
            _onApnSave();
          }
        });
      }

      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function _keyDownHandler(evt) {
      if ((evt.key === 'Backspace' ||
           evt.key === 'EndCall') &&
        Settings.currentPanel === '#apn-editor') {
        evt.preventDefault();
        _openWaringDialog(evt.key);
      }
    }

    function _checkMandatoryItems() {
      var apnName = _mandatoryItems.apnName.value;
      var apnType = _mandatoryItems.apnType.value;

      return (apnName !== '' && apnType !== '');
    }

    function _back(softKeyName) {
      if (softKeyName === 'EndCall') {
        window.close();
      } else {
        SettingsService.navigate('apn-list', {
          action: _editType
        });
      }
    }

    var _showApnChangeWarningDialog = () => {
      return new Promise(resolve => {
        var dialogConfig = {
          title: {id: 'confirmation', args: {}},
          body: {id: 'change-apn-warning-message', args: {}},
          desc: {id: 'change-apn-warning-question', args: {}},
          cancel: {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            callback: function() {
              resolve(false);
            }
          },
          confirm: {
            name: 'Ok',
            l10nId: 'ok',
            priority: 3,
            callback: function() {
              resolve(true);
            }
          }
        };

        var dialog = new ConfirmDialogHelper(dialogConfig);
        dialog.show(document.getElementById('app-confirmation-dialog'));
      });
    };

    function _onApnSave(softKeyName) {
      if (!_editorSession) {
        _back(softKeyName);
        return;
      }

      // Display the warning only when Data roaming is turned on and it is
      // the current APN in use that’s being edited.
      Promise.all([
        ApnSettingsManager.getActiveApnId(_serviceId, _apnType),
        new Promise(resolve => {
          SettingsCache.getSettings(results => {
            resolve(results['ril.data.roaming_enabled']);
          });
        })
      ]).then(results => {
        var activeApnId = results[0];
        var dataRoamingEnabled = results[1];
        if (activeApnId === _apnItem.id && dataRoamingEnabled) {
          return _showApnChangeWarningDialog();
        } else {
          return true;
        }
      }).then(result => {
        if (result) {
          _editorSession.commit().then(() => {
            _back(softKeyName);
            _showToaster();
          });
          _editorSession = null;
        }
      });
    }

    function _showToaster() {
      Toaster.showToast({
        messageL10nId: 'changessaved',
        latency: 2000,
        useTransition: true
      });
    }

    function _openWaringDialog(softKeyName) {
      var dialogConfig = {
        title: {id: 'confirmation', args: {}},
        body: {id: 'apn-editor-warning-body', args: {}},
        desc: {id: 'apn-editor-warning-desc', args: {}},
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback: function() {}
        },
        confirm: {
          name: 'Discard',
          l10nId: 'discard',
          priority: 3,
          callback: function() {
            _back(softKeyName);
          }
        }
      };

      if (_checkMandatoryItems()) {
        dialogConfig.accept = {
          name: 'Save',
          l10nId: 'save',
          priority: 2,
          callback: function() {
            _onApnSave(softKeyName);
          }
        };
      }

      var dialog = new ConfirmDialogHelper(dialogConfig);
      dialog.show(document.getElementById('app-confirmation-dialog'));
    }

    function _onItemInput() {
      _updateSoftKey(_checkMandatoryItems());
    }

    function _addTextInputEvent() {
      var item = null;
      for (item in _mandatoryItems) {
        _mandatoryItems[item].addEventListener('input', _onItemInput);
      }
    }

    function _removeTextInputEvent() {
      var item = null;
      for (item in _mandatoryItems) {
        _mandatoryItems[item].removeEventListener('input', _onItemInput);
      }
    }

    function _onItemFocus(item) {
      var input = item.target.querySelector('input');
      input && input.focus();
    }

    function _addInputFocusEvent() {
      var liElements = _rootElement.querySelectorAll('li');
      for (var i = 0; i < liElements.length; i++) {
        liElements[i].addEventListener('focus', _onItemFocus);
      }
    }

    function _removeInputFocusEvent() {
      var liElements = _rootElement.querySelectorAll('li');
      for (var i = 0; i < liElements.length; i++) {
        liElements[i].removeEventListener('focus', _onItemFocus);
      }
    }

    function _initUI(options) {
      // If this flag has been set, which means that users have been left
      // the app before so we should keep the original state instead of
      // refreshing it.
      if (_leftApp) {
        _leftApp = false;
        return;
      }

      var mode = options.mode || 'new';
      _apnItem = options.item || {};
      _apnType = options.type || 'default';
      _serviceId = options.serviceId;

      var enableSaveSoftkey = (mode === 'edit');
      _updateSoftKey(enableSaveSoftkey);

      switch (mode) {
        case 'new':
          var defaultApnItem = {
            apn: {
              types: [_apnType]
            }
          };
          _editType = 'new';
          _editorSession = _apnEditor.createApn(_serviceId, defaultApnItem);
          break;
        case 'edit':
          _editType = 'edit';
          _editorSession = _apnEditor.editApn(_serviceId, _apnItem);
          break;
      }
    }

    return SettingsPanel({
      onInit: function ae_onInit(rootElement, options) {
        _rootElement = rootElement;
        _mandatoryItems = {
          apnType: _rootElement.querySelector('input.types'),
          apnName: _rootElement.querySelector('input.apn')
        };
        _apnEditor = new ApnEditor(rootElement);
      },

      onBeforeShow: function ae_onBeforeShow(rootElement, options) {
        _initUI(options);
        _addInputFocusEvent();
        window.addEventListener('keydown', _keyDownHandler);
      },

      onbeforeHide: function ae_onBeforeHide() {
        SettingsSoftkey.hide();
        _removeInputFocusEvent();
        window.removeEventListener('keydown', _keyDownHandler);
      },

      onShow: function ae_onShow() {
        _addTextInputEvent();
      },

      onHide: function ae_onHide() {
        _removeTextInputEvent();
        _leftApp = document.hidden;
        if (!_leftApp && _editorSession) {
          _editorSession.cancel();
        }
      }
    });
  };
});
