define(['require','modules/settings_panel','modules/settings_service','shared/toaster'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');
  var Toaster = require("shared/toaster") ;
  return function ctor_device_inthe_area() {
    var bluetooth = navigator.mozBluetooth;
    var _ = navigator.mozL10n.get;
    var nopairedDesc = document.getElementById('nopaired-devices');
    var confirmationDialog = document.getElementById('app-confirmation-dialog');
    var defaultAdapter = null ;
    var connectingAddress = null;
    var isDisconnecting = false;
    var connectedAddress = null;
    var elements = {} ;
    // Service ID for profiles
    var Profiles = {
      'HFP': 0x111E,
      'A2DP': 0x110D
    };
    var pairList = {
      list: document.getElementById('bluetooth-paired-devices'),
      index: [],
      clear: function emptyList() {
        while (this.list.hasChildNodes()) {
          this.list.removeChild(this.list.lastChild);
        }
        this.index = [];
      },
      show: function showArea(isShown) {
        if (!isShown) {
          this.clear();
        }
        this.list.hidden = !isShown;
      }
    };

    function setDeviceDisconnect(device, callback) {
      if (!bluetooth.enabled || !defaultAdapter ||
          device.address !== connectedAddress) {
        if (callback)
          callback();
        return;
      }

      // Don't allow user to disconnect when it's connecting / disconnecting.
      if (isDisconnecting || connectingAddress !== null) {
        return;
      }
      isDisconnecting = true;
      var small = pairList.index[connectedAddress].item.querySelector('small');
      small.setAttribute('data-l10n-id', 'device-status-disconnecting');
      var req = defaultAdapter.disconnect(device);
      req.onerror = function () {
        var toaster = {
          messageL10nId: 'error-disconnect-toast',
          latency: 2000,
          useTransition: true
        };
        Toaster.showToast(toaster);
       };
      req.onsuccess = function() {
        connectedAddress = null;
        small.setAttribute('data-l10n-id', 'device-status-tap-connect');
        if (callback)
          callback();
        isDisconnecting = false;
      };
      req.onerror = function() {
        isDisconnecting = false;
      };
    }
    function setDeviceConnect(device) {
      // we only support audio-card device to connect now
      if (!bluetooth.enabled || !defaultAdapter ||
          device.icon !== 'audio-card' ||
          device.address === connectedAddress) {
        connectingAddress = null;
        return;
      }

      // Don't allow user to connect when it's connecting / disconnecting.
      if (isDisconnecting || connectingAddress !== null) {
        return;
      }

      var doConnect = function() {

        var showErrorConnectMsg = function(){
          var toaster = {
            messageL10nId: 'error-connect-toast',
            latency: 2000,
            useTransition: true
          };
          Toaster.showToast(toaster);
        }

        var showSuccessConnectMsg = function(){
          var toaster = {
            messageL10nId: 'success-connect-toast',
            messageL10nArgs:{'deviceName':device.name},
            latency: 2000,
            useTransition: true
          };
          Toaster.showToast(toaster);
        }

        var connectSuccess = function bt_connectSuccess() {
          if (connectingAddress) {
            showSuccessConnectMsg();
            connectingAddress = null;
          }
        };

        var connectError = function bt_connectError() {
          // Connection state might be changed before DOM request response.
          if (connectingAddress) {
            // Clear the text of connecting status.
            var small =
              pairList.index[connectingAddress].item.querySelector('small');
            small.setAttribute('data-l10n-id', 'device-status-tap-connect');
            connectingAddress = null;
            showErrorConnectMsg();
          }
        };

        var req = defaultAdapter.connect(device);
        req.onsuccess = connectSuccess; // At least one profile is connected.
        req.onerror = connectError; // No available profiles are connected.

        connectingAddress = device.address;
        if (!pairList.index[connectingAddress]) {
          return;
        }

        var small =
          pairList.index[connectingAddress].item.querySelector('small');
        small.setAttribute('data-l10n-id', 'device-status-connecting');
      };

      // disconnect current connected device first
      if (connectedAddress && pairList.index[connectedAddress]) {
        setDeviceDisconnect(pairList.index[connectedAddress].device, doConnect);
      } else {
        doConnect();
      }
    }
    function showDeviceConnected(deviceAddress, connected, profile) {
      var deviceItem = pairList.index[deviceAddress];
      if (!deviceItem)
        return;

      deviceItem.connectedProfiles[profile] = connected;

      var existConnectedProfile = false;
      if (connected) {
        existConnectedProfile = true;
      } else {
        // Check if there are other connected profiles
        for (var profile in deviceItem.connectedProfiles) {
          existConnectedProfile = existConnectedProfile ||
              deviceItem.connectedProfiles[profile];
        }
      }

      if (existConnectedProfile) {
        connectedAddress = deviceAddress;
        // record connected device so if Bluetooth is turned off and then on
        // we can restore the connection
        window.asyncStorage.setItem('device.connected', connectedAddress);
      } else {
        if (connectedAddress === deviceAddress) {
          connectedAddress = null;
          window.asyncStorage.removeItem('device.connected');
        }
      }

      var l10nId = '';
      var hfpConnected = deviceItem.connectedProfiles[Profiles.HFP];
      var a2dpConnected = deviceItem.connectedProfiles[Profiles.A2DP];
      if (hfpConnected || a2dpConnected) {
        l10nId = 'device-status-tap-disconnect';
      } else {
        l10nId = 'device-status-tap-connect';
      }

      var small = pairList.index[deviceAddress].item.querySelector('small');
      if (l10nId) {
        small.setAttribute('data-l10n-id', l10nId);
      } else {
        small.removeAttribute('data-l10n-id');
        small.textContent = '';
      }
    }
    // private DOM helper: create a device list item
    function newListItem(device, descL10nId) {
      var deviceName = document.createElement('span');
      deviceName.classList.add('break-all');
      if (device.name !== '') {
        deviceName.textContent = device.name;
      } else {
        deviceName.setAttribute('data-l10n-id', 'unnamed-device');
      }

      var deviceDesc = document.createElement('small');
      if (descL10nId) {
        deviceDesc.setAttribute('data-l10n-id', descL10nId);
      }

      var li = document.createElement('li');
      var anchor = document.createElement('a');
      anchor.onclick = function(e){e.stopPropagation();}
      li.classList.add('bluetooth-device');
      if(device.icon==""){
         li.classList.add('helpx');
      }else{
         li.classList.add('bluetooth-type-' + device.icon);
      }
      anchor.appendChild(deviceName);
      anchor.appendChild(deviceDesc); // should append this first
      li.appendChild(anchor);

      return li;
    }

    function setDeviceUnpair(address) {
      var device = pairList.index[address].device ;
      showUnpairDialog(address === connectedAddress, device.name, function(isConnectedAddress){
        function unpairDevice(){
          // backend takes responsibility to disconnect first.
          var req = defaultAdapter.unpair(device.address);
          req.onerror = function bt_pairError() {
            getPairedDevice();
          };
          req.onsuccess = function bt_pairSuccess(){
            getPairedDevice();
          };
        }
        if(isConnectedAddress){
          setDeviceDisconnect(device,unpairDevice) ;
        }else{
          unpairDevice();
        }
      });
    }
    function showUnpairDialog(isConnectedDevice, deviceName, callback){
      var title = 'device-option-unpair-confirmation';
      var msg = 'device-option-unpair-device';
      var dialogConfig = {
        title: {id: title, args: {}},
        body: {id: msg, args: {deviceName}},
        cancel: {
          l10nId:'cancel',
          priority:1,
          callback: function(){
            dialog.destroy();
          },
        },
        confirm: {
          l10nId:'device-option-unpair',
          priority:3,
          callback: function(){
            callback(isConnectedDevice);
            dialog.destroy();
          },
        },
      };
      var dialog = new ConfirmDialogHelper(dialogConfig);
      dialog.show(confirmationDialog);
    }
    function showSoftkey(){
      var softkeyParams = {
        header: { l10nId:'fxa-options' },
        items: [
        {
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method: function() {
          }
        },
        {
          l10nId: 'device-option-unpair',
          priority: 3,
          method: function(){
            var address = elements.panel.querySelector('li.focus').dataset.address ;
            setDeviceUnpair(address);
          }
        }]
      };
      if(Settings.currentPanel=="#paired-device"){
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      }
    }
    // In the callback we returns an array of connected device items.
    // Each device item contains "device" and "connectedProfiles".
    function getConnectedDeviceItems(callback) {
      if (!callback)
        return;

      if (!defaultAdapter) {
        callback([]);
        return;
      }

      var getConnectedDevicesByProfile = function(profileID, gcdCallback) {
        if (!gcdCallback)
          return;

        var req = defaultAdapter.getConnectedDevices(profileID);
        req.onsuccess = function() {
          gcdCallback(req.result || []);
        };
        req.onerror = function() {
          gcdCallback(null);
        };
      };

      var connectedDeviceItemsMap = {}; // hash by device address
      var updateDeviceItemsMap = function(profileID, connectedDevices) {
        if (!connectedDevices)
          return;

        connectedDevices.forEach(function(connectedDevice) {
          var info = connectedDeviceItemsMap[connectedDevice.address];
          if (info) {
            info.connectedProfiles[profileID] = true;
          } else {
            info = {
              'device': connectedDevice,
              'connectedProfiles': {}
            };
            info.connectedProfiles[profileID] = true;
          }
          connectedDeviceItemsMap[connectedDevice.address] = info;
        });
      };

      // XXX: we should have better ways of doing this.
      getConnectedDevicesByProfile(Profiles.HFP, function(hfpResult) {
        updateDeviceItemsMap(Profiles.HFP, hfpResult);
        getConnectedDevicesByProfile(Profiles.A2DP, function(a2dpResult) {
          updateDeviceItemsMap(Profiles.A2DP, a2dpResult);

          var connectedDeviceItems = [];
          for (var i in connectedDeviceItemsMap) {
            var item = connectedDeviceItemsMap[i];
            connectedDeviceItems.push(item);
          }
          callback(connectedDeviceItems);
        });
      });
    }
    function getPairedDevice(callback) {
      if (!bluetooth.enabled || !defaultAdapter)
        return;
      var req = defaultAdapter.getPairedDevices();
      req.onsuccess = function bt_getPairedSuccess() {
        // copy for sorting
        var paired = req.result.slice();
        var length = paired.length;
        if (length == 0) {
          pairList.show(false);
          SettingsSoftkey.hide();
          nopairedDesc.classList.add('visible');
          return;
        }

        showSoftkey();
        nopairedDesc.classList.remove('visible');
        pairList.clear();
        paired.sort(function(a, b) {
          return a.name.toLowerCase() > b.name.toLowerCase();
        });
        for (var i = 0; i < length; i++) {
          (function(device) {
            var descL10nId = '';
            if (device.icon === 'audio-card') {
              if (device.address === connectedAddress) {
                descL10nId = 'device-status-tap-disconnect';
              } else {
                descL10nId = 'device-status-tap-connect';
              }
            } else {
              descL10nId = '';
            }
            var aItem = newListItem(device, descL10nId);
            aItem.onclick = function(){
              var device = pairList.index[this.dataset.address].device;
              if (device.address === connectedAddress) {
                setDeviceDisconnect(device);
              } else {
                setDeviceConnect(device);
              }
            };
            aItem.dataset.address= device.address ;
            pairList.list.appendChild(aItem);
            pairList.index[device.address] = {
              device: device,
              item: aItem,
              connectedProfiles: {}
            };
            // if the device has to be connected when it just paired
            // wait for a while so they can have time to communicate
            // their connection protocol
            if (device.address === connectingAddress &&
                device.icon === 'audio-card') {
              var small = aItem.querySelector('small');
              small.setAttribute('data-l10n-id', 'device-status-connecting');
              setTimeout(function() {
                setDeviceConnect(device);
              }, 5000);
            }
          })(paired[i]);
        }
        // update the connection status
        getConnectedDeviceItems(function(connectedDeviceItems) {
          if (connectedDeviceItems.length > 0) {
            connectedDeviceItems.forEach(function(item) {
              var connectedDevice = item.device;
              var connectedProfiles = item.connectedProfiles;
              for (var profile in connectedProfiles) {
                showDeviceConnected(connectedDevice.address, true, profile);
              }
            });
          }
          pairList.show(true);
          var ev = new CustomEvent('panelready',{
           detail:{
            current:Settings.currentPanel
           }
          }) ;
          window.dispatchEvent(ev) ;
          // the callback function now is for restoring the connected device
          // when the bluetooth is turned on.
          if (callback)
            callback();
        });
      };
    }

    function restoreConnection() {
      // Reconnect the one kept in the async storage.
      window.asyncStorage.getItem('device.connected', function(value) {
        if (!value || !pairList.index[value])
          return;

        var device = pairList.index[value].device;
        if(!device.connected){
          setDeviceConnect(device);
        }
      });
    }
    // do default actions (start discover avaliable devices)
    // when DefaultAdapter is ready.
    function initWithAdapter() {
      defaultAdapter.onpairedstatuschanged = function bt_getPairedMessage(evt) {
        //dispatchEvent(new CustomEvent('bluetooth-pairedstatuschanged'));
        getPairedDevice();
      };
      defaultAdapter.onhfpstatuschanged = function bt_hfpStatusChanged(evt) {
        showDeviceConnected(evt.address, evt.status, Profiles.HFP);
      };

      defaultAdapter.ona2dpstatuschanged = function bt_a2dpStatusChanged(evt) {
        showDeviceConnected(evt.address, evt.status, Profiles.A2DP);
      };
    }
    function initialDefaultAdapter(callback) {
      if (!bluetooth.enabled)
        return;
      var req = bluetooth.getDefaultAdapter();
      req.onsuccess = function bt_getAdapterSuccess() {
        defaultAdapter = req.result;
        if (defaultAdapter == null) {
          // we can do nothing without DefaultAdapter, so set bluetooth disabled
          settings.createLock().set({'bluetooth.enabled': false});
          return;
        }

        initWithAdapter() ;
        if(callback) callback();
      };
      req.onerror = function bt_getAdapterFailed() {
        // we can do nothing without DefaultAdapter, so set bluetooth disabled
        settings.createLock().set({'bluetooth.enabled': false});
      };
    }
    return SettingsPanel({
      onInit: function(panel) {
        elements = {} ;
        elements.panel = panel ;
        this.keydownHandler = function(e){
          switch(e.key){
            case 'Enter':
            case 'Accept':
              panel.querySelector('li.focus').focus();
              break;
          }
        }.bind(this);
     },
     onBeforeShow:function(){
       pairList.clear();
     },
     onShow:function(){
       initialDefaultAdapter(function(){
         // Get paired device
           getPairedDevice(function() {
             for (var address in pairList.index) {
               var deviceItem = pairList.index[address];
               if (Object.keys(deviceItem.connectedProfiles).length > 0)
                 return;
             }

             // If there is no current connection and we have one device connected
             // before, restore it.
             restoreConnection();
           });
       });
       window.addEventListener('keydown',this.keydownHandler);
     },
     onBeforeHide:function(){
       SettingsSoftkey.hide();
       window.removeEventListener('keydown',this.keydownHandler);
     }
    });
  };
});
