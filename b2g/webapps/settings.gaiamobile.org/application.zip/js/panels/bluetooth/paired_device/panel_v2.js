/**
 * The Bluetooth v2 panel
 *
 */
define(['require','modules/bluetooth/bluetooth_context','modules/bluetooth/bluetooth_connection_manager','panels/bluetooth/bt_template_factory','modules/mvvm/list_view','modules/settings_panel'],function(require) {
  

  var BtContext = require('modules/bluetooth/bluetooth_context');
  var BtConnectionManager =
    require('modules/bluetooth/bluetooth_connection_manager');
  var BtTemplateFactory = require('panels/bluetooth/bt_template_factory');
  var ListView = require('modules/mvvm/list_view');
  var SettingsPanel = require('modules/settings_panel');

  var _debug = false;
  var debug = function() {};
  if (_debug) {
    debug = function btp_debug(msg) {
      console.log('--> [Bluetooth][Panel]: ' + msg);
    };
  }

  return function ctor_bluetooth() {
    var elements;
    var pairedDeviceTemplate;
    var _pairedDevicesListView;

    return SettingsPanel({
      onInit: function(panel) {
        debug('onInit():');

        this._boundUpdatePairedDesc = this._updatePairedDesc.bind(this);
        
        elements = {
          panel: panel,
          pairedDevicesList: panel.querySelector('#bluetooth-paired-devices'),
          nopairedDesc: panel.querySelector('#nopaired-devices')
        };

        pairedDeviceTemplate =
          BtTemplateFactory('paired', this._onPairedDeviceItemClick.bind(this));

        _pairedDevicesListView = ListView(elements.pairedDevicesList,
                                          BtContext.getPairedDevices(),
                                          pairedDeviceTemplate);
      },

      onBeforeShow: function() {
        debug('onBeforeShow():');
        BtContext.observe('numberOfPairedDevices', this._boundUpdatePairedDesc);
        this._updatePairedDesc(BtContext.numberOfPairedDevices);
      },

      onBeforeHide: function() {
        debug('onBeforeHide():');
        BtContext.unobserve('numberOfPairedDevices', this._boundUpdatePairedDesc);
        SettingsSoftkey.hide();
      },

      _onPairedDeviceItemClick: function(deviceItem) {
        //connect audio-card devices
        if (!((deviceItem.type === 'audio-card') ||
              (deviceItem.type === 'audio-input-microphone'))) {
          return;
        }

        if (deviceItem.connectionStatus === 'connected') {
          BtConnectionManager.disconnect(deviceItem.data).then(() => {
            debug('_connectHeadsetDevice(): connect device successfully');
          }, (reason) => {
            debug('_connectHeadsetDevice(): connect device failed, ' +
                  'reason = ' + reason);
          });
        } else {
          BtConnectionManager.connect(deviceItem.data).then(() => {
            debug('_connectHeadsetDevice(): connect device successfully');
          }, (reason) => {
            debug('_connectHeadsetDevice(): connect device failed, ' +
                  'reason = ' + reason);
          });
        }
      },

      _showUnpairDialog: function() {
        var deviceItem = elements.panel.querySelector('li.focus').attribute;
        var title = 'device-option-unpair-confirmation';
        var msg = 'device-option-unpair-device';
        var dialogConfig = {
          title: {id: title, args: {}},
          body: {id: msg, args: {deviceName: deviceItem.name}},
          cancel: {
            l10nId:'cancel',
            priority:1,
            callback: function() {
            }
          },
          confirm: {
            l10nId:'device-option-unpair',
            priority:3,
            callback: function() {
              comfirmToUnpair();
            }
          }
        };
        var dialog = new ConfirmDialogHelper(dialogConfig);
        dialog.show(document.getElementById('app-confirmation-dialog'));

        function comfirmToUnpair() {
          debug('_confirmToUnpair(): deviceItem.address = ' +
                deviceItem.address);
          BtContext.unpair(deviceItem.address).then(() => {
            debug('_onPairedDeviceItemClick(): unpair successfully');
          }, (reason) => {
            debug('_onPairedDeviceItemClick(): unpair failed, ' +
                  'reason = ' + reason);
          });
        }
      },

      _updatePairedDesc: function(numberOfPairedDevices) {
        if (numberOfPairedDevices === 0) {
          SettingsSoftkey.hide();
          elements.nopairedDesc.classList.add('visible');
        } else {
          this._updateSoftkey();
          elements.nopairedDesc.classList.remove('visible');
        }
      },

      _updateSoftkey: function() {
        var params = {
          items: [
            {
              name: 'Select',
              l10nId: 'select',
              priority: 2,
              method: function() {
              }
            },
            {
              l10nId: 'device-option-unpair',
              priority: 3,
              method: this._showUnpairDialog
            }
          ]
         };

       SettingsSoftkey.init(params);
       SettingsSoftkey.show();
      }

    });
  };

});
