/**
 * The Bluetooth panel
 *
 * Bluetooth v2 panel, still on working..
 */
define(['require','modules/bluetooth/bluetooth_context','modules/bluetooth/bluetooth_connection_manager','panels/bluetooth/bt_template_factory','modules/mvvm/list_view','modules/settings_panel','modules/settings_service'],function(require) {
  

  var BtContext = require('modules/bluetooth/bluetooth_context');
  var BtConnectionManager =
    require('modules/bluetooth/bluetooth_connection_manager');
  var BtTemplateFactory = require('panels/bluetooth/bt_template_factory');
  var ListView = require('modules/mvvm/list_view');
  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');

  var _debug = false;
  var debug = function() {};
  if (_debug) {
    debug = function btp_debug(msg) {
      console.log('--> [Bluetooth][Panel]: ' + msg);
    };
  }

  return function ctor_bluetooth() {
    var elements;
    var foundDeviceTemplate;
    var _foundDevicesListView;

    return SettingsPanel({
      onInit: function(panel) {
        debug('onInit():');
        this._boundUpdateSearchingItem = this._updateSearchingItem.bind(this);
        this._boundUpdateNearbyDevicesDesc = this._updateNearbyDevicesDesc.bind(this);

        elements = {
          panel: panel,
          foundDevicesList: panel.querySelector('#bluetooth-devices'),
          searchingItem: panel.querySelector('#bluetooth-searching'),
          nearbyDevicesDesc: panel.querySelector('#nodevices-nearby'),
        };

        // found devices list item click events
        foundDeviceTemplate =
          BtTemplateFactory('remote', this._onFoundDeviceItemClick.bind(this));

        // create found devices list view
        _foundDevicesListView = ListView(elements.foundDevicesList,
                                         BtContext.getRemoteDevices(),
                                         foundDeviceTemplate);

      },

      onBeforeShow: function() {
        debug('onBeforeShow():');
        BtContext.observe('discovering', this._boundUpdateSearchingItem);
        BtContext.observe('discovering', this._boundUpdateNearbyDevicesDesc);
        this._updateSoftkey(true);
      },

      onShow: function() {
        debug('onShow():');
        this._searchAgain();
      },

      onBeforeHide: function() {
        debug('onBeforeHide():');
        BtContext.unobserve('discovering', this._boundUpdateSearchingItem);
        BtContext.unobserve('discovering', this._boundUpdateNearbyDevicesDesc);
        SettingsSoftkey.hide();
      },

      onHide: function() {
        debug('onHide():');
        BtContext.stopDiscovery();
      },

      _onFoundDeviceItemClick: function(deviceItem) {
        this._toPairDevice(deviceItem);
      },

      _toPairDevice: function(deviceItem) {
        debug('_onFoundDeviceItemClick(): deviceItem.address = ' +
              deviceItem.address);
        // Update device pairing status first.
        deviceItem.paired = 'pairing';
        // Pair with the remote device.
        BtContext.pair(deviceItem.address).then(() => {
          debug('_onFoundDeviceItemClick(): pair successfully');
          // Connect the device which is just paired.
          SettingsService.navigate('bluetooth_v2');
          this._connectHeadsetDevice(deviceItem);
        }, (reason) => {
          debug('_onFoundDeviceItemClick(): pair failed, ' +
                'reason = ' + reason);
          // Reset the paired status back to false,
          // since the 'pairing' status is given in Gaia side.
          deviceItem.paired = false;
          this._showConfirmDialog(deviceItem);
        });
      },

      _connectHeadsetDevice: function(deviceItem) {
        if (!((deviceItem.type === 'audio-card') ||
              (deviceItem.type === 'audio-input-microphone'))) {
          return;
        }

        BtConnectionManager.connect(deviceItem.data).then(() => {
          debug('_connectHeadsetDevice(): connect device successfully');
        }, (reason) => {
          debug('_connectHeadsetDevice(): connect device failed, ' +
                'reason = ' + reason);
        });
      },

      _updateSearchingItem: function(discovering) {
        debug('_updateSearchingItem(): ' +
              'callback from observe "discovering" = ' + discovering);
        elements.searchingItem.hidden = !discovering;
        this._updateSoftkey(discovering);
      },

      _updateNearbyDevicesDesc: function(discovering) {
        var devicesNearby = elements.foundDevicesList.childNodes;
        if (discovering === false && devicesNearby.length === 0) {
          elements.nearbyDevicesDesc.classList.add('visible');
        }
      },

      _searchAgain: function() {
        elements.nearbyDevicesDesc.classList.remove('visible');
        BtContext.startDiscovery().then(() => {
          debug('_searchAgain(): startDiscovery successfully');
        }, (reason) => {
          debug('_searchAgain(): startDiscovery failed, ' +
                'reason = ' + reason);
        });
      },

      _showConfirmDialog: function(deviceItem) {
        var self = this;
        var dialogConfig = {
          title: {id: 'error-pair-title', args: {}},
          body: {id: 'error-pair-fail', args: {'devicename':deviceItem.name}},
          desc:{id: 'error-pair-checkpin',args:{}},
          cancel: {
            l10nId:'cancel',
            priority:1,
            callback: function() {}
          },
          confirm: {
            l10nId:'pair',
            priority:3,
            callback: function() {
              self._toPairDevice(deviceItem);
            }
          }
        }
        var dialog = new ConfirmDialogHelper(dialogConfig);
        dialog.show(document.getElementById('app-confirmation-dialog'));
      },

      _updateSoftkey: function(discovering) {
        if(discovering) {
          var params = {
            items: [
             {
              name: 'Select',
              l10nId: 'select',
              priority: 2,
              method: function() {
              }
             }
            ]
          };
        } else {
          var params = {
          items: [
            {
              name: 'Select',
              l10nId: 'select',
              priority: 2,
              method: function() {
              }
            },
            {
              name: 'Rescan',
              l10nId: 'rescan',
              priority: 3,
              method: this._searchAgain
            }
          ]
         };
       }
       SettingsSoftkey.init(params);
       SettingsSoftkey.show();
      }

    });
  };

});
