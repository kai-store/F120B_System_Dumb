 /* global DsdsSettings */
define(['require'],function(require) {
  

  var telephony = navigator.mozTelephony;

  function VoLTEItem(element) {
    this._descItem = element;
    this._imsHandler = null;
    this._init();
  }

  VoLTEItem.prototype = {

    _init: function() {
      this._updateImsHandler();
      this.updateVolteDesc = this._updateVolteDesc.bind(this);
      this.initEventListener = this._initEventListener.bind(this);
    },

    _initEventListener: function() {
      if (telephony) {
        telephony.ontelephonycoveragelosing = (evt) => {
          this.updateVolteDesc('poorSignal');
        };
      }
    },

    _updateImsHandler: function() {
      var serviceId = DsdsSettings.getIccCardIndexForCellAndDataSettings();
      var imsHandler = navigator.mozMobileConnections[serviceId].imsHandler;

      if (imsHandler) {
        var status = imsHandler.enabled ? 'on' : 'off';
        this.updateVolteDesc(status);

        // Do not add any desc when VoLTE is OFF
        if (imsHandler.enabled) {
          if (imsHandler.preferredProfile === 'cellular-preferred') {
            this.updateVolteDesc('cellularData');
          }

          // If the VoLTE has error code,
          //   devices would not to listen on other status change.
          if (imsHandler.unregisteredReason !== '') {
            this.updateVolteDesc('errorCode', {
              unregisteredReason: imsHandler.unregisteredReason
            });
          }
        }
        this.initEventListener();
      }
    },

    _updateVolteDesc: function root_updateVolteDesc(status, args) {
      if (status === '') {
        return;
      }

      var l10n = 'volte-status-' + status;
      navigator.mozL10n.setAttributes(this._descItem, l10n, args);
    }
  };

  return function ctor_volteItem(element) {
    return new VoLTEItem(element);
  };
});
