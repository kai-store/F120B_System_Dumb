/* global PerformanceTestingHelper */
define(['require','modules/dialog_service','modules/wifi_utils','shared/wifi_helper','modules/wifi_context'],function(require) {
  

  var DialogService = require('modules/dialog_service');
  var WifiUtils = require('modules/wifi_utils');
  var WifiHelper = require('shared/wifi_helper');
  var WifiContext = require('modules/wifi_context');
  var wifiManager = WifiHelper.getWifiManager();

  var WifiNetworkList = function(elements,callback) {
    var list = elements.wifiAvailableNetworks;

    var wifiNetworkList = {
      _scanRate: 5000, // 5s after last scan results
      _scanning: false,
      _autoscan: false,
      _index: {}, // index of all scanned networks
      _networks: {},
      _list: elements.wifiAvailableNetworks,
      _showSearchStatus: function(enabled) {
        list.hidden = enabled;
        elements.infoItem.hidden = !enabled;
      },
      clear: function() {
        // clear the network list
        this._index = {};
        this._networks = {};

        // remove all items except the text expl.
        // and the "search again" button
        var wifiItems = list.querySelectorAll('li');
        var len = wifiItems.length;
        for (var i = len - 1; i >= 0; i--) {
          list.removeChild(wifiItems[i]);
        }
      },
      scan: function() {
        var self = this;
        self._showSearchStatus(true);

        window.performance.measure('settingPanelWifiVisible', 'wifiListStart');
        PerformanceTestingHelper.dispatch('settings-panel-wifi-visible');

        // scan wifi networks and display them in the list
        if (this._scanning) {
          return;
        }

        // stop auto-scanning if wifi disabled or the app is hidden
        if (!wifiManager.enabled || document.hidden) {
          this._scanning = false;
          return;
        }

        this._scanning = true;
        var req = WifiHelper.getAvailableAndKnownNetworks();

        req.onsuccess = function onScanSuccess() {
          self.clear();
          var allNetworks = req.result;
          var network;

          for (var i = 0; i < allNetworks.length; ++i) {
            network = allNetworks[i];
            var key = WifiUtils.getNetworkKey(network);
            // keep connected network first, or select the highest strength
            if (!self._networks[key] || network.connected) {
              self._networks[key] = network;
            } else {
              if (!self._networks[key].connected &&
                network.relSignalStrength >
                  self._networks[key].relSignalStrength) {
                    self._networks[key] = network;
              }
            }
          }
          var networkKeys = Object.getOwnPropertyNames(self._networks);
          // display network list
          if (networkKeys.length) {
            // sort networks by signal strength
            networkKeys.sort(function(a, b) {
              return self._networks[b].relSignalStrength -
                self._networks[a].relSignalStrength;
            });

            // add detected networks
            for (var j = 0; j < networkKeys.length; j++) {
              network = self._networks[networkKeys[j]];
              var listItem = WifiUtils.newListItem({
                network: network,
                onClick: self._toggleNetwork.bind(self),
                showNotInRange: true
              });

              // put connected network on top of list
              if (WifiHelper.isConnected(network)) {
                if (list.childNodes.length !== 0) {
                  list.insertBefore(listItem, list.childNodes[0]);
                } else {
                  list.appendChild(listItem);
                }
              } else {
                list.appendChild(listItem);
              }

              // add composited key to index
              self._index[networkKeys[j]] = listItem;
            }
          } else {
            // display a "no networks found" message if necessary
            list.appendChild(WifiUtils.newExplanationItem('noNetworksFound'));
          }

          // hide the "Searching" status
          self._showSearchStatus(false);
          if (callback && typeof callback === 'function') {
            callback();
          }
          window.performance.measure('settingsPanelWifiReady', 'wifiListStart');
          PerformanceTestingHelper.dispatch('settings-panel-wifi-ready');

          // auto-rescan if requested
          if (self._autoscan) {
            window.setTimeout(self.scan.bind(self), self._scanRate);
          }

          self._scanning = false;
        };

        req.onerror = function onScanError(error) {
          // always try again.
          self._scanning = false;

          window.performance.measure('settingsPanelWifiReady', 'wifiListStart');
          PerformanceTestingHelper.dispatch('settings-panel-wifi-ready');

          window.setTimeout(self.scan.bind(self), self._scanRate);
        };
      },

      getWpsAvailableNetworks: function() {
        // get WPS available networks
        var ssids = Object.getOwnPropertyNames(this._networks);
        var wpsAvailableNetworks = [];
        for (var i = 0; i < ssids.length; i++) {
          var network = this._networks[ssids[i]];
          if (WifiHelper.isWpsAvailable(network)) {
            wpsAvailableNetworks.push(network);
          }
        }
        return wpsAvailableNetworks;
      },
      set autoscan(value) {
        this._autoscan = value;
      },
      get autoscan() {
        return this._autoscan;
      },
      get scanning() {
        return this._scanning;
      },
      _toggleNetwork: function(network) {
        var self = this;

        var keys = WifiHelper.getSecurity(network);
        var security = (keys && keys.length) ? keys.join(', ') : '';
        var sl = Math.min(Math.floor(network.relSignalStrength / 20), 4);

        if (WifiHelper.isConnected(network)) {
          // online: show status + offer to disconnect
          DialogService.show('wifi-status', {
            sl: sl,
            network: network,
            security: security,
          }).then(function(result) {
            var type = result.type;
            if (type === 'submit') {
              WifiContext.forgetNetwork(network, function() {
                self.scan();
              });
            }
          });
        } else if (network.password && (network.password == '*')) {
          // offline, known network (hence the '*' password value):
          // no further authentication required.
          WifiHelper.setPassword(network);
          WifiContext.associateNetwork(network);
        } else {
          // offline, unknown network: propose to connect
          var key = WifiHelper.getKeyManagement(network);
          switch (key) {
            case 'WEP':
            case 'WPA-PSK':
            case 'WPA-EAP':
            case 'WPA2-PSK':
            case 'WPA/WPA2-PSK':
              DialogService.show('wifi-auth', {
                sl: sl,
                security: security,
                network: network,
              }).then(function(result) {
                var type = result.type;
                var authOptions = result.value;
                if (type === 'submit') {
                  WifiHelper.setPassword(
                    network,
                    authOptions.password,
                    authOptions.identity,
                    authOptions.eap,
                    authOptions.authPhase2,
                    authOptions.certificate,
                    authOptions.keyIndex
                  );
                  WifiContext.associateNetwork(network);
                }
              });
              break;
            default:
              WifiContext.associateNetwork(network);
              break;
          }
        }
      }
    };

    var updateItemPosition = function updateConnectingItemPosition(network) {
      var key = WifiUtils.getNetworkKey(network);
      var connectedItem = wifiNetworkList._index[key];
      if (!connectedItem) {
        return;
      }

      if (list.childNodes.length !== 0) {
        list.insertBefore(connectedItem, list.childNodes[0]);
      } else {
        list.appendChild(connectedItem);
      }
      list.childNodes[0].focus();
      var evt = new CustomEvent('refresh');
      window.dispatchEvent(evt);
    };

    // networkStatus has one of the following values:
    // connecting, associated, connected, connectingfailed, disconnected.
    WifiContext.addEventListener('wifiEnabled', event => {
      WifiUtils.updateListItemStatus({
        listItems: wifiNetworkList._index,
        activeItemDOM: list.querySelector('.active'),
        network: event.network,
        networkStatus: event.status
      });
    });

    WifiContext.addEventListener('wifiStatusChange', event => {
      if (event.status === 'connected') {
        updateItemPosition(event.network);
      }

      WifiUtils.updateListItemStatus({
        listItems: wifiNetworkList._index,
        activeItemDOM: list.querySelector('.active'),
        network: event.network,
        networkStatus: event.status
      });
    });

    WifiContext.addEventListener('wifiConnectionInfoUpdate', event => {
      WifiUtils.updateNetworkSignal(event.network, event.relSignalStrength);
    });

    return wifiNetworkList;
  };

  return WifiNetworkList;
});
