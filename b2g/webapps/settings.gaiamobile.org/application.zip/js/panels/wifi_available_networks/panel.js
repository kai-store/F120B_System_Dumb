define(['require','modules/settings_panel','shared/settings_listener','modules/wifi_context'],function(require) {
  

  var SettingsPanel = require('modules/settings_panel');
  var SettingsListener = require('shared/settings_listener');
  var WifiContext = require('modules/wifi_context');

  return function ctor_wifi_available_networks() {
    var elements;

    function _refreshPanel() {
      var evt = new CustomEvent('refresh');
      window.dispatchEvent(evt);
    }

    return SettingsPanel({
      onInit: function(panel) {
        this._settings = navigator.mozSettings;
        this._wifiSectionVisible = true;
        this._scanPending = false;
        this._networkListPromise = null;
        this._initialized = false;
        this._dialogPanelShow = false;
        elements = {
          wifiAvailableNetworks: panel.querySelector('.wifi-availableNetworks'),
        };
        elements.infoItem = panel.querySelector('.searching_icon');
        elements.networklist = {
          infoItem: elements.infoItem,
          wifiAvailableNetworks: elements.wifiAvailableNetworks
        };

        SettingsListener.observe('wifi.enabled', true, (enabled) => {
          if (enabled) {
            this._networkList().then((networkList) => {
              networkList.scan();
            });
          } else {
            // Re-enable UI toggle
            this._networkList().then((networkList) => {
              networkList.autoscan = false;
            });
          }
        });

        this.initAll = this._initAll.bind(this);
        this.handleDialogShow = this._handleDialogShow.bind(this);
        this.onWifiStatusChange = this._onWifiStatusChange.bind(this);
        this.openWrongPasswordDialog = this._openWrongPasswordDialog.bind(this);
        this.openConnetingFailedDialog =
          this._openConnetingFailedDialog.bind(this);
        this.openObtainingIPFailedDialog =
          this._openObtainingIPFailedDialog.bind(this);
      },
      onBeforeShow: function() {
        if (!this._dialogPanelShow) {
          this._wifiSectionVisible = true;
          this._updateVisibilityStatus();
          WifiContext.addEventListener('wifiStatusChange',
            this.onWifiStatusChange);
          WifiContext.addEventListener('wifiWrongPassword',
            this.openWrongPasswordDialog);
          WifiContext.addEventListener('wifiConnectingFailed',
            this.openConnetingFailedDialog);
          WifiContext.addEventListener('wifiObtainingIPFailed',
            this.openObtainingIPFailedDialog);
        }
      },
      onShow: function() {
        if (!this._dialogPanelShow) {
          var wifiAuthPanel = document.getElementById("wifi-auth");
          var wifiStatusPanel = document.getElementById("wifi-status");
          if (!wifiAuthPanel.classList.contains("current") && !wifiStatusPanel.classList.contains("current")) {
            this._initSoftkey();
            window.addEventListener("keydown", this._handleKeydown);
          }
          window.addEventListener('dialogpanelshow', this.handleDialogShow);
          window.addEventListener("dialogpanelhide", this.initAll);
        }
      },
      onBeforeHide: function() {
        if (!this._dialogPanelShow) {
          this._wifiSectionVisible = false;
          SettingsSoftkey.hide();
          window.removeEventListener('keydown', this._handleKeydown);
          window.removeEventListener('dialogpanelshow', this.handleDialogShow);
          window.removeEventListener('dialogpanelhide', this.initAll);
          WifiContext.removeEventListener('wifiStatusChange',
            this.onWifiStatusChange);
          WifiContext.removeEventListener('wifiWrongPassword',
            this.openWrongPasswordDialog);
          WifiContext.removeEventListener('wifiConnectingFailed',
            this.openConnetingFailedDialog);
          WifiContext.removeEventListener('wifiObtainingIPFailed',
            this.openObtainingIPFailedDialog);
        }
      },
      _initAll: function(e) {
        this._dialogPanelShow = false;
        var dialogpanel = e.detail.dialogpanel;
        this._initSoftkey();
        this._initpanelready(dialogpanel);
        window.addEventListener("keydown", this._handleKeydown);
      },
      _initSoftkey: function() {
        var self = this;
        var softkeyParams = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [{
            name: 'Select',
            l10nId: 'select',
            priority: 2
          },
          {
            name: 'Rescan',
            l10nId: 'rescan',
            priority: 3,
            method: function() {
              self._networkList().then((networkList) => {
                networkList.scan();
              });
            }
          }]
        };
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },
      _onWifiStatusChange: function(event) {
        var scanStates =
          new Set(['connected', 'connectingfailed', 'disconnected']);
        if (scanStates.has(event.status)) {
          if (this._wifiSectionVisible) {
            _refreshPanel();
          } else {
            this._scanPending = true;
          }
        }
      },
      _handleKeydown: function(e) {
        switch (e.key) {
          case 'BrowserBack':
          case 'Backspace':
          case 'KanjiMode':
            Settings.currentPanel = "#wifi";
            break;
        }
      },
      _handleDialogShow: function() {
        this._dialogPanelShow = true;
        window.removeEventListener('keydown', this._handleKeydown);
      },
      _initpanelready: function(dialogpanel) {
        if (Settings.currentPanel == "#wifi-available-networks" && !this._dialogPanelShow) {
          var evt = new CustomEvent("panelready", {
            detail: {
              current: Settings.currentPanel,
              previous: dialogpanel
            }
          });
          window.dispatchEvent(evt);
        }
      },
      _updateVisibilityStatus: function() {
        this._networkList().then(function(networkList) {
          if (this._scanPending) {
            networkList.scan();
            this._scanPending = false;
          }
        }.bind(this));
      },

      _openWrongPasswordDialog: function() {
        this._openBadCredentialsDialog('wifi-authentication-failed');
      },

      _openConnetingFailedDialog: function() {
        this._openBadCredentialsDialog('wifi-association-reject');
      },

      _openObtainingIPFailedDialog: function() {
        this._openBadCredentialsDialog('wifi-DHCP-failed');
      },

      _openBadCredentialsDialog: function(bodyId) {
        var self = this;
        var network = WifiContext.currentNetwork;

        var onConfirm = function onConfirm() {
          self._networkList().then(function(networkList) {
            networkList._toggleNetwork(network);
          });
        };

        var dialogConfig = {
          title: {
            id: 'wifi-bad-credentials-title',
            args: {}
          },
          body: {
            id: bodyId,
            args: {
              ssid: network.ssid
            }
          },
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback: function() {
              dialog.destroy();
              onConfirm();
            },
          }
        };

        var dialog = new ConfirmDialogHelper(dialogConfig);
        dialog.show(document.getElementById('app-confirmation-dialog'));
      },
      _networkList: function() {
        if (!this._networkListPromise) {
          this._networkListPromise = new Promise((resolve) => {
            require(['panels/wifi_available_networks/wifi_network_list'], (WifiNetworkList) => {
              resolve(WifiNetworkList(elements.networklist, this._initpanelready.bind(this)));
            });
          });
        }
        return this._networkListPromise;
      }
    });
  };
});
