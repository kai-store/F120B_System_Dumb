
function ensureFileBackedBlob(blob,callback){'use strict';if(blob instanceof File){return callback(blob);}
var TMPDIR='.gallery/tmp';var storage=navigator.getDeviceStorage('pictures');cleanupTempDir(function(){saveAsTempFile(blob,function(file){callback(file);});});function cleanupTempDir(callback){var yesterday=new Date(Date.now()-24*60*60*1000);var cursor=storage.enumerate(TMPDIR);cursor.onsuccess=function(){var file=cursor.result;if(file){if(file.lastModifiedDate<yesterday){var request=storage.delete(file.name);request.onsuccess=request.onerror=function(){cursor.continue();};}
else{cursor.continue();}}
else{callback();}};cursor.onerror=function(){if(cursor.error.name!=='NotFoundError'){console.error('Failed to clean temp directory',cursor.error.name);}
callback();};}
function saveAsTempFile(blob,callback){var filename=TMPDIR+'/'+
Math.random().toString().substring(2)+'.'+
blob.type.substring(6);var write=storage.addNamed(blob,filename);write.onsuccess=function(){var read=storage.get(filename);read.onsuccess=function(){callback(read.result);};read.onerror=fail;};write.onerror=fail;function fail(){console.error('Failed to save memory-backed blob as a file.');callback(blob);}}}