'use strict';
function showFileInformation(fileinfo) {
  if (fileinfo.metadata.video) {
    var req = videostorage.get(fileinfo.metadata.video);
    req.onsuccess = function() {
      fileinfo.size = req.result.size;
      fileinfo.type = req.result.type || 'video/3gp';
      populateMediaInfo(fileinfo);
    };
  } else {
    populateMediaInfo(fileinfo);
  }

  function populateMediaInfo(fileinfo) {
    var data = {
      //set the video filename using metadata
      'info-name': getFileName(fileinfo.metadata.video || fileinfo.name),
      'info-size': MediaUtils.formatSize(fileinfo.size),
      'info-type': fileinfo.type,
      'info-date': MediaUtils.formatDate(fileinfo.date),
      'info-resolution':
        fileinfo.metadata.width + 'x' + fileinfo.metadata.height
    };

    var name_label = 'name-label';
    var size_label =  'size-label';
    var image_type_label = 'image-type-label'
    var date_taken_label = 'date-taken-label';
    var resolution_label = 'resolution-label';

    var list_cont = {};
    list_cont[name_label] = data['info-name'];
    list_cont[size_label] = data['info-size'];
    list_cont[image_type_label] = data['info-type'];
    list_cont[date_taken_label] = data['info-date'];
    list_cont[resolution_label] = data['info-resolution'];

    var infoContainer = infoDialog.querySelector('#infoView');
    infoContainer.innerHTML = '';
    Object.keys(list_cont).forEach(function (key) {
      var nameItem = document.createElement('dt');
      nameItem.setAttribute('data-l10n-id',key);
      nameItem.classList.add('p-pri');
      nameItem.textContent = lget(key);
      var valueItem = document.createElement('dd');
      valueItem.classList.add('value');
      valueItem.classList.add('p-sec');
      valueItem.textContent = list_cont[key];
      infoContainer.appendChild(nameItem);
      infoContainer.appendChild(valueItem);
    });
    infoDialog.classList.remove('hidden');
    infoDialog.querySelector('#info-view-container').focus();
    infoDialog.querySelector('#info-view-container').scroll(0, 0);
  }

  function getFileName(path) {
    return path.split('/').pop();
  }
}