'use strict';var GestureDetector=(function(){function GD(e,options){this.element=e;this.options=options||{};this.options.panThreshold=this.options.panThreshold||GD.PAN_THRESHOLD;this.state=initialState;this.timers={};}
GD.prototype.startDetecting=function(){var self=this;eventtypes.forEach(function(t){self.element.addEventListener(t,self);});};GD.prototype.stopDetecting=function(){var self=this;eventtypes.forEach(function(t){self.element.removeEventListener(t,self);});};GD.prototype.handleEvent=function(e){var handler=this.state[e.type];if(!handler){return;}
if(e.changedTouches){if(e.type==='touchend'&&e.changedTouches.length>1){console.warn('gesture_detector.js: spurious extra changed touch on '+'touchend. See '+'https://bugzilla.mozilla.org/show_bug.cgi?id=785554');}
for(var i=0;i<e.changedTouches.length;i++){handler(this,e,e.changedTouches[i]);handler=this.state[e.type];}}
else{handler(this,e);}};GD.prototype.startTimer=function(type,time){this.clearTimer(type);var self=this;this.timers[type]=setTimeout(function(){self.timers[type]=null;var handler=self.state[type];if(handler){handler(self,type);}},time);};GD.prototype.clearTimer=function(type){if(this.timers[type]){clearTimeout(this.timers[type]);this.timers[type]=null;}};GD.prototype.switchTo=function(state,event,touch){this.state=state;if(state.init){state.init(this,event,touch);}};GD.prototype.emitEvent=function(type,detail){if(!this.target){console.error('Attempt to emit event with no target');return;}
var event=this.element.ownerDocument.createEvent('CustomEvent');event.initCustomEvent(type,true,true,detail);this.target.dispatchEvent(event);};GD.HOLD_INTERVAL=1000;GD.PAN_THRESHOLD=20;GD.DOUBLE_TAP_DISTANCE=50;GD.DOUBLE_TAP_TIME=500;GD.VELOCITY_SMOOTHING=0.5;GD.SCALE_THRESHOLD=20;GD.ROTATE_THRESHOLD=22.5;GD.THRESHOLD_SMOOTHING=0.9;var abs=Math.abs,floor=Math.floor,sqrt=Math.sqrt,atan2=Math.atan2;var PI=Math.PI;var eventtypes=['touchstart','touchmove','touchend'];function eventTime(e){var ts=e.timeStamp;if(ts>2*Date.now()){return Math.floor(ts/1000);}else{return ts;}}
function coordinates(e,t){return Object.freeze({screenX:t.screenX,screenY:t.screenY,clientX:t.clientX,clientY:t.clientY,timeStamp:eventTime(e)});}
function midpoints(e,t1,t2){return Object.freeze({screenX:floor((t1.screenX+t2.screenX)/2),screenY:floor((t1.screenY+t2.screenY)/2),clientX:floor((t1.clientX+t2.clientX)/2),clientY:floor((t1.clientY+t2.clientY)/2),timeStamp:eventTime(e)});}
function between(c1,c2){var r=GD.THRESHOLD_SMOOTHING;return Object.freeze({screenX:floor(c1.screenX+r*(c2.screenX-c1.screenX)),screenY:floor(c1.screenY+r*(c2.screenY-c1.screenY)),clientX:floor(c1.clientX+r*(c2.clientX-c1.clientX)),clientY:floor(c1.clientY+r*(c2.clientY-c1.clientY)),timeStamp:floor(c1.timeStamp+r*(c2.timeStamp-c1.timeStamp))});}
function touchDistance(t1,t2){var dx=t2.screenX-t1.screenX;var dy=t2.screenY-t1.screenY;return sqrt(dx*dx+dy*dy);}
function touchDirection(t1,t2){return atan2(t2.screenY-t1.screenY,t2.screenX-t1.screenX)*180/PI;}
function touchRotation(d1,d2){var angle=d2-d1;if(angle>180){angle-=360;}else if(angle<=-180){angle+=360;}
return angle;}
function isDoubleTap(lastTap,thisTap){var dx=abs(thisTap.screenX-lastTap.screenX);var dy=abs(thisTap.screenY-lastTap.screenY);var dt=thisTap.timeStamp-lastTap.timeStamp;return(dx<GD.DOUBLE_TAP_DISTANCE&&dy<GD.DOUBLE_TAP_DISTANCE&&dt<GD.DOUBLE_TAP_TIME);}
var initialState={name:'initialState',init:function(d){d.target=null;d.start=d.last=null;d.touch1=d.touch2=null;d.vx=d.vy=null;d.startDistance=d.lastDistance=null;d.startDirection=d.lastDirection=null;d.lastMidpoint=null;d.scaled=d.rotated=null;},touchstart:function(d,e,t){d.switchTo(touchStartedState,e,t);}};var touchStartedState={name:'touchStartedState',init:function(d,e,t){d.target=e.target;d.touch1=t.identifier;d.start=d.last=coordinates(e,t);if(d.options.holdEvents){d.startTimer('holdtimeout',GD.HOLD_INTERVAL);}},touchstart:function(d,e,t){d.clearTimer('holdtimeout');d.switchTo(transformState,e,t);},touchmove:function(d,e,t){if(t.identifier!==d.touch1){return;}
if(abs(t.screenX-d.start.screenX)>d.options.panThreshold||abs(t.screenY-d.start.screenY)>d.options.panThreshold){d.clearTimer('holdtimeout');d.switchTo(panStartedState,e,t);}},touchend:function(d,e,t){if(t.identifier!==d.touch1){return;}
if(d.lastTap&&isDoubleTap(d.lastTap,d.start)){d.emitEvent('tap',d.start);d.emitEvent('dbltap',d.start);d.lastTap=null;}
else{d.emitEvent('tap',d.start);d.lastTap=coordinates(e,t);}
d.clearTimer('holdtimeout');d.switchTo(initialState);},holdtimeout:function(d){d.switchTo(holdState);}};var panStartedState={name:'panStartedState',init:function(d,e,t){d.start=d.last=between(d.start,coordinates(e,t));if(e.type==='touchmove'){panStartedState.touchmove(d,e,t);}},touchmove:function(d,e,t){if(t.identifier!==d.touch1){return;}
var current=coordinates(e,t);d.emitEvent('pan',{absolute:{dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY},relative:{dx:current.screenX-d.last.screenX,dy:current.screenY-d.last.screenY},position:current});var dt=current.timeStamp-d.last.timeStamp;var vx=(current.screenX-d.last.screenX)/dt;var vy=(current.screenY-d.last.screenY)/dt;if(d.vx==null){d.vx=vx;d.vy=vy;}
else{d.vx=d.vx*GD.VELOCITY_SMOOTHING+
vx*(1-GD.VELOCITY_SMOOTHING);d.vy=d.vy*GD.VELOCITY_SMOOTHING+
vy*(1-GD.VELOCITY_SMOOTHING);}
d.last=current;},touchend:function(d,e,t){if(t.identifier!==d.touch1){return;}
var current=coordinates(e,t);var dx=current.screenX-d.start.screenX;var dy=current.screenY-d.start.screenY;var angle=atan2(dy,dx)*180/PI;if(angle<0){angle+=360;}
var direction;if(angle>=315||angle<45){direction='right';}else if(angle>=45&&angle<135){direction='down';}else if(angle>=135&&angle<225){direction='left';}else if(angle>=225&&angle<315){direction='up';}
d.emitEvent('swipe',{start:d.start,end:current,dx:dx,dy:dy,dt:e.timeStamp-d.start.timeStamp,vx:d.vx,vy:d.vy,direction:direction,angle:angle});d.switchTo(initialState);}};var holdState={name:'holdState',init:function(d){d.emitEvent('holdstart',d.start);},touchmove:function(d,e,t){var current=coordinates(e,t);d.emitEvent('holdmove',{absolute:{dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY},relative:{dx:current.screenX-d.last.screenX,dy:current.screenY-d.last.screenY},position:current});d.last=current;},touchend:function(d,e,t){var current=coordinates(e,t);d.emitEvent('holdend',{start:d.start,end:current,dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY});d.switchTo(initialState);}};var transformState={name:'transformState',init:function(d,e,t){d.touch2=t.identifier;var t1=e.touches.identifiedTouch(d.touch1);var t2=e.touches.identifiedTouch(d.touch2);d.startDistance=d.lastDistance=touchDistance(t1,t2);d.startDirection=d.lastDirection=touchDirection(t1,t2);d.scaled=d.rotated=false;},touchmove:function(d,e,t){if(t.identifier!==d.touch1&&t.identifier!==d.touch2){return;}
var t1=e.touches.identifiedTouch(d.touch1);var t2=e.touches.identifiedTouch(d.touch2);var midpoint=midpoints(e,t1,t2);var distance=touchDistance(t1,t2);var direction=touchDirection(t1,t2);var rotation=touchRotation(d.startDirection,direction);if(!d.scaled){if(abs(distance-d.startDistance)>GD.SCALE_THRESHOLD){d.scaled=true;d.startDistance=d.lastDistance=floor(d.startDistance+
GD.THRESHOLD_SMOOTHING*(distance-d.startDistance));}else{distance=d.startDistance;}}
if(!d.rotated){if(abs(rotation)>GD.ROTATE_THRESHOLD){d.rotated=true;}else{direction=d.startDirection;}}
if(d.scaled||d.rotated){d.emitEvent('transform',{absolute:{scale:distance/d.startDistance,rotate:touchRotation(d.startDirection,direction)},relative:{scale:distance/d.lastDistance,rotate:touchRotation(d.lastDirection,direction)},midpoint:midpoint});d.lastDistance=distance;d.lastDirection=direction;d.lastMidpoint=midpoint;}},touchend:function(d,e,t){if(t.identifier===d.touch2){d.touch2=null;}else if(t.identifier===d.touch1){d.touch1=d.touch2;d.touch2=null;}else{return;}
if(d.scaled||d.rotated){d.emitEvent('transformend',{absolute:{scale:d.lastDistance/d.startDistance,rotate:touchRotation(d.startDirection,d.lastDirection)},relative:{scale:1,rotate:0},midpoint:d.lastMidpoint});}
d.switchTo(afterTransformState);}};var afterTransformState={name:'afterTransformState',touchstart:function(d,e,t){d.switchTo(transformState,e,t);},touchend:function(d,e,t){if(t.identifier===d.touch1){d.switchTo(initialState);}}};return GD;}());'use strict';var Format={padLeft:function(input,len,padWith){padWith=padWith||' ';var pad=len-(input+'').length;while(--pad>-1){input=padWith+input;}
return input;}};'use strict';function VideoPlayer(container,autoHideProgressBar){if(typeof container==='string')
container=document.getElementById(container);container.classList.add('video-player-container');VideoPlayer.instancesToLocalize.set(container,this);function newelt(parent,type,classes,l10n_id,attributes){var e=document.createElement(type);if(classes){e.className=classes;}
if(l10n_id){e.dataset.l10nId=l10n_id;}
if(attributes){for(var attribute in attributes){e.setAttribute(attribute,attributes[attribute]);}}
parent.appendChild(e);return e;}
var poster=newelt(container,'img','videoPoster');var player=newelt(container,'video','videoPlayer');var controls=newelt(container,'div','videoPlayerControls');var playbutton=newelt(controls,'button','videoPlayerPlayButton','playbackPlay');var footer=newelt(controls,'div','videoPlayerFooter hidden');var pausebutton=newelt(footer,'button','videoPlayerPauseButton','playbackPause');var slider=newelt(footer,'div','videoPlayerSlider',null,{'role':'slider','aria-valuemin':0});var elapsedText=newelt(slider,'span','videoPlayerElapsedText p-thi');var progress=newelt(slider,'div','videoPlayerProgress');var backgroundBar=newelt(progress,'div','videoPlayerBackgroundBar');var elapsedBar=newelt(progress,'div','videoPlayerElapsedBar');var durationText=newelt(slider,'span','videoPlayerDurationText p-thi');var fullscreenButton=newelt(slider,'button','videoPlayerFullscreenButton','playbackFullscreen');if(autoHideProgressBar===undefined||autoHideProgressBar===false){this.autoHideFooter=false;}
else
{this.autoHideFooter=true;}
this.footer=footer;this.poster=poster;this.player=player;this.controls=controls;this.playing=false;this.fullScreen=false;this.inSecureMode=(window.location.hash==='#secure');player.preload='metadata';player.mozAudioChannelType='content';var self=this;var controlsHidden=false;var dragging=false;var pausedBeforeDragging=false;var endedTimer;var videourl;var posterurl;var rotation;var videotimestamp;var orientation=0;var videowidth,videoheight;var playbackTime;var capturedFrame;this.controlFullScreenEventHandler=function(e){switch(e.key){case'ArrowRight':case'ArrowDown':case'ArrowUp':case'ArrowLeft':case"Backspace":case"BrowserBack":case"BrowserSearch":case"F2":case"SoftRight":case"ContextMenu":case"F1":case"SoftLeft":case"Enter":case"Accept":self.stopFullScreen();self.fullScreen=false;break;default:break;}};this.palyVideoParams={header:{l10nId:'message'},items:[{name:'Pause',l10nId:'pause',icon:'pause',priority:2,method:function(){if(self.fullScreen){self.fullScreen=false;return;}}},{name:'Full Screen',l10nId:'tcl-full-screen',priority:1,method:function(){if(self.fullScreen){self.fullScreen=false;return;}
self.startFullScreen();}},{name:'Options',l10nId:'options',priority:3,method:function(){self.pause();self.onOptionsShow();}},]};this.securePalyVideoParams={header:{l10nId:'message'},items:[{name:'Pause',l10nId:'pause',icon:'pause',priority:2,method:function(){if(self.fullScreen){self.fullScreen=false;return;}}},{name:'Full Screen',l10nId:'tcl-full-screen',priority:1,method:function(){if(self.fullScreen){self.fullScreen=false;return;}
self.startFullScreen();}},{name:'Delete',l10nId:'delete',priority:3,method:function(){self.pause();self.onDeleteConfirm();}},]};this.load=function(video,posterimage,width,height,rotate,timestamp){this.reset();videourl=video;posterurl=posterimage;rotation=rotate||0;videowidth=width;videoheight=height;videotimestamp=timestamp;if(navigator.mozL10n.readyState==='complete'){this.localize();}
this.init();setPlayerSize();};this.reset=function(){videotimestamp=0;if(!footer.classList.contains('hidden')){this.showFooter(true);}
this.resetPlayer();hidePlayer();hidePoster();};this.init=function(){playbackTime=0;hidePlayer();showPoster();this.pause();};this.showFooter=function(bShown){if(arguments[0]===undefined)
bShown=true;if(bShown){footer.classList.remove('hidden');}else{footer.classList.add('hidden');}};function hidePlayer(){player.style.display='none';player.removeAttribute('src');player.load();self.playerShowing=false;}
function showPlayer(){if(self.onloading){self.onloading();}
player.style.display='block';player.src=videourl;self.playerShowing=true;player.oncanplay=function(){player.oncanplay=null;if(playbackTime!==0){player.currentTime=playbackTime;}
self.play();};}
function hidePoster(){poster.style.display='none';poster.removeAttribute('src');if(capturedFrame){URL.revokeObjectURL(capturedFrame);capturedFrame=null;}}
function showPoster(){poster.style.display='block';if(capturedFrame)
poster.src=capturedFrame;else
poster.src=posterurl;}
this.setPlayerSize=setPlayerSize;this.setPlayerOrientation=setPlayerOrientation;this.pause=function pause(){if(!this.playing){return;}
if(self.playerShowing){this.playing=false;player.pause();}
playbutton.classList.remove('hidden');if(this.onpaused)
this.onpaused();};this.resetPlayer=function _resetPlayer(){footer.classList.add('hidden');player.currentTime=0;this.pause();updateTime();};this.play=function play(){if(this.inSecureMode){SoftkeyHelper.init(self.securePalyVideoParams,function(){});}else{SoftkeyHelper.init(self.palyVideoParams,function(){});}
if(!this.playerShowing){hidePoster();showPlayer();return;}
playbutton.classList.add('hidden');this.playing=true;player.play();footer.classList.remove('hidden');controlsHidden=false;if(this.onFooterShow){this.onFooterShow();}
if(this.onplaying){this.onplaying();}};this.startFullScreen=function _fullScreen(){var self=this;footer.classList.add('hidden');controlsHidden=true;this.fullScreen=true;SoftkeyHelper.onlyHide();setTimeout(function(){window.addEventListener('keyup',self.controlFullScreenEventHandler);},400);};this.stopFullScreen=function _fullScreen(){window.removeEventListener('keyup',this.controlFullScreenEventHandler);footer.classList.remove('hidden');controlsHidden=false;updateTime();SoftkeyHelper.show();};fullscreenButton.addEventListener('tap',function(e){if(self.onfullscreentap){e.stopPropagation();self.onfullscreentap();}});playbutton.addEventListener('tap',function(e){if(!self.playerShowing||player.paused){self.play();}
e.stopPropagation();});pausebutton.addEventListener('tap',function(e){self.pause();e.stopPropagation();});controls.addEventListener('tap',function(e){if(e.target===controls&&!player.paused){footer.classList.toggle('hidden');controlsHidden=!controlsHidden;}});player.onloadedmetadata=function(){var formattedTime=formatTime(player.duration);durationText.textContent='-'+formattedTime;slider.setAttribute('aria-valuemax',player.duration);navigator.mozL10n.setAttributes(slider,'playbackSeekBar',{'duration':formattedTime});self.pause();};window.addEventListener('resize',function(){setPlayerSize();});player.onended=ended;function ended(){if(dragging)
return;if(endedTimer){clearTimeout(endedTimer);endedTimer=null;}
if(self.onFooterShow){self.stopFullScreen();self.fullScreen=false;}
self.pause();footer.classList.add('hidden');self.init();if(self.onFooterHide){self.onFooterHide();}
if(self.autoHideFooter){self.showFooter(false);}};player.ontimeupdate=updateTime;function updateTime(){if(isNaN(player.duration)){return;}
if(!controlsHidden){var formattedElapsedTime=formatTime(player.currentTime);var formattedDurationTime=formatTime(player.duration-player.currentTime);durationText.textContent='-'+formattedDurationTime;elapsedText.textContent=formattedElapsedTime;slider.setAttribute('aria-valuenow',player.currentTime);slider.setAttribute('aria-valuetext',formattedElapsedTime);if(player.duration===Infinity||player.duration===0)
return;var percent=(player.currentTime/player.duration)*100+'%';var startEdge=navigator.mozL10n.language.direction==='ltr'?'left':'right';elapsedBar.style.width=percent;}
if(player.currentTime===player.duration){elapsedBar.style.width=0;}
if(!endedTimer){if(!dragging&&player.currentTime>=player.duration-1){var timeUntilEnd=(player.duration-player.currentTime+.5);endedTimer=setTimeout(ended,timeUntilEnd*1000);}}
else if(dragging&&player.currentTime<player.duration-1){clearTimeout(endedTimer);endedTimer=null;}}
window.addEventListener('visibilitychange',visibilityChanged);function visibilityChanged(){if(document.hidden){if(!self.playerShowing)
return;self.pause();if(player.currentTime!==0){playbackTime=player.currentTime;captureCurrentFrame(function(blob){capturedFrame=URL.createObjectURL(blob);hidePlayer();showPoster();});}
else{hidePlayer();showPoster();}}}
function captureCurrentFrame(callback){var canvas=document.createElement('canvas');canvas.width=videowidth;canvas.height=videoheight;var context=canvas.getContext('2d');context.drawImage(player,0,0);canvas.toBlob(callback);}
function setPlayerSize(){var containerWidth=container.clientWidth;var containerHeight=container.clientHeight;if(!videowidth||!videoheight)
return;var width,height;switch(rotation){case 0:case 180:width=videowidth;height=videoheight;break;case 90:case 270:width=videoheight;height=videowidth;}
var xscale=containerWidth/width;var yscale=containerHeight/height;var scale=Math.min(xscale,yscale);width*=scale;height*=scale;var left=((containerWidth-width)/2);var top=((containerHeight-height)/2);var transform;switch(rotation){case 0:transform='translate('+left+'px,'+top+'px)';break;case 90:transform='translate('+(left+width)+'px,'+top+'px) '+'rotate(90deg)';break;case 180:transform='translate('+(left+width)+'px,'+(top+height)+'px) '+'rotate(180deg)';break;case 270:transform='translate('+left+'px,'+(top+height)+'px) '+'rotate(270deg)';break;}
transform+=' scale('+scale+')';poster.style.transform=transform;player.style.transform=transform;}
function setPlayerOrientation(newOrientation){orientation=newOrientation;}
function computePosition(panPosition,rect){var position;switch(orientation){case 0:position=(panPosition.clientX-rect.left)/rect.width;break;case 90:position=(rect.bottom-panPosition.clientY)/rect.height;break;case 180:position=(rect.right-panPosition.clientX)/rect.width;break;case 270:position=(panPosition.clientY-rect.top)/rect.height;break;}
return position;}
slider.addEventListener('pan',function pan(e){e.stopPropagation();if(player.duration===Infinity)
return;if(!dragging){dragging=true;pausedBeforeDragging=player.paused;if(!pausedBeforeDragging){player.pause();}}
var rect=backgroundBar.getBoundingClientRect();var position=computePosition(e.detail.position,rect);var pos=Math.min(Math.max(position,0),1);if(navigator.mozL10n.language.direction==='rtl'){pos=1-pos;}
player.currentTime=player.duration*pos;updateTime();});slider.addEventListener('swipe',function swipe(e){e.stopPropagation();dragging=false;if(player.currentTime>=player.duration){self.pause();}else if(!pausedBeforeDragging){player.play();}});slider.addEventListener('keypress',function(e){var step=Math.max(player.duration/20,2);if(e.keyCode==e.DOM_VK_DOWN){player.currentTime-=step;}else if(e.keyCode==e.DOM_VK_UP){player.currentTime+=step;}});function formatTime(time){time=Math.round(time);var minutes=Math.floor(time/60);var seconds=time%60;if(minutes<60){return Format.padLeft(minutes,2,'0')+':'+
Format.padLeft(seconds,2,'0');}else{var hours=Math.floor(minutes/60);minutes=Math.round(minutes%60);return hours+':'+Format.padLeft(minutes,2,'0')+':'+
Format.padLeft(seconds,2,'0');}
return'';}
var acm=navigator.mozAudioChannelManager;if(acm){acm.addEventListener('headphoneschange',function onheadphoneschange(){if(!acm.headphones&&self.playing){self.pause();}});}
this.localize=function(){var label;var portrait=videowidth<videoheight;if(rotation==90||rotation==270){portrait=!portrait;}
var orientation=navigator.mozL10n.get(portrait?'orientationPortrait':'orientationLandscape');if(videotimestamp){var locale_entry=navigator.mozL10n.get('videoDescription',{orientation:orientation});if(!self.dtf){self.dtf=new navigator.mozL10n.DateTimeFormat();}
label=self.dtf.localeFormat(videotimestamp,locale_entry);}else{label=navigator.mozL10n.get('videoDescriptionNoTimestamp',{orientation:orientation});}
poster.setAttribute('aria-label',label);};}
VideoPlayer.prototype.hide=function(){this.controls.style.display='none';};VideoPlayer.prototype.show=function(){this.controls.style.display='block';};VideoPlayer.instancesToLocalize=new WeakMap();navigator.mozL10n.ready(function(){for(var container of document.querySelectorAll('.video-player-container')){var instance=VideoPlayer.instancesToLocalize.get(container);if(instance){instance.localize();}}});function MediaFrame(container,includeVideo,maxImageSize,autoHideProgressBar){this.clear();if(typeof container==='string')
container=document.getElementById(container);this.container=container;this.maximumImageSize=maxImageSize||0;this.image=new Image();this.image.className='image-view';this.image.style.opacity=0;this.image.onload=function(){this.style.opacity=1;};this.image.style.transformOrigin='center center';this.image.style.backgroundImage='none';this.image.style.backgroundSize='contain';this.image.style.backgroundRepeat='no-repeat';this.container.appendChild(this.image);if(includeVideo!==false){this.video=new VideoPlayer(container,autoHideProgressBar);this.video.hide();}
container.classList.add('media-frame-container');MediaFrame.instancesToLocalize.set(container,this);}
MediaFrame.instancesToLocalize=new WeakMap();navigator.mozL10n.ready(function(){for(var container of document.querySelectorAll('.media-frame-container')){var instance=MediaFrame.instancesToLocalize.get(container);if(instance){instance.localize();}}});MediaFrame.computeMaxImageDecodeSize=function(mem){if(!mem){return 0;}
else if(mem<256){return 2*1024*1024;}
else if(mem<512){var screensize=screen.width*window.devicePixelRatio*screen.height*window.devicePixelRatio;if(mem<325&&screensize>480*800){return 2.5*1024*1024;}
return 3*1024*1024;}
else if(mem<1024){return 5*1024*1024;}
else{return(mem/1024)*8*1024*1024;}};if(navigator.getFeature){MediaFrame.pendingPromise=navigator.getFeature('hardware.memory');MediaFrame.pendingPromise.then(function resolve(mem){delete MediaFrame.pendingPromise;MediaFrame.maxImageDecodeSize=MediaFrame.computeMaxImageDecodeSize(mem);},function reject(err){delete MediaFrame.pendingPromise;MediaFrame.maxImageDecodeSize=0;});}
MediaFrame.prototype.displayImage=function displayImage(blob,width,height,preview,rotation,mirrored,largeSize)
{var self=this;if(MediaFrame.pendingPromise){MediaFrame.pendingPromise.then(function resolve(){self.displayImage(blob,width,height,preview,rotation,mirrored);});return;}
this.clear();this.imageblob=blob;this.fullSampleSize=computeFullSampleSize(blob,width,height);this.fullsizeWidth=this.fullSampleSize.scale(width);this.fullsizeHeight=this.fullSampleSize.scale(height);if(largeSize===true){this.fullImageURL=galleryErrorLargeSrc;}else{this.imageurl=URL.createObjectURL(blob);this.fullImageURL=this.imageurl+this.fullSampleSize;}
this.rotation=rotation||0;this.mirrored=mirrored||false;this.displayingImage=true;if(navigator.mozL10n.readyState==='complete'){this.localize();}
function usePreview(preview){if(!preview)
return false;if(!preview.width||!preview.height)
return false;if(!preview.start&&!preview.filename)
return false;if(Math.abs(width/height-preview.width/preview.height)>0.01)
return false;if(self.minimumPreviewWidth&&self.minimumPreviewHeight){return Math.max(preview.width,preview.height)>=Math.max(self.minimumPreviewWidth,self.minimumPreviewHeight)&&Math.min(preview.width,preview.height)>=Math.min(self.minimumPreviewWidth,self.minimumPreviewHeight);}
var screenWidth=window.innerWidth*window.devicePixelRatio;var screenHeight=window.innerHeight*window.devicePixelRatio;return((preview.width>=2*screenWidth||preview.height>=2*screenHeight)&&(preview.width>=2*screenHeight||preview.height>=2*screenWidth));}
if(usePreview(preview)){if(preview.start){gotPreview(blob.slice(preview.start,preview.end,'image/jpeg'),preview.width,preview.height);}
else{var storage=navigator.getDeviceStorage('pictures');var getreq=storage.get(preview.filename);getreq.onsuccess=function(){gotPreview(getreq.result,preview.width,preview.height);};getreq.onerror=function(){noPreview();};}}
else{noPreview();}
function gotPreview(previewblob,previewWidth,previewHeight){self.previewurl=URL.createObjectURL(previewblob);self.previewImageURL=self.previewurl;self.previewWidth=previewWidth;self.previewHeight=previewHeight;self.displayingPreview=true;self._displayImage(self.previewImageURL,self.previewWidth,self.previewHeight);}
function noPreview(){self.previewurl=null;var previewSampleSize=computePreviewSampleSize(blob,width,height);if(previewSampleSize!==Downsample.NONE){self.previewImageURL=self.imageurl+previewSampleSize;self.previewWidth=previewSampleSize.scale(width);self.previewHeight=previewSampleSize.scale(height);self.displayingPreview=true;self._displayImage(self.previewImageURL,self.previewWidth,self.previewHeight);}
else{self.previewImageURL=null;self.displayingPreview=false;self._displayImage(self.fullImageURL,self.fullsizeWidth,self.fullsizeHeight);}}
function computeFullSampleSize(blob,width,height){if(blob.type!=='image/jpeg'){return Downsample.NONE;}
var max=MediaFrame.maxImageDecodeSize||0;if(self.maximumImageSize&&(max===0||self.maximumImageSize<max)){max=self.maximumImageSize;}
if(!max||width*height<=max){return Downsample.NONE;}
return Downsample.areaAtLeast(max/(width*height));}
function computePreviewSampleSize(blob,width,height){if(blob.type!=='image/jpeg'){return Downsample.NONE;}
var screenWidth=window.innerWidth*window.devicePixelRatio;var screenHeight=window.innerHeight*window.devicePixelRatio;var portraitScale=Math.min(screenWidth/width,screenHeight/height);var landscapeScale=Math.min(screenHeight/width,screenWidth/height);var scale=Math.max(portraitScale,landscapeScale);return Downsample.sizeNoMoreThan(scale);}};MediaFrame.prototype._displayImage=function(url,width,height,bg){if(bg){this.image.style.backgroundImage='url('+bg+')';}
else{this.image.style.backgroundImage='none';}
this.image.src=url;this.image.classList.add('displayframe');if(this.rotation==0||this.rotation==180){this.itemWidth=width;this.itemHeight=height;}else{this.itemWidth=height;this.itemHeight=width;}
this.computeFit();this.setPosition();var temp=this.image.clientLeft;};MediaFrame.prototype.localize=function localize(){if(!this.displayingImage){return;}
var portrait=this.fullsizeWidth<this.fullsizeHeight;if(this.rotation==90||this.rotation==270){portrait=!portrait;}
var timestamp=this.imageblob.lastModifiedDate;var orientation=navigator.mozL10n.get(portrait?'orientationPortrait':'orientationLandscape');var label='';if(timestamp){var locale_entry=navigator.mozL10n.get('imageDescription',{orientation:orientation});if(!this.dtf){this.dtf=new navigator.mozL10n.DateTimeFormat();}
label=this.dtf.localeFormat(new Date(timestamp),locale_entry);}else{label=navigator.mozL10n.get('imageDescriptionNoTimestamp',{orientation:orientation});}
this.image.setAttribute('aria-label',label);};MediaFrame.prototype._switchToFullSizeImage=function _switchToFull(){if(!this.displayingImage||!this.displayingPreview)
return;this.displayingPreview=false;this._displayImage(this.fullImageURL,this.fullsizeWidth,this.fullsizeHeight,this.previewImageURL);};MediaFrame.prototype._switchToPreviewImage=function _switchToPreview(){if(!this.displayingImage||this.displayingPreview||!this.previewImageURL){return;}
this.displayingPreview=true;this._displayImage(this.previewImageURL,this.previewWidth,this.previewHeight);};MediaFrame.prototype.displayVideo=function displayVideo(videoblob,posterblob,width,height,rotation)
{if(!this.video)
return;this.clear();this.displayingVideo=true;this.videoblob=videoblob;this.posterblob=posterblob;this.videourl=URL.createObjectURL(videoblob);this.posterurl=URL.createObjectURL(posterblob);this.video.load(this.videourl,this.posterurl,width,height,rotation||0,videoblob.lastModifiedDate);this.video.show();};MediaFrame.prototype.clear=function clear(){this.displayingImage=false;this.displayingPreview=false;this.displayingVideo=false;this.itemWidth=this.itemHeight=null;this.imageblob=null;this.videoblob=null;this.posterblob=null;this.fullSampleSize=null;this.fullImageURL=null;this.previewImageURL=null;this.fullsizeWidth=this.fullsizeHeight=null;this.previewWidth=this.previewHeight=null;this.fit=null;if(this.imageurl){URL.revokeObjectURL(this.imageurl);}
this.imageurl=null;if(this.previewurl){URL.revokeObjectURL(this.previewurl);}
this.previewurl=null;if(this.image){this.image.style.opacity=0;this.image.style.backgroundImage='none';this.image.src='';this.image.removeAttribute('aria-label');}
if(this.video){this.video.reset();this.video.hide();if(this.videourl)
URL.revokeObjectURL(this.videourl);this.videourl=null;if(this.posterurl)
URL.revokeObjectURL(this.posterurl);this.posterurl=null;}};MediaFrame.prototype.setPosition=function setPosition(zoom){if(!this.fit||!this.displayingImage)
return;var dx=this.fit.left,dy=this.fit.top;switch(this.rotation){case 0:case 180:dx+=(this.fit.width-this.itemWidth)/2;dy+=(this.fit.height-this.itemHeight)/2;break;case 90:case 270:dx+=(this.fit.width-this.itemHeight)/2;dy+=(this.fit.height-this.itemWidth)/2;break;}
var sx=this.mirrored?-this.fit.scale:this.fit.scale;var sy=this.fit.scale;var transform='translate('+dx+'px, '+dy+'px) '+'scale('+sx+','+sy+')'+'rotate('+this.rotation+'deg) ';this.image.style.transform=transform;if(!zoom){this.image.setAttribute('data-origin-scale',this.fit.scale);this.image.setAttribute('data-scale-delta',this.fit.scale/5);this.image.setAttribute('data-zoom-in',0);this.image.setAttribute('data-zoom-out',0);}};MediaFrame.prototype.computeFit=function computeFit(){if(!this.displayingImage)
return;this.viewportWidth=this.container.offsetWidth;this.viewportHeight=this.container.offsetHeight;var scalex=this.viewportWidth/this.itemWidth;var scaley=this.viewportHeight/this.itemHeight;var scale=Math.min(Math.min(scalex,scaley),1);var width=Math.floor(this.itemWidth*scale);var height=Math.floor(this.itemHeight*scale);this.fit={width:width,height:height,left:Math.floor((this.viewportWidth-width)/2),top:Math.floor((this.viewportHeight-height)/2),scale:scale,baseScale:scale};};MediaFrame.prototype.reset=function reset(){if(this.displayingImage&&!this.displayingPreview&&this.previewImageURL){this._switchToPreviewImage();return;}
this.computeFit();this.setPosition();if(this.displayingVideo)
this.video.setPlayerSize();};MediaFrame.prototype.resize=function resize(){var oldWidth=this.viewportWidth;var oldHeight=this.viewportHeight;var newWidth=this.container.offsetWidth;var newHeight=this.container.offsetHeight;var oldfit=this.fit;if(!oldfit)
return;this.computeFit();var newfit=this.fit;if(Math.abs(oldfit.scale-oldfit.baseScale)<0.01||newfit.baseScale>oldfit.scale){this.reset();return;}
oldfit.left+=(newWidth-oldWidth)/2;oldfit.top+=(newHeight-oldHeight)/2;oldfit.baseScale=newfit.baseScale;this.fit=oldfit;this.setPosition();};MediaFrame.prototype.zoom=function zoom(scale,fixedX,fixedY,time){if(!this.displayingImage)
return;if(this.displayingPreview)
this._switchToFullSizeImage();if(this.fit.scale*scale>1){scale=1/(this.fit.scale);}
else if(this.fit.scale*scale<this.fit.baseScale){scale=this.fit.baseScale/this.fit.scale;}
this.fit.scale=this.fit.scale*scale;this.fit.width=Math.floor(this.itemWidth*this.fit.scale);this.fit.height=Math.floor(this.itemHeight*this.fit.scale);var photoX=fixedX-this.fit.left;var photoY=fixedY-this.fit.top;photoX=Math.floor(photoX*scale);photoY=Math.floor(photoY*scale);this.fit.left=fixedX-photoX;this.fit.top=fixedY-photoY;if(this.fit.width<=this.viewportWidth){this.fit.left=(this.viewportWidth-this.fit.width)/2;}
else{if(this.fit.left>0)
this.fit.left=0;if(this.fit.left+this.fit.width<this.viewportWidth){this.fit.left=this.viewportWidth-this.fit.width;}}
if(this.fit.height<=this.viewportHeight){this.fit.top=(this.viewportHeight-this.fit.height)/2;}
else{if(this.fit.top>0)
this.fit.top=0;if(this.fit.top+this.fit.height<this.viewportHeight){this.fit.top=this.viewportHeight-this.fit.height;}}
if(time){var transition='transform '+time+'ms ease';this.image.style.transition=transition;var self=this;this.image.addEventListener('transitionend',function done(){self.image.removeEventListener('transitionend',done);self.image.style.transition='';});}
this.setPosition();};MediaFrame.prototype.zoomFrame=function zoomFrame(scale,fixedX,fixedY,time){if(!this.displayingImage)
return;if(this.displayingPreview)
this._switchToFullSizeImage();this.fit.scale=scale;var overflowx=Math.abs(this.fit.width-this.viewportWidth);var overflowy=Math.abs(this.fit.height-this.viewportHeight);if(this.fit.left>0||this.fit.width<=this.viewportWidth){var ratiol=0.5;}else{var ratiol=Math.abs(this.fit.left/overflowx);}
if(this.fit.top>0||this.fit.height<=this.viewportHeight){var ratiot=0.5;}else{var ratiot=Math.abs(this.fit.top/overflowy);}
this.fit.width=Math.floor(this.itemWidth*this.fit.scale);this.fit.height=Math.floor(this.itemHeight*this.fit.scale);var photoX=fixedX-this.fit.left;var photoY=fixedY-this.fit.top;photoX=Math.floor(photoX*scale);photoY=Math.floor(photoY*scale);this.fit.left=fixedX-photoX;this.fit.top=fixedY-photoY;if(this.fit.width<=this.viewportWidth){this.fit.left=(this.viewportWidth-this.fit.width)/2;}
else{if(this.fit.left>0)
this.fit.left=0;if(Math.abs(this.fit.left)+this.fit.width<this.viewportWidth){this.fit.left=this.viewportWidth-this.fit.width;}else{this.fit.left=(this.viewportWidth-this.fit.width)*ratiol;}}
if(this.fit.height<=this.viewportHeight){this.fit.top=(this.viewportHeight-this.fit.height)/2;}
else{if(this.fit.top>0)
this.fit.top=0;if(Math.abs(this.fit.top)+this.fit.height<this.viewportHeight){this.fit.top=this.viewportHeight-this.fit.height;}else{this.fit.top=(this.viewportHeight-this.fit.height)*ratiot;}}
if(time){var transition='transform '+time+'ms ease';this.image.style.transition=transition;var self=this;this.image.addEventListener('transitionend',function done(){self.image.removeEventListener('transitionend',done);self.image.style.transition=null;});}
this.setPosition(true);};MediaFrame.prototype.pan=function(dx,dy){if(!this.displayingImage){return dx;}
if(this.fit.height>this.viewportHeight){this.fit.top+=dy;if(this.fit.top>0)
this.fit.top=0;if(this.fit.top+this.fit.height<this.viewportHeight)
this.fit.top=this.viewportHeight-this.fit.height;}
var extra=0;if(this.fit.width<=this.viewportWidth){extra=dx;}
else{this.fit.left+=dx;if(this.fit.left>0){extra=this.fit.left;this.fit.left=0;}
if(this.fit.left+this.fit.width<this.viewportWidth){extra=this.fit.left+this.fit.width-this.viewportWidth;this.fit.left=this.viewportWidth-this.fit.width;}}
this.setPosition(true);return extra;};MediaFrame.prototype.setMinimumPreviewSize=function(w,h){this.minimumPreviewWidth=w;this.minimumPreviewHeight=h;};'use strict';var frames=$('frames');var maxImageSize=CONFIG_MAX_IMAGE_PIXEL_SIZE;var previousFrame=new MediaFrame($('frame1'),true,maxImageSize);var currentFrame=new MediaFrame($('frame2'),true,maxImageSize);var nextFrame=new MediaFrame($('frame3'),true,maxImageSize);if(CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH){previousFrame.setMinimumPreviewSize(CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH,CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT);currentFrame.setMinimumPreviewSize(CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH,CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT);nextFrame.setMinimumPreviewSize(CONFIG_REQUIRED_EXIF_PREVIEW_WIDTH,CONFIG_REQUIRED_EXIF_PREVIEW_HEIGHT);}
var transitioning=false;new GestureDetector(frames).startDetecting();var frameOffset=0;frames.addEventListener('tap',tapHandler);frames.addEventListener('dbltap',dblTapHandler);frames.addEventListener('pan',panHandler);frames.addEventListener('swipe',swipeHandler);frames.addEventListener('transform',transformHandler);window.addEventListener('moveframe',moveFrameHandler);frames.addEventListener('wheel',wheelHandler);currentFrame.video.onfullscreentap=previousFrame.video.onfullscreentap=nextFrame.video.onfullscreentap=function fullscreenRequested(ev){setView(LAYOUT_MODE.fullscreen);resizeFrames();};currentFrame.video.onplaying=previousFrame.video.onplaying=nextFrame.video.onplaying=function hideToolbarOnPlay(){this.isToolbarHidden=fullscreenView.classList.contains('toolbar-hidden');if(!this.isToolbarHidden){fullscreenView.classList.add('toolbar-hidden');}};currentFrame.video.onpaused=previousFrame.video.onpaused=nextFrame.video.onpaused=function restoreToolbarOnPause(){this.isToolbarHidden=fullscreenView.classList.contains('toolbar-hidden');if(this.isToolbarHidden===true){fullscreenView.classList.remove('toolbar-hidden');}
delete this.isToolbarHidden;};function removeTransition(event){event.target.style.transition=null;}
previousFrame.container.addEventListener('transitionend',removeTransition);currentFrame.container.addEventListener('transitionend',removeTransition);nextFrame.container.addEventListener('transitionend',removeTransition);function deleteSinglePhoto(){var msg;if(files[currentFileIndex].metadata.video){msg='delete-video?';}
else{msg='delete-photo?';}
NFC.unshare();Dialogs.confirm({messageId:msg,cancelId:'cancel',confirmId:'delete',danger:true,bodyClass:'showing-dialog'},function(){fullscreenButtons.delete.classList.add('disabled');fullscreenButtons.share.classList.add('disabled');fullscreenButtons.edit.classList.add('disabled');deleteFile(currentFileIndex);NFC.share(getCurrentFile);},function(){NFC.share(getCurrentFile);});}
function shareSingleItem(){var fileinfo=files[currentFileIndex];if(fileinfo.metadata.video){share([currentFrame.videoblob]);}
else{if(!fileinfo.metadata.rotation&&!fileinfo.metadata.mirrored&&!CONFIG_MAX_PICK_PIXEL_SIZE){share([currentFrame.imageblob]);}
else{LazyLoader.load(['shared/js/media/crop_resize_rotate.js'],shareModifiedImage);}}
function shareModifiedImage(){var metadata=fileinfo.metadata;Spinner.show();var maxsize=CONFIG_MAX_PICK_PIXEL_SIZE||CONFIG_MAX_IMAGE_PIXEL_SIZE;cropResizeRotate(currentFrame.imageblob,null,maxsize||null,null,metadata,function(error,rotatedBlob){if(error){console.error('Error while rotating image: ',error);rotatedBlob=currentFrame.imageblob;}
ensureFileBackedBlob(rotatedBlob,function(file){Spinner.hide();share([file],currentFrame.imageblob.name);});});}}
var taptimer=null;function tapHandler(e){if(taptimer||(!currentFrame.displayingImage&&!currentFrame.displayingVideo)){return;}
taptimer=setTimeout(function(){taptimer=null;singletap(e);},GestureDetector.DOUBLE_TAP_TIME);}
function dblTapHandler(e){if(currentFrame.displayingVideo){return;}
clearTimeout(taptimer);taptimer=null;doubletapOnPhoto(e);}
function resizeFrames(){nextFrame.reset();previousFrame.reset();currentFrame.reset();}
function singletap(e){if(currentView===LAYOUT_MODE.fullscreen){if((currentFrame.displayingImage||currentFrame.video.player.paused)&&isPhone){fullscreenView.classList.toggle('toolbar-hidden');}}else if(currentView===LAYOUT_MODE.list&&!files[currentFileIndex].metadata.video){setView(LAYOUT_MODE.fullscreen);resizeFrames();}}
function doubletapOnPhoto(e){if(photodb.parsingBigFiles){return;}
var scale;if(currentFrame.fit.scale>currentFrame.fit.baseScale){scale=currentFrame.fit.baseScale/currentFrame.fit.scale;}else{scale=2;}
currentFrame.zoom(scale,e.detail.clientX,e.detail.clientY,200);}
function panHandler(event){if(transitioning){return;}
var dx=event.detail.relative.dx;var dy=event.detail.relative.dy;var oldFrameOffset=frameOffset;if((frameOffset>0&&dx>0)||(frameOffset<0&&dx<0)||(frameOffset!==0&&frameOffset>-dx)){frameOffset+=dx;}
else{if(frameOffset!==0){dx+=frameOffset;frameOffset=0;}
frameOffset+=currentFrame.pan(dx,dy);}
if(navigator.mozL10n.language.direction==='ltr'){if((currentFileIndex===0&&frameOffset>0)||(currentFileIndex===files.length-1&&frameOffset<0)){frameOffset=0;}}else{if((currentFileIndex===0&&frameOffset<0)||(currentFileIndex===files.length-1&&frameOffset>0)){frameOffset=0;}}
if(frameOffset!==oldFrameOffset){setFramesPosition();}}
function swipeHandler(event){if(frameOffset===0){return;}
var direction=(frameOffset<0)?1:-1;if(navigator.mozL10n.language.direction==='rtl'){direction*=-1;}
var farenough=Math.abs(frameOffset)>window.innerWidth*TRANSITION_FRACTION;var velocity=event.detail.vx;var fastenough=Math.abs(velocity)>TRANSITION_SPEED;var samedirection=velocity===0||frameOffset/velocity>=0;var fileexists=(direction===1&&currentFileIndex+1<files.length)||(direction===-1&&currentFileIndex>0);var time;if(direction!==0&&(farenough||fastenough)&&samedirection&&fileexists){var speed=Math.max(Math.abs(velocity),TRANSITION_SPEED);time=(window.innerWidth-Math.abs(frameOffset))/speed;if(direction===1){nextFile(time);}else{previousFile(time);}}
else if(frameOffset!==0){time=Math.abs(frameOffset)/TRANSITION_SPEED;currentFrame.container.style.transition=nextFrame.container.style.transition=previousFrame.container.style.transition='transform '+time+'ms ease';resetFramesPosition();transitioning=true;setTimeout(function(){transitioning=false;},time);}}
function wheelHandler(event){if(event.deltaMode!==event.DOM_DELTA_PAGE||!event.deltaX){return;}
if(event.deltaX>0){nextFile(150);}else{previousFile(150);}}
function transformHandler(e){if(transitioning){return;}
if(photodb.parsingBigFiles){return;}
currentFrame.zoom(e.detail.relative.scale,e.detail.midpoint.clientX,e.detail.midpoint.clientY);}
function moveFrameHandler(e){if(photodb.parsingBigFiles)
return;var deltax=6
switch(e.detail.keyId){case 0:currentFrame.pan(deltax,0);break;case 1:currentFrame.pan(-deltax,0);break;case 2:currentFrame.pan(0,deltax);break;case 3:currentFrame.pan(0,-deltax);break;}}
function setupFrameContent(n,frame){if(n<0||n>=files.length){frame.clear();delete frame.filename;return;}
var fileinfo=files[n];if(fileinfo.name===frame.filename){return;}
frame.filename=fileinfo.name;photodb.getFile(fileinfo.name,function(imagefile){if(fileinfo.metadata.video){getVideoFile(fileinfo.metadata.video,function(videofile){frame.displayVideo(videofile,imagefile,fileinfo.metadata.width,fileinfo.metadata.height,fileinfo.metadata.rotation||0);});}
else{frame.displayImage(imagefile,fileinfo.metadata.width,fileinfo.metadata.height,fileinfo.metadata.preview,fileinfo.metadata.rotation,fileinfo.metadata.mirrored,fileinfo.metadata.largeSize);}});}
var FRAME_BORDER_WIDTH=3;function setFramesPosition(){var width=window.innerWidth+FRAME_BORDER_WIDTH;currentFrame.container.style.transform='translateX('+frameOffset+'px)';if(navigator.mozL10n.language.direction==='ltr'){nextFrame.container.style.transform='translateX('+(frameOffset+width)+'px)';previousFrame.container.style.transform='translateX('+(frameOffset-width)+'px)';}
else{nextFrame.container.style.transform='translateX('+(frameOffset-width)+'px)';previousFrame.container.style.transform='translateX('+(frameOffset+width)+'px)';}
nextFrame.container.classList.remove('current');previousFrame.container.classList.remove('current');currentFrame.container.classList.add('current');nextFrame.container.setAttribute('aria-hidden',true);previousFrame.container.setAttribute('aria-hidden',true);currentFrame.container.removeAttribute('aria-hidden');}
function resetFramesPosition(){frameOffset=0;setFramesPosition();}
function showFile(n){updateFocusThumbnail(n);updateFrames();}
function resetCurrentLockStatus(){if(!currentFrame.container.lockStatusNode){createFullscreenLockStatusIcon();}
currentFrame.container.lockStatusNode.reset(chkIsCurrentLocked()?true:false);}
function createFullscreenLockStatusIcon(){var lockStatusNode=document.createElement('div');lockStatusNode.classList.add('fullscreen-lock-status');lockStatusNode.classList.add('gaia-icon');lockStatusNode.classList.add('icon-lock');lockStatusNode.reset=function(locked){this.style.display=locked?'block':'none';}
currentFrame.container.lockStatusNode=lockStatusNode;currentFrame.container.appendChild(lockStatusNode);}
function updateFrames(){var n=currentFileIndex;setupFrameContent(Gallery.getPrevFileIndex(false),previousFrame);setupFrameContent(n,currentFrame);setupFrameContent(Gallery.getNextFileIndex(false),nextFrame);resetFramesPosition();resetCurrentLockStatus();}
function clearFrames(){previousFrame.clear();currentFrame.clear();nextFrame.clear();delete previousFrame.filename;delete currentFrame.filename;delete nextFrame.filename;}
function nextFile(time){if(Gallery.currentFocusIndex===files.length-1){return;}
var nextFileIndex=Gallery.getNextFileIndex(false);if(currentFileIndex===nextFileIndex){return;}
if(currentFrame.displayingVideo&&currentFrame.video.playerShowing){currentFrame.video.init();}
transitioning=true;setTimeout(function(){transitioning=false;},time);var transition='transform '+time+'ms ease';currentFrame.container.style.transition=transition;nextFrame.container.style.transition=transition;var tmp=previousFrame;previousFrame=currentFrame;currentFrame=nextFrame;nextFrame=tmp;currentFileIndex=Gallery.getNextFileIndex(true);nextFileIndex=Gallery.getNextFileIndex(false);updateFocusThumbnail(currentFileIndex);resetFramesPosition();setupFrameContent(nextFileIndex,nextFrame);currentFrame.container.addEventListener('transitionend',function done(e){this.removeEventListener('transitionend',done);previousFrame.reset();});resetCurrentLockStatus();}
function moveToPrev(cur_pos){var pos_save=cur_pos;if(cur_pos===0){return 0;}
while(true){cur_pos=cur_pos-1;if(files[cur_pos].metadata.largeSize!=true){return cur_pos;}
else{if(cur_pos===0){return pos_save;}}}}
function moveToNext(cur_pos,max_length){var pos_save=cur_pos;if(cur_pos>=max_length-1){return cur_pos;}
while(true){cur_pos=cur_pos+1;if(files[cur_pos].metadata.largeSize!=true){return cur_pos;}
else{if(cur_pos>=max_length-1){return pos_save;}}}}
function previousFile(time){if(Gallery.currentFocusIndex===0){return;}
var previousFileIndex=Gallery.getPrevFileIndex(false);if(currentFileIndex===previousFileIndex){return;}
if(currentFrame.displayingVideo&&currentFrame.video.playerShowing){currentFrame.video.init();}
transitioning=true;setTimeout(function(){transitioning=false;},time);var transition='transform '+time+'ms ease';previousFrame.container.style.transition=transition;currentFrame.container.style.transition=transition;var tmp=nextFrame;nextFrame=currentFrame;currentFrame=previousFrame;previousFrame=tmp;currentFileIndex=Gallery.getPrevFileIndex(true);previousFileIndex=Gallery.getPrevFileIndex(false);updateFocusThumbnail(currentFileIndex);resetFramesPosition();setupFrameContent(previousFileIndex,previousFrame);currentFrame.container.addEventListener('transitionend',function done(e){this.removeEventListener('transitionend',done);nextFrame.reset();});resetCurrentLockStatus();}
var ZOOM_IN_LIMIT=9;var ZOOM_OUT_LIMIT=0;var ZOOM_GRADE_RATIO=0.09;function zoomOut(){var originScale=parseFloat(currentFrame.image.getAttribute('data-origin-scale'));var scaleDelta=parseFloat(currentFrame.image.getAttribute('data-scale-delta'));var zoomInTimes=parseInt(currentFrame.image.getAttribute('data-zoom-in'));var zoomOutTimes=parseInt(currentFrame.image.getAttribute('data-zoom-out'));var scale=currentFrame.fit.scale;if(zoomOutTimes>=ZOOM_OUT_LIMIT){return false;}
zoomOutTimes++;zoomInTimes--;updateZoomData(zoomInTimes,zoomOutTimes);scale=scale-scaleDelta;currentFrame.zoomFrame(scale,0,0,200);return zoomOutTimes>=ZOOM_OUT_LIMIT?false:true;}
function zoomIn(){var originScale=parseFloat(currentFrame.image.getAttribute('data-origin-scale'));var scaleDelta=parseFloat(currentFrame.image.getAttribute('data-scale-delta'));var zoomInTimes=parseInt(currentFrame.image.getAttribute('data-zoom-in'));var zoomOutTimes=parseInt(currentFrame.image.getAttribute('data-zoom-out'));var scale=currentFrame.fit.scale;if(zoomInTimes>=ZOOM_IN_LIMIT){return false;}
zoomInTimes++;zoomOutTimes--;updateZoomData(zoomInTimes,zoomOutTimes);scale=scale+scaleDelta;currentFrame.zoomFrame(scale,0,0,200);return zoomInTimes>=ZOOM_IN_LIMIT?false:true;}
function updateZoomData(inTimes,outTimes){currentFrame.image.setAttribute('data-zoom-in',inTimes);currentFrame.image.setAttribute('data-zoom-out',outTimes);}
function restoreFrame(){var originalScale=currentFrame.image.getAttribute('data-origin-scale');updateZoomData(0,0);currentFrame.zoomFrame(parseFloat(originalScale),0,0,200);}