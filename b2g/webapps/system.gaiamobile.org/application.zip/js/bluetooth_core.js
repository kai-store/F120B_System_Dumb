/* exported BluetoothCore */
/* global BaseModule, Bluetooth, BluetoothTransfer, NfcHandoverManager */
'use strict';

(function() {
  var BluetoothCore = function(bluetooth) {
    this.bluetooth = bluetooth;
  };

  /**
   * BluetoothCore handle bluetooth related function and bootstrap
   * modules for v1/v2 API.
   *
   * @class BluetoothCore
   */
  BaseModule.create(BluetoothCore, {
    name: 'BluetoothCore',

    start: function() {
      // init Bluetooth module
      if (typeof(window.navigator.mozBluetooth.onattributechanged) ===
        'undefined') { // APIv1
        return LazyLoader.load(['js/bluetooth.js']).then(function() {
          window.Bluetooth = Bluetooth1;
          return window.Bluetooth.init();
        });
      } else { // APIv2
        return LazyLoader.load(['js/bluetooth_v2.js']).then(function() {
          window.Bluetooth = new Bluetooth2();
          return window.Bluetooth.init();
        });
      }
    } 
  });
}());
