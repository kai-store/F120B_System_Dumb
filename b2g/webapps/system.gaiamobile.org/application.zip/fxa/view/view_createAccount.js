var View = {
  length: 3,
  start: FxaModuleStates.ABOUT
};
