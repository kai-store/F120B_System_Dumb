function Database () {}

Database.prototype = {
	constructor: Database,
    instance:null,
    
    createNewDatabase : function(databaseName, databaseVersion, callback) {
        console.log("DB NAME :"+databaseName+">>>> VERSION : "+databaseVersion);
        //open Database  
        var req = indexedDB.open(databaseName, databaseVersion);
       
        //Success handler for open db 
        req.onsuccess = function (evt) {
            var db = evt.target.result;
            console.log("DB :"+db);
             callback(db, req, false);
        };

        //Failer handler for open db 
        req.onerror = function (evt) {
            console.log("openDb:", evt.target.errorCode);
            callback(null, req, false);
        };

        req.onupgradeneeded = function (evt) {
            var db = evt.currentTarget.result;
            callback(db, req, true);
        };

    }


};

Database.getInstance= function(){
    Database.instance = new Database();
    return Database.instance
};
