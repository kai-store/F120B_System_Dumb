function ChannelListDAO () {
	this.channelId = "";
	this.serverChannelId = "";
	this.channelProfileVersion = "";
	this.channelContentVersion = "";
	this.channelGlobalId = "";
	this.serverChannelStatus = "";
    this.serverChannelCheck = "";
	this.serverChannelNeedPlayIntroVideo = "";
	this.channelGetOkResponse = "";
	this.channelUpdateLogoURL = "";
    this.channelDescription = "";
    this.channelFollowType = -1;
    this.channelIsFollowing= false;
    this.channelName = "";
    this.channelSerialNumber = "";
    this.channelCardVersion = "";
    this.channelIsReceivingMessage = "";
    this.PinToChat = "";
    this.channelPortraitId = "";
    this.channelPublicId = "";
    this.channelAttentive = "";
    this.channelOfficial = "";
    this.channelImagePath="";
    this.channelSubmenuJSON="";
}

ChannelListDAO.prototype = {
	constructor:ChannelListDAO,
    listenMessages:function(){
        console.log("Listen channels Started");
          
        //  if( 'function' === typeof importScripts) {
                self.importScripts('../../utils/underscore.js');
                self.importScripts('../user-db.js');
                self.importScripts('../db-utils.js');
                self.importScripts('../database.js');
                self.importScripts('../db.consts.js');
                self.importScripts('../../app-const.js');
                self.importScripts('../../app-mode.js');
                // self.importScripts('../dao/group-mapping-dao.js');
                // self.importScripts('../dao/group-dao.js');
                // self.importScripts('../dao/contact-dao.js');
                self.importScripts('../dao/session-dao.js');
                // self.importScripts('../dao/channels-list-dao.js');
                self.importScripts('../../cin/CinBase64.js');
                self.importScripts('../../cin/cin.request.conts.js');
                self.importScripts('../../cin/message/message.const.js');
        //    }

        self.onmessage = function(event) {
           if(event.data.length == 0) return;
          
           
           var funcName = event.data.functionName;
           var userId = event.data.userId;
        //    console.log("param1: "+funcName+">>>>>>>> param2: "+userId);   
           switch(funcName) {
                case "addToLDB":
                    var userData = event.data.data;
                    var data = {
                        channelId : userData.channelId,
                        serverChannelId : userData.serverChannelId,
                        channelProfileVersion : userData.channelProfileVersion,
                        channelContentVersion : userData.channelContentVersion,
                        channelGlobalId : userData.channelGlobalId,
                        serverChannelStatus : userData.serverChannelStatus,
                        serverChannelCheck : userData.serverChannelCheck,
                        serverChannelNeedPlayIntroVideo : userData.serverChannelNeedPlayIntroVideo,
                        channelGetOkResponse : userData.channelGetOkResponse,
                        channelUpdateLogoURL : userData.channelUpdateLogoURL,
                        channelDescription : userData.channelDescription,
                        channelFollowType : userData.channelFollowType,
                        channelIsFollowing : userData.channelIsFollowing,
                        channelName : userData.channelName,
                        channelSerialNumber : userData.channelSerialNumber,
                        channelCardVersion : userData.channelCardVersion,
                        channelIsReceivingMessage : userData.channelIsReceivingMessage,
                        PinToChat : userData.PinToChat,
                        channelPortraitId : userData.channelPortraitId,
                        channelPublicId : userData.channelPublicId,
                        channelAttentive : userData.channelAttentive,
                        channelOfficial : userData.channelOfficial,
                        channelImagePath : userData.channelImagePath,
                        channelSubmenuJSON : userData.channelSubmenuJSON
                    } 
   
                    ChannelListDAO.getInstance().addByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "bulkAddToLDB":
                    var data = event.data.data;
                    ChannelListDAO.getInstance().bulkAddToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData);
                    });
                    break;
                case "addByDataToLDB":
                    var data = event.data.data;
                    ChannelListDAO.getInstance().addByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateByDataToLDB":
                    var data = event.data.data;
                    ChannelListDAO.getInstance().updateByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "bulkUpdateToLDB":
                    var data = event.data.data;
                    ChannelListDAO.getInstance().bulkUpdateToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                // case "bulkAddOfFocusChannelToLDB":
                //     var data = event.data.data;
                //     ChannelListDAO.getInstance().bulkAddOfFocusChannelToLDB(userId, data, function(success){
                //         var responseData = {
                //             result:success,
                //             callId:event.data.callId
                //         }
                //         self.postMessage(responseData);
                //     });
                //     break;
                // case "updateFocusChannelByDataToLDB":
                //     var data = event.data.data;
                //     ChannelListDAO.getInstance().updateFocusChannelByDataToLDB(userId, data, function(success){
                //         var responseData = {
                //             result:success,
                //             callId:event.data.callId
                //         }
                //         self.postMessage(responseData)
                //     });
                //     break;
                case "getAllFromLDB":
                    ChannelListDAO.getInstance().getAllFromLDB(userId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                // case "getAllFocusChannelsFromLDB":
                //     ChannelListDAO.getInstance().getAllFocusChannelsFromLDB(userId, function(success){
                //         var responseData = {
                //             result:success,
                //             callId:event.data.callId
                //         }
                //         self.postMessage(responseData)
                //     });
                //     break;
                case "getByChannelIdFromLDB":
                    var channelId = event.data.channelId;
                    ChannelListDAO.getInstance().getByChannelIdFromLDB(userId, channelId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                // case "getByFocusIdFromLDB":
                //     var channelId = event.data.channelId;
                //     ChannelListDAO.getInstance().getByFocusIdFromLDB(userId, channelId, function(success){
                //         var responseData = {
                //             result:success,
                //             callId:event.data.callId
                //         }
                //         self.postMessage(responseData)
                //     });
                //     break;
                case "deleteAllFromLDB":
                    ChannelListDAO.getInstance().deleteAllFromLDB(userId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                
                   
                   
                default:
                    console.log("Nothing to do with messages dao for :"+funcName);
            }
           
        };
    },
    addToLDB:function(userId, callback){
        //Arranging Emoticon Data to be inserted
	    var data = {
            channelId : this.channelId,
            serverChannelId : this.serverChannelId,
            channelProfileVersion : this.channelProfileVersion,
            channelContentVersion : this.channelContentVersion,
            channelGlobalId : this.channelGlobalId,
            serverChannelStatus : this.serverChannelStatus,
            serverChannelCheck : this.serverChannelCheck,
            serverChannelNeedPlayIntroVideo : this.serverChannelNeedPlayIntroVideo,
            channelGetOkResponse : this.channelGetOkResponse,
            channelUpdateLogoURL : this.channelUpdateLogoURL,
            channelDescription : this.channelDescription,
            channelFollowType :this.channelFollowType,
            channelIsFollowing : this.channelIsFollowing,
            channelName :this.channelName,
            channelSerialNumber:this.channelSerialNumber,
            channelCardVersion:this.channelCardVersion,
            channelIsReceivingMessage:this.channelIsReceivingMessage,
            PinToChat:this.PinToChat,
            channelPortraitId:this.channelPortraitId,
            channelPublicId:this.channelPublicId,
            channelAttentive:this.channelAttentive,
            channelOfficial:this.channelOfficial,
            channelImagePath:this.channelImagePath,
            channelSubmenuJSON:this.channelSubmenuJSON
        }
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_LIST], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
	},
    bulkAddToLDB:function(userId, channels, callback){
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_LIST], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST);
            putNext(0);

            function putNext(i) {
                if (i<channels.length) {
                    var request = objectStore.put(channels[i])
                    request.onsuccess = function(event) {
                        putNext(i+1)
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    addByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                 
            //Making INSERT contact request to Local DB
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_LIST], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(userId, data, callback){
        
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
               console.log("trans in channel"+trans);
               console.log("object store"+objectStore);
               var isSuccess = false;
                trans.oncomplete = function(evt) {  
                    callback(isSuccess);
                };
            
                var cursorRequest = index.openCursor(data.channelId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.serverChannelId != undefined && data.serverChannelId != null){
                             updateData.serverChannelId = data.serverChannelId;
                         }
                         if(data.channelProfileVersion != undefined && data.channelProfileVersion != null){
                             updateData.channelProfileVersion = data.channelProfileVersion;
                         }
                         if(data.channelContentVersion != undefined && data.channelContentVersion != null){
                             updateData.channelContentVersion = data.channelContentVersion;
                         }
                         if(data.channelGlobalId != undefined && data.channelGlobalId != null){
                             updateData.channelGlobalId = data.channelGlobalId;
                         }
                         if(data.serverChannelStatus != undefined && data.serverChannelStatus != null){
                             updateData.serverChannelStatus = data.serverChannelStatus;
                         }
                         if(data.serverChannelCheck != undefined && data.serverChannelCheck != null){
                             updateData.serverChannelCheck = data.serverChannelCheck;
                         }
                         if(data.serverChannelNeedPlayIntroVideo != undefined && data.serverChannelNeedPlayIntroVideo != null){
                             updateData.serverChannelNeedPlayIntroVideo = data.serverChannelNeedPlayIntroVideo;
                         }
                         if(data.channelGetOkResponse != undefined && data.channelGetOkResponse != null){
                             updateData.channelGetOkResponse = data.channelGetOkResponse;
                         }
                         if(data.channelUpdateLogoURL != undefined && data.channelUpdateLogoURL != null){
                             updateData.channelUpdateLogoURL = data.channelUpdateLogoURL;
                         }
                         if(data.channelFollowType != undefined && data.channelFollowType != null){
                             updateData.channelFollowType = data.channelFollowType;
                         } 

                         if(data.channelIsFollowing != undefined && data.channelIsFollowing != null){
                             updateData.channelIsFollowing = data.channelIsFollowing;
                         }

                         if(data.channelName != undefined && data.channelName != null){
                             updateData.channelName = data.channelName;
                         }
                         if(data.channelSerialNumber != undefined && data.channelSerialNumber != null){
                             updateData.channelSerialNumber = data.channelSerialNumber;
                         }
                         if(data.channelCardVersion != undefined && data.channelCardVersion != null){
                             updateData.channelCardVersion = data.channelCardVersion;
                         }
                         if(data.channelIsReceivingMessage != undefined && data.channelIsReceivingMessage != null){
                             updateData.channelIsReceivingMessage = data.channelIsReceivingMessage;
                         }
                         if(data.PinToChat != undefined && data.PinToChat != null && data.PinToChat != -1){
                             updateData.PinToChat = data.PinToChat;
                         }
                         if(data.channelPortraitId != undefined && data.channelPortraitId != null){
                             updateData.channelPortraitId = data.channelPortraitId;
                         }
                         if(data.channelPublicId != undefined && data.channelPublicId != null){
                             updateData.channelPublicId = data.channelPublicId;
                         }
                         if(data.channelAttentive != undefined && data.channelAttentive != null){
                             updateData.channelAttentive = data.channelAttentive;
                         }
                         if(data.channelOfficial != undefined && data.channelOfficial != null){
                             updateData.channelOfficial = data.channelOfficial;
                         }
                         if(data.channelImagePath != undefined && data.channelImagePath != null){
                             updateData.channelImagePath = data.channelImagePath;
                         } 
                          if(data.channelDescription != undefined && data.channelDescription != null){
                             updateData.channelDescription = data.channelDescription;
                         }                         
                         if(data.channelSubmenuJSON != undefined && data.channelSubmenuJSON != null){
                             updateData.channelSubmenuJSON = data.channelSubmenuJSON;
                         }
         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                                isSuccess = true;
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    bulkUpdateToLDB:function(userId, portraitData, callback){
        UserDB.getInstance().create(userId, function(success){
            putNext(0);

            function putNext(i) {
                if (i<portraitData.length) {
                    var pData = portraitData[i];
                    if(pData && pData.channelId){
                        ChannelListDAO.getInstance().updateByDataToLDB(userId, pData, function(sucess){
                            putNext(i+1)
                        });
                    }
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    // bulkAddOfFocusChannelToLDB:function(userId, channels, callback){
    //     UserDB.getInstance().create(userId, function(success){
    //         var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST], "readwrite")
    //                         .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
    //         putNext(0);

    //         function putNext(i) {
    //             if (i<channels.length) {
    //                 var request = objectStore.put(channels[i])
    //                 request.onsuccess = function(event) {
    //                     putNext(i+1)
    //                 };
    //             } else {   // complete
    //                 console.log('populate complete');
    //                 callback(true);
    //             }
    //         }  
    //     });
    // },
    // updateFocusChannelByDataToLDB:function(userId, data, callback){
    //      UserDB.getInstance().create(userId, function(success){
    //             var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST, 'readwrite');
    //             var objectStore = trans
    //                         .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
    //             var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
               
    //             trans.oncomplete = function(evt) {  
    //                 callback(true);
    //             };
            
    //             var cursorRequest = index.openCursor(data.channelId);
            
    //             cursorRequest.onerror = function(error) {
    //                 console.log("Error in fetching contacts : "+error);
    //                 callback(false);
    //             };
            
    //             cursorRequest.onsuccess = function(evt) {                 
    //                 var cursor = evt.target.result;
    //                 if (cursor) {
    //                      var updateData = cursor.value;
    //                      if(data.serverChannelId != undefined && data.serverChannelId != null){
    //                          updateData.serverChannelId = data.serverChannelId;
    //                      }
    //                      if(data.channelProfileVersion != undefined && data.channelProfileVersion != null){
    //                          updateData.channelProfileVersion = data.channelProfileVersion;
    //                      }
    //                      if(data.channelContentVersion != undefined && data.channelContentVersion != null){
    //                          updateData.channelContentVersion = data.channelContentVersion;
    //                      }
    //                      if(data.channelGlobalId != undefined && data.channelGlobalId != null){
    //                          updateData.channelGlobalId = data.channelGlobalId;
    //                      }
    //                      if(data.serverChannelStatus != undefined && data.serverChannelStatus != null){
    //                          updateData.serverChannelStatus = data.serverChannelStatus;
    //                      }
    //                      if(data.serverChannelCheck != undefined && data.serverChannelCheck != null){
    //                          updateData.serverChannelCheck = data.serverChannelCheck;
    //                      }
    //                      if(data.serverChannelNeedPlayIntroVideo != undefined && data.serverChannelNeedPlayIntroVideo != null){
    //                          updateData.serverChannelNeedPlayIntroVideo = data.serverChannelNeedPlayIntroVideo;
    //                      }
    //                      if(data.channelGetOkResponse != undefined && data.channelGetOkResponse != null){
    //                          updateData.channelGetOkResponse = data.channelGetOkResponse;
    //                      }
    //                      if(data.channelUpdateLogoURL != undefined && data.channelUpdateLogoURL != null){
    //                          updateData.channelUpdateLogoURL = data.channelUpdateLogoURL;
    //                      }
    //                      if(data.channelFollowType != undefined && data.channelFollowType != null){
    //                          updateData.channelFollowType = data.channelFollowType;
    //                      }



    //                      if(data.channelName != undefined && data.channelName != null){
    //                          updateData.channelName = data.channelName;
    //                      }
    //                      if(data.channelSerialNumber != undefined && data.channelSerialNumber != null){
    //                          updateData.channelSerialNumber = data.channelSerialNumber;
    //                      }
    //                      if(data.channelCardVersion != undefined && data.channelCardVersion != null){
    //                          updateData.channelCardVersion = data.channelCardVersion;
    //                      }
    //                      if(data.channelIsReceivingMessage != undefined && data.channelIsReceivingMessage != null){
    //                          updateData.channelIsReceivingMessage = data.channelIsReceivingMessage;
    //                      }
    //                      if(data.PinToChat != undefined && data.PinToChat != null){
    //                          updateData.PinToChat = data.PinToChat;
    //                      }
    //                      if(data.channelPortraitId != undefined && data.channelPortraitId != null){
    //                          updateData.channelPortraitId = data.channelPortraitId;
    //                      }
    //                      if(data.channelPublicId != undefined && data.channelPublicId != null){
    //                          updateData.channelPublicId = data.channelPublicId;
    //                      }
    //                      if(data.channelAttentive != undefined && data.channelAttentive != null){
    //                          updateData.channelAttentive = data.channelAttentive;
    //                      }
    //                      if(data.channelOfficial != undefined && data.channelOfficial != null){
    //                          updateData.channelOfficial = data.channelOfficial;
    //                      }
    //                      if(data.channelImagePath != undefined && data.channelImagePath != null){
    //                          updateData.channelImagePath = data.channelImagePath;
    //                      }                         
                         
         
    //                      var res = cursor.update(updateData);
    //                         res.onsuccess = function(e){
    //                             console.log("update success!!");
    //                         }
    //                         res.onerror = function(e){
    //                             console.log("update failed!!");
    //                             callback(false);
    //                         }
                        
    //                     cursor.continue();
    //                 }
    //             };
    //     });	 
	// },
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_LIST], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    getByChannelIdFromLDB:function(userId, channelId, callback){  
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
                // var request = index.get(channelId);

                var items=[];
                trans.oncomplete = function(evt) {  
                    callback(items);
                };
            
                var cursorRequest = index.openCursor(channelId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback([]);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var cvalue = cursor.value;
                        if(cvalue){
                          
                                items.push(cvalue);
                           
                        }
                        cursor.continue();
                    }
                };
                
                // //Handler for success operation
                // request.onsuccess = function(event) {
                //     callback(event.target.result);            
                // };

                // //Handler for success operation
                // request.onerror = function(event) {
                //     callback([]);
                // }
        }); 
    },

    // getByFocusIdFromLDB:function(userId, channelId, callback){  
    //      UserDB.getInstance().create(userId, function(success){
    //             var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST , IDBTransaction.READ_ONLY);
    //             var objectStore = trans
    //                         .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
    //             var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
    //             var request = index.get(channelId);
                
    //             //Handler for success operation
    //             request.onsuccess = function(event) {
    //                 callback(event.target.result);            
    //             };

    //             //Handler for success operation
    //             request.onerror = function(event) {
    //                 callback([]);
    //             }
    //     }); 
    // },
   
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_LIST], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	}
   
	
};

ChannelListDAO.getInstance= function(){
    if(!ChannelListDAO.instance){
        ChannelListDAO.instance = new ChannelListDAO();
        ChannelListDAO.instance.listenMessages(); 
    }
    return ChannelListDAO.instance;
};
ChannelListDAO.getInstance();
