function ChannelContentDAO () {
	this.channelId = "";
    this.channelUniqueContentId = "";
	this.channelContentId = "";
	this.channelContentVersion = "";
	this.channelContentColumnIndex = "";
	this.channelContentSummaryInfo = "";
	this.channelContentColumnTitle = "";
}


ChannelContentDAO.prototype = {
	constructor:ChannelContentDAO,
  
    addToLDB:function(userId, callback){
        //Arranging Emoticon Data to be inserted
	    var data = {
            channelId : this.channelId,
            channelUniqueContentId : this.channelUniqueContentId,
            channelContentId : this.channelContentId,
            channelContentVersion : this.channelContentVersion,
            channelContentColumnIndex : this.channelContentColumnIndex,
            channelContentSummaryInfo : this.channelContentSummaryInfo,
            channelContentColumnTitle : this.channelContentColumnTitle

        } 
        
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
	},
    addByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                 
            //Making INSERT contact request to Local DB
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(userId, data, callback){
        
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT);
                var index = objectStore.index(DatabaseConstants.CHANNEL_CONTENT_ID);
               
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.channelContentId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.channelId != undefined && data.channelId != null){
                             updateData.channelId = data.channelId;
                         }
                         if(data.channelContentId != undefined && data.channelContentId != null){
                             updateData.channelContentId = data.channelContentId;
                         }
                         if(data.channelContentVersion != undefined && data.channelContentVersion != null){
                             updateData.channelContentVersion = data.channelContentVersion;
                         }
                         if(data.channelContentColumnIndex != undefined && data.channelContentColumnIndex != null){
                             updateData.channelContentColumnIndex = data.channelContentColumnIndex;
                         }
                         if(data.channelContentSummaryInfo != undefined && data.channelContentSummaryInfo != null){
                             updateData.channelContentSummaryInfo = data.channelContentSummaryInfo;
                         }
                         if(data.channelContentColumnTitle != undefined && data.channelContentColumnTitle != null){
                             updateData.channelContentColumnTitle = data.channelContentColumnTitle;
                         }
                                     
         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    
    getByChannelContentIdFromLDB:function(userId, channelCotentId, callback){  
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT);
                var index = objectStore.index(DatabaseConstants.CHANNEL_CONTENT_ID);
                var request = index.get(channelCotentId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
   
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	}
   
	
};

ChannelContentDAO.getInstance= function(){
    if(!ChannelContentDAO.instance){
        ChannelContentDAO.instance = new ChannelContentDAO();
    }
    return ChannelContentDAO.instance;
};
