function FileDownloadDAO() {
	this.sessionId = "";
	this.peerId = "";
	this.sessionType = "";
    this.msgType = "";
    this.msgId = "";
    this.fileId = "";
    this.fileByteArray = "";
}

FileDownloadDAO.prototype = {
	constructor: FileDownloadDAO,
  
    addToLDB:function(userId, data, callback){
        //Arranging Session Data to be inserted

        // First check record exists or not, if not addToLDB else updateLDB
        FileDownloadDAO.getInstance().getByFileIdFromLDB(userId, data.fileId, function(fileObj){
            var newByteArray = [];
            if(fileObj){
                // updated to LDB
                if(fileObj.fileByteArray){
                    if(fileObj.fileByteArray.length > 0){
                        newByteArray = fileObj.fileByteArray;
                        newByteArray.push(data.fileByteArray);
                    }
                }
                if(newByteArray.length < 1){
                    newByteArray.push(data.fileByteArray);
                }
            }else{
                // add to LDB
                newByteArray.push(data.fileByteArray);
            }

            data.fileByteArray = newByteArray;

            UserDB.getInstance().create(userId, function(success){
                console.log("Insert Active User : "+UserDB.getInstance().database);
                    //Making INSERT contact request to Local DB 
                    var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD], "readwrite")
                                .objectStore(DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD)
                                .put(data);

                    //Handler for success operation
                    request.onsuccess = function(event) {
                        callback(true)
                    };

                    //Handler for failure operation                   
                    request.onerror = function(event) {
                        callback(false)
                    }   
            });

        });
          
	},

    
    getByFileIdFromLDB:function(userId, fileId, callback){
        UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID);
                
                var item;
                trans.oncomplete = function(evt) { 
                    callback(item);
                };
            
                var cursorRequest = index.openCursor(fileId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in deleting session : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        item = cursor.value;
                    }
                };
              
          });
	},

    
    deleteByFileIdFromLDB:function(userId, fileId, callback){
        UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID);
                
                trans.oncomplete = function(evt) { 
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(fileId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in deleting session : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
};

FileDownloadDAO.getInstance = function(){
    if(!FileDownloadDAO.instance){
        FileDownloadDAO.instance = new FileDownloadDAO();
    }
    return FileDownloadDAO.instance;
};
