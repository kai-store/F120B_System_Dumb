function Group() {
	this.groupId = "";
	this.groupName = "";
	this.groupMaxCount = "";
	this.groupVersion = "";
	this.groupCreatorId = "";
	this.groupMessageType = "";
	this.groupIsTop = "";
	this.groupProtraitId = "";
	this.groupPortraitSize = "";
    this.groupThumb = "";
    this.users = [];
}

Group.prototype = {
	constructor: Group, 
    listenMessages:function(){
        console.log("Listen Group Message Started");
        // self.onmessage = function(event) {
        //     debugger;
        //    if(event.data.length == 0) return;  
        //    var funcName = event.data[0];
        //    var userId = event.data[1];
        //    console.log("param1: "+funcName+">>>>>>>> param2: "+userId);  
        //    debugger; 
        //    switch(funcName) {
        //         case "addToLDB":
        //             Group.getInstance().addToLDB(userId, function(success){
        //                 self.postMessage(success)
        //             });
        //             break;
        //         case "addByDataToLDB":
                    
        //             break;
        //         case "deleteByGroupIdFromLDB":
        //             var groupId = event.data[2];
        //             Group.getInstance().deleteByGroupIdFromLDB(userId, groupId, function(success){
        //                 console.log("Delete SUCESSSSSSSSS : "+success);
        //                 self.postMessage(success)
        //             });
        //             break;
        //         default:
        //             console.log("Nothing to do");
        //     }
        //    
        // };
    },
    addToLDB:function(userId, callback){
        // debugger;
        //Arranging Contact Data to be inserted
	    var data = {
            groupId : this.groupId,
            groupName : this.groupName,
            groupMaxCount : this.groupMaxCount,
            // users : this.users,
            groupVersion : this.groupVersion,
            groupCreatorId : this.groupCreatorId,
            groupMessageType : this.groupMessageType,
            groupIsTop : this.groupIsTop,
            groupProtraitId : this.groupProtraitId,
            groupThumb : this.groupThumb,
            groupPortraitSize : this.groupPortraitSize       
        }

        var that = this;
          UserDB.getInstance().create(userId, function(success){
             
            console.log("Insert Group : "+UserDB.getInstance().database);
                //Making INSERT group request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    
                    console.log("GROUP CREATED SUCCESSFULLY");
                    if(that.users.length > 0){
                        data.users = that.users;
                        GroupMapping.getInstance().addNewMembersToLDB(userId, data, function(success){
                            callback(true, that.groupId)
                        });
                    }else{
                   
                        callback(true, that.groupId)
                    }
                   
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false, that.groupId)
                }   
          });
          
	},
    addByDataToLDB:function(userId, data, callback){
        // debugger;
        var that = this;
          UserDB.getInstance().create(userId, function(success){
              
            console.log("Insert Group : "+UserDB.getInstance().database);
                //Making INSERT group request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    
                    console.log("GROUP CREATED SUCCESSFULLY");
                    if(data.users.length > 0){
                        GroupMapping.getInstance().addNewMembersToLDB(userId, data, function(success){
                            callback(true, that.groupId)
                        });
                    }else{
                        callback(true, that.groupId)
                    }
                   
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false, that.groupId)
                }   
          });
          
    },
    addGroupInfoToLDB:function(userId, data, callback){
        UserDB.getInstance().create(userId, function(success){
            console.log("Insert Group : "+UserDB.getInstance().database);

            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
                            .put(data);

            request.onsuccess = function(event) {
                console.log("GROUP CREATED SUCCESSFULLY");
                if(data.users.length > 0){
                    GroupMapping.getInstance().addNewMembersToLDB(userId, data, function(success){
                        callback(true);
                    });
                }else{
                    callback(true);
                }
            };
        
            request.onerror = function(event) {
                callback(false);
            };   
        });  
    },
    
    addNewUsers:function(userId, groupId, groupMembers ,callback){
        
        GroupMapping.getInstance().getByGroupIdFromLDB(userId, groupId, function(users){
            console.log(users);
            // var newMembers = [];
            // groupMembers.forEach(function(groupMember,userIndex){
            //     var isAlreadyThere = false;
            //     users.forEach(function(user,index){
            //          if(user.userId == groupMember.userId){
            //             // newMembers.push(groupMember);
            //             isAlreadyThere = true;
            //          }
            //      });

            //     if (!isAlreadyThere) {
            //         newMembers.push(groupMember);
            //     };
            // });

             var data = {
                    groupId : groupId,
                    users : groupMembers   
                } 

            GroupMapping.getInstance().addNewMembersToLDB(userId, data, function(success){
                callback(success)
            });
          
                
        });  
             

    },
    updateUserNameByUserIdToLDB:function(userId, groupUserId, groupUserName, callback){
         GroupMapping.getInstance().updateUserNameByUserIdToLDB(userId, groupUserId, groupUserName, function(success){
                callback(success)
        });
    },
    // addNewUsers:function(userId, groupId, newUserIds ,callback){
    //     Group.getInstance().getByGroupIdFromLDB(userId, groupId, function(group){
    //         console.log("Group Name :" +group.groupName);
    //          var allUsers = group.userIds+"|"+newUserIds;
    //           console.log("allUsers :" +allUsers);

    //            var data = {
    //                 groupId : group.groupId,
    //                 groupName : group.groupName,
    //                 groupMaxCount : group.groupMaxCount,
    //                 userIds : allUsers,
    //                 groupVersion : group.groupVersion,
    //                 groupCreatorId : group.groupCreatorId,
    //                 groupMessageType : group.groupMessageType,
    //                 groupIsTop : group.groupIsTop,
    //                 groupProtraitId : group.groupProtraitId,
    //                 groupPortraitSize : group.groupPortraitSize       
    //             } 
               
    //              console.log("Insert Group : "+UserDB.getInstance().database);
    //                 //Making INSERT group request to Local DB 
    //                 var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP], "readwrite")
    //                             .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
    //                             .put(data);

    //                 //Handler for success operation            
    //                 request.onsuccess = function(event) {
    //                     callback(true)
    //                 };

    //                 //Handler for failure operation                   
    //                 request.onerror = function(event) {
    //                     callback(false)
    //                 }   
            
              
    //     });
    // },
    updateByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
              var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
                // var request = index.get(data.groupId);
            
             
                // trans.oncomplete = function(evt) {  
                //     callback(true);
                // };
            
                var cursorRequest = index.openCursor(data.groupId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.groupThumb && data.groupThumb != ""){
                             updateData.groupThumb = data.groupThumb;
                         }
                         if(data.groupName && data.groupName != ""){
                             updateData.groupName = data.groupName;
                         }
                         if(data.groupMaxCount != undefined && data.groupMaxCount != null){
                             updateData.groupMaxCount = data.groupMaxCount;
                         }
                         if(data.groupVersion != undefined && data.groupVersion != null){
                             updateData.groupVersion = data.groupVersion;
                         }
                         if(data.groupCreatorId != undefined && data.groupCreatorId != null){
                             updateData.groupCreatorId = data.groupCreatorId;
                         }
                         if(data.groupMessageType != undefined && data.groupMessageType != null){
                             updateData.groupMessageType = data.groupMessageType;
                         }
                         if(data.groupIsTop != undefined && data.groupIsTop != null){
                             updateData.groupIsTop = data.groupIsTop;
                         }
                         if(data.groupProtraitId != undefined && data.groupProtraitId != null){
                             updateData.groupProtraitId = data.groupProtraitId;
                         }
                         if(data.groupPortraitSize != undefined && data.groupPortraitSize != null){
                             updateData.groupPortraitSize = data.groupPortraitSize;
                         }
                     
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                                callback(true);
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        // cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_GROUP);
            var items = [];
        
            trans.oncomplete = function(evt) {  
                callback(_.sortBy(items,function (i) { return i.groupName.toLowerCase(); }));
                // var sorted = _.sortBy(array, function (i) { return i.name.toLowerCase(); });
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
	},
   
     getByGroupIdFromLDB:function(userId, groupId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP, IDBTransaction.READ_ONLY);
            var request = trans
                        .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
                        .get(groupId);
            
            //Handler for success operation
            request.onsuccess = function(event) {
                var group = event.target.result;
                if(group != undefined && group != null){
                    GroupMapping.getInstance().getByGroupIdFromLDB(userId, groupId, function(users){
                        group.users = users;
                        
                        callback(group)
                    });  
                }else{
                    callback({});   
                }
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback({});
            } 
        });
    },
    deleteGroupMemberByGroupId: function(userId, groupId, memberId, callback){
        GroupMapping.getInstance().deleteMemberByGroupIdFromLDB(userId, groupId, memberId, function(success){
            callback(success)
        }); 
    },
   
    deleteByGroupIdFromLDB:function(userId, groupId, callback){
        // debugger;
        UserDB.getInstance().create(userId, function(success){
              //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
                        .delete(groupId);
            
            //Handler for success operation
            request.onsuccess = function(event) {
                
                GroupMapping.getInstance().deleteByGroupIdFromLDB(userId, groupId, function(success){
                    callback(success)
                });
                // callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
	},
	deleteAllFromLDB:function(userId, callback){
        // debugger;
        UserDB.getInstance().create(userId, function(success){
              //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_GROUP)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
	}
	
};

Group.getInstance= function(){
    if(!Group.instance){
        Group.instance = new Group();
        // Group.instance.listenMessages();
    }
    return Group.instance;
};

Group.getInstance();
