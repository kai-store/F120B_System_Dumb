function GroupMapping() {
	this.groupId = "";
	this.userId = "";
	this.userName = "";
    this.phoneBookName = "";
    this.colorCode = "";
    this.mobileNumber = "";
}

GroupMapping.prototype = {
	constructor: GroupMapping,
  
    addToLDB:function(userId, callback){
        //Arranging Contact Data to be inserted
	    var data = {
            groupId : this.groupId,
            userId : this.userId,
            userName : this.userName,
            phoneBookName : this.phoneBookName,
            colorCode : this.colorCode,
            mobileNumber : this.mobileNumber     
        } 

        var that = this;
          UserDB.getInstance().create(userId, function(success){
            console.log("Insert Group : "+UserDB.getInstance().database);
                //Making INSERT group request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    console.log("GROUP MAPPER CREATED SUCCESSFULLY");
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    updateByDataToLDB:function(userId, data, callback){
        //Arranging Contact Data to be inserted
        var that = this;
          UserDB.getInstance().create(userId, function(success){
            console.log("Insert Group : "+UserDB.getInstance().database);
                //Making INSERT group request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    console.log("GROUP MAPPER CREATED SUCCESSFULLY");
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    addByGroupDataToLDB:function(userId, group, callback){
        //Arranging group Data to be inserted
        var that = this;
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            putNext(0);

            function putNext(i) {
                if (i<group.users.length) {
                    var groupMember = group.users[i];
                    groupMember.groupId = group.groupId;
                    var request = objectStore.put(groupMember)
                    request.onsuccess = function(event) {
                        putNext(i+1)
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
          

         });

	},
    addNewMembersToLDB:function(userId, groupData, callback){
        GroupMapping.getInstance().getByGroupIdFromLDB(userId, groupData.groupId, function(users){
            console.log(users);
            var newMembers = [];
            var groupMembers = groupData.users;
            groupMembers.forEach(function(groupMember,userIndex){
                var isAlreadyThere = false;
                users.forEach(function(user,index){
                     if(user.userId == groupMember.userId){
                        // newMembers.push(groupMember);
                        isAlreadyThere = true;
                     }
                 });

                if (!isAlreadyThere) {
                    newMembers.push(groupMember);
                };
            });

             var data = {
                    groupId : groupData.groupId,
                    users : newMembers   
                } 

            GroupMapping.getInstance().addByGroupDataToLDB(userId, data, function(success){
                callback(success)
            });
          
                
        });  
        //  UserDB.getInstance().create(userId, function(success){
        //       var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, 'readwrite');
        //         var objectStore = trans
        //                     .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
        //         var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
        //         // var request = index.get(data.groupId);
            
        //         var items = [];
        //         trans.oncomplete = function(evt) {
                   
        //             if(items != undefined){
        //                  var finalUsers = [];
        //                  data.users.forEach(function(newUser){
        //                     var isUserAlreadyThere = false;
        //                     items.forEach(function(oldUser){
        //                         if(newUser.userId == oldUser.userId){
        //                             isUserAlreadyThere = true;
        //                         }  
        //                     });

        //                     if(!isUserAlreadyThere){
        //                         finalUsers.push(newUser);
        //                     }
        //                  });
                     
        //                     console.log("Adding New Members to GRoups LBD");
        //                     data.users = finalUsers;
        //                     GroupMapping.getInstance().addByGroupDataToLDB(userId, data, function(success){
        //                         callback(true);
        //                     });
        //             }
        //             else{
        //                 GroupMapping.getInstance().addByGroupDataToLDB(userId, data, function(success){
        //                         callback(true);
        //                 });
        //             }
        //         };
            
        //         var cursorRequest = index.openCursor(data.groupId);
            
        //         cursorRequest.onerror = function(error) {
        //             console.log("Error in fetching groups mapping : "+error);
        //             callback(false);
        //         };
            
        //         cursorRequest.onsuccess = function(evt) {                 
        //             var cursor = evt.target.result;
        //             if (cursor) {
        //                 //  var updateData = cursor.value;
        //                 //  data.users.forEach(function(user){
        //                 //      if(updateData.userId == user.userId){
        //                 //         isUserAlreadyThere = true;
        //                 //      }  
        //                 //  });
        //                 items.push(cursor.value)
                         
        //                 cursor.continue();
        //             }
        //         };
        // });	 
	},
    updateUserNameByUserIdToLDB:function(userId, groupUserId, groupUserName, callback){
         UserDB.getInstance().create(userId, function(success){
              var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);
                // var request = index.get(data.groupId);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(groupUserId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(groupUserName != undefined && groupUserName != null){
                             updateData.userName = groupUserName;
                         }
                     
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                                // callback(true);
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var items = [];
        
            trans.oncomplete = function(evt) {  
                callback(items);
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
	},
     getByGroupIdFromLDB:function(userId, groupId, callback){	
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
                var request = index.get(groupId);
            
                var items = [];
                trans.oncomplete = function(evt) {  
                    callback(_.sortBy(items,"userName"));
                };
            
                var cursorRequest = index.openCursor(groupId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        items.push(cursor.value);
                        cursor.continue();
                    }
                };
        });
    },
    getUserInfoByUserIdFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);
            
                var item;
                trans.oncomplete = function(evt) {  
                    callback(item);
                };
            
                var cursorRequest = index.openCursor(userId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        item = cursor.value;
                    }
                };
        });
    },
    deleteMemberByGroupIdFromLDB:function(userId, groupId, memberId, callback){
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                   callback(true);
                };
            
                var cursorRequest = index.openCursor(groupId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        if(cursor.value.userId == memberId){
                            var request = cursor.delete();
                            request.onsuccess = function() {
                                console.log('Deleted Group Member');
                            };
                            request.onerror = function(error) {
                                console.log('Delete Memeber Failed');
                                callback(false);
                            };
                        }
                       
                        cursor.continue();
                    }
                };
        });
	},
    deleteByGroupIdFromLDB:function(userId, groupId, callback){
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                   callback(true);
                };
            
                var cursorRequest = index.openCursor(groupId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        
                            var request = cursor.delete();
                            request.onsuccess = function() {
                                console.log('Deleted Group Member');
                            };
                            request.onerror = function(error) {
                                console.log('Delete Memeber Failed');
                                callback(false);
                            };
                        
                       
                        cursor.continue();
                    }
                };
        });
	},
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
              //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
	}
	
};

GroupMapping.getInstance= function(){
    if(!GroupMapping.instance){
        GroupMapping.instance = new GroupMapping();
    }
    return GroupMapping.instance;
};
