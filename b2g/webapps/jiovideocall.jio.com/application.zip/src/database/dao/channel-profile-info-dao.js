function ChannelProfileDAO () {
    this.channelId = "";
	this.channelProfileVersion = "";
    this.channelContentVersion = "";
    this.channelSerialNumber = "";
	this.channelName = "";
	this.channelShareFlag = "";
	this.channelIntroVideoId = "";
	this.channelShareImageFlag = "";
	this.channelShareIconFlag = "";
	this.channelTransitionVideoId = "";
    this.channelEndVideoId = "";
    this.channelRedCode = "";
    this.channelGreenCode = "";
    this.channelBlueCode = "";
    this.channelLogoURL = "";
    this.channelContentSummaryInfo = "";
    this.channelIsRedDot = "";
  
}


ChannelProfileDAO.prototype = {
	constructor:ChannelProfileDAO,
  
    addToLDB:function(userId, callback){
        //Arranging Emoticon Data to be inserted
	    var data = {
            channelId : this.channelId,
            channelProfileVersion : this.channelProfileVersion,
            channelContentVersion : this.channelContentVersion,
            channelSerialNumber : this.channelSerialNumber,
            channelName : this.channelName,
            channelShareFlag : this.channelShareFlag,
            channelIntroVideoId : this.channelIntroVideoId,
            channelShareImageFlag : this.channelShareImageFlag,
            channelShareIconFlag : this.channelShareIconFlag,
            channelTransitionVideoId : this.channelTransitionVideoId,
            channelEndVideoId : this.channelEndVideoId,
            channelRedCode : this.channelRedCode,
            channelGreenCode : this.channelGreenCode,
            channelBlueCode : this.channelBlueCode,
            channelLogoURL : this.channelLogoURL,
            channelContentSummaryInfo : this.channelContentSummaryInfo,
            channelIsRedDot : this.channelIsRedDot
            
        } 
        
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
	},
    addByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                 
            //Making INSERT contact request to Local DB
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(userId, data, callback){
        
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
               
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.channelId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.channelProfileVersion != undefined && data.channelProfileVersion != null){
                             updateData.channelProfileVersion = data.channelProfileVersion;
                         }
                         if(data.channelContentVersion != undefined && data.channelContentVersion != null){
                             updateData.channelContentVersion = data.channelContentVersion;
                         }
                         if(data.channelSerialNumber != undefined && data.channelSerialNumber != null){
                             updateData.channelSerialNumber = data.channelSerialNumber;
                         }
                         if(data.channelName != undefined && data.channelName != null){
                             updateData.channelName = data.channelName;
                         }
                         if(data.channelShareFlag != undefined && data.channelShareFlag != null){
                             updateData.channelShareFlag = data.channelShareFlag;
                         }
                         if(data.channelIntroVideoId != undefined && data.channelIntroVideoId != null){
                             updateData.channelIntroVideoId = data.channelIntroVideoId;
                         }
                         if(data.channelShareImageFlag != undefined && data.channelShareImageFlag != null){
                             updateData.channelShareImageFlag = data.channelShareImageFlag;
                         }
                         if(data.channelShareIconFlag != undefined && data.channelShareIconFlag != null){
                             updateData.channelShareIconFlag = data.channelShareIconFlag;
                         }
                         if(data.channelTransitionVideoId != undefined && data.channelTransitionVideoId != null){
                             updateData.channelTransitionVideoId = data.channelTransitionVideoId;
                         }
                         if(data.channelEndVideoId != undefined && data.channelEndVideoId != null){
                             updateData.channelEndVideoId = data.channelEndVideoId;
                         }
                         if(data.channelRedCode != undefined && data.channelRedCode != null){
                             updateData.channelRedCode = data.channelRedCode;
                         }
                         if(data.channelGreenCode != undefined && data.channelGreenCode != null){
                             updateData.channelGreenCode = data.channelGreenCode;
                         }
                         if(data.channelBlueCode != undefined && data.channelBlueCode != null){
                             updateData.channelBlueCode = data.channelBlueCode;
                         }
                         if(data.channelLogoURL != undefined && data.channelLogoURL != null){
                             updateData.channelLogoURL = data.channelLogoURL;
                         }
                         if(data.channelContentSummaryInfo != undefined && data.channelContentSummaryInfo != null){
                             updateData.channelContentSummaryInfo = data.channelContentSummaryInfo;
                         }
                         if(data.channelIsRedDot != undefined && data.channelIsRedDot != null){
                             updateData.channelIsRedDot = data.channelIsRedDot;
                         }
                         console.log("updateData : "+updateData);
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("explore update success!!");
                            }
                            res.onerror = function(e){
                                console.log("explore update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    
    getByChannelIdFromLDB:function(userId, channelId, callback){
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
                var request = index.get(channelId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
   
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	}
   
	
};

ChannelProfileDAO.getInstance= function(){
    if(!ChannelProfileDAO.instance){
        ChannelProfileDAO.instance = new ChannelProfileDAO();
    }
    return ChannelProfileDAO.instance;
};
