function TestWorker() {
    this.worker = null;
    this.nextCallId = 0;
    this.callbacks = {};
}

TestWorker.prototype = {
	constructor: TestWorker,
    startWorker:function(){
        var that = this;
        this.worker = new Worker('src/database/workers/test-worker-dao.js');
        //  this.worker.importScripts('../../utils/underscore.js');
        //         this.worker.importScripts('../user-cipher-db.js');
        //         this.worker.importScripts('../user-db.js');
        //         this.worker.importScripts('../db-utils.js');
        //         this.worker.importScripts('../database.js');
        //         this.worker.importScripts('../db.consts.js');
        //         this.worker.importScripts('../../app-const.js');
        //         this.worker.importScripts('../../app-mode.js');
        //         this.worker.importScripts('../dao/group-mapping-dao.js');
        //         this.worker.importScripts('../dao/group-dao.js');
        //         this.worker.importScripts('../dao/contact-dao.js');
        //         this.worker.importScripts('../dao/session-dao.js');
        //         // self.importScripts('../dao/channels-list-dao.js');
        //         // self.importScripts('../dao/channels-focus-list-dao.js');
        //         this.worker.importScripts('../../cin/CinBase64.js');
        //         this.worker.importScripts('../../cin/cin.request.conts.js');
        //         this.worker.importScripts('../../cin/message/message.const.js');
        this.worker.onmessage = function(event) {
           console.log("Parent Worker");
        };     
	},
    getAll:function(){	
        
        this.worker.postMessage("Helloooo");
        
	}
};

TestWorker.getInstance = function(){
    if(!TestWorker.instance){
        TestWorker.instance = new TestWorker();
        TestWorker.instance.startWorker();
    }
    return TestWorker.instance;
};
