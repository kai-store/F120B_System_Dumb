import React from 'react';
import ReactDOM from 'react-dom';
import JioBaseComponent from './shared/jioBaseComponent';
import OptionMenuRenderer from './shared/option_menu_renderer';
import DialogRenderer from './shared/dialog_renderer';
// import ReactSoftKey from 'react-soft-key';
import ReactSoftKey from './lib/react-soft-key';
import Service from 'service';
import history from './shared/my_history';
import HistoryManager from 'history-manager';
import Routes from './routes';
import '../scss/app.scss';
import 'common-scss';
import 'gaia-icons';
import 'l10n';
import CallStore from 'data/call-store';
import MessageStore from 'data/message-store';
import ChannelStore from 'data/channels-store';
import GroupListStore from 'data/groupList-store';
import ReactGA from 'react-ga';
// import firebase from 'firebase';

// JioChatSDK
import JioChatSDK from './sdk/jio-sdk';

// import TestWorker from './database/workers/test-worker';
class App extends JioBaseComponent {
    name = 'App';    
    
    componentDidMount() {
        window.appInstance = this; // For debugging purpose
        window.isDev = false;
        window.isFromPush = false;
        window.deviceId = null;//UUID.randomUUIDHex(); // Hardcoding the device id
        window.msgNotificationEnabled = true;
        window.notificationSoundEnabled = true;
        window.notificationVibrationEnabled = true;
        window.chatSoundEnabled = true;
        window.showMessagePreview = true;
        window.msgDelayTime = 0;
        window.showLastSeen = true;
        window.showReadReceipt = true;
        window.dndFrom = ""; 
        window.dndTo = "";
        window.isTesting = false;
        window.isGroupListAPICalled = false;
        window.isReleaseBuild = true;
        // window.isChatDetailEntered = false;

        window.isFirstTimeJioAnalytics = true;
        window.deviceInfoLoaded = false;
        window.onSimChanged = false;

        this.sdkObj = JioChatSDK.getInstance();
        this.isDeviceMode = this.sdkObj.isDeviceMode();

        history.replace('/splash');
        // AppConstants.videoFrameRateTestEnabled = true;//It should be true only if video frame change test needs to added
        var sdkInstance = JioChatSDK.getInstance();
        sdkInstance.setSDKCapability(AppMode.TYPE);
        AppConstants.windowHeight = window.innerHeight;

        // Set this value for local contacts when running in browser.
        // sdkInstance.setSDKMode(JCSDKConstants.SDK_DEBUG_MODE);

        if(AppMode.TYPE == AppMode.APP_TYPE_JVC){
            UserModel.getInstance().setFAQlink('http://www.jiochat.com/faq_video/');
            ReactGA.initialize('UA-93922548-2');
            ReactGA.pageview('/splash');
        } else if(AppMode.TYPE == "JCL"){
            UserModel.getInstance().setFAQlink('http://www.jiochat.com/faq_channels/');
            ReactGA.initialize('UA-93922548-3');
            ReactGA.pageview('/splash');
        } else if(AppMode.TYPE == "JMS"){ 
            UserModel.getInstance().setFAQlink('http://www.jiochat.com/faq_messages/');
        }

        if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
            VAModel.getInstance().registerVoiceActivity();
        }
              
        var currentDate = new Date();
        window.getStartTimeForAnalytics = currentDate.getTime();
        // no need to set it here..added in lifecycle
        // var deviceInfo = new JCDeviceInfo();
        // deviceInfo.setDeviceID(window.deviceId);
        // sdkInstance.setDeviceInfo(deviceInfo);

        // this should be true for JioVideo app
        // AppMode.TYPE=="JVC" = true;
        // if(AppMode.TYPE=="JVC"){
        if(AppMode.TYPE != AppMode.APP_TYPE_JMS && AppMode.TYPE != AppMode.APP_TYPE_JCL){    
            this.setIncomingHDCallCallbacks();
            this.setOutgoingHDCallCallbacks();
        }
        // }

        if(AppMode.TYPE  != AppMode.APP_TYPE_JSDK){
            this.setGAErrorUpdateCallback();
        }

        if( AppMode.TYPE != AppMode.APP_TYPE_JVC && AppMode.TYPE  != AppMode.APP_TYPE_JSDK){

            // this.setMessageLocalCallback();
            this.setOtherCallbacks();
            this.setUpdatesAvailableOnMessages();
            this.setMessageCallback();
            this.setGroupNotificationCallback();
            // this.setOfflineMessageCallback();
            this.setUploadCallback();
            this.setDownloadCallback();
            
        }

        //added by binesh to check internet connectivity
        this.checkInternetStatus();
    }

    checkInternetStatus(){
        var that = this;
        window.addEventListener("offline", function(e) {
            if(AppMode.TYPE == AppMode.APP_TYPE_JVC){
                ReactGA.event({
                    category: 'No internet available',
                    action: '',
                    label: 'Internet not available'
                });
                /* Jio analytic code *****/
                var analyticDataObj = {
                    "eventName" : "no_internet",
                    "eventType" : "events",
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
            }
            console.log("Internet Disconnected");
            that.emit(AppConstants.EMIT_INTERNET_DISCONNECTED);
        }, false);
          
        window.addEventListener("online", function(e) {
            console.log("Internet Connected");
            that.emit(AppConstants.EMIT_INTERNET_CONNECTED);
        }, false);      
    }

    setGAErrorUpdateCallback(){
        JIOUtils.setGAErrorUpddateCallback(function(gaObject){
            console.log("This is Ga error code test "+errCode);
            ReactGA.event({
                category: 'API error ',
                action: 'Videocall',
                label: 'API call failed'
            });
            /**** Jio analytics code */
            var analyticDataObj = {
                "eventName" : "APIerror_"+gaObject.method,
                "eventType" : "events",
                "exceptionType" : gaObject.event,   
                "exceptionMsg" : gaObject.msg,
                "errorMsg" : gaObject.errorCode,
                "dateTime" : new Date()
            };
            JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
        });
    }    

    setMessageLocalCallback(){
        var that = this;
        var messageStore = MessageStore.getInstance();
        JioChatSDK.getInstance().setMessageLocalCallback({
            onMessageAdded: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.push(chatMsgObj);

                // Do emit
                that.updateMessagesLocally(msgArray);
                
            },
            onMessageSent: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }
                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(String(msgItem.msgId) == String(chatMsgObj.msgId)){
                        msgItem.msgStatus = chatMsgObj.msgStatus;
                        msgItem.msgSequence = chatMsgObj.msgSequence;
                        msgItem.msgDateTime = chatMsgObj.dateTime;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);

            },
            onMessageFailed: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = MessageStore.getInstance().currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = MessageStore.getInstance().getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(String(msgItem.msgId) == String(chatMsgObj.msgId)){
                        msgItem.msgStatus = chatMsgObj.msgStatus;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);
            },
            onMessageReceived: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.push(chatMsgObj);

                // Do emit
                that.updateMessagesLocally(msgArray);
            },
            onReply: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = MessageStore.getInstance().currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = MessageStore.getInstance().getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(String(msgItem.msgId) == String(chatMsgObj.msgId)){
                        msgItem.msgStatus = chatMsgObj.msgStatus;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);
            },
            onReadReply: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = MessageStore.getInstance().currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = MessageStore.getInstance().getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(msgItem.msgType != MessageConsts.TYPE_FREE_SMS && msgItem.msgType != MessageConsts.TYPE_UPDATE_STATUS && msgItem.msgSequence < chatMsgObj.msgSequence && msgItem.msgDirection == 0){
                        msgItem.msgStatus = MessageConsts.STATUS_READBYFRIEND;
                        // msgItem.msgSequence = chatMsgObj.msgSequence;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);
            },
            onOfflineMessagesReceived: function(chatMsgObj, chatMsgArr){
                
                if(!chatMsgArr) return;
                if(chatMsgArr.length < 1) return;

                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }
                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                chatMsgArr.forEach(function(cMsgObj, index){
                    msgArray.push(cMsgObj);
                });

                // Do emit
                that.updateMessagesLocally(msgArray);
            }
        });
    }

    setOtherCallbacks(){
        var that = this;
        JioChatSDK.getInstance().setOtherCallbacks({
            onUpdateContacts: function(){
                
            },
            onUpdateChannels: function(){

            },
            onUpdateExplore: function(){

            },
            onClearChatHistory: function(){
                that.updateChat();
                that.updateMessages();
            },
            onGroupInfoChanged: function(){
                that.updateGroupInfo();
            }
        });
    }

    setUpdatesAvailableOnMessages(){
        var that = this;
        JioChatSDK.getInstance().setUpdatesAvailableOnMessages({
            onMessagesAvailable: function(){
                that.updateChat();
                that.updateMessages();
            },
            onChatAvailable: function(){
                that.updateChat();
                that.updateMessages();
            },
            onBroadcastMessageAvailable: function(){
                that.updateChat();
                that.updateBroadcastMessages();
            },
            onBuddyLeave: function(){
                that.updateOnBuddyLeave();
            }
        });
    }

    setMessageCallback(){
        var that = this;
        JioChatSDK.getInstance().setMessageCallback({
            onMessageAdded: function(chatMessage){
                // debugger;
                console.log('onMessageAdded invoked. This will be invoked when message gets added to LDB');
            },
            onTextMessage: function(chatMessage){
                console.log('onTextMessage invoked');
                // debugger;
                that.updateChat();
                that.updateMessages();
            },
            onTyping: function(userId){
                // debugger;
                console.log('onTyping invoked');
                that.updateTypingNotification(userId);
            },
            onReply: function(peerId, messageId, chatMsg){
                // debugger;
                console.log('onReplyInvoked invoked');
                that.updateMessages();
            },
            onReadReply: function(peerId, isReadOtherOne, lastReadSeq, chatMsg){
                // debugger;
                console.log('onReadReply invoked');
                that.updateMessages();
            },

            //Offline message callback
            onMessagesReceived: function(chatMessages){
                
                console.log('onMessagesReceived invoked');
                that.updateChat();
                that.updateMessages();
            },
            onOfflineMessagesReceived: function(chatMessages){
                // debugger;
            },
            onOfflineMessageSent: function(chatMessage){
                // debugger;
                console.log('onOfflineMessageSent invoked');
            },
            onOfflineMessageSentError: function(errResponse){
                // debugger;
                console.log('onOfflineMessageSentError invoked');
            },

            onMessageSent: function(chatMessage){
                console.log('onMessageSent invoked');
                that.updateChat();
                that.updateMessages();
            },
            onMessageSentError: function(errResponse){
                console.log('onMessageSentError invoked');
            },

            onContactReceived: function(response){
                // debugger;
            },
            onContactError: function(errResponse){
                // debugger;
            },

            onContactPortraitReceived: function(response){
                // debugger;
            },
            onContactPortraitError: function(contRes, errResponse){
                // debugger;
            },

            onGroupInfoReceived: function(response){
                // Take only the group title
                // debugger;
            },
            onGroupInfoError: function(groupId, errResponse){
                // debugger;
            },

            onGroupMembersReceived: function(groupResponse){
                //Take the group title & the members list
                // debugger;
            },
            onGroupMembersError: function(groupId, version, errResponse){
                // debugger;
            },

            onGroupPortraitReceived: function(response){
                // debugger;
            },
            onGroupPortraitError: function(errResponse){
                // debugger;
            }
        });
    }

    setGroupNotificationCallback(){
        var that = this;
        JioChatSDK.getInstance().setGroupNotificationCallback({
            onGroupJoined: function(group, version){
                console.log("onGroupJoined invoked. Will be invoked whenever you joined to a new group");
                that.updateChat();
            },
            onGroupInfoChanged: function(group, sourceId, name, version, groupMaxCount, updateUserName){
                console.log("onGroupInfoChanged invoked. Will be invoked whenever groupName changed");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupBuddyUpdate: function(group, version, sourceId, sourceName, newMembers, isFromInvite){
                console.log("onGroupBuddyUpdate invoked. Will be invoked whenever member added to the group");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupBuddyLeave: function(group, version, sourceId, sourceName, newMembers){
                console.log("onGroupBuddyUpdate invoked. Will be invoked whenever member removed from the group");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupSetChanged: function(groupId, msgType){
                console.log("onGroupSetChanged invoked.");
            },
            onGroupJoinedSyncNotify: function(groupId){
                console.log("onGroupJoinedSyncNotify invoked.");
            },
            onGroupPortraitChanged: function(group, version, portraitId, portraitSize, sourceId, thumb){
                console.log("onGroupPortraitChanged invoked. Will be invoked whenever group profile photo changed/updated");
                that.updateGroupInfo();
                // that.emit('onGroupPortraitChanged', group);
            },
            onGroupAdminUpdated: function(group, newAdminUserId, newAdminUserName, version){
                console.log("onGroupAdminUpdated invoked. Will be invoked when admin transfers its group admin rights to other member");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupAdminUpdatedForNewAdmin: function(group, version){
                console.log("onGroupAdminUpdated invoked. Will be invoked when admin quit group & transfers admin rights to other member");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            }
        });
    }

    setIncomingHDCallCallbacks(){
        console.log("[call : incoming] setIncomingHDCallCallbacks ");
        var that = this;
        JioChatSDK.getInstance().setInComingHDCallback({
            onRinging: function(hdCall){//incoming call
                // debugger;
                console.log("[call : incoming] ringing.. ");
                console.log("[call : incoming] HDCALL "+ JSON.stringify(hdCall));
                that.loadIncomingCallWindow(hdCall);
            },
            onPacketRecevied: function(hdCall, userId, count){//incoming&outgoing call
                console.log("[call : incoming] packet received");
            },
            onCallBusy: function(hdCall, userId, status){//incoming call
            },
            onCallHold: function(hdCall){ 	
                console.log("[call : incoming] Peer Busy"); 			
                AudioPlayer.getInstance().play(AudioType.CALL_BUSY_RINGING_SOUND); 			
            },
            onICERecevied: function(hdCall, iceCandidates, status){//incoming&outgoing call
                console.log("[call : incoming] ICE received"); 			
                PeerConnection.getInstance().handleCandidate(hdCall); 
            },
            onSDPRecevied: function(hdCall){//incoming&outgoing call
            },
            onTURNRecived: function(hdCall){//incoming&outgoing call
            },
            onCallEnd: function(hdCall){//incoming&outgoing call  
                console.log("[call : incoming] end call from server onEND"); 		
                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND);
                if(PeerConnection.getInstance().hdCall != null){	                   	
                    var callId = String(PeerConnection.getInstance().hdCall.callID);
                    console.log("[call : incoming] end call comparison result",String(hdCall.callID) == callId); 		
                    if(String(hdCall.callID) == callId){
                        that.emit(AppConstants.EMIT_CALL_END);
                    }
                }
            },
            onError: function(error){//incoming&outgoing call
                console.log("[call : incoming] error from server",error); 	
                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND);
                if(error.errCode == 200){
                    that.emit(AppConstants.EMIT_CALL_PEER_OFFLINE);
                }else{
                    that.emit(AppConstants.EMIT_CALL_ERROR,error);
                }
                that.anyOtherCallInteruptedWhileCall = false;
                
            }
        });
    }

   
    setOutgoingHDCallCallbacks(){
        var that = this;
        JioChatSDK.getInstance().setOutgoingHDCallback({   
            onPacketRecevied: function(hdCall, userId, count){//incoming&outgoing call
                // debugger;
            },
            onICERecevied: function(hdCall, iceCandidates, status){//incoming&outgoing call
                console.log("[call : outgoing] ICE received from server"); 	  
                PeerConnection.getInstance().handleCandidate(hdCall); 
            },
          
            onSDPRecevied: function(hdCall){//incoming&outgoing call
                // debugger;
                console.log("[call : outgoing] SDP received from server");
                PeerConnection.getInstance().hdCall = hdCall;
                PeerConnection.getInstance().onRinging = true;
                PeerConnection.getInstance().handleAnswer(hdCall);  
                PeerConnection.getInstance().sendIceCandidatesToServer();
            },
            onTURNRecived: function(hdCall){//incoming&outgoing call
                console.log("[call : outgoing] TURN received from server",hdCall);
                // debugger;
                // if(AppConstants.SUDDEN_END_CALL){
                //     PeerConnection.getInstance().EndCallOnStatusCall(hdCall,{ 			
                //         onSuccess: function(){ 			
                //             console.log("END CALL SUCCESS CALLBACK  RECEIVED: ");			
                //         }, 			
                //             onError: function(error){ 			
                //             console.log("END CALL FAILURE CALLBACK  RECEIVED: "+error);		
                //         } 			
                //     }); 
                // }
                PeerConnection.getInstance().isCaller = true;
                PeerConnection.getInstance().createOffer(hdCall);
                  
            },
            onAnsCall: function(hdCall, userId, version){//outgoing call
                // debugger;

                ReactGA.event({
                    category: 'Call connected',
                    action: '',
                    label: 'Call connected to peer side'
                });

                var analyticDataObj = {
                    "eventName" : "call_success",
                    "eventType" : "events",
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);

                console.log("[call : outgoing] Remote answered");
                that.emit(AppConstants.EMIT_CALL_PEER_ANSWERED);
                PeerConnection.getInstance().isCallOnGoing = true;
                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND);
           
            },
            onRemoteRinging: function(hdCall){//outgoing call
                var currentDate = new Date();  
                console.log("[call : outgoing] HDCALL "+ JSON.stringify(hdCall));                
                var totalTime = currentDate.getSeconds() - new Date(window.callInitiatedTime).getSeconds();
                ReactGA.event({
                    category: 'Call setup time',
                    action: '',
                    label: 'Button click to ringing',
                    value:totalTime
                });
                ReactGA.event({
                    category: 'Call success',
                    action: '',
                    label: ''
                });

                var analyticDataObj1 = {
                    "eventName" : "call_setup_time",
                    "eventType" : "events",
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj1);
    
                var analyticDataObj2 = {
                    "eventName" : "call_setup_time",
                    "eventType" : "events",
                    "timeStamp" : totalTime,
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj2);

                console.log("[call : outgoing] remote ringing");
                that.userNotAvailable(hdCall);                
                AudioPlayer.getInstance().play(AudioType.OUTGOING_CALL_RINGING_SOUND);
                that.emit(AppConstants.EMIT_CALL_REMOTE_RINGING);
                
            },
            onCallHold: function(hdCall){
                console.log("[call : outgoing] Remote busy");
                console.log("analytics fail");
                ReactGA.event({
                    category: 'Call reject',
                    action: 'Video call',
                    label: 'Call rejeceted'
                });
                /* Jio analytic code *****/
                var analyticDataObj = {
                    "eventName" : "call_reject",
                    "eventType" : "events",
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj); 

                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND);
                AudioPlayer.getInstance().play(AudioType.CALL_BUSY_RINGING_SOUND);
                
                AppConstants.USER_BUSY_TIMEOUT = setTimeout(function(){
                    clearTimeout(AppConstants.USER_NOT_AVAILABLE_TIMEOUT);
                    PeerConnection.getInstance().EndCallOnStatusCall(hdCall,{ 			
                        onSuccess: function(){ 			
                            console.log("END CALL SUCCESS CALLBACK  RECEIVED: ") 			
                        }, 			
                            onError: function(error){ 			
                            console.log("END CALL FAILURE CALLBACK  RECEIVED: "+error) 			
                        } 			
                    }); 	
                    // if(AppMode.TYPE === AppMode.APP_TYPE_JC) {
                    //     that.emit(AppConstants.EMIT_CALL_REMOTE_UNAVAILABLE); 
                    // }else {
                        that.emit(AppConstants.EMIT_CALL_END);
                    // }                 
                    
                },7000);                
            },
            onCallEnd: function(hdCall){//incoming&outgoing call
                console.log("[call : outgoing] endcall status from server");
                console.log("[call : outgoing] CALL STATUS",PeerConnection.getInstance().isCallOnGoing);
                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND);		
                if(!PeerConnection.getInstance().isCallOnGoing){ 	
                    AudioPlayer.getInstance().play(AudioType.CALL_BUSY_RINGING_SOUND);
                    if((location.href.split("/")[location.href.split("/").length - 1]) == "home"){
                        AudioPlayer.getInstance().stop(AudioType.CALL_BUSY_RINGING_SOUND);
                        return;
                    }
                    console.log("BUSY TONE");
                    AppConstants.USER_BUSY_TIMEOUT = setTimeout(function(){
                        // if(AppMode.TYPE === AppMode.APP_TYPE_JC) {
                        //     console.log("[video call]: unavailable");
                            // that.emit(AppConstants.EMIT_CALL_REMOTE_UNAVAILABLE); 
                        // } else {
                            that.emit(AppConstants.EMIT_CALL_END);
                        // }   
                    },7000);
                }else {
                    that.emit(AppConstants.EMIT_CALL_END);		
                }
            },
            onError: function(error){//incoming&outgoing call
                console.log("[call : outgoing] error from server");
                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND);

                ReactGA.event({
                    category: 'Call failed',
                    action: 'Videocall',
                    label: 'Video call failed'
                });
                /**** Jio analytics code */
                var analyticDataObj = {
                    "eventName" : "call_failed",
                    "eventType" : "events",
                    "exceptionType" : error.errMsg,   
                    "exceptionMsg" : error.errMsg,
                    "errorMsg" : error.errMsg,
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);

                if(error.errCode == 200){
                    that.emit(AppConstants.EMIT_CALL_PEER_OFFLINE);
                }else if(error.errCode == 105){
                    that.emit(AppConstants.EMIT_HD_CALL_NOT_SUPPORTED);
                }
                else{
                    that.emit(AppConstants.EMIT_CALL_ERROR,error);
                }
            }
    });
  }

  loadIncomingCallWindow(hdCall){
    //   debugger;
        // var tempHDCall = PeerConnection.getInstance().hdCall;
        var that = this;
        var tempHDCall = hdCall;
        console.log("JVC: hdCall",hdCall);
        if(PeerConnection.getInstance().isCallOnGoing || PeerConnection.getInstance().hdCall != null){
            // debugger;
            console.log("[call : incoming] Already some calls are going on");
                hdCall.setState(RTMRequestConsts.BUSY_STATE_HOLD);
                PeerConnection.getInstance().HoldCall(hdCall, {
                    onSuccess: function(){
                        // debugger;
                        console.log("[call : incoming] HOLD CALL SUCCESS CALLBACK  RECEIVED: ");
                        AppConstants.THIRD_INCOMING_CALL = true;
                        CallStore.getInstance().addMissedCallLog(hdCall);
                    },
                    onError: function(error){
                        // debugger;
                        console.log("[call : incoming] HOLD CALL FAILURE CALLBACK  RECEIVED: "+error)
                    }
                });
                // if(!PeerConnection.getInstance().isCallOnGoing){
                //     // that.stopRinging();
                //     that.emit(AppConstants.EMIT_CALL_END);
                // }
            // return;
        }else{
            PeerConnection.getInstance().isCaller = false;
            // PeerConnection.getInstance().hdCall = tempHDCall;
            if(hdCall.isAudioCall()){
                if(AppMode.TYPE == AppMode.APP_TYPE_JVC){  
                    // history.push('/voiceCall/incoming/' +hdCall.from);
                    PeerConnection.getInstance().EndCallOnStatusCall(hdCall,{
                        onSuccess: function(){
                            console.log("[call : incoming] END CALL SUCCESS CALLBACK  RECEIVED: ");
                        },
                        onError: function(error){
                            console.log("[call : incoming] END CALL FAILURE CALLBACK  RECEIVED: "+error)
                        }
                    });
                    return;
                }else {
                    if(AppConstants.videoOptionOpen){
                        document.activeElement.parentNode.parentNode.parentNode.classList.add('hidden');
                    }
                    if(AppConstants.alertViewOpen){
                        document.activeElement.parentNode.parentNode.classList.add('hidden');
                    }
                    if(AppMode.TYPE == AppMode.APP_TYPE_DESKTOP) {
                        that.emit(AppConstants.EMIT_HD_CALL_INCOMING_AUDIO,hdCall.from);
                    }else {
                        history.push('/voiceCall/incoming/' +hdCall.from);
                    }                    
                }        
            }else{
                // that.hide();
                 if(AppConstants.videoOptionOpen){
                    document.activeElement.parentNode.parentNode.parentNode.classList.add('hidden');
                }   
                if(AppConstants.alertViewOpen){
                    document.activeElement.parentNode.parentNode.classList.add('hidden');
                }
                if(AppMode.TYPE == AppMode.APP_TYPE_DESKTOP) {
                    that.emit(AppConstants.EMIT_HD_CALL_INCOMING_VIDEO,hdCall.from);
                }else {
                    history.push('/videoCall/incoming/'+hdCall.from);
                }
                
            }
            PeerConnection.getInstance().onRinging = true;
            console.log("SESSION KEY : "+hdCall.key+" >>>>>>>>> SESSION TOKEN : "+hdCall.address +">>>>>> CALL ID : "+hdCall.callID);
            setTimeout(function(){
                PeerConnection.getInstance().handleAnswer(hdCall); 
            },1000);
            AudioPlayer.getInstance().play(AudioType.OUTGOING_CALL_RINGING_SOUND); 
            // }          

        }
  }
  userNotAvailable(hdCall){
      var that = this;
        AppConstants.USER_NOT_AVAILABLE_TIMEOUT = setTimeout(function(){ 	
            console.log("[call : outgoing] iscallOngoing status",PeerConnection.getInstance().isCallOnGoing);		
            if(!PeerConnection.getInstance().isCallOnGoing){ 			
                    // that.stopRinging();
                console.log('analytics didnt pick call');
                ReactGA.event({
                    category: 'VideoCall',
                    action: 'Call',
                    label: 'Success',
                    value: 0
                }); 			
                AudioPlayer.getInstance().stop(AudioType.OUTGOING_CALL_RINGING_SOUND); 			
                PeerConnection.getInstance().EndCallOnStatusCall(hdCall,{ 			
                    onSuccess: function(){ 			
                        console.log("[call : outgoing] END CALL SUCCESS CALLBACK  RECEIVED: ") 			
                    }, 			
                        onError: function(error){ 			
                        console.log("[call : outgoing] END CALL FAILURE CALLBACK  RECEIVED: "+error) 			
                    } 			
                }); 			
                that.emit(AppConstants.EMIT_CALL_REMOTE_UNAVAILABLE); 			
            }                     			
        },75000);
    }

//   setOfflineMessageCallback(){
//       var that = this;
//         JioChatSDK.getInstance().setOfflineMessagesCallback({
//             onMessagesReceived: function(chatMessage){
//                 // debugger;
//                 console.log('onMessagesReceived invoked');
//                 that.updateChat();
//                 that.updateMessages();
//             },
//             onMessageSent: function(chatMessage){
//                 console.log('onMessageSent invoked');
//                 that.updateChat();
//                 that.updateMessages();
//             },
//             onMessageSentError: function(errResponse){
//                 console.log('onMessageSentError invoked');
//             },
//         });
//   }

  setUploadCallback(){
    var that = this;
    JioChatSDK.getInstance().setUploadCallback({
        onProgressChanged: function(attachment){
            that.emit(AppConstants.EMIT_FILE_UPLOAD_PROGRESS_CHANGED, attachment);
        },
        onSuccess: function(attachment){
            that.emit(AppConstants.EMIT_FILE_UPLOAD_SUCCESS, attachment);
        },
        onError: function(attachment){
            that.emit(AppConstants.EMIT_FILE_UPLOAD_ERROR, attachment);
        }
    });
  }

  setDownloadCallback(){
      var that = this;
      JioChatSDK.getInstance().setDownloadCallback({
        onProgressChanged: function(attachment){
            that.emit(AppConstants.EMIT_FILE_DOWNLOAD_PROGRESS_CHANGED, attachment);
        },
        onSuccess: function(attachment){
            that.emit(AppConstants.EMIT_FILE_DOWNLOAD_SUCCESS, attachment);
        },
        onError: function(attachment){
            that.emit(AppConstants.EMIT_FILE_DOWNLOAD_ERROR, attachment);
        }
    });
  }

  updateChat(){
      if(this.isLocationExists("home") || this.isLocationExists("chatlist")){
          this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_CHAT_HISTORY, true);
        }
        if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
            this.emit(AppConstants.UPDATES_AVAILABLE_ON_RECENT_CHANNELS);
        }
    }

  updateMessages(){
      if(this.isLocationExists("chatDetail")){
            this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_MESSAGES);
        }
    }

    updateOnBuddyLeave(){
        this.emit(AppConstants.EMIT_SESSION_REMOVED_ON_BUDDY_LEAVE);
    }

    updateMessagesLocally(msgArray){
      if(this.isLocationExists("chatDetail")){
            this.emit(AppConstants.EMIT_LOCAL_UPDATES_AVAILABLE_ON_MESSAGES, msgArray);
        }
    }
  
  updateBroadcastMessages(){
      if(this.isLocationExists("broadcastDetailView")){
            this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_BROADCAST_MESSAGES);
        }
    }

  updateGroupInfo(){
      if(this.isLocationExists("home") || this.isLocationExists("chatlist") || this.isLocationExists("chatDetail") || this.isLocationExists("groupInformation")){
            this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_CHAT_WHEN_GROUP_INFO_CHANGED, true);
        }
    }
    
updateTypingNotification(userId){
    if(this.isLocationExists("home") || this.isLocationExists("chatlist")){
        this.emit(AppConstants.ON_TYPING_NOTIFICATION, userId);
    }

    else if(this.isLocationExists("chatDetail")){
        this.emit(AppConstants.EMIT_TYPING_NOTIFICATION_ON_CHAT_DETAIL, userId);
    }
}

  isLocationExists(pageName){
    if(AppMode.TYPE == AppMode.APP_TYPE_DESKTOP) {
        return true;
      }
      
      return window.location.href.toLowerCase().indexOf(pageName.toLowerCase()) > -1 ? true : false;
    }
 
    render() {
        if(AppMode.TYPE == AppMode.APP_TYPE_DESKTOP) {
        return <div id='app' tabIndex='-1'>
                   <div className="statusbar-placeholder"></div>
                    <HistoryManager className="margin-bottom" ref="history" history={history} routes={Routes} />
                    <div id="menu-root" ></div>
                    <DialogRenderer />
                </div>;
        }else if(AppMode.TYPE=="MOBILE"){
        return <div id='app' tabIndex='-1'>
                   <div className="statusbar-placeholder"></div>
                    <HistoryManager className="margin-bottom" ref="history" history={history} routes={Routes} />
                    <div id="menu-root" ></div>
                    <DialogRenderer />
                </div>;
        } else {
            return (
                <div id='app' tabIndex='-1'>
                    <div className="statusbar-placeholder"></div>
                    <HistoryManager className="margin-bottom" ref="history" history={history} routes={Routes} />
                    <ReactSoftKey ref="softkey" />
                    <div id="menu-root" ></div>
                    <DialogRenderer />
                </div>
            );
        }
    }
}
window.__myapp_container = document.getElementById('root');
ReactDOM.render(<App />, document.getElementById('root'));
