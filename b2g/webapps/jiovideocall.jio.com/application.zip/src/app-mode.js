function AppMode(){}

// AppType definitions
AppMode.APP_TYPE_JVC = "JVC";
AppMode.APP_TYPE_JC = "JC";
AppMode.APP_TYPE_JCL = "JCL";
AppMode.APP_TYPE_JMS = "JMS";
AppMode.APP_TYPE_JSDK = "JSDK";
AppMode.APP_TYPE_DESKTOP = "DESKTOP";
AppMode.APP_TYPE_MOBILE = "MOBILE";
AppMode.APP_TYPE_TIZEN = "TIZEN";

//App is in JVC Mode
 
AppMode.APP_VERSION_JC  = 'v2.1.9(JioChat)';
AppMode.APP_VERSION_JVC = 'v1.3.30';
AppMode.APP_VERSION_JMS = 'v1.1.3(JioMessaging)';
AppMode.APP_VERSION_JCL = 'v1.1.3(JioChannels)';
AppMode.APP_VERSION_JCSDK = 'v1.1.3';
AppMode.APP_VERSION_DESKTOP = 'v1.1.3(Desktop)';
AppMode.APP_VERSION_MOBILE = 'v1.1.3(Mobile)';
AppMode.APP_VERSION_TIZEN = 'v1.1.3(Tizen)';

//AppModes = JVC | JC | JCL | JMS | JSDK | DESKTOP | MOBILE | TIZEN

AppMode.TYPE  = AppMode.APP_TYPE_JVC;
AppMode.FINAL_VERSION  = AppMode.APP_VERSION_JVC;

