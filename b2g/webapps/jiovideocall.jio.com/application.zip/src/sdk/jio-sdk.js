import BaseModule from '../lib/base-module';
import JCUser from './jc-user';
import JCCall from './jc-call';
import ChatListStore from '../data/chatlist-store';
import OnBoardingStore from '../data/onboarding-store';
import JCMessageClient from './jcmessage-client';
import JioContactsClient from './jc-contactsclient';
import JCChannelsClient from './jc-channelsclient';
import JCFileClient from './jc-fileclient';
// import JCDeviceInfo from './jc-deviceinfo';
import JIOSDKUtils from './base-jc-user.js';
import JCStickersClient from './jc-stickers-client';
import JCExploreClient from './jc-exploreclient';
import JCGroupClient from './jc-groupclient';
import JCDeviceUtility from './jc-device-utility';

/**
 * @classdesc
 * JioChatSDK is an entry point class, this class will init all global callbacks and SDK related information. JioChatSDK is a singleton class. You should use
 * getInstance() to get this instance,
 * @version 0.5
 * @class JioChatSDK
 */
export default class JioChatSDK extends BaseModule {
    start() {
        this.sdkMode = JCSDKConstants.SDK_RELEASE_MODE;
        // console.log("calling pointing http Production  from sdk");
        HTTPRequestConts.setProduction();
        // HTTPRequestConts.setIOT();
        // HTTPRequestConts.setPreProduction(); //for testing
        this.deviceInfo = null;
        this.hdInCallback = null;
        this.hdOutCallback = null;
        this.messageCallback = null;
        this.messageLocalCallback = null;
        this.offlineMessagesCallback = null;
        this.grpNotificationCallback = null;
        this.logger = null;
        this.updatesAvailableOnMessagesCallback = null;
        this.otherCallbacks = null;
        this.sdkLifeCycleCallback = null;
        this.settings = new JCSettings();
        this.initLogger();
        // this.logger.disableLogger();
        this.logger.enableLogger();
        this.sdkEnableMode = JCSDKConstants.SDK_ENABLED_MODE;
        this.setSDKCapability(AppMode.TYPE);
        ChatListStore.getInstance();
        console.log("sdkLifeCycleCallback is"+this.sdkLifeCycleCallback);
    }
    /**
     * @function setAppType
     * @desc
     * setAppType method should be mandatorily called while setting sdk parameters. This is used to set app type, to support multiple apps.
     * This method will accepts five values, JCSDKConstants.SDK_APP_TYPE_SDK, JCSDKConstants.SDK_APP_TYPE_JMS, JCSDKConstants.SDK_APP_TYPE_JC and JCSDKConstants.SDK_APP_TYPE_JCL
     * @param {JCSDKConstants.SDK_APP_TYPE_SDK | JCSDKConstants.SDK_APP_TYPE_JVC | JCSDKConstants.SDK_APP_TYPE_JMS | JCSDKConstants.SDK_APP_TYPE_JC | JCSDKConstants.SDK_APP_TYPE_JCL} appType - App Type
     * @memberof JioChatSDK#
     */
    setAppType(appType){
        this.appType = appType;
        UserModel.getInstance().setAppType(appType);
    }
    getAppType(){
       return this.appType;
    }

    initializePush(callback){
        OnBoardingStore.getInstance().initializePush(callback);
    }  
    
    
    /**
     * @function setSDKLifeCycle
     * @desc 
     * Method will set lifeCycleCallback for sdk app launch, 
     * @param {LifeCycleCallback} lifeCycleCallback - Life cycle Callback for proper app launching.
     * @memberof JioChatSDK#
     */
    setSDKLifeCycle(lifeCycleCallback){
        this.sdkLifeCycleCallback = lifeCycleCallback;
        console.log("sdkLifeCycleCallback is in setSDKLifeCycle "+this.sdkLifeCycleCallback);
        if(this.appType == undefined || this.appType == null){
            JIOUtils.sendError(100,"Please set apptype.", this.sdkLifeCycleCallback);
            throw new Error("Please set apptype.");
        }
        UserModel.getInstance().setAppType(JioChatSDK.getInstance().appType);
        // this.reqestDeviceInfo();
        if(AppMode.TYPE == AppMode.APP_TYPE_JSDK){
            this.requestPush();//for sdk, since onSIMchanged is not working
        } else {
            this.requestSIMChanged();
        }
    }
    
    /**
     * @function setSDKNotificationCallback
     * @desc 
     * Method will set SDKNotificationCallback for sdk app,
     * This will give force logout callback for now,
     * you can expect more notifications in this callback in future. 
     * @param {SDKNotificationCallback} SDKNotificationCallback - SDKNotificationCallback for sdk notification such as force logout.
     * @memberof JioChatSDK#
     */
    setSDKNotificationCallback(SDKNotificationCallback){
        ChatListStore.getInstance().setSDKNotificationCallback(SDKNotificationCallback);
    }



    requestSIMChanged(callback){
        var that = this;
        console.log("sdkLifeCycleCallback is in requestSIMChanged  "+this.sdkLifeCycleCallback);
        
        if(!this.sdkLifeCycleCallback){
            throw ("setSDKLifeCycle method is not implemented.");
        }

        if (typeof this.sdkLifeCycleCallback.onSIMChanged !== "function") {
            throw ("onSIMChanged method not implemented.");
            return;
        }

        this.sdkLifeCycleCallback.onSIMChanged({
            onSuccess: function(isChanged){
                if(isChanged === true){
                    that.deleteUserModel();
                    return;
                }
                that.requestPush();
            },
            onError: function(){
                that.requestPush();
            }
        });

    }

    deleteUserModel(){
        var userModel = UserModel.getInstance();
        var phoneNumber = userModel.getPhoneNumber();
        if(phoneNumber == undefined || phoneNumber == null){
            this.requestPush();
            return;
        }
        var that = this;
        var fileName = userModel.getFileName(phoneNumber);
        this.deleteUserMetaFile(fileName, {
            onSuccess:function(){
                userModel.clearAll();
                UserDB.getInstance().clearDBAccess();
                UserCipherDB.getInstance().clearDBAccess();
                that.requestPush();
            },
            onError: function(){
                userModel.clearAll();                
                UserDB.getInstance().clearDBAccess();
                UserCipherDB.getInstance().clearDBAccess();
                that.requestPush();
            }
        });
    }
    
    deleteUserMetaFile(userFile, callback){
        var userModel = UserModel.getInstance();        
        var that = this;
        DeviceModel.deleteJioFileFromDevice(userModel.getMetaFileName(),{
            onSuccess: function(){
                that.deleteUserFile(userFile, callback);
            },
            onError: function(){
                console.log("[Model:: User] error while deleting user model file");
                that.deleteUserFile(userFile, callback);
            }
        });
    }

    deleteUserFile(fileName, callback){
        DeviceModel.deleteJioFileFromDevice(fileName,{
            onSuccess: function(){
                callback.onSuccess();
            },
            onError: function(){
                callback.onError();
            }
        });
    }
    
    reqestDeviceInfo(callback){
        if(!this.sdkLifeCycleCallback){
            throw ("setSDKLifeCycle method is not implemented.");
        }  
        if (typeof this.sdkLifeCycleCallback.onReqDeviceInfo !== "function") {
            throw ("onReqDeviceInfo method is not implemented.");
        }
        
        this.sdkLifeCycleCallback.onReqDeviceInfo({
            onSuccess: function(deviceInfo){
                // debugger;
                var instance = JioChatSDK.getInstance();
                var _deviceInfo = instance.getDeviceInfo();
                if(_deviceInfo == null || _deviceInfo == undefined){
                    _deviceInfo = new JCDeviceInfo();
                }
                var deviceID = EncryptionUtils.getSeqID(deviceInfo.getDeviceID());
                _deviceInfo.setDeviceID(deviceID);
                JioChatSDK.getInstance().setDeviceInfo(_deviceInfo);
                UserModel.getInstance().setPushToken(_deviceInfo);

                if(callback){
                    callback.onSuccess();
                    return;
                }
                JioChatSDK.getInstance().onStart();
            },
            onError: function(){
                if(callback){
                    callback.onError();
                    return;
                }
                throw "Device info is required.";
            }
        });
    }

    requestPush(){
        //No SDK Callback set
        var that = this;
        console.log("sdkLifeCycleCallback is in requestPush  "+this.sdkLifeCycleCallback);
        
        if(!this.sdkLifeCycleCallback){
            throw ("setSDKLifeCycle method is not implemented.");
        }
        //onReqPush method not implemented.
        // Then read object from file, based on that we need to call other methods.
        if (typeof this.sdkLifeCycleCallback.onReqPush !== "function") {
            this.initUserObjectFromFile();
            return;
        }
        this.sdkLifeCycleCallback.onReqPush({
            onSuccess: function(pushObject){
                var instance = JioChatSDK.getInstance();
                var deviceInfo = new JCDeviceInfo();
                deviceInfo.setPush(pushObject);
                instance.setDeviceInfo(deviceInfo);
                UserModel.getInstance().setPushToken(deviceInfo);
                instance.initUserObjectFromFile();
            },
            onError: function(){
                console.log("sdkLifeCycleCallback is in onRequestPush onError "+that.sdkLifeCycleCallback);
                
                JioChatSDK.getInstance().initUserObjectFromFile();
            }
        });

    }

    initUserObjectFromFile(){
        console.log("sdkLifeCycleCallback is in initUserObjectFromFile "+this.sdkLifeCycleCallback);
        
        var instance = UserModel.getInstance();
        instance.initData();
        
        if(this.getAppType() === JCSDKConstants.SDK_APP_TYPE_DESKTOP){
            this.reqestDeviceInfo();
            return;
        }
        var that = this;

        var phoneNumber = instance.getPhoneNumber();
        instance.readUserModelToFile(phoneNumber,{
            onSuccess: function(userModelJSON){
                if(!userModelJSON){
                    JioChatSDK.getInstance().reqSSOToken();
                    return;
                }
                UserModel.getInstance().clone(userModelJSON);
                JioChatSDK.getInstance().reqestDeviceInfo();//JioChatSDK.getInstance().appType
            },
            onError: function(){
                if(!phoneNumber){
                    JioChatSDK.getInstance().reqSSOToken();
                    return;
                }

                JioChatSDK.getInstance().reqestDeviceInfo();
            }
        });
    }
    
    reqSSOToken(){
        if(!this.sdkLifeCycleCallback){
            throw ("setSDKLifeCycle method is not implemented.");
        }
        if (typeof this.sdkLifeCycleCallback.onReqSSOToken !== "function") {
            //this.initUserObjectFromFile();
            this.manualLogin();
            return;
        }
        console.log("sdkLifeCycleCallback is in reqSSOToken "+this.sdkLifeCycleCallback);
        
        this.sdkLifeCycleCallback.onReqSSOToken({
            onSuccess: function(ssoLogon){
                JioChatSDK.getInstance().autoLogonReq(ssoLogon);
            },
            onError: function(){
                JioChatSDK.getInstance().manualLogin();
            }
        });

    }
    manualLogin(){
        if (typeof this.sdkLifeCycleCallback.reqManualLogin !== "function") {
            console.log("reqManualLogin is not implemented....")
            return;
        }
        var that = this;
        JioChatSDK.getInstance().reqestDeviceInfo({
            onSuccess: function(){
               JioChatSDK.getInstance().reqManualLogin();
            },
            onError: function(){
                that.lifeCyleError(error);
            }
        });
        
    }
    reqManualLogin(){
        this.sdkLifeCycleCallback.reqManualLogin({
            onSuccess: function(){
                JioChatSDK.getInstance().start();//JioChatSDK.getInstance().appType
            },
            onError: function(error){
                JioChatSDK.getInstance().lifeCyleError(error);
            }
        });
    }
    
    autoLogonReq(ssoObject){
        var that = this;
        JioChatSDK.getInstance().reqestDeviceInfo({
            onSuccess: function(){
               JioChatSDK.getInstance().reqAutoLogon(ssoObject);
            },
            onError: function(){
                that.lifeCyleError(error);
            }
        });
    }

    reqAutoLogon(ssoObject){
        var that = this;
        JioChatSDK.getInstance().autoRegister(ssoObject, {
            onSuccess: function(profile){
                JioChatSDK.getInstance().profileReq(profile);
            }, onError: function(error){
                that.lifeCyleError(error);
            }
        });
    }

    profileReq(profile){
        if (typeof this.sdkLifeCycleCallback.onProfile === "function") {
            this.sdkLifeCycleCallback.onProfile(profile);
        }
        // if (typeof this.sdkLifeCycleCallback.onStart === "function") {
        //     this.sdkLifeCycleCallback.onStart();
        // }
        this.onStart();
    }
    
    onStart(){
        console.log("sdkLifeCycleCallback is in onStart ");
        
        if (typeof this.sdkLifeCycleCallback.onStart !== "function") {
            throw ("setSDKLifeCycle.onStart() method is not implemented.");
        }

        // Set Global Callback
        ChatListStore.getInstance().setGlobalCallback();
        this.callProfileAPI();
        
        this.sdkLifeCycleCallback.onStart();
    }

    lifeCyleError(error){
        if (typeof this.sdkLifeCycleCallback.onError === "function") {
            this.sdkLifeCycleCallback.onError(error);
        }
    }
    /**
     * Method will set your current device information to SDK. This method has to be called after getInstance of SDK
     * @param {JCDeviceInfo} deviceInfo
     * @memberof JioChatSDK#
     * @example
     * var sdkInstance = JioChatSDK.getInstance();
     * var deviceInfo = JCDeviceInfo();
     * deviceInfo.setDeviceId("<deviceId>");
     * sdkInstance.setDeviceInfo(deviceInfo);
     */
    setDeviceInfo(deviceInfo) {
        if (deviceInfo) {
            this.deviceInfo = deviceInfo;
            UserModel.getInstance().setPushToken(this.deviceInfo);
        }
    }

    /**
     * @desc
     * exitApp method shoul be mandatorily called while closing the application
     * @function exitApp
     * @param {CommonCallback} callback
     * @memberof JioChatSDK#
     */
    exitApp(callback){
        UserModel.getInstance().initDataIntoFile(callback)
    }

    getDeviceInfo() {
        return this.deviceInfo;
    }

    /**
     * Method will set all incoming messages and outgoing message events like delivered to party b. PartyB Typing etc.., 
     * @param {MessageCallback} msgCallback - Message Callback 
     * @memberof JioChatSDK#
     */
    setMessageCallback(msgCallback) {
        this.messageCallback = msgCallback;
    }

    /**
     * Method will return MessageCallback, if its set otherwise it will return null
     * @returns {MessageCallback} Message Callback, if its set
     * @memberof JioChatSDK#
     * @ignore 
     */
    getMessageCallback() {
        return this.messageCallback;
    }

    /**
     * 
     * @param {InComingHDCallback} callback
     * @memberof JioChatSDK# 
     * @ignore
     */
    setInComingHDCallback(callback) {
        RTMManager.getInstance().setInCallback(callback);
        this.hdInCallback = callback;
    }

    getInComingHDCallback(callback) {
        return this.hdInCallback;
    }
    /**
     * 
     * @param {*} callback 
     * @memberof JioChatSDK#
     * @ignore
     */
    setOutgoingHDCallback(callback) {
        RTMManager.getInstance().setCallback(callback);
        this.hdOutCallback = callback;
    }

    getOutgoingHDCallback(callback) {
        return this.hdOutCallback;
    }

    /**
     * 
     * @param {GroupNotificationCallback} callback 
     * @memberof JioChatSDK#
     * @ignore
     */
    setGroupNotificationCallback(callback) {
        this.grpNotificationCallback = callback;
    }

    /**
     * 
     * @returns callback 
     * @memberof JioChatSDK#
     * @ignore
     */
    getGroupNotificationCallback() {
        return this.grpNotificationCallback;
    }

    /**
     * Method will set offline message like sending offline, receiving offline messages.
     * @param {OfflineMessagesCallback} offlineMessagesCallback - Message Callback
     * @memberof JioChatSDK#
     */
    setOfflineMessagesCallback(offlineMessagesCallback) {
        this.offlineMessagesCallback = offlineMessagesCallback;
    }

    /**
     * Method will return offlineMessagesCallback, if its set otherwise it will return null
     * @returns {OfflineMessagesCallback} offlineMessagesCallback Callback, if its set
     * @memberof JioChatSDK#
     * @ignore
     */
    // getOfflineMessagesCallback() {
    //     return this.offlineMessagesCallback;
    // }

    /**
     * Method will set callback for file upload
     * @param {UploadCallback} callback - Callback
     * @memberof JioChatSDK#
     */
    setUploadCallback(callback) {
        this.getFileClient().setUploadCallback(callback);
    }

    /**
     * Method will return UploadCallback, if its set otherwise it will return null
     * @returns {UploadCallback} Callback, if its set
     * @memberof JioChatSDK# 
     * @ignore
     */
    getUploadCallback() {
        return this.getFileClient().getUploadCallback();
    }

    /**
     * Method will set callback for file download. 
     * @param {DownloadCallback} callback - Callback
     * @memberof JioChatSDK#
     */
    setDownloadCallback(callback) {
        this.getFileClient().setDownloadCallback(callback);
    }

    /**
     * Method will return DownloadCallback, if its set otherwise it will return null
     * @returns {DownloadCallback} Callback, if its set
     * @memberof JioChatSDK#
     * @ignore
     */
    getDownloadCallback() {
        return this.getFileClient().getDownloadCallback();
    }

    /**
     * Method will return user client,
     * @return JCUser
     * @memberof JioChatSDK#
     */
    getUserClient() {
        return JCUser.getInstance();
    }

    /**
     * Method will send auto logon request to the server and returns success or failure response as callbacks.
     * @function autoRegister
     * @param {JCSSO} ssoToken - 
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JioChatSDK#
     */
    autoRegister(ssoToken, callback) {
        if (this.isLoggedIn()) {
            this.getUserClient().getProfile(callback);
            return;
        }

        this.getUserClient().autoLogonUser(ssoToken, callback);
    }

    /**
     * Method will send register as new user request to the server and returns success or failure response as callbacks.
     * @function registerUser
     * @param {String} phoneNumber - This is user phone number(Jio number).
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JioChatSDK#
     */
    registerUser(phoneNumber, callback) {
        this.getUserClient().registerUser(phoneNumber, callback);
    }

    /**
     * Method will send get OTP request to the server and returns success or failure response as callbacks.
     * @function getOtpSMS
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JioChatSDK#
     */
    getOtpSMS(callback) {
        this.getUserClient().getOtpSMS(callback);
    }

    /**
     * Method will send verify OTP request to the server and returns success or failure response as callbacks.
     * @function verifyOtp
     * @param {string} otp - This is otp number entered by the user.
     * @param {JCUserProfileCallBack} callback - success or failure callbacks in return.
     * @memberof JioChatSDK#
     */
    verifyOtp(otp, callback) {
        this.getUserClient().verifyOtp(otp, {
            onSuccess: function(profile){
                var sdk = JioChatSDK.getInstance();
                sdk.profileReq(profile);
            },
            onError: function(errror){
                callback.onError(errror);
            }
        });
    }

    /**
     * Method will send reload(get new) OTP request to the server and returns success or failure response as callbacks.
     * @function getNewCaptcha
     * @param {Number} captchaKey - This is captcha key.
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JioChatSDK#
     */
    getNewCaptcha(key, callback) {
        this.getUserClient().getNewCaptcha(key, callback);
    }

    /**
     * Method will send validate OTP request to the server and returns success or failure response as callbacks.
     * @function validateCaptcha
     * @param {String} captchaText - This is captcha text entered by the user.
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JioChatSDK#
     */
    validateCaptcha(captchaText, callback) {
        this.getUserClient().validateCaptcha(captchaText, callback);
    }

    /**
     * Method will return an instance of JCMessageClient, using this class, you perform message related operations.
     * @function getMessageClient
     * @memberof JioChatSDK#
     * @return {JCMessageClient} instance
     */
    getMessageClient() {
        return JCMessageClient.getInstance();
    }


    /**
     * Method will return an instance of JCStickersClient, using this class, you perform Sticker related operations.
     * @function getStickersClient
     * @memberof JioChatSDK#
     * @return {JCStickersClient} instance
     * @ignore
     */
    getStickersClient() {
        return JCStickersClient.getInstance();
    }

    /**
     * Method will return an instance of JioContactsClient, using this object you can device and jio contact related operations.
     * @function getContactsClient
     * @memberof JioChatSDK#
     * @return {JioContactsClient} instance
     */
    getContactsClient() {
        return JioContactsClient.getInstance();
    }


    /**
     * Method will return true if user logged in OR register via auto logon OR manual registration Otherwise return false.
     * @function isLoggedIn
     * @memberof JioChatSDK#
     * @return {Boolean}
     */
    isLoggedIn() {
        return JIOSDKUtils.isLoggedIn();
    }

    /**
     * Method will set the SDK mode. By defalut app is in release mode, If you want to convert project as debug mode then please set JCSDKConstants.SDK_DEBUG_MODE. 
     * This method will accepts only two values, JCSDKConstants.SDK_DEBUG_MODE and JCSDKConstants.SDK_RELEASE_MODE.
     * @param {JCSDKConstants.SDK_RELEASE_MODE | JCSDKConstants.SDK_DEBUG_MODE} sdkMode - sdk mode
     * @memberof JioChatSDK#
     */
    setSDKMode(sdkMode) {
        this.sdkMode = sdkMode;
        // switch(sdkMode){
        //     case 
        // }
    }

    /**
     * Method will set the SDK Enviornment mode. By defalut app is in Production mode. 
     * This method will accepts 4 values, JCSDKConstants.SDK_ENVIORNMENT_PROD, JCSDKConstants.SDK_ENVIORNMENT_PREPROD
     * JCSDKConstants.SDK_ENVIORNMENT_IOT and JCSDKConstants.SDK_ENVIORNMENT_REPLICA .
     * @param {JCSDKConstants.SDK_ENVIORNMENT_PROD | JCSDKConstants.SDK_ENVIORNMENT_PREPROD | JCSDKConstants.SDK_ENVIORNMENT_IOT | JCSDKConstants.SDK_ENVIORNMENT_REPLICA} enviornmentMode - enviornment mode
     * @memberof JioChatSDK#
     */
    setSDKEnviornment(enviornmentMode) {
        switch (enviornmentMode) {
            case JCSDKConstants.SDK_ENVIORNMENT_PROD:
                HTTPRequestConts.setProduction();
                break;

            case JCSDKConstants.SDK_ENVIORNMENT_PREPROD:
                HTTPRequestConts.setPreProduction();
                break;

            case JCSDKConstants.SDK_ENVIORNMENT_IOT:
                HTTPRequestConts.setIOT();
                break;

            case JCSDKConstants.SDK_ENVIORNMENT_REPLICA:
                HTTPRequestConts.setReplica();
                break;
        }
    }


    /**
     * Method will return current SDK mode. By default SDK mode is release.
     * @return {JCSDKConstants.SDK_RELEASE_MODE | JCSDKConstants.SDK_DEBUG_MODE} sdkMode - sdk mode
     * @memberof JioChatSDK#
     */
    getSDKMode() {
        return this.sdkMode;
    }


    /** 
     * Method will return call client,
     * @return JCCall
     * @memberof JioChatSDK#
     */
    getCallClient() {
        return JCCall.getInstance();
    }

    /**
     * Method will return an instance of JCChannelsClient, using this class, you perform channels related operations.
     * @function getChannelsClient
     * @memberof JioChatSDK#
     * @return {JCChannelsClient} instance
     */
    getChannelsClient() {
        return JCChannelsClient.getInstance();
    }

    initLogger() {
        this.logger = function () {
            var oldConsole = null;
            var pub = {};

            pub.enableLogger = function enableLogger() {
                if (oldConsole == null)
                    return;
                window['console']['log'] = oldConsole.log;
                window['console']['info'] = oldConsole.info;
                // window['console']['warn'] = oldConsole.warn;                                                                      
            };

            pub.disableLogger = function disableLogger() {
                oldConsole = console;
                window['console']['log'] = function () {};
                window['console']['info'] = function () {};
                // window['console']['warn'] = function() {};                                    
            };
            return pub;
        }();
    }

    showLogger() {
        if (!this.logger) {
            this.initLogger();
        }
        logger.enableLogger();
    }

    isDeviceMode() {
        var sdkMode = this.getSDKMode();
        return sdkMode == JCSDKConstants.SDK_RELEASE_MODE || sdkMode == JCSDKConstants.SDK_PREPROD_RELEASE_MODE;
    }

    isProd() {
        var sdkMode = this.getSDKMode();
        return sdkMode == JCSDKConstants.SDK_RELEASE_MODE || sdkMode == JCSDKConstants.SDK_DEBUG_MODE;
    }

    isSDKMode() {
        // return JCSDKConstants.SDK_DISABLED_MODE;//Testing
        // return JCSDKConstants.SDK_ENABLED_MODE;//Testing
        return this.sdkEnableMode;
    }

    setEnableSDKMode(mode) {
        this.sdkEnableMode = mode;
    }

    /**
     * Method will return an instance of JCFileClient, using this object you can do file upload & download operations
     * @function getFileClient
     * @memberof JioChatSDK#
     * @return {JCFileClient} instance
     */
    getFileClient() {
        return JCFileClient.getInstance();
    }

    setUpdatesAvailableOnMessages(callback) {
        this.updatesAvailableOnMessagesCallback = callback;
    }

    getUpdatesAvailableOnMessages() {
        return this.updatesAvailableOnMessagesCallback;
    }
    /**
     * Method will return an instance of JCExploreClient, using this class, you perform channels related operations.
     * @function getExploreClient
     * @memberof JioChatSDK#
     * @return {JCExploreClient} instance
     */
    getExploreClient() {
        return JCExploreClient.getInstance();
    }

    setOtherCallbacks(callback) {
        this.otherCallbacks = callback;
    }

    getOtherCallbacks() {
        return this.otherCallbacks;
    }

    setSDKCapability(capability) {
        var settings = new JCSettings();
        settings.init(capability);
        this.settings = settings;
        if (capability === AppMode.APP_TYPE_JVC || capability === AppMode.APP_TYPE_JC ||
            capability === AppMode.APP_TYPE_JCL || capability === AppMode.APP_TYPE_JMS || capability === AppMode.APP_TYPE_DESKTOP || capability === AppMode.APP_TYPE_MOBILE || capability === AppMode.APP_TYPE_TIZEN) {
            this.setEnableSDKMode(JCSDKConstants.SDK_DISABLED_MODE);
        } else if (capability === AppMode.APP_TYPE_JSDK) {
            this.setEnableSDKMode(JCSDKConstants.SDK_ENABLED_MODE);
        }
    }

    setSettings(settings) {
        this.settings = settings;
    }

    getSettings() {
        return this.settings;
    }

    /**
     * Method will return an instance of JioGroupClient, using this class, you perform message related operations.
     * @function getMessageClient
     * @memberof JioChatSDK#
     * @return {JioGroupClient} instance
     */
    getGroupClient() {
        return JCGroupClient.getInstance();
    }

    getDeviceUtility() {
        return JCDeviceUtility.getInstance();
    }

    setMessageLocalCallback(callback){
        this.messageLocalCallback = callback;
    }

    getMessageLocalCallback(){
        return this.messageLocalCallback;
    }

    callProfileAPI(){
        var instance = UserModel.getInstance();
        if(!instance) return;

        var userId = String(instance.getUserID());
        if(instance && userId && userId != ""){
            // Call the Own Profile API to connect websocket
            JioChatSDK.getInstance().getUserClient().getProfile({
                onSuccess:function(data){
                    console.log("Own Profile API is success. Hopefully websocket will be connected");
                },
                onError:function(err){
                    console.log("Own Profile API Error");
                }
            });   
        }
    }

}
/**
 * Method will retutn an instance of JioChatSDK class. You should not create class object directly.
 * @return JioChatSDK class ref.
 * @example
 * var sdk = JioChatSDK.getInstance();
 * sdk.setMessageCallback({});
 */
JioChatSDK.getInstance = function () {
    if (!JioChatSDK.instance) {
        JioChatSDK.instance = new JioChatSDK();
        JioChatSDK.instance.start();
    }
    return JioChatSDK.instance;
}
window.JioChatSDK = JioChatSDK;