/**
 * @interface JCSDKConstants
 * @classdesc
 * This interface will represents SDK constants.
 * 
 */
function JCSDKConstants(){

}
/**
 * Const to define SDK as debug. This will represents on device false and sdk will point to prod server.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_DEBUG_MODE = -1;
/**
 * Const to define SDK as true. This will represents on device true and sdk will point to prod server.
 * @memberof JCSDKConstants
 */
JCSDKConstants.SDK_RELEASE_MODE = 1;


/**
 * Const to define SDK as debug. This will represents on device false will point prepod server.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_PREPROD_DEBUG_MODE = -2;


/**
 * Const to define SDK as debug. This will represents on device true will point to preprod server.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_PREPROD_RELEASE_MODE = 2;

/**
 * Const to define SDK as debug. This will represents on device true will point to preprod server.
 * @memberof JCSDKConstants
 * @ignore
 * 
 */
JCSDKConstants.SDK_DISABLED_MODE = -3;

/**
 * Const to define SDK as debug. This will represents on device true will point to preprod server.
 * @memberof JCSDKConstants
 * @ignore
 * 
 */
JCSDKConstants.SDK_ENABLED_MODE = 3;

/**
 * Const to define SDK enviornment as Production.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_ENVIORNMENT_PROD = 9;

/**
 * Const to define SDK enviornment as Pre-Production.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_ENVIORNMENT_PREPROD = 8;

/**
 * Const to define SDK enviornment as IOT.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_ENVIORNMENT_IOT = 7;

/**
 * Const to define SDK enviornment as Replica.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_ENVIORNMENT_REPLICA = 6;


/**
 * Const to define SDK APP TYPE as as JC.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_APP_TYPE_JVC = 1;//APP_TYPE_JVC

/**
 * Const to define SDK APP TYPE as as JCL.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_APP_TYPE_JCL = 2;//APP_TYPE_JCL


/**
 * Const to define SDK APP TYPE as as JMS.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_APP_TYPE_JMS = 3;//APP_TYPE_JMS

/**
 * Const to define SDK APP TYPE as as JC.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_APP_TYPE_JC = 2;//APP_TYPE_JC

/**
 * Const to define SDK APP TYPE as as SDK.
 * @memberof JCSDKConstants
 * 
 */
JCSDKConstants.SDK_APP_TYPE_SDK = 3;//APP_TYPE_JSDK

JCSDKConstants.SDK_APP_TYPE_DESKTOP = 5;//APP_TYPE_DESKTOP