import BaseModule from '../lib/base-module';
import JIOSDKUtils from './base-jc-user.js';
import ChannelsStore from '../data/channels-store.js';
// import ChatListStore from '../data/chatlist-store.js';
// import MessageStore from '../data/message-store.js';
// import GroupListStore from '../data/groupList-store.js';
// import SettingsStore from '../data/setting-store.js';

/**
 * @classdesc
 * JCChannelsClient is a singleton class which will do all channels operations, fetch recent channels, focused channels, recommended channels, follow & unfollow, etc.,
 * 
 * @class JCChannelsClient
 */
export default class JCChannelsClient extends BaseModule {
    start(){
        // this.chatInstance = ChatListStore.getInstance();
		// this.msgInstance = MessageStore.getInstance();
		// this.groupListInstance = GroupListStore.getInstance();
		// this.settingInstance = SettingsStore.getInstance();
        this.channelInstance = ChannelsStore.getInstance();
    }

    /**
	 * Method for getting all recent channels.
	 * @param {RecentChannelsCallback} callback - success/error callback once we get response
	 * @memberof JCChannelsClient#
	 */
	getRecentChannels(callback){
		this.channelInstance.getRecentChannels(AppConstants.PAGE_TYPE_CHAT_VIEW, callback);
	}

    /**
	 * Method for getting all followed channels.
	 * @param {FollowedChannelsCallback} callback - success/error callback once we get response
	 * @memberof JCChannelsClient#
	 */
	getFollowedChannels(callback){
		this.channelInstance.getRecentChannels(AppConstants.PTYPE_CONTACTS_VIEW, callback);
	}

	/**
	 * Method for getting all recommended channels.
	 * @param {object} callback - {onChannelsReceived: (channels)=>{},onChannelUpdate: (channelInfo)=>{},onError: (err)=>{}} callback once we get response
	 * @memberof JCChannelsClient#
	 */
	getRecommendedChannels(callback){
		this.channelInstance.getChannelsFromLDB(callback);
	}
	
	/**
	 * Method for getting more recommended channels.
	 * @param {object} callback- {onChannelsReceived: (channels)=>{},onChannelUpdate: (channelInfo)=>{},onError: (err)=>{}} callback once we get response
	 * @memberof JCChannelsClient#
	 */
	loadMoreRecommendedChannels(callback){
		this.channelInstance.loadMoreRecommendedChannel(callback);
	}

	/**
	 * Method for getting recommended channel detail.
	 * @param {object} callback - {onChannelsReceived: (channelList,totalCount,nextindex,noRecord,endResult)=>{},
	 * 								onChannelUpdate: (channelList,totalCount,nextindex,noRecord,endResult)=>{},
	 * 									onError: (err)=>{}} callback once we get response
	 * @param {String} searchText - pass the text to be searched as channel name
	 * @memberof JCChannelsClient#
	 */
	searchChannel(searchText,callback){
		this.channelInstance.searchChannelAPICall(searchText,callback);
	}

	/**
	 * Method for getting more search channels.
	 * @param {object} callback - {onChannelsReceived: (channelList,totalCount,nextindex,noRecord,endResult)=>{},
	 * 								onChannelUpdate: (channelList,totalCount,nextindex,noRecord,endResult)=>{},
     * 								onError: (err)=>{}} callback once we get response
	 * @param {integer} startIndex - nextindex from search channel function
	 * @param {integer} count	- number of channel you want to get 
	 * @param {string} searchText - privious text , you sent in search function
	 * @memberof JCChannelsClient#
	 */
	loadMoreSearchChannel(startIndex,count,searchText,callback){
		this.channelInstance.loadMoreSearchChannel(startIndex,count,searchText,callback);
	}
	
	/**
	 * Method for getting recommended channel detail.
	 * @param {object} callback - {onSuccess: (channelDetail)=>{},onError: (err)=>{}} callback once we get response
	 * @param {String} channelId - pass the channel id from channel list
	 * @memberof JCChannelsClient#
	 */
	getRecommendedChannelDetail(channelId,callback){
		this.channelInstance.getChannelDataFromLDB(channelId,callback);
	}

	/**
	 * Method for getting recommended channel detail.
	 * @param {object} callback - {onSuccess: (channelDetail)=>{},onError: (err)=>{}} callback once we get response
	 * @memberof JCChannelsClient#
	 */
	getSearchedChannelDetail(callback){
		this.channelInstance.getSearchedChannelDetailMap(callback);
	}

	/**
	 * Method for getting recommended channel detail.
	 * @param {object} callback - {onSuccess: (channelDetail)=>{},onError: (err)=>{}} callback once we get response
	 * @param {String} channelId - pass the channel id from channel list
	 * @memberof JCChannelsClient#
	 */
	getFocusChannelDetail(channelId,callback){
		this.channelInstance.getFocusChannelDataFromLDB(channelId,callback);
	}

	/**
	 * Method for getting recommended channel detail.
	 * @param {object} callback - {onSuccess: (true)=>{},onError: (err)=>{}} callback once we get response
	 * @param {object} channel - pass the current channel object
	 * @param {boolean} checkboxStatus - true/false true-to check and false-to uncheck
	 * @memberof JCChannelsClient#
	 */
	checkUncheckReceiveMessage(channel,checkboxStatus,callback){
		this.channelInstance.recieveChannelMessageApi(channel,checkboxStatus,callback);
	}

	/**
	 * Method for getting menu list of current channel.
	 * @param {object} callback - {onSuccess: (channelMenu)=>{},onError: (err)=>{}} callback once we get response
	 * @param {object} channel - pass the current channel object
	 * @memberof JCChannelsClient#
	 */
	getChannelMenuList(channel,callback){
		this.channelInstance.callMenuListAPI(channel,callback);
	}

	/**
	 * Method for follow or unfollow current channel.
	 * @param {object} callback - {onSuccess: (updatedChannel)=>{},onError: (err)=>{}} callback once we get response
	 * @param {object} channel - pass the current channel object
	 * @param {integer} followunfollow - pass the followUnfollow data 0 for follow or -1 for unfollow  channel 
	 * @memberof JCChannelsClient#
	 */
	followUnfollowChannel(channel,followunfollow,callback){
		this.channelInstance.followUnfollowChannelApi(channel,followunfollow,callback);
	}

	/**
	 * Method for getting public message for current menu/submenu.
	 * @param {object} callback - {onSuccess: (true)=>{},onError: (false)=>{}} callback once we get response
	 * @param {object} subMenuData - pass the current submenu/menu object
	 * @memberof JCChannelsClient#
	 */
	getPublicMenuMessage(subMenuData,callback){
		this.channelInstance.getPublicMenuMessage(subMenuData,callback);
	}
	getFocusChannelOfflineMessage(followChannelList,callback){
		this.channelInstance.getFocusChannelOfflineMessage(channelListArray,callback);
	}
	
	/**
	 * Method for getting more search channels.
	 * @param {object} callback - {onChannelsReceived:[] ,
	 * 								onChannelUpdate: (updatedInfo)=>{},
 	 * @memberof JCChannelsClient#
	 */
	updateFocusChannelOnUpdateAvailable(callback){
		this.channelInstance.updateFocusChannelOnUpdateAvailable(callback);
	}
}

/**
 * Method will retutn an instance of JCChannelsClient class. You should not create class object directly.
 * @return JCChannelsClient class ref.
 * @example
 * var channelsClient = JCChannelsClient.getInstance();
 * channelsClient.getRecentChannels(callback);
 */
JCChannelsClient.getInstance = function(){
    if( !JCChannelsClient.instance) {
        JCChannelsClient.instance = new JCChannelsClient();
		JCChannelsClient.instance.start();
    }
    return JCChannelsClient.instance;
}
