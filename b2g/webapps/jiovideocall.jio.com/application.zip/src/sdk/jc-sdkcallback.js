/**
 * @interface LifeCycleCallback
 * @desc
 * LifeCycleCallback is an anonymous interface.
 * These are the lifeCycle events trriggered by SDK during launch. 
 */
var LifeCycleCallback = {
    /**
     * Method will be triggered when device info is required by SDK 
     * @function onReqDeviceInfo
     * @callback LifeCycleCallback~onReqDeviceInfo
     * @param {RequestDeviceInfoCallback} requestDeviceInfoCallback - contains the RequestDeviceInfoCallback
     * @memberof LifeCycleCallback
     */
    onReqDeviceInfo:function(requestDeviceInfoCallback){
        
    },

    /**
     * Method will be triggered when push object is required by SDK to enable push
     * @function onReqPush
     * @callback LifeCycleCallback~onReqPush
     * @param {RequestPushCallback} requestPushCallback - contains RequestPushCallback, It is sent from SDK side.
     * @memberof LifeCycleCallback
     */
    onReqPush: function(requestPushCallback){

    },

    /**
     * Method will be triggered when sso Token is required by SDK for login
     * @function onReqSSOToken
     * @callback LifeCycleCallback~onReqSSOToken
     * @param {RequestSSOTokenCallback} requestSSOTokenCallback - contains requestSSOTokenCallback, This callback is sent by SDK. provide SSO token to onSuccess of RequestSSOTokenCallback
     * @memberof LifeCycleCallback
     */
    onReqSSOToken: function(requestSSOTokenCallback){

    },

    /**
     * Method will be triggered when User profile is received.
     * @function onProfile
     * @callback LifeCycleCallback~onProfile
     * @param {Object} profile - contains the error information like errorMsg, errorCode
     * @param profile.name - name of the user
     * @param profile.gender - gender of the user 0-female , 1-male, 2-unknown
	 * @param profile.mood - Mood of the user
	 * @param profile.expression - Expression of the user
	 * @param profile.userId - User id for the user
     * @param profile.version - version of the user profile
     * @param profile.isOnline - online status of the user
     * @param profile.mobileNo - mobile number of the user.
     * @param profile.portraitId - id of Profile Picture.
     * @param profile.pictureSize - size of profile picture
     * @param profile.thumbData - profile picture of the user.
     * @memberof LifeCycleCallback
     */
    onProfile: function(profile){

    },
    /**
     * Method will be triggered when launching process from SDK is completed.Now other procedures can be carried out.
     * @function onStart
     * @callback LifeCycleCallback~onStart
     * @memberof LifeCycleCallback
     */
    onStart: function(){

    },
    /**
     * Method will be triggered when message gets failed.
     * @function onExit
     * @ignore 
     * @callback LifeCycleCallback~onExit
     * @memberof LifeCycleCallback
     */
    onExit: function(){

    },
    /**
     * Method will be triggered when SDK lifeCycle will encounter error
     * @function onError
     * @callback LifeCycleCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof LifeCycleCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface RequestDeviceInfoCallback
 * @desc
 * RequestDeviceInfoCallback is an anonymous interface will be provide to LifeCycleCallback~onReqDeviceInfo
 * Provide the JCDeviceInfo to the onSuccess method of this event to proceed.
 */
 var RequestDeviceInfoCallback = {
    /**
     * Provide JCDeviceInfo object to this callback, this JCDeviceInfo is required for login.
     * @function onSuccess
     * @callback RequestDeviceInfoCallback~onSuccess
     * @param {JCDeviceInfo} jcDeviceInfo - JCDeviceInfo object
     * @memberof RequestDeviceInfoCallback
     */ 
    onSuccess : function(jcDeviceInfo){

     },
    /**
     * if you are unable to get jcDeviceInfo trigger this method.
     * @function onError
     * @callback RequestDeviceInfoCallback~onError
     * @memberof RequestDeviceInfoCallback
     */
    onError : function(){

    }
 }


 /**
 * @interface RequestPushCallback
 * @desc
 * RequestPushCallback is an anonymous interface.
 * It will sent by SDK whenever SDK requires push Object information to enable push notification from server.
 */
 var RequestPushCallback = {
    /**
     * Provide push object to this callback to enable push notificato from server.
     * @function onSuccess
     * @callback RequestPushCallback~onSuccess
     * @param {JCPush} pushTokenObject - pushToken object received from initializePush() of jioChatSDk
     * @memberof RequestPushCallback
     */ 
    onSuccess : function(pushTokenObject){

     },
    /**
     * If you are unable to get push object,trigger onError of RequestPushCallback callback
     * @function onError
     * @callback RequestPushCallback~onError
     * @memberof RequestPushCallback
     */
    onError : function(){

    }
 }

 /**
 * @interface RequestSSOTokenCallback
 * @desc
 * RequestSSOTokenCallback is an anonymous interface.
 * This will be sent by SDK to onReqSSOToken event
 * Provide SSO token to onSuccess of RequestSSOTokenCallback to proceed with login.
 */
 var RequestSSOTokenCallback = {
    /**
     * Trigger this method once you receive and create jcSSO object
     * Provide jcSSO object to this callback.
     * @function onSuccess
     * @callback RequestSSOTokenCallback~onSuccess
     * @param {JCSSO} jcSSO - JCSSO object.
     * @memberof RequestSSOTokenCallback
     */ 
    onSuccess : function(jcSSO){

    },
    /**
     * trigger this method when you are unable to get SSO Token.
     * @function onError
     * @callback RequestSSOTokenCallback~onError
     * @memberof RequestSSOTokenCallback
     */
    onError : function(){

    }
 }

 /**
 * @interface CommonCallback
 * @desc
 *A common callback to get success or failure status.
 */
 var CommonCallback = {
    /**
     * Method will triggered on Success of operation
     * @function onSuccess
     * @callback CommonCallback~onSuccess
     * @memberof CommonCallback
     */ 
    onSuccess : function(){

    },
    /**
     * Method will triggered on encountering error
     * @function onError
     * @callback CommonCallback~onError
     * @memberof CommonCallback
     */
    onError : function(){

    }
 }

 /**
 * @interface CommonResponseCallback
 * @desc
 *A common callback to get success response or failure response.
 */
 var CommonResponseCallback = {
    /**
     * Method will triggered on Success of operation
     * @function onSuccess
     * @callback CommonResponseCallback~onSuccess
     * @param {Object} response - response object
     * @memberof CommonResponseCallback
     */ 
    onSuccess : function(response){

    },
    /**
     * Method will triggered on encountering error
     * @function onError
     * @callback CommonResponseCallback~onError
     * @memberof CommonResponseCallback
     */
    onError : function(error){

    }
 }

/**
 * @interface SDKNotificationCallback
 * @desc
 *A notification callback for force logout
 * currently only logout event notification will be received.
 * In future may contain more notification.
 */
var SDKNotificationCallback = {
    /**
     * Method will triggered when force logout occured
     * @function onLogout
     * @callback SDKNotificationCallback~onLogout
     * @memberof SDKNotificationCallback
     */ 
    onLogout : function(){

    }
 }
 