/**
 * @interface RecentChatCallback
 * @desc
 * RecentChatCallback is an anonymous interface will get invoked when we get messages from LDB
 */
var RecentChatCallback = {
    /**
     * Method will be triggered for getting recent chat
     * @function onSuccess
     * @callback RecentChatCallback~onSuccess
     * @param {Map<String,JCChat>} chats - contains the map if chat conversation exists else empty array will be returned. Here key will be sessionId & value will be the JCChat object.
     * @memberof RecentChatCallback
     */
    
    /**
     * Method will be triggered when no recent chat.
     * @function onError
     * @callback RecentChatCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof RecentChatCallback
     */
};
