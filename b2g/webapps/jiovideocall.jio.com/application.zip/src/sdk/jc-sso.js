/**
* Class holds information related to SSO token.
* @class JCSSO
*/
function JCSSO(){
	this.phoneNumber = null;
	this.name = null;
	this.token = null;
	this.lbCookie = null;
}
JCSSO.prototype = {
	/**
	 * Method will set phone number. Phone number should contains country code.
	 * @param  {string} - phoneNumber
	 * @memberof JCSSO#
	 */
	setPhoneNumber: function(phoneNumber) {
		this.phoneNumber = phoneNumber;

		/** mushtaq added this code since there is no any other way to do this for JC sdk. 
			Because integration team won't accept to call this method.

			It is required to update phone number in LDB(Key for User LDB)
		*/
		OnboardingModel.getInstance().setUserPhoneNo(this.phoneNumber);
		
		var daoData = {
            mobileNumber: phoneNumber
		};
		ActiveUser.getInstance().addByDataToLDB(daoData, function(success) {
            if (success) {
                console.log('[JC SSO] Add Phone number LDB success ');
            } else {
                console.log('[JC SSO] Add Phone number LDB failure ');
            }        
        });    
		// OnboardingStore.getInstance().addPhonenumberLDB(this.phoneNumber, function(success){
		// 	console.log('[JC SSO] Phone no. added in LDB.');
		// 	// no action required
		// });
	},
	/**
	*
	* Method will set phonenumber if its set ,otherwise it will return null.
	* @return  {String} - phonenumber, if its set
	* @memberof JCSSO#
	* 
	*/
	getPhoneNumber: function(){
		return this.phoneNumber;
	},
	/**
	* Method will set user name, which is return by SSO Engine.
	* @param  {string} username
	* @memberof JCSSO#
	* 
	*/
	setName: function(name){
		this.name = name;
	},
	/**
	* Method will return user name if its set, otherwise it will return null.
	* @return  {string} user name, if its set
	* @memberof JCSSO#
	* 
	*/
	getName:function(){
		return this.name;
	},

	/**
	* Method will set sso token. Please don't modify token.
	* @param  {string} token - sso token
	* @memberof JCSSO#
	* 
	*/
	setToken:function(token){
		this.token = token;
	},
	/**
	* Method will get sso token.
	* @param  {string} token - sso token
	* @memberof JCSSO#
	* 
	*/
	getToken:function(){
		return this.token;
	},
	/**
	* Method will set lb cookie. Please don't modify cookie.
	* @param  {string} cookie - cookie
	* @memberof JCSSO#
	* 
	*/
	setlbCookie: function(lbCookie){
		this.lbCookie = lbCookie;
	},
	/**
	* Method will get cookie.
	* @param  {string} cookie - cookie
	* @memberof JCSSO#
	*/
	getlbCookie: function(){
		return this.lbCookie;
	}
}

// JCSSO.prototype.setName = function(name){
// 	this.name = name;
// }

// JCSSO.prototype.getName = function(){
// 	return this.name;
// }

// JCSSO.prototype.setToken = function(token){
// 	this.token = token;
// }

// JCSSO.prototype.getToken = function(){
// 	return this.token;
// }


// JCSSO.prototype.setlbCookie = function(lbCookie){
// 	this.lbCookie = lbCookie;
// }


// JCSSO.prototype.getlbCookie = function(){
// 	return this.lbCookie;
// }

JCSSO.getJCSSOObject = function(successResponse){
	var phoneNumber = '+'+ successResponse.KEY_MSISDN;

	var ssoToken = new JCSSO();
	ssoToken.setPhoneNumber(phoneNumber);
	// ssoToken.setName(successResponse.KEY_USER_ATTRIBUTES.user.commonName);
	ssoToken.setName(successResponse.KEY_USER.commonName);
    ssoToken.setToken(successResponse.KEY_SSO_TOKEN);
	ssoToken.setlbCookie(successResponse.KEY_LB_COOKIE);
	console.log('[JS-SSO] ssoToken object '+ JSON.stringify(ssoToken));
	
    return ssoToken;
}