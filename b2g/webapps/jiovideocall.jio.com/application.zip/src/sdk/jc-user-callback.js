/**
 * JCCommonUserCallBack 
 * @interface JCCommonUserCallBack
 */
var JCCommonUserCallBack = {
    /**
     * Method will be triggered once the server responds success. 
     * @callback JCCommonUserCallBack~onSuccess
     * @memberof JCCommonUserCallBack
     */
     onSuccess:function(){

     },

    /**
     * Method will be triggered once the server responds error.
     * @function onError
     * @callback JCCommonUserCallBack~onError
     * @param {Error} error - Error response from server.
     * @memberof JCCommonUserCallBack
     */
     onError:function(error){
        
     }

}

/**
 * AutoLogonCallback 
 * @interface AutoLogonCallback
 */
var AutoLogonCallback = {
    /**
     * Method will be triggered once the server responds success for auto logon api call. 
     * @callback AutoLogonCallback~onSuccess
     * @param {Object} response - Success response from server.
     * @memberof AutoLogonCallback
     */
     onSuccess:function(response){

     },

    /**
     * Method will be triggered once the server responds error for auto logon api call.
     * @function onError
     * @callback AutoLogonCallback~onError
     * @param {Error} error - Error response from server.
     * @memberof AutoLogonCallback
     */
     onError:function(error){
        
     }
}


/**
 * JCCommonUserCallBack 
 * @interface JCUserProfileCallBack
 */
var JCUserProfileCallBack = {
    /**
     * Method will be triggered once the server responds success for profile api call. 
     * @callback JCUserProfileCallBack~onSuccess
     * @param {Object} response - Success response from server.
     * @memberof JCUserProfileCallBack
     */
     onSuccess:function(response){

     },

    /**
     * Method will be triggered once the server responds error for profile api call.
     * @function onError
     * @callback JCUserProfileCallBack~onError
     * @param {Error} error - Error response from server.
     * @memberof JCUserProfileCallBack
     */
     onError:function(error){
        
     }

}

/**
 * JCUserDownloadPortraitCallBack 
 * @interface JCUserDownloadPortraitCallBack
 */
var JCUserDownloadPortraitCallBack = {
    /**
     * Method will be triggered once the server responds success for download portrait api call. 
     * @callback JCUserDownloadPortraitCallBack~onSuccess
     * @param {Object} portraits - Success response from server.
     * @memberof JCUserDownloadPortraitCallBack
     */
     onSuccess:function(portraits){

     },

    /**
     * Method will be triggered once the server responds error for download portrait api call.
     * @function onError
     * @callback JCUserDownloadPortraitCallBack~onError
     * @param {Error} error - Error response from server.
     * @memberof JCUserDownloadPortraitCallBack
     */
     onError:function(error){
        
     }

}

/**
 * JCUserCameraPictureCallBack 
 * @interface JCUserCameraPictureCallBack
 */
var JCUserCameraPictureCallBack = {
    /**
     * Method will be triggered once the server responds success. 
     * @callback JCUserCameraPictureCallBack~onSuccess
     * @param {Object} image - Success response from server.
     * @memberof JCUserCameraPictureCallBack
     */
     onSuccess:function(portraits){

     },

    /**
     * Method will be triggered once the server responds error.
     * @function onError
     * @callback JCUserCameraPictureCallBack~onError
     * @param {Error} error - Error response from server.
     * @memberof JCUserCameraPictureCallBack
     */
     onError:function(error){
        
     }

}
