/**
 * Class is for JCExplore information.
 * @class
 */
function JCExplore(){
    this.channelId = "";
    this.channelProfileVersion = "";
    this.channelContentVersion = "";
    this.channelSerialNumber = "";
    this.channelName = "";
    this.channelShareFlag = "";
    this.channelIntroVideoId = "";
    this.channelShareImageFlag = "";
    this.channelShareIconFlag = "";
    this.channelTransitionVideoId = "" ;
    this.channelEndVideoId = "";
    this.channelRedCode = "";
    this.channelGreenCode = "";
    this.channelBlueCode = "";
    this.channelLogoURL = "";
    this.channelContentSummaryInfo = "";
    this.channelIsRedDot = "";
}

JCExplore.prototype = {
    

    init: function(exploreObj){
        this.channelId = String(exploreObj.channelID);
        this.channelProfileVersion =exploreObj.serChProfileVer;
        this.channelName =exploreObj.channelName;
        this.channelShareFlag =exploreObj.shareFlag;
        this.channelIntroVideoId =exploreObj.introduceVideoID;
        this.channelShareImageFlag = exploreObj.shareImageFlag;
        this.channelShareIconFlag = exploreObj.shareIconFlag;
        this.channelTransitionVideoId = exploreObj.transitionVideoID;
        this.channelEndVideoId = exploreObj.endVideoID;
        this.channelRedCode = exploreObj.redCode;
        this.channelGreenCode = exploreObj.greenCode;
        this.channelBlueCode = exploreObj.blueCode;
        this.channelLogoURL = exploreObj.channelLogoUrl;
        this.channelContentSummaryInfo = exploreObj.channelSumm;
        this.channelIsRedDot = exploreObj.isRedDot;
    },
    
    getColorCode:function() {
        var red = this.convertToHex(this.channelRedCode);
        var green = this.convertToHex(this.channelGreenCode);
        var blue = this.convertToHex(this.channelBlueCode);
        red = red.length < 2 ? "0" + red : red;
        green = green.length < 2 ? "0" + green : green;
        blue = blue.length < 2 ? "0" + blue : blue;
        var hex = "#" + red + green + blue;
        return hex;
    },

    // Convert to Hex
    convertToHex:function(num) {
        // Hex can store 16 different values in 1 character
        if (num == null) return "00";
        num = num.length < 2 ? "0" + num : num
        return num.toString(16);
    },

    /**
     * Method will set the channelId. 
     * @param {String} channelId - contains the channelId of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelId: function(channelId) {
        this.channelId = channelId;
    },

    /**
     * Method will get the channelId(exploreListChannel).
     * @return {String}
     * @memberof JCExplore#
     */

    getChannelId: function(){
        return this.channelId;
    },

    /**
     * Method will set the channelProfileVersion. 
     * @param {Number} channelProfileVersion - contains the channelProfileVersion of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelProfileVersion: function(channelProfileVersion){
        this.channelProfileVersion = channelProfileVersion;

    },

    /**
     * Method will get the channelProfileVersion(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */
    
    getChannelProfileVersion: function(){
        return this.channelProfileVersion;
    },

    /**
     * Method will set the channelContentVersion. 
     * @param {Number} channelContentVersion - contains the channelContentVersion of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelContentVersion: function(channelContentVersion){
        this.channelContentVersion = channelContentVersion;
    },

    /**
     * Method will get the channelContentVersion(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelContentVersion: function(){
        return this.channelContentVersion;
    },
    /**
     * Method will set the channelSerialNumber. 
     * @param {Number} channelContentVersion - contains the channelSerialNumber of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelSerialNumber: function(channelSerialNumber){
        this.channelSerialNumber = channelSerialNumber;
    },

    /**
     * Method will get the channelSerialNumber(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelSerialNumber: function(){
        return this.channelSerialNumber;
    },


    /**
     * Method will set the channelName. 
     * @param {String} channelName - contains the channelName of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelName:function(channelName){
        this.channelName = channelName;
    },

    /**
     * Method will get the channelName(exploreListChannel).
     * @return {String}
     * @memberof JCExplore#
     */

    getChannelName: function(){
        return this.channelName;
    },
    /**
     * Method will set the channelShareFlag.
     * @param {Boolean} channelShareFlag - contains the channelShareFlag of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelShareFlag:function(channelShareFlag){
        this.channelShareFlag = channelShareFlag;
    },
     /**
     * Method will get the channelShareFlag(exploreListChannel).
     * @return {Boolean}
     * @memberof JCExplore#
     */

    getChannelShareFlag: function(){
        return this.channelShareFlag;
    },

    /**
     * Method will set the channelIntroVideoId.
     * @param {Number} channelIntroVideoId - contains the channelIntroVideoId of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelIntroVideoId:function(channelIntroVideoId){
        this.channelIntroVideoId = channelIntroVideoId;
    },

    /**
     * Method will get the channelIntroVideoId(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelIntroVideoId: function(){
        return this.channelIntroVideoId;
    },
    /**
     * Method will set the channelShareImageFlag.
     * @param {Boolean} channelShareImageFlag - contains the channelShareImageFlag of exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelShareImageFlag:function(channelShareImageFlag){
        this.channelShareImageFlag = channelShareImageFlag;
    },

    /**
     * Method will get the channelShareImageFlag(exploreListChannel).
     * @return {Boolean}
     * @memberof JCExplore#
     */

    getChannelShareImageFlag: function(){
        return this.channelShareImageFlag;
    },

    /**
     * Method will set the channelShareIconFlag.
     * @param {Boolean} channelShareIconFlag - contains the channelShareIconFlag of exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelShareIconFlag:function(channelShareIconFlag){
        this.channelShareIconFlag = channelShareIconFlag;
    },

    /**
     * Method will get the channelShareIconFlag(exploreListChannel).
     * @return {Boolean}
     * @memberof JCExplore#
     */

    getChannelShareIconFlag: function(){
        return this.channelShareIconFlag;
    },

     /**
     * Method will set the channelTransitionVideoId.
     * @param {Number} channelTransitionVideoId - contains the channelTransitionVideoId of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelTransitionVideoId:function(channelTransitionVideoId){
        this.channelTransitionVideoId = channelTransitionVideoId;
    },

    /**
     * Method will get the channelTransitionVideoId(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelTransitionVideoId: function(){
        return this.channelTransitionVideoId;
    },

    /**
     * Method will set the channelEndVideoId.
     * @param {Number} channelEndVideoId - contains the channelEndVideoId of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelEndVideoId:function(channelEndVideoId){
        this.channelEndVideoId = channelEndVideoId;
    },

    /**
     * Method will get the channelEndVideoId(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelEndVideoId: function(){
        return this.channelEndVideoId;
    },

     /**
     * Method will set the channelRedCode.
     * @param {Number} channelRedCode - contains the channelRedCode of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelRedCode:function(channelRedCode){
        this.channelRedCode = channelRedCode;
    },

    /**
     * Method will get the channelRedCode(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelRedCode: function(){
        return this.channelRedCode;
    },

     /**
     * Method will set the channelGreenCode.
     * @param {Number} channelGreenCode - contains the channelGreenCode of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelGreenCode:function(channelGreenCode){
        this.channelGreenCode = channelGreenCode;
    },

     /**
     * Method will get the channelGreenCode(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getChannelGreenCode: function(){
        return this.channelGreenCode;
    },

    /**
     * Method will set the channelBlueCode.
     * @param {Number} channelBlueCode - contains the channelBlueCode of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelBlueCode:function(channelBlueCode){
        this.channelBlueCode = channelBlueCode;
    },

    /**
     * Method will get the channelBlueCode(exploreListChannel).
     * @return {Number}
     * @memberof JCExplore#
     */

    getchannelBlueCode: function(){
        return this.channelBlueCode;
    },
    
    /**
     * Method will set the channelLogoURL.
     * @param {String} channelLogoURL - contains the channelLogoURL of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */


    setChannelLogoURL:function(channelLogoURL){
        this.channelLogoURL = channelLogoURL;
    },

     /**
     * Method will get the channelLogoURL(exploreListChannel).
     * @return {String}
     * @memberof JCExplore#
     */

    getChannelLogoURL: function(){
        return this.channelLogoURL;
    },

    /**
     * Method will set the channelContentSummaryInfo.
     * @param {String} channelContentSummaryInfo - contains the channelContentSummaryInfo of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelContentSummaryInfo:function(channelContentSummaryInfo){
        this.channelContentSummaryInfo = channelContentSummaryInfo;
    },

    /**
     * Method will get the channelContentSummaryInfo(exploreListChannel).
     * @return {String}
     * @memberof JCExplore#
     */

    getChannelContentSummaryInfo: function(){
        return this.channelContentSummaryInfo;
    },

    /**
     * Method will set the channelIsRedDot.
     * @param {Boolean} channelIsRedDot - contains the channelIsRedDot of  exploreListChannel.
     * @memberof JCExplore#
     * @ignore
     */

    setChannelIsRedDot:function(channelIsRedDot){
        this.channelIsRedDot = channelIsRedDot;
    },

    /**
     * Method will get the channelIsRedDot(exploreListChannel).
     * @return {Boolean}
     * @memberof JCExplore#
     */

    getChannelIsRedDot: function() {
        return this.channelIsRedDot;
    }
}
