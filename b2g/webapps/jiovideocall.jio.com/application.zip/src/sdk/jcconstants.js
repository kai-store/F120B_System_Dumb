/**
 * @interface CINRequestConts
 * @classdesc
 * 
 */
var CINRequestConts = {
    /**
     * @member SESSIONSINGLE
     * @desc
     * For one to one chat.
     * @memberof CINRequestConts
     */

    /**
     * @member SESSIONGROUP
     * @desc
     * For group chat
     * @memberof CINRequestConts
     */

    /**
     * @member SESSIONPUBLIC
     * @desc
     * For channel chat.
     * @memberof CINRequestConts
     */
};

/**
 * @interface MessageConsts
 * @classdesc
 * 
 */
var MessageConsts = {
    /**
     * @member TYPE_TEXT
     * @desc
     * For sending text/emoji message.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_IMAGE
     * @desc
     * For sending image.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_VOICE
     * @desc
     * For sending voice message.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_FILE
     * @desc
     * For sending file.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_VIDEO
     * @desc
     * For sending video message.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_EMOTICON
     * @desc
     * For sending emoticons.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_GRAFFI
     * @desc
     * For sending doodle message.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_CARD
     * @desc
     * For sharing contact message.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_LOCATION
     * @desc
     * For sending location.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_FREE_SMS
     * @desc
     * For free sms
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_PP
     * @desc
     * For public messages.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_PUBLIC_IMAGETEXT
     * @desc
     * For sending public image text.
     * @memberof MessageConsts
     */

     /**
     * @member TYPE_CLIENT_FORWARD_IMAGETEXT
     * @desc
     * Forwarding image text.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_CLIENT_FORWARD_PUBLICACCOUNT_CARD
     * @desc
     * Forwarding public account card.
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_RMCSHARE_STORY
     * @desc
     * Channels story
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_JIOMONEY
     * @desc
     * For Sending jio money
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_UPDATE_STATUS
     * @desc
     * For displaying status messages like group info changed, added new member, etc., to the UI
     * @memberof MessageConsts
     */

    /**
     * @member TYPE_UNREAD_MESSAGE
     * @desc
     * For displaying unread messages to the UI
     * @memberof MessageConsts
     */
};

/**
 * @interface AppConstants
 * @classdesc
 * 
 */
var AppConstants = {
    /**
     * @member CHATDETAIL
     * @default
     * @desc
     * Deleting messages. 
     * @memberof AppConstants
     */
    
    /**
     * @member BROADCAST
     * @desc
     * Deleting Broadcast message
     * @memberof AppConstants
     */

    /**
     * @member CHANNELS
     * @desc
     * Deleting channel message
     * @memberof AppConstants
     */

    /**
     * @member RECENT_CHANNELS
     * @desc
     * For deleting recent channels
     * @memberof AppConstants
     */
};
