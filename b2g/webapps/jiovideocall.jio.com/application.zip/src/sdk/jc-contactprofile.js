/**
 * Class is for JCContactProfile information. 
 * @class JCContactProfile
 */
function JCContactProfile () {
    this.name = "";
    this.gender = -1;
	this.mood = "";
    this.expression = -1;
	this.userId = "";
	this.version = -1;
	this.onlineStatus = false;
	this.notifyNow = "";
	this.value = "";
	this.mobileNo = "";
	this.portraitId = "";
	this.pictureSize = "";
	this.avatar = "";
}

JCContactProfile.prototype = {
    init: function(profileObj){
        this.name = profileObj.name;
        this.gender =  profileObj.gender;
        this.mood = profileObj.mood;
        this.expression =  profileObj.expression;
        this.userId = String(profileObj.userId);
        this.version = profileObj.version;
        this.onlineStatus = profileObj.isOnline;
        this.notifyNow = profileObj.notifyNow;
        this.value = profileObj.value;
        this.mobileNo = profileObj.mobileNo;
        this.portraitId = profileObj.portraitId;
        this.pictureSize = profileObj.pictureSize;
        this.avatar = profileObj.thumbData;
    },

    /**
     * Method will set the name..
     * @param {String} name - contains the name
     * @memberof JCContactProfile#
     * @ignore
     */
    setName: function(name){
        this.name = name;
    },

    /**
     * Method to get the name.
     * @return {String}
     * @memberof JCContactProfile#
     */
    getName: function(){
        return this.name;
    },

    /**
     * Method to get the gender.
     * @return {Number}
     * @memberof JCContactProfile#
     */
    getGender: function(){
        return this.gender;
    },

    /**
     * Method to get the mood.
     * @return {String}
     * @memberof JCContactProfile#
     */
    getMood: function(){
        return this.mood;
    },

    /**
     * Method to get the expression.
     * @return {Number}
     * @memberof JCContactProfile#
     */
    getExpression: function(){
        return this.expression;
    },

    /**
     * Method to get the version.
     * @return {Number}
     * @memberof JCContactProfile#
     */
    getVersion: function(){
        return this.version;
    },

    /**
     * Method to get the userId.
     * @return {String}
     * @memberof JCContactProfile#
     */
    getUserId: function(){
        if(!this.userId) return "";
        return String(this.userId);
    },

    /**
     * Method will return onlineStatus.
     * @return {Boolean}
     * @memberof JCContactProfile#
     */
    isOnline: function(){
        return this.onlineStatus
    },

    /**
     * Method to get the notifyNow.
     * @return {String}
     * @memberof JCContactProfile#
     * @ignore
     */
    getNotifyNow: function(){
        return this.notifyNow;
    },

    /**
     * Method to get the mobileNo.
     * @return {String}
     * @memberof JCContactProfile#
     */
    getMobileNo: function(){
        return this.mobileNo;
    },

    /**
     * Method to get the portraitId.
     * @return {String}
     * @memberof JCContactProfile#
     */
    getPortraitId: function(){
        return this.portraitId;
    },

    /**
     * Method to get the avatar image.
     * @return {String}
     * @memberof JCContactProfile#
     */
    getAvatar: function(){
        return this.avatar;
    },



}