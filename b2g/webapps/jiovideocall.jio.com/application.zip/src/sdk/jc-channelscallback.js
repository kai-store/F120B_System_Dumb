/**
 * @interface RecentChannelsCallback
 * @desc
 * RecentChannelsCallback is an anonymous interface will get invoked when we get recent chanels
 */
var RecentChannelsCallback = {
    /**
     * Method will triggered when retrieved all recent channels
     * @function onSuccess
     * @callback RecentChannelsCallback~onSuccess
     * @param {Map<string,JCChat>} channels - contains the Map object
     * @memberof RecentChannelsCallback
     */
    onSuccess:function(channels){
        
    },

    /**
     * Method will be triggered when no recent channels.
     * @function onError
     * @callback RecentChannelsCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof RecentChannelsCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface FollowedChannelsCallback
 * @desc
 * FollowedChannelsCallback is an anonymous interface will get invoked when we get followed channels
 */
var FollowedChannelsCallback = {
    /**
     * Method will triggered when retrieved all followed channels
     * @function onSuccess
     * @callback FollowedChannelsCallback~onSuccess
     * @param {Map<string,object>} followedChannels - contains the Map object
     * @memberof FollowedChannelsCallback
     */
    onSuccess:function(followedChannels){
        
    },

    /**
     * Method will be triggered when no followed channels.
     * @function onError
     * @callback FollowedChannelsCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof FollowedChannelsCallback
     */
    onError: function(errorResponse){

    }
}
