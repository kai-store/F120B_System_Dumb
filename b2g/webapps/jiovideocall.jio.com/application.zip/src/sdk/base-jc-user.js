import BaseModule from '../lib/base-module';

export default class JIOSDKUtils extends BaseModule {
   
    
  
}

JIOSDKUtils.isLoggedIn_UPDA = function() {
	var userID = UserModel.getInstance().getUserID();
	var abc = userID !== undefined && userID !== null && String(userID).trim().length!==0;
	console.log("JC BASE USER: " + abc);
    return abc;
};

JIOSDKUtils.isLoggedIn = function() {
	var userID = UserModel.getInstance().getUserID();
	var userName = UserModel.getInstance().getUserName();
	var isLoggedFlag = userID!==undefined && userID!== null && String(userID).trim().length!==0;
	console.log("User Logged in "+ isLoggedFlag+"with userId "+userID+" UserName is "+userName);
	// if(isLoggedFlag){//&& !userName
	// 	// debugger;
	// 	console.log("already logged in");//getAllFromLDB
	// 	// ActiveUser.getInstance().getByUserIdFromLDB(String(userID),function(userDao){
	// 	ActiveUser.getInstance().getAllFromLDB(function(userDao){		
	// 		console.log("userModel from DB is"+JSON.stringify(userDao));
	// 		if(userDao){
	// 			UserModel.getInstance().setUserName(userDao.userName);
	// 			// return isLoggedFlag;
	// 		}else{
	// 			console.log("could not get userModel from DB");
	// 			// return isLoggedFlag;				
	// 		}
	// 	});
	// }else{
	// 	// console.log("UserName is"+userName);
	// 	console.log("Not logged in");
	// 	// return isLoggedFlag;//userID!==undefined && userID!== null && String(userID).trim().length!==0;
	// }
	//---Following block of code is added to solve userName undefined issue in SDK
	//---Added by shubham.
	if(isLoggedFlag){
			var userModel = localStorage.getItem(AppConstants.SKEY_USER_MODEL);
			console.log("userModel from local storage is "+JSON.stringify(userModel));			
			if(userModel){
				userModel = JSON.parse(userModel);
				console.log("UserModel.userName is "+userModel.userName);
				if(userModel.userName){
					// console.log("UserModel.userName is"+userModel.userName);
					UserModel.getInstance().setUserName(userModel.userName);
					return isLoggedFlag;		
				}else{
					console.log("userModel userName not present in local storage");
					return isLoggedFlag;
				}
			}else{
				console.log("UserModel is not present in localStorage");
				return isLoggedFlag;
				
			}
			
	}else{
		return isLoggedFlag;
	}

};

JIOSDKUtils.isLoggedOrThrowError = function(callback) {
	if(JIOSDKUtils.isLoggedIn()!==true){
		JIOUtils.sendError(-1, "Please login.", callback);
		return false;
	}
	return true;
};
