/**
 * Class is for JCExploreContent information.
 * @class
 */
function JCExploreContent(){
    this.channelId = "";
    this.channelContentVersion = "";
    this.channelPageId = "";
    this.channelPageLocalIndex = "";
    this.channelContentInfoId = "";
    this.channelContentColumnIndex = "";
    this.channelContentType = "";
    this.channelVideoId = "";
    this.channelResourceURI = "";
    this.channelMediaHTML = "";
    this.channelMediaVideo = "";
    this.channelMediaStream = "";
    this.channelContentColumnTitle = "";
    this.channelIntroVideoId = "";
    

}


JCExploreContent.prototype = {
    init :function(contentObj){
        var colIndex = String(contentObj.locColIndex);
        var pageIndex = String(contentObj.locPageIndex);
        this.channelPageId = this.getChannelId() + "_" + colIndex + "_" + pageIndex;
        this.channelPageLocalIndex = contentObj.locPageIndex;
        this.channelContentInfoId = contentObj.contentType;
        this.channelContentColumnIndex = colIndex;
        this.channelContentType = contentObj.contentType;
        this.channelVideoId = contentObj.videoID;
        this.channelResourceURI = contentObj.resourceURI;
        this.channelMediaHTML = contentObj.MEDIA_HTML;
        this.channelMediaVideo = contentObj.MEDIA_VIDEO;
        this.channelMediaStream = contentObj.MEDIA_STREAM;
    },

     /**
     * Method will set the channelId. 
     * @param {String} channelId - contains the channelId of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelId: function(channelId){
        this.channelId = channelId;
    },

     /**
     * Method will get the channelId(explorDetail).
     * @return {String}
     * @memberof JCExploreContent#
     */

    getChannelId: function(){
        return this.channelId;
    },

    /**
     * Method will set the channelContentVersion. 
     * @param {Number} channelContentVersion - contains the channelContentVersion of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelContentVersion: function(channelContentVersion){
        this.channelContentVersion = channelContentVersion;
    },

    /**
     * Method will get the channelContentVersion(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelContentVersion: function(){
        return this.channelContentVersion;
    },


    /**
     * Method will set the channelPageId. 
     * @param {String} channelPageId - contains the channelPageId of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelPageId: function(channelPageId){
        this.channelPageId = channelPageId;
    },

    /**
     * Method will get the channelPageId(explorDetail).
     * @return {String}
     * @memberof JCExploreContent#
     */

    getChannelPageId: function(){
        return this.channelPageId;
    },

    /**
     * Method will set the channelPageLocalIndex. 
     * @param {Number} channelPageLocalIndex - contains the channelPageLocalIndex of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannellPageLocalIndex: function(channelPageLocalIndex){
        this.channelPageLocalIndex = channelPageLocalIndex;
    },

    /**
     * Method will get the channelPageLocalIndex(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannellPageLocalIndex: function(){
        return this.channelPageLocalIndex;
    },

    /**
     * Method will set the channelContentInfoId. 
     * @param {Number} channelContentInfoId - contains the channelContentInfoId of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */


    setChannelContentInfoId: function(channelContentInfoId){
        this.channelContentInfoId = channelContentInfoId;
    },

    /**
     * Method will get the channelContentInfoId(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelContentInfoId: function(){
        return this.channelContentInfoId;
    },

    /**
     * Method will set the channelContentColumnIndex. 
     * @param {String} channelContentColumnIndex - contains the channelContentColumnIndex of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelContentColumnIndex: function(channelContentColumnIndex){
        this.channelContentColumnIndex = channelContentColumnIndex;
    },

    /**
     * Method will get the channelContentColumnIndex(explorDetail).
     * @return {String}
     * @memberof JCExploreContent#
     */

    getChannelContentColumnIndex: function(){
        return this.channelContentColumnIndex;
    },

    /**
     * Method will set the channelContentType. 
     * @param {Number} channelContentType - contains the channelContentType of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelContentType: function(channelContentType){
        this.channelContentType = channelContentType;
    },

    /**
     * Method will get the channelContentType(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelContentType: function(){
        return this.channelContentType;
    },

    /**
     * Method will set the channelVideoId. 
     * @param {Number} channelVideoId - contains the channelVideoId of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelVideoId: function(channelVideoId){
        this.channelVideoId = channelVideoId;
    },

    /**
     * Method will get the channelVideoId(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelVideoId: function(){
        return this.channelVideoId;
    },

    /**
     * Method will set the channelResourceURI. 
     * @param {String} channelResourceURI - contains the channelResourceURI of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelResourceURI: function(channelResourceURI){
        this.channelResourceURI = channelResourceURI;
    },

    /**
     * Method will get the channelResourceURI(explorDetail).
     * @return {String}
     * @memberof JCExploreContent#
     */

    getChannelResourceURI: function(){
        return this.channelResourceURI;
    },

    /**
     * Method will set the channelMediaHTML. 
     * @param {Number} channelMediaHTML - contains the channelMediaHTML of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelMediaHTML: function(channelMediaHTML){
        this.channelMediaHTML = channelMediaHTML;
    },
    
    /**
     * Method will get the channelMediaHTML(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelMediaHTML: function(){
        return this.channelMediaHTML;
    },

    /**
     * Method will set the channelMediaVideo. 
     * @param {Number} channelMediaVideo - contains the channelMediaVideo of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelMediaVideo: function(channelMediaVideo){
        this.channelMediaVideo = channelMediaVideo;
    },

    /**
     * Method will get the channelMediaVideo(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannellMediaVideo: function(){
        return this.channelMediaVideo;
    },

    /**
     * Method will set the channelMediaStream. 
     * @param {Number} channelMediaStream - contains the channelMediaStream of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelMediaStream: function(channelMediaStream){
        this.channelMediaStream = channelMediaStream;
    },

    /**
     * Method will get the channelMediaStream(explorDetail).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelMediaStream: function(){
        return this.channelMediaStream;
    },

    /**
     * Method will set the channelContentColumnTitle. 
     * @param {String} channelContentColumnTitle - contains the channelContentColumnTitle of  explorDetail.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelContentColumnTitle: function(channelContentColumnTitle){
        this.channelContentColumnTitle = channelContentColumnTitle;
    },

    /**
     * Method will get the channelContentColumnTitle(explorDetail).
     * @return {String}
     * @memberof JCExploreContent#
     */

    getChannelContentColumnTitle: function(){
        return this.channelContentColumnTitle;
    },
    /**
     * Method will set the channelIntroVideoId.
     * @param {Number} channelIntroVideoId - contains the channelIntroVideoId of  exploreListChannel.
     * @memberof JCExploreContent#
     * @ignore
     */

    setChannelIntroVideoId:function(channelIntroVideoId){
        this.channelIntroVideoId = channelIntroVideoId;
    },

    /**
     * Method will get the channelIntroVideoId(exploreListChannel).
     * @return {Number}
     * @memberof JCExploreContent#
     */

    getChannelIntroVideoId: function(){
        return this.channelIntroVideoId;
    }
   

    
}
