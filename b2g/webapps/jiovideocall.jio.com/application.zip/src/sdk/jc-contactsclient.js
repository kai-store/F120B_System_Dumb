import BaseModule from '../lib/base-module';
import ContactsStore from '../data/contacts-store';
/**
 * Class is for JC-Contact information. 
 * @class JioContactsClient
 *  
 */

export default class JioContactsClient extends BaseModule {

    start(){
        this.allowBatchUpdateFirstTime = false;
    }

    /**
     * Method will get all contacts from device, sent to server, check this number is jio user or not and saved it to database and get all data from database. 
     * @param {DeviceContactsCallback} callback - get all contacts.
     * @memberof JioContactsClient#
     */
    syncContacts(callback){
        var that = this;
        console.log('[SDK::JC-Contacts-Client:::ContactsSync] calling the sync contacts.');
        ContactsStore.getInstance().fetchContactsfromDevice({
            onSuccess: function(data){
                console.log('[SDK::JC-Contacts-Client:::ContactsSync] fetched contacts from device.'+ JSON.stringify(data));
                var unSyncContacts = ContactsModel.getInstance().getOnlyUnSyncContacts(data);                
                if (unSyncContacts.length > 0) {
                    if (unSyncContacts.length > 200) {
                        console.log('[SDK::JC-Contacts-Client:::ContactsSync] morethan 200 contacts are not synced.');
                        that.allowBatchUpdateFirstTime = true;
                    } else { // If the length is not greater than 200 then it is not a batch update. This condition is required while adding contacts from app itself
                        that.allowBatchUpdateFirstTime = false;
                    }

                    console.log('[SDK::JC-Contacts-Client:::ContactsSync] unsynced contacts.'+ JSON.stringify(unSyncContacts));
                    that.updateUnsyncContact(unSyncContacts,callback);
                } else if(data){
                    if(typeof callback.onProfilePictureUpdate === "function"){
                        // callback.onProfilePictureUpdate(data); 
                        console.log("processResponse calling from ontacts client syncContacts ");

                        console.log('[SDK::JC-Contacts-Client:::ContactsSync] no any unsynced contacts. calling processResponseForSyncContact.');
                        ContactsStore.getInstance().processResponseForSyncContact(undefined, data, callback);                          
                    }else{
                        console.log('[SDK::JC-Contacts-Client:::ContactsSync] no any unsynced contacts. returning the data as it is.');
                        callback.onSuccess(data);   
                    }
                }
            }
        });

        if(callback.onUpdate){
            console.log('[SDK::JC-Contacts-Client:::ContactsSync] no any unsynced contacts. calling setSyncContactUpdateListner.');
            ContactsStore.getInstance().setSyncContactUpdateListner(callback.onUpdate);
        }else{
            console.log("sync contact onUpdate is not present in callback");
        }
    }

    /**
     * Method will get all contacts from database. 
     * @param {AllContactsCallback} callback - get all contacts.
     * @memberof JioContactsClient#
     */
    getContacts(callback){
        ContactsStore.getInstance().fetchContactsfromLDB(callback);
        
    }

    /**
     * Method will get selected contact detail from database.
     * @param {String} id - user id of the contact
     * @param {ContactsInfoCallback} callback - get contact detail
     * @memberof JioContactsClient#
     */
    getContactDetail(id, callback){
        ContactsStore.getInstance().getUserContactByUserID(id, callback);
    }

    /**
     * Method will get SYNC contacts list from server.
     * @param {Object} contactsList - contacts list not having user id
     * @param {String} contactsList.name - name for the contact
     * @param {String} contactsList.mobileNo - mobile number for the contact
     * @param {ContactsSyncCallback} callback - get contact list
     * @memberof JioContactsClient#
     */
    updateUnsyncContact(allContacts, callback){
        ContactsStore.getInstance().checkUnSyncedContacts(allContacts, callback);
    }

    /**
     * Method will the profile details from the server for desired userId.
     * @param {String} userId  - userId of the person who's profile to be fetched from server
     * @param {ProfileWithUserIdCallback} callback - gets contact with profile
     * @memberof JioContactsClient#
     */
    getProfileWithUserId(userId, callback){
        ContactsStore.getInstance().getCompleteProfileWithUserId(userId, callback);
    }

    /**
     * Method will SYNC the phone numbers and return the profile details from the server.
     * @param {Object} allContacts  - object with array of phone Numbers with +91, ex:-{"phoneNumbers":["+918888444410","+919658747474"]}
     * @param {Array} allContacts.phoneNumbers - mobile number for the contact ex:-["+918888444410","+919658747474"]
     * @param {SyncContactWithProfileCallback} callback - get contact list with profile
     * @memberof JioContactsClient#
     */
    syncContactWithProfile(allContacts, callback){
        var that = this;
        console.log("calling contact sync with numbers");
        ContactsStore.getInstance().syncContactWithProfile(allContacts.phoneNumbers, {
            onSuccess: function(data){
                var unSyncContacts = ContactsModel.getInstance().getOnlyUnSyncContacts(data);                
                // var unSyncContacts = data;
                if (unSyncContacts.length > 0) {
                    if (unSyncContacts.length > 200) {
                        that.allowBatchUpdateFirstTime = true;
                    } else { // If the length is not greater than 200 then it is not a batch update. This condition is required while adding contacts from app itself
                        that.allowBatchUpdateFirstTime = false;
                    }
                    // ContactsModel.getInstance().setSyncContactWithNumbersFlag(true);
                    that.updateUnsyncContact(unSyncContacts,{
                        onSuccess:function(data){
                            console.log("sync contact with numbers"+JSON.stringify(data));//
                            ContactsStore.getInstance().getByMobileNumber(allContacts.phoneNumbers,function(response){
                                console.log("Response from DB is for sync with numbers"+JSON.stringify(response));
                                callback.onSuccess(response);

                            });
                        },
                        onProfilePictureUpdate:function(profileData){
                            ContactsStore.getInstance().getByMobileNumber(allContacts.phoneNumbers,function(response){
                                console.log("Response from DB is for sync with numbers"+JSON.stringify(response));
                                if(typeof callback.onProfilePictureUpdate === "function" ){
                                    callback.onProfilePictureUpdate(response);

                                }else{
                                    callback.onSuccess(response);
                                    
                                }

                            });
                        }
                    });
                    
                }
            }
        });
    }

    /**
     * Method will block or unblock the contact.
     * @param {Object[]} data - list of contacts object contains (name, userId, mobileNo)
     * @param {String} data.userId - The id for the user.
     * @param {String} data.name - The name for the user.
     * @param {String} data.tel - The mobile number for the user ex:-"+919657441111"
     * @param {Number} block - 1 is for  block or 0 is for unblock
     * @param {ContactsBlacklistCallback} callback - get contact list
     * @memberof JioContactsClient#
     */
    blockContact(list, block, callback){
        ContactsStore.getInstance().callHandleBlackListAPIClientFromAddBlock(list, block, callback);
    }
     /**
     * Method will block or unblock the contact.
     * @param {String} contactUserId - The id for the user.
     * @param {Boolean} isFav - true to favourite and false to unFavourite.
     * @param {String} mobileNo - The mobile number for the user
     * @param {ContactsFavouriteCallback} callback
     * @memberof JioContactsClient#
     */
    callAddRemoveFavouriteContact(mobileNo, contactUserId,isFav, callback){
        ContactsStore.getInstance().callAddRemoveFavouriteContact(mobileNo, contactUserId, isFav,callback);
    }

}

/**
 * Method will retutn an instance of JioContactsClient class. You should not create class object directly.
 * @return JioContactsClient class ref.
 * @example
 * var contactClient = JioContactsClient.getInstance();
 * contactClient.getDeviceContact(callback);
 */
JioContactsClient.getInstance = function(){
    if( !JioContactsClient.instance) {
        JioContactsClient.instance = new JioContactsClient();
        JioContactsClient.instance.start();
    }
    return JioContactsClient.instance;
}
