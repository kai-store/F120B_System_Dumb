import BaseModule from '../lib/base-module';
import OnboardingStore from '../data/onboarding-store';

/**
 * JCUser is a class which has all the server and local database calls related to onboarding screens.
 * @class JCUser
 */
export default class JCUser extends BaseModule {
    start(){
        this.phoneNumber = localStorage.getItem(AppConstants.SKEY_USER_PHONE_NO);
        this.onboardingInstance = OnboardingStore.getInstance();
    }

    /**
     * Method will send auto logon request to the server and returns success or failure response as callbacks.
     * @function autoLogonUser
     * @param {JCSSO} ssoToken - SSO Information.
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
	autoLogonUser(ssoToken, callback) {
       var deviceInfo = JioChatSDK.getInstance().getDeviceInfo();
       if(deviceInfo && deviceInfo.getDeviceID()){
           //TODO call ZLA req.
           var handleError = false, forceSSo = true; 
           var deviceId = deviceInfo.getDeviceID();
           // this.onboardingInstance.autoRegister(handleError, forceSSo, deviceId, callback);
           this.onboardingInstance.callAutoLogonDetailsAPIClient(ssoToken, deviceId, callback);
           return;
       }
       JIOUtils.sendError(100, "Please set deviceInfo", callback);
    //    callback.onError({100, "Please set device info."});    
    }

    /**
     * Method will send register as new user request to the server and returns success or failure response as callbacks.
     * @function registerUser
     * @param {Number} phoneNumber - This is user phone number(Jio number).
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    registerUser(phoneNumber, callback) {
       this.phoneNumber = phoneNumber;
       OnboardingStore.getInstance().callRegisterAPIClient(phoneNumber, callback);
    }

     /**
     * Method will send get OTP request to the server and returns success or failure response as callbacks.
     * @function getOtpSMS
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    getOtpSMS(callback) {
       OnboardingStore.getInstance().callSMSOTPAPIClient(this.phoneNumber, callback);
    }

    /**
     * Method will send verify OTP request to the server and returns success or failure response as callbacks.
     * @function verifyOtp
     * @param {String} otp - This is otp number entered by the user.
     * @param {JCUserProfileCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    verifyOtp(otp, callback) {
       OnboardingStore.getInstance().callVerifySMSOTPAPIClient(this.phoneNumber, otp, callback);
    }

    /**
     * Method will send reload(get new) OTP request to the server and returns success or failure response as callbacks.
     * @function getNewCaptcha
     * @param {String} captchaKey - This is captcha key.
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    getNewCaptcha(key, callback) {
       OnboardingStore.getInstance().callNewCaptchaAPIClient(key, callback);
    }

    /**
     * Method will send validate OTP request to the server and returns success or failure response as callbacks.
     * @function validateCaptcha
     * @param {String} captchaText - This is captcha text entered by the user.
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    validateCaptcha(captchaText, callback) {
       OnboardingStore.getInstance().callCaptchaAPIClient(captchaText, callback);
    }

    /**
     * Method will send update profile request to the server and returns success or failure response as callbacks.
     * @function updateProfile
     * @param {object} profileData - This is complete user profile data.
     * @param {String} profileData.name - The name of user.
     * @param {String} profileData.phno - The phone number of user.
     * @param {Number} profileData.selGender - The gender of user.
     * @param {String} profileData.status - The status of user.
     * @param {Number} profileData.expression - The mood of user.
     * @param {String} profileData.portraitId - The portrait id for profile image.
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    updateProfile(profileData, callback) {
       OnboardingStore.getInstance().callUpdateProfileAPIClient(profileData, callback);
    }

    /**
     * Method will send get profile details request to the server and returns success or failure response as callbacks.
     * @function getProfile
     * @param {JCUserProfileCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    getProfile(callback) {
       OnboardingStore.getInstance().callGetProfileAPIClient(callback);
    }

    /**
     * Method will send challenge request to the server and returns success or failure response as callbacks.
     * @function sendChallengeRequest
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    sendChallengeRequest(callback) {
       OnboardingStore.getInstance().callChallengeAPIClient(callback);
    }

    /**
     * Method will send keep alive request to the server and returns success or failure response as callbacks.
     * @function setKeepAlive
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     * @ignore
     */
    setKeepAlive(callback) {
       OnboardingStore.getInstance().callKeepAliveAPIClient(callback);
    }

     /**
     * Method will send upload portrait image request to the server and returns success or failure response as callbacks.
     * @function uploadPortrait
     * @param {ByteArray} image - This is as buffer array image.
     * @param {Number} size - Size of buffer array(Image).
     * @param {JCCommonUserCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    uploadPortrait(image, size, callback) {
       OnboardingStore.getInstance().callUploadPortraitAPIClient(image, size, callback);
    }

    /**
     * Method will send download portrait request to the server.
     * @function downloadPortrait
     * @param {ByteArray} userId - This is user id of user.
     * @param {String} portraitId - This is portrait ID of particular user.
     * @param {JCUserDownloadPortraitCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    downloadPortrait(userId, portraitId, callback) {
       OnboardingStore.getInstance().callDownloadPortraitAPIClient(userId, portraitId, callback);
    }

    /**
     * Method for getting picture from device Model.
     * @function getCameraPictureFromDevice
     * @param {JCUserCameraPictureCallBack} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    getCameraPictureFromDevice(callback) {
       OnboardingStore.getInstance().callGetCameraPictureFromDevice(callback);
    }

    /**
     * Getting device information from local database.
     * @function getDeviceInformationByDeviceId
     * @param {String} deviceId - This is device id getting from local database.
     * @param {function} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    getDeviceInformationByDeviceId(deviceId, callback) {
       OnboardingStore.getInstance().getDeviceInfoLDB(deviceId, callback);
    }

    // /**
    //  * Method for adding phone number to local database.
    //  * @function addPhoneNumberToLDB
    //  * @param {Number} phoneNumber - This is user phone number.
    //  * @param {function} callback - success or failure callbacks in return.
    //  * @memberof JCUser#
    //  */
    // addPhoneNumber(phoneNumber, callback) {
    //    OnboardingStore.getInstance().addPhonenumberLDB(phoneNumber, callback);
    // }
    
    // /**
    //  * Method for adding user profile details to local database.
    //  * @function addPhoneNumberToLDB
    //  * @param {object} profileData - This is complete user profile data.
    //  * @param {String} profileData.name - The name of user.
    //  * @param {Number} profileData.phno - The phone number of user.
    //  * @param {Number} profileData.selGender - The gender of user.
    //  * @param {function} callback - success or failure callbacks in return.
    //  * @memberof JCUser#
    //  */
    // addProfile(profileData, callback) {
    //    OnboardingStore.getInstance().addProfileLDB(profileData, callback);
    // }

    // /**
    //  * Method for update user profile to local database
    //  * @function updateProfileOnLDB
    //  * @param {object} profileData - This is complete user profile data.
    //  * @param {String} profileData.name - The name of user.
    //  * @param {Number} profileData.phno - The phone number of user.
    //  * @param {Number} profileData.selGender - The gender of user.
    //  * @param {String} profileData.status - The status of user.
    //  * @param {Number} profileData.expression - The mood of user.
    //  * @param {String} profileData.portraitId - The portrait id for profile image.
    //  * @param {function} callback - success or failure callbacks in return.
    //  * @memberof JCUser#
    //  */
    // updateProfile(profileData, callback) {
    //    OnboardingStore.getInstance().updateProfileLDB(profileData, callback);
    // }

    /**
     * Method for update user profile image to local database
     * @function updateProfileImage
     * @param {base64} imageData - The base64 format of image.
     * @param {Number} phoneNumber - The phone number of user.
     * @param {function} callback - success or failure callbacks in return.
     * @memberof JCUser#
     */
    updateProfileImage(imageData, phoneNumber, callback) {
       OnboardingStore.getInstance().updateImgToLDB(imageData, phoneNumber, callback);
    }

    // /**
    //  * Method for fetching all profile data from local database
    //  * @function updateProfileImageOnLDB
    //  * @param {function} callback - success or failure callbacks in return.
    //  * @memberof JCUser#
    //  */
    // getProfileData(callback) {
    //    OnboardingStore.getInstance().getProfileLDB(callback);
    // }
    
}

JCUser.getInstance = function(){
    if( !JCUser.instance) {
        JCUser.instance = new JCUser();
        JCUser.instance.start();
    }
    return JCUser.instance;
}
