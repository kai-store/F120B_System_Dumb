function JIOClient(){
	this.cmpIP = 'ws://52.76.248.2:8081';
	this.isSocketCallbackSet = false;
}

JIOClient.getInstance = function(){
    if( !JIOClient.instance ){
        JIOClient.instance = new JIOClient();
    }
    return JIOClient.instance;
}

JIOClient.prototype.getCINClient = function(){
    var instance = CINClient.getInstance(this.cmpIP);
	if(!this.isSocketCallbackSet){
    	instance.setLogonRequired(true);
		instance.setSocketCallback(this.socketCallback);
		this.isSocketCallbackSet = true;
	}
    return instance;
}

JIOClient.prototype.setSocketCallback = function(initCallback){
	this.isSocketCallbackSet = false;
	this.socketCallback = initCallback;
};

JIOClient.prototype.getSocketCallback = function(){
	return this.socketCallback;
};

JIOClient.prototype.setOfflineCallback = function(offlineCallback){
	this.offlineCallback = offlineCallback;
};

JIOClient.prototype.getOfflineCallback = function(){
	return this.offlineCallback;
};

JIOClient.prototype.setMessageCallback = function(chatCallback){
	this.chatCallback = new InComingMessageProxyCallback(chatCallback);
};

JIOClient.prototype.getMessageCallback = function(){
	return this.chatCallback;
};

JIOClient.prototype.setGroupCallback = function(groupCallback){
	this.groupCallback = new InComingGroupProxyCallback(groupCallback);
};

JIOClient.prototype.getGroupCallback = function(){
	return this.groupCallback;
};

JIOClient.prototype.setAVCallback = function(avCallback){
	RTMManager.getInstance().setCallback(avCallback);
};

JIOClient.prototype.getAVCallback = function(){
	return 	RTMManager.getInstance().getCallback();
};

JIOClient.prototype.setNotificationCallback = function(notificationCallback){
	this.notificationCallback = new InComingNotificationProxyCallback(notificationCallback);
};

JIOClient.prototype.getNotificationCallback = function(){
	return this.notificationCallback;
};

JIOClient.prototype.isConnected = function(){
	return 	this.getCINClient().isOnline();
}

JIOClient.prototype.register = function(contactNumber, callback) {

	if(!contactNumber || contactNumber.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}
	UserModel.getInstance().setPhoneNumber(contactNumber);
	var httpReq = new HTTPRequest(HTTPRequestConts.GET_NAV);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,true);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.setCINResponseParser();
	httpReq.setCINMessageObject();
	// httpReq.addHeader(HTTPRequestConts.GET_NAV_END, '',false);
	httpReq.setCallback(new NavProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);	
};

/*JIOClient.prototype.getSmsCode = function(contactNumber, callback) {
	if(contactNumber && contactNumber.length > 0){
		var instance = UserModel.getInstance();
		instance.setPhoneNumber(contactNumber);
		contactNumber = instance.getEPhoneNumber();
		var httpReq = new HTTPRequest(HTTPRequestConts.SMS_ACP);
		httpReq.setRequestMethod(HTTPRequestConts.GET);
		httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
		httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber);
		httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
		httpReq.addHeader('lv', '0', false);
		httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
		httpReq.setCINMessageObject();
		httpReq.setCINResponseParser();
		httpReq.setCallback(new SMSProxyCallback(callback));
		HTTPClient.getInstance().send(httpReq);
	}else
	{

	}	

	if(!contactNumber || contactNumber.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}
	UserModel.getInstance().setPhoneNumber(contactNumber);
	var httpReq = new HTTPRequest(HTTPRequestConts.GET_NAV);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,true);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.setCINResponseParser();
	httpReq.setCINMessageObject();
	// httpReq.addHeader(HTTPRequestConts.GET_NAV_END, '',false);
	httpReq.setCallback(new NavProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);
};*/

JIOClient.prototype.getSmsCode = function(contactNumber, callback) {
	if(!contactNumber || contactNumber.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}
	var instance = UserModel.getInstance();
	instance.setPhoneNumber(contactNumber);
	contactNumber = instance.getEPhoneNumber();
	var httpReq = new HTTPRequest(HTTPRequestConts.SMS_ACP);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.addHeader('lv', '0', false);
	httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
	httpReq.setCINMessageObject();
	httpReq.setCINResponseParser();
	httpReq.setCallback(new SMSProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);	
};

JIOClient.prototype.validateCaptcha = function(key, validationNumber, callback){
	if(!validationNumber || validationNumber.toString().length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}
	if(!key || key.toString().length === 0){
		JIOUtils.sendError(ErrorCodes.CAPTCHA_CODE, "Provide captcha", callback);
		return;
	}
	var httpReq = new HTTPRequest(HTTPRequestConts.SMS_ACP);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	var contactNumber = UserModel.getInstance().getEPhoneNumber();
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.addHeader('lv', '0', false);
	httpReq.addHeader('pid', key, true);
	httpReq.addHeader('pc', validationNumber, true);
	httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
	httpReq.setCINResponseParser();
	httpReq.setCallback(callback);
	HTTPClient.getInstance().send(httpReq);
};

JIOClient.prototype.generateCaptcha = function(callback){
	var httpReq = new HTTPRequest(HTTPRequestConts.GEN_CAPTCHA_CODE);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	// var contactNumber = "KzkxOTkwMTM5NjM0MA;;";
	var contactNumber = UserModel.getInstance().getEPhoneNumber();
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,false);
	httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
	httpReq.setCINMessageObject();
	httpReq.setCINResponseParser();
	httpReq.setCallback(new GenrateCaptchaProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);
};


JIOClient.prototype.validateOtp = function(contactNumber, otp, callback){
	
	if(!contactNumber || contactNumber.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}
	if(!otp || otp.toString().length === 0){
		JIOUtils.sendError(ErrorCodes.NO_OTP, "Provide otp", callback);
		return;
	}
	var instance  = UserModel.getInstance();
	instance.setPhoneNumber(contactNumber);
	var httpReq = new HTTPRequest(HTTPRequestConts.VALIDATE_OTP);
	httpReq.setRequestMethod(HTTPRequestConts.GET);

	var code = otp +""+ instance.getDomain();

	spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(JIOUtils.getBytes(code)));
	var data = spark.end(true);

	spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(JIOUtils.getBytes(data)));
	data = spark.end(true);	
	data = new Int8Array(JIOUtils.getBytes(data));

	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);

	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, instance.getEPhoneNumber(), false);
	httpReq.addHeader('rd', data, true);
	httpReq.addHeader('dev', HTTPRequestConts.DEV_ID, true);
	httpReq.addHeader('na', '', false);
	httpReq.addHeader('lv', 0, false);	
	httpReq.addHeader('oem', HTTPRequestConts.OEM);	
	httpReq.addHeader('imei', HTTPRequestConts.IMEI, true);
	httpReq.addHeader('dm', HTTPRequestConts.BRAND, true);
	httpReq.addHeader('osv', HTTPRequestConts.OS_VERSION, true);

	httpReq.setCINMessageObject();
	httpReq.setCINResponseParser();
	httpReq.setCallback(new SMSValidationProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);	
};

JIOClient.prototype.getTinyUrl = function(callback){
	var httpReq = new HTTPRequest(HTTPRequestConts.TINY_URL);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.setCallback(callback);
	HTTPClient.getInstance().send(httpReq);
};

JIOClient.prototype.challenge = function(callback){
	instance = UserModel.getInstance();

	var cinReq = new CINRequest(CINRequestConts.LOGON, CINRequestConts.EVENT_CHALLENGE);
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.setIsRefeshAfterLogon(false);

	cinReq.addHeaderInt8(CINRequestConts.LANGUAGE, instance.getLanguage());
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(callback);
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.logon = function(callback) {
	var instance =	UserModel.getInstance();

	var array = new Array();

	spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(instance.getUserID()));
	spark.append(new Int8Array(instance.getToken()));
	spark.append(new Int8Array(instance.getServerKey()));

	md5FirstBytes = new Int8Array(JIOUtils.getBytes(spark.end(true)));
		
	m5PasswordSpark = new SparkMD5.ArrayBuffer();

	m5PasswordSpark.append(new Int8Array(instance.getPassword()));
	var m5Password = m5PasswordSpark.end(true);
	m5Password = new Int8Array(JIOUtils.getBytes(m5Password));

	var array = new Array();

	for(index=0;index<16;index++){
		array[index] = md5FirstBytes[index];
		array[index+16] = m5Password[index];
	}
	
	JIOUtils.logArray(array);

	var cinReq = new CINRequest(CINRequestConts.LOGON, CINRequestConts.EVENT_LOGON);

	cinReq.addHeaderInt64(CINRequestConts.LANGUAGE, instance.getLanguage());
	cinReq.addHeaderString(CINRequestConts.NAME, instance.getDeviceModel());
	cinReq.addHeaderInt32(CINRequestConts.TYPE, CINRequestConts.PLATFORM_TYPE);
	cinReq.addHeaderString(CINRequestConts.VERSION, CINRequestConts.PLATFORM_VERSION);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, 100001);
	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, HTTPRequestConts.DEV_ID); 
	cinReq.addHeader(CINRequestConts.PASSWORD, array); 
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, CINRequestConts.PLATFORM_CAPABILITY);

	cinReq.setIsRefeshAfterLogon(false);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(callback);
	this.getCINClient().send(cinReq);	
};

JIOClient.prototype.checkCredential = function(callback) {
 	var instance =	UserModel.getInstance();
 
 	var cinReq = new CINRequest(CINRequestConts.LOGON, CINRequestConts.EVENT_CHECKCREDENTIAL);
 
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderInt32(CINRequestConts.LANGUAGE, instance.getLanguage());
 	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, HTTPRequestConts.DEV_ID); 
	cinReq.addHeader(CINRequestConts.CREDENTIAL, instance.getCredential());
 	cinReq.addHeaderString(CINRequestConts.VERSION, CINRequestConts.PLATFORM_VERSION);
 	cinReq.addHeaderInt64(CINRequestConts.STATUS, 100001);
 	cinReq.addHeaderInt32(CINRequestConts.CAPABILITY, CINRequestConts.PLATFORM_CAPABILITY);//c	cinReq.setCallback(callback);

 	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new LogonProxyCallback(callback));
	
 	this.getCINClient().send(cinReq);	
};

JIOClient.prototype.keepAlive = function(){
	if(!UserModel.getInstance().keepAliveExpire){
		UserModel.getInstance().keepAliveExpire = 1000;
	}
	setTimeout(function(){
		cinReq = new CINRequest(CINRequestConts.LOGON, CINRequestConts.EVENT_KEEP_ALIVE);

		cinReq.addHeaderInt32(CINRequestConts.STATUS, 0x01);
		cinReq.setCINMessageObject();
		cinReq.setCallback({
			onSuccess: function(cinMessage){
				UserModel.getInstance();
				var expire = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.EXPIRE));
				expire = ((expire*1000)-60000);
				if(expire<0){
					expire = 1000;
				}
				var instance = UserModel.getInstance();
				instance.keepAliveExpire = expire;
				if(instance.isLoggedIn()){
					JIOClient.getInstance().keepAlive();
				}
			},
			onError: function(error){
				if(error.errCode === ErrorCodes.REFRESH_REQUEST){
					var instance = UserModel.getInstance();
					if(instance.isLoggedIn()){
						JIOClient.getInstance().keepAlive();
					}
				}
				// if(UserModel.getInstance().isLoggedIn()){
				// 	JIOClient.getInstance().keepAlive();
				// }
			}
		});
		
		JIOClient.getInstance().getCINClient().send(cinReq);
	}, UserModel.getInstance().keepAliveExpire);
};

JIOClient.prototype.getUserCard = function(userId, version, notifyNow, callback){

	if(!userId || userId === null){
		JIOUtils.sendError(ErrorCodes.NO_USERID, "Provide userID", callback);
		return;
	}	
	var cinReq = new CINRequest(CINRequestConts.TAKE, CINRequestConts.EVENT_TAKE_CARD);
	//cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, userId);
	cinReq.addHeaderInt8(CINRequestConts.VERSION, version);
	
	if (notifyNow) {
		cinReq.addHeaderInt8(CINRequestConts.TOKEN, 1);
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new ProfileProxyCallback(callback));

	this.getCINClient().send(cinReq);
};


JIOClient.prototype.updateProfile = function(profile, callback){
	var name = profile.getName();
	var mood = profile.getMood();
	var gender = profile.getGender();
	var exprassion = profile.getExpression();

	cinReq = new CINRequest(CINRequestConts.REQ_METHOD, CINRequestConts.EVENT_UPDATE_CARD);

	msg = new CINRequest(CINRequestConts.REQ_METHOD);

	if(name && name.length > 0){
		msg.addHeaderString(CINRequestConts.HEADER_RCS_NAME, name);
	}

	if(mood && mood.length > 0){
		msg.addHeaderString(CINRequestConts.HEADER_RCS_MOOD, mood);
	}

	if(exprassion){
		msg.addHeaderInt32(CINRequestConts.HEADER_RCS_EXPRESSION, exprassion);		
	}

	if(gender){
		msg.addHeaderInt32(CINRequestConts.HEADER_RCS_GENDER, gender);		
	}

	cinReq.addBody(CINRequestConts.BODY, msg.convert());
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(callback);
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.getProfile = function(callback){
	var instance = UserModel.getInstance();
	this.getContactProfile(instance.getUserID(), 1, callback);
};

JIOClient.prototype.getContactProfile = function(userId, version, callback){
	if(!userId || userId === null){
		JIOUtils.sendError(ErrorCodes.NO_USERID, "Provide userID", callback);
		return;
	}
	cinReq = new CINRequest(CINRequestConts.TAKE, CINRequestConts.EVENT_TAKE_CARD);
	cinReq.addHeader(CINRequestConts.TO, userId);	
	cinReq.addHeaderInt32(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new ProfileProxyCallback(callback));
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.checkVersion = function(contactNumber, callback) {
	if(!contactNumber || contactNumber.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}	
	var httpReq = new HTTPRequest(HTTPRequestConts.GET_NAV);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,true);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_END, '',false);
	httpReq.setCINResponseParser();
	httpReq.setCallback(callback);
	HTTPClient.getInstance().send(httpReq);	
};

JIOClient.prototype.getAllOfflineMessages = function(){
	console.log("----- getAllOfflineMessages -----");

	var cinReq = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.EVENT_GET_HISTORY_COUNT);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new OfflineMessageCountProxyCallback());

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.getOfflineMessages = function(from, index, pageSize){
	var cinReq = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.EVENT_GET_OFFLINE_MSG);

	cinReq.addHeaderInt32(CINRequestConts.STATUS, 0x01);

	msg = new CINRequest(CINRequestConts.MESSAGE);

	msg.addHeader(CINRequestConts.INFO_HEADER_USERID, from);

	if(index>0){
		msg.addHeaderInt64(CINRequestConts.INFO_HEADER_OFFLINE_COUNT, index);
	}

	msg.addHeaderInt64(CINRequestConts.INFO_HEADER_OFFLINE_READ_SEQ, pageSize);

	cinReq.addBody(CINRequestConts.BODY, msg.convert());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new InOfflineMessageProxyCallback());

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.getLastSeen = function(to, callback){
	var cinReq = new CINRequest(CINRequestConts.ASK, CINRequestConts.EVENT_LAST_LOGON_TIME);

	cinReq.addHeader(CINRequestConts.TO, to);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback({
		onSuccess: function(cinMessage){
			ask = new Ask(to, cinMessage);
			callback.onSuccess(ask);
		},
		onError: function(cinMessage){
			callback.onError(cinMessage);
		}
	});

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.sendOfflineMessages = function(chatMessages) {
	instance = JIOClient.getInstance();
	chatMessages.forEach(function(chatMessage, index){
		instance.sendMessage(chatMessage, new OfflineMessageProxyCallback(chatMessage));
	});
};

JIOClient.prototype.sendMessage = function(chatMessage, callback) {

	var instance = UserModel.getInstance();

	if(instance.getToken() === null) {
		JIOUtils.sendError(100,"Unable to send text msg.", callback);
		return;
	}

	var userId = chatMessage.getTo();

	if(!userId && userId === null){
		userId = instance.getUserID();
	}
	
	var cinReq = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.EVENT_SEND_MSG);

	if(chatMessage.isGroup()){
		cinReq = new CINRequest(CINRequestConts.GROUPMESSAGE);
	}
	
	cinReq.addHeader(CINRequestConts.TO, userId);

	var mobileNumbers = chatMessage.getMobileNumbers();
	if(mobileNumbers && mobileNumbers.length>0){
		mobileNumbers.forEach(function(mobileNumber){
			if (mobileNumber && mobileNumber !== null) {
				cinReq.addHeader(CINRequestConts.MOBILENO, mobileNumber);
			}
		});
	}

	var from = chatMessage.getFrom();
	if (from && from !== null) {
		cinReq.addHeader(CINRequestConts.INDEX, from);
	}

	var uuid = chatMessage.getMessageId();

	cinReq.addHeader(CINRequestConts.MESSAGEID, uuid);
	
	var messageStatus = MessageStatus.getValue(false, false, true, false);

	if (messageStatus !== 0) {
		cinReq.addHeaderInt32(CINRequestConts.STATUS, messageStatus);
	}

	msgType = chatMessage.getMessageType();
	
	if (msgType !== MessageConsts.TYPE_TEXT) {
		cinReq.addHeaderInt32(CINRequestConts.TYPE, msgType);
	}

	var message = chatMessage.getMessageBody();

	if((msgType == MessageConsts.TYPE_TEXT 
		|| msgType == MessageConsts.TYPE_CARD
		|| msgType == MessageConsts.TYPE_FREE_SMS)) {

		uuid =  UUID.randomUUID();

		// message = JIOUtils.getBytes(message);
		
		var bodyBytes = EncryptionUtils.encrypt(message, uuid);

		cinReq.addHeader(CINRequestConts.ENCRYPT, uuid);
		
		cinReq.addHeader(CINRequestConts.SERVERDATA, instance.getToken());

		cinReq.addBody(CINRequestConts.BODY, bodyBytes);
	} else {
		cinReq.addBody(CINRequestConts.BODY, message);
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new ChatProxyCallback(callback, chatMessage));

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.sendRawMessage = function(contactNumbers, userIDs, msgType, message, callback) {

	var instance = UserModel.getInstance();

	if(instance.getToken() === null) {
		JIOUtils.sendError(100,"Unable to send text msg.", callback);
		return;
	}

	var userId = instance.getUserID();
	
	var cinReq = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.EVENT_SEND_MSG);

	cinReq.addHeader(CINRequestConts.TO, userId);

	if (contactNumbers && contactNumbers !== null) {
		contactNumbers.forEach(function(mobile, index){
			cinReq.addHeader(CINRequestConts.MOBILENO, mobile);
		});
	}

	if (userIDs && userIDs !== null) {
		userIDs.forEach(function(userID, index){
			cinReq.addHeader(CINRequestConts.INDEX, userID);
		});
	}
	var uuid = UUID.randomUUID();
	cinReq.addHeader(CINRequestConts.MESSAGEID, uuid);
	
	var messageStatus = MessageStatus.getValue(false, false, true, false);

	if (messageStatus !== 0) {
		cinReq.addHeaderInt32(CINRequestConts.STATUS, messageStatus);
	}

	if (msgType !== MessageConsts.TYPE_TEXT) {
		cinReq.addHeaderInt32(CINRequestConts.TYPE, msgType);
	}

	if((msgType == MessageConsts.TYPE_TEXT 
		|| msgType == MessageConsts.TYPE_CARD
		|| msgType == MessageConsts.TYPE_FREE_SMS)) {

		uuid =  UUID.randomUUID();

		// message = JIOUtils.getBytes(message);
		
		var bodyBytes = EncryptionUtils.encrypt(message, uuid);

		cinReq.addHeader(CINRequestConts.ENCRYPT, uuid);
		
		cinReq.addHeader(CINRequestConts.SERVERDATA, instance.getToken());

		cinReq.addBody(CINRequestConts.BODY, bodyBytes);
	} else {
		cinReq.addBody(CINRequestConts.BODY, message);
	}
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new ChatProxyCallback(callback, cinReq));
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.typing = function(peerId, callback) {
	if(!peerId || peerId === null){
		JIOUtils.sendError(ErrorCodes.NO_PEERID, "Provide peerId", callback);
		return;
	}	
	var cinReq = new CINRequest(CINRequestConts.TYPING);
	cinReq.addHeader(CINRequestConts.TO, peerId);
	cinReq.setCallback(callback);	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.clearChat = function(to, from, callback){
	if(!to || to === null || !from || from === null){
		JIOUtils.sendError(ErrorCodes.NO_USER_ID, "", callback);
		return;
	}
	var cinReq =  new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.EVENT_CLEAR_RECORDS);
	
	cinReq.addHeader(CINRequestConts.FROM, from);
	cinReq.addHeader(CINRequestConts.TO, to);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback, ErrorCodes.CLEAR_CHAT));
	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.chat = function(contactNumber, message, callback) {
	array = new Array();
	array.push(contactNumber);
	this.sendRawMessage(null, array, MessageConsts.TYPE_TEXT, message, callback);
};
	
JIOClient.prototype.logOff = function(callback) {
	instance = UserModel.getInstance();

	var cinReq = new CINRequest(CINRequestConts.LOGON, CINRequestConts.EVENT_LOGOFF);
	cinReq.addHeader(CINRequestConts.FROM,instance.getUserID()); // User id for testing
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(callback);
	this.getCINClient().send(cinReq);
};

//----------------PhoneBook------------------------

JIOClient.prototype.contactSync = function(phoneBook,isUploadAll,isLast,callback){
	var cinReq = new CINRequest(CINRequestConts.SERVICE,CINRequestConts.EVENT_GET_USERID);
	var instance = UserModel.getInstance();

	cinReq.addHeaderString(CINRequestConts.VERSION, "2.1.7");
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderInt64(CINRequestConts.INDEX, CinBase64.getByte(isUploadAll));

	if(isLast == 1)
		cinReq.addHeaderInt64(CINRequestConts.SYNC_BATCH, CinBase64.getByte(isLast));

	phoneBook.forEach(function(eachContact, index) {
		var cinMessage = new CINRequest(CINRequestConts.SERVICE);
		cinMessage.addHeaderString(CINRequestConts.GET_USER_ID_BODY_PHONE, eachContact.mobileNo);
		cinMessage.addHeaderString(CINRequestConts.GET_USER_ID_BODY_NAME, eachContact.name);
		cinReq.addBody(CINRequestConts.BODY, cinMessage.convert());
	});	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new PhoneUploadProxyCallback(callback));
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.deleteContact = function(list, callback) {
	var instance = UserModel.getInstance();
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_DELETE_CONTACT_LIST);
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());//pass USERID

	list.forEach(function(mobileNo) {
		if(mobileNo && mobileNo.length > 0)
			cinReq.addHeader(CINRequestConts.MOBILENO, mobileNo);//check version					
    });

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback, ErrorCodes.DELETE_CONTACT));
	//cinReq.setCallback(new DeleteContactProxyCallback(callback));	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.handleBlackList = function(list,isAdd, callback){
	var cinRequest = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_HANDLE_BLACK_LIST);
	var instance = UserModel.getInstance();
	cinRequest.addHeader(CINRequestConts.FROM, instance.getUserID());
	if(isAdd == 1)
		cinRequest.addHeaderInt8(CINRequestConts.TYPE, CINRequestConts.HANDLE_ADD);
	else if(isAdd == 0)
		cinRequest.addHeaderInt8(CINRequestConts.TYPE, CINRequestConts.HANDLE_REMOVE);
	else if(isAdd == 2)
		cinRequest.addHeaderInt8(CINRequestConts.TYPE, CINRequestConts.HANDLE_DELETE_ALL);

	list.forEach(function(eachContact, index) {
		var cinMessage = new CINRequest(CINRequestConts.SERVICE);
		cinMessage.addHeader(CINRequestConts.HEADER_USER_ID, eachContact.userId);
		if(eachContact.name && eachContact.name.length > 0)
			cinMessage.addHeaderString(CINRequestConts.HEADER_NAME, eachContact.name);		
		cinMessage.addHeaderString(CINRequestConts.HEADER_MOBILE, eachContact.mobileNo);
		cinRequest.addBody(CINRequestConts.BODY, cinMessage.convert());
	});	

	cinRequest.setCINMessageObject();
	cinRequest.setCallback(new BlackListContactProxyCallback(callback));	
	this.getCINClient().send(cinRequest);
};

JIOClient.prototype.getAllBlackListContacts= function(callback){
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_GET_BLACK_LIST);
	var instance = UserModel.getInstance();
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new BlackListContactProxyCallback(callback));	
	this.getCINClient().send(cinReq);
};

//----------------PhoneBook End------------------------


JIOClient.prototype.inviteViaEmail = function(email ,callback) {
	if(!email || email.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_EMAIL, "Provide email to proceed", callback);
		return;
	}
	instance = UserModel.getInstance();	
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.INVITE_VIA_EMAIL);
	cinReq.addHeader(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeaderString(CINRequestConts.EMAIL,email);//pass email
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new InviteProxyCallback(callback));
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.inviteViaSMS = function(phoneNumber , tinyUrl, callback) {
	if(!phoneNumber || phoneNumber.toString().length === 0){
		JIOUtils.sendError(ErrorCodes.NO_MOBILE_NO, "Provide Mobile Number", callback);
		return;
	}
	if(!tinyUrl || tinyUrl.length === 0){
		JIOUtils.sendError(ErrorCodes.NO_TINY_URL, "", callback);
		return;
	}
	instance = UserModel.getInstance();	
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.INVITE_VIA_SMS);
	cinReq.addHeader(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeaderString(CINRequestConts.MOBILENO, phoneNumber);	
	cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(tinyUrl));
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new InviteProxyCallback(callback));
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.initializeGroup = function(groupId, version, callback){
	if(!groupId || groupId === null){
		JIOUtils.sendError(ErrorCodes.NO_USER_ID, "Provide group id", callback);
		return;
	}
	instance = UserModel.getInstance();

	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_INITIALIZE);

	cinReq.addHeader(CINRequestConts.TO, groupId);
	if(version)
	 	cinReq.addHeaderInt32(CINRequestConts.VERSION, version);
	else
		cinReq.addHeaderInt32(CINRequestConts.VERSION, 1);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new GroupProxyCallback(callback));

	this.getCINClient().send(cinReq);
}

JIOClient.prototype.getGroupList = function(selfUserId, callback){
	if(!selfUserId || selfUserId === null){
		JIOUtils.sendError(ErrorCodes.NO_USER_ID, "Provide id", callback);
		return;
	}
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_GET_GROUP_LIST);
	
	cinReq.addHeader(CINRequestConts.TO, selfUserId);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new GetGroupsProxyCallback(callback));
	
	this.getCINClient().send(cinReq);
};


JIOClient.prototype.reply = function(selfId, receiverId, messageId, callback){
	if(!selfId || selfId === null){
		JIOUtils.sendError(ErrorCodes.NO_USER_ID, "Provide user id", callback);
		return;
	}
	if(!receiverId || receiverId === null){
		JIOUtils.sendError(ErrorCodes.NO_PEERID, "Provide receiver id", callback);
		return;
	}
	if(!messageId || messageId === null){
		JIOUtils.sendError(ErrorCodes.NO_MESSAGE_ID, "Provide message id", callback);
		return;
	}
	var cinReq = new CINRequest(CINRequestConts.REPLY);
	cinReq.addHeader(CINRequestConts.FROM, selfId);
	cinReq.addHeader(CINRequestConts.TO, receiverId);
	cinReq.addHeader(CINRequestConts.MESSAGEID, messageId);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);		
	cinReq.setCallback(new ReadReplyProxyCallback(callback));	
	this.getCINClient().send(cinReq);
};


JIOClient.prototype.readReply = function(selfId, peerId, lastSeq, unreadCount, type, callback){
	if(!selfId || selfId === null){
		JIOUtils.sendError(ErrorCodes.NO_USER_ID, "Provide user id", callback);
		return;
	}
	if(!peerId || peerId === null){
		JIOUtils.sendError(ErrorCodes.NO_PEERID, "Provide receiver id", callback);
		return;
	}

	var cinReq = new CINRequest(CINRequestConts.READ_REPLY);
	//cinReq.setRequestEvent(CINRequestConts.EVENT_GET_GROUP_LIST);
	cinReq.addHeader(CINRequestConts.FROM,selfId);
	cinReq.addHeader(CINRequestConts.TO, selfId);
	cinReq.addHeader(CINRequestConts.INDEX, peerId);
	cinReq.addHeaderInt64(CINRequestConts.CREDENTIAL, unreadCount);

	if(lastSeq > 0){
		cinReq.addHeaderInt64(CINRequestConts.KEY, lastSeq);	
	}

	if(type === CINRequestConts.READ_REPLY_TYPE_DELETE_SESSION){
		cinReq.addHeaderInt32(CINRequestConts.TYPE, type);	
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);		
	cinReq.setCallback(new ReadReplyProxyCallback(callback));	
	this.getCINClient().send(cinReq);
};


JIOClient.prototype.getGroupInfo = function(groupId, callback){
	if(!groupId || groupId === null){
		JIOUtils.sendError(ErrorCodes.NO_USER_ID, "Provide group id", callback);
		return;
	}
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_GET_GROUP_INFO);

	cinReq.addHeader(CINRequestConts.TO, groupId);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new GroupProxyCallback(callback));

	this.getCINClient().send(cinReq);
};


JIOClient.prototype.createGroup = function(userId, selfName, groupTitle, userIDs, callback) {

	instance = UserModel.getInstance();
	var cinReq = new CINRequest(CINRequestConts.GROUP, CinBase64.getByte(0x00));
	if(!userId || userId === null){
		cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
		cinReq.addHeader(CINRequestConts.TO, instance.getUserID());
	}else{
		cinReq.addHeader(CINRequestConts.FROM, userId);
		cinReq.addHeader(CINRequestConts.TO, userId);
	}
	if(!selfName || selfName.length == 0){
		JIOUtils.sendError(ErrorCodes.NO_USER_NAME, "Provide your name", callback);
		return;
	}
	if(!groupTitle || groupTitle.length == 0 || groupTitle.length > 16){
		JIOUtils.sendError(ErrorCodes.NO_GROUP_TITLE, "Provide your group title with not exceeding 16 characters", callback);
		return;
	}

	cinReq.addHeaderString(CINRequestConts.NAME, groupTitle);
	cinReq.addHeaderString(CINRequestConts.TYPE, selfName);

	userIDs.forEach(function(groupUserId) {
		if(groupUserId && groupUserId != null)
			cinReq.addHeader(CINRequestConts.INDEX, groupUserId);
    });

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new GroupProxyCallback(callback));
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.updateGroup = function(groupId, groupTitle, userName, callback) {
	instance = UserModel.getInstance();
	
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_UPDATE_GROUP);
	if(groupId && groupId !== null && groupTitle && groupTitle.length > 0 && userName && userName !== null){
		cinReq.addHeader(CINRequestConts.TO, groupId);	
		cinReq.addHeaderString(CINRequestConts.NAME, groupTitle);	
		cinReq.addHeaderString(CINRequestConts.INDEX, userName);
	}		

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new GroupProxyCallback(callback));

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.joinGroup = function(callback){
	
};



JIOClient.prototype.updateGroupSet = function(userId, groupId, callback) {
	instance = UserDB.getInstance();
	
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_UPDATE_GROUP_SET);
	
	cinReq.addHeader(CINRequestConts.FROM, userId);
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.addHeaderString(CINRequestConts.TOKEN, instance.getToken());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new GroupProxyCallback(callback));
	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.updateGroupMessageAcceptSet = function(grupId, token, callback) {
	instance = UserDB.getInstance();

	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_UPDATE_GROUP_MESSAGE_ACCEPT_SET);
		
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, grupId);
	cinReq.addHeaderString(CINRequestConts.TOKEN, token);
	//cinReq.addHeader(CINRequestConts.INDEX,userName);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new GroupProxyCallback(callback));

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.deleteMessage = function(peerId, messageIds, albumMessageIds, sessionID, callback) {
	var cinReq = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.EVENT_DELETE_MSG);

	cinReq.addHeader(CINRequestConts.TO, peerId);//may be groupID

	if(messageIds && messageIds !==null){
		messageIds.forEach(function(messageId) {
			cinReq.addHeader(CINRequestConts.VERSION, messageId);//check version
	    });
	}

	if(albumMessageIds && albumMessageIds !==null){
		albumMessageIds.forEach(function(messageId) {
			cinReq.addHeader(CINRequestConts.MESSAGEID, messageId);//check version						
	    });
	}

	cinReq.addHeader(CINRequestConts.TOKEN, sessionID);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new DeleteMessageProxyCallback(messageIds,callback));


	this.getCINClient().send(cinReq);
};

JIOClient.prototype.transferGroupAdmin = function(groupId, newAdminUserId, callback) {
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_TRANSFER_GROUP_ADMIN);
	
	cinReq.addHeader(CINRequestConts.TO, groupId);
	
	cinReq.addHeader(CINRequestConts.INDEX, newAdminUserId);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new GroupAdminProxyCallback(callback));

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.groupInvite = function(groupId, name, profiles, callback) {

	instance = UserModel.getInstance();
	
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_INVITE_GROUP);

	cinReq.addHeader(CINRequestConts.TO, groupId);

	cinReq.addHeaderString(CINRequestConts.NAME, name); //inviter name


	var groupInfo = new CINRequest(CINRequestConts.GROUP);

	profiles.forEach(function(profile) {
		groupInfo.addHeaderString(CINRequestConts.GROUP_USER_NAME, profile.getName());
		groupInfo.addHeader(CINRequestConts.GROUP_USER_USERID, profile.getUserID());
    });

	cinReq.addBody(CINRequestConts.BODY, groupInfo.convert());
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new GroupProxyCallback(callback));
	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.enterGroup = function(groupId, selfName, sourceId, sourceName) {
	
	cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_ENTER_GROUP);

	cinReq.addHeader(CINRequestConts.TO, groupId);

	cinReq.addHeaderName(CINRequestConts.NAME, selfName);

	cinReq.addHeader(CINRequestConts.TYPE, sourceId);

	cinReq.addHeaderString(CINRequestConts.INDEX, sourceName);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback, 200));

	this.getCINClient().send(cinReq);
};

JIOClient.prototype.quitGroup = function(groupId, selfName, callback) {

	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_QUIT_GROUP);
	
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.addHeaderString(CINRequestConts.NAME, selfName); //quiting user name
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new GroupProxyCallback(callback));
	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.kickFromGroup = function(groupId, userId, userName, callback) {
	var cinReq = new CINRequest(CINRequestConts.GROUP, CINRequestConts.EVENT_QUIT_GROUP);
	instance = UserModel.getInstance();
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.addHeaderString(CINRequestConts.NAME, userName); //kicked user name
	
	var groupInfo = new CINRequest(CINRequestConts.GROUP);

	groupInfo.addHeader(CINRequestConts.GROUP_USER_USERID, userId);//userId who is to be kicked
	groupInfo.addHeader(CINRequestConts.GROUP_USER_NAME, userName);
	cinReq.addBody(CINRequestConts.BODY, groupInfo.convert());
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new GroupProxyCallback(callback));
	
	this.getCINClient().send(cinReq);
};


JIOClient.prototype.setLastSeenVisible = function(isVisiable, callback) {
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_SET_LAST_SEEN);
	cinReq.addHeaderInt32(CINRequestConts.STATUS, isVisiable===true ? 1 : 0);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback,300));
	
	this.getCINClient().send(cinReq);
}

JIOClient.prototype.setMessagePreview = function(isVisiable, callback) {
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_SET_MESSAGE_PREVIEW);

	cinReq.addHeaderInt32(CINRequestConts.STATUS, isVisiable===true ? 1 : 0);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback,400));
	
	this.getCINClient().send(cinReq);
}

JIOClient.prototype.setMessageReadReply = function(isOpen, callback) {
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_SET_MESSAGE_READREPLY);
	
	cinReq.addHeaderInt32(CINRequestConts.STATUS, isOpen===true ? 1 : 0);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback,500));
	
	this.getCINClient().send(cinReq);
}

JIOClient.prototype.setSocialContentNotify = function(isReceive, callback) {
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_SET_SOCIAL_NOTIFY);
	
	msg = new CINRequest(CINRequestConts.SERVICE);
	msg.addHeaderInt32(CinBase64.getByte(0x0A), CINRequestConts.TYPE_RECEIVE_CONTENT);
	msg.addHeaderInt32(CinBase64.getByte(0x12), isReceive===true ? 1 : 0);
	cinReq.addBody(CINRequestConts.BODY, msg.convert());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback,500));
	
	this.getCINClient().send(cinReq);
}

JIOClient.prototype.getFreeSmsQuota = function(callback) {
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_GET_FREE_SMS_QUOTA);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback({
		onSuccess: function(cinMessage){
			var chatMessage = new ChatMessage();
			chatMessage.dayQuota = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.KEY));
			chatMessage.monthQuota = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.INDEX));
			callback.onSuccess(chatMessage);
		},
		onError: function(){
			JIOUtils.sendError(500, "Unable to get sms quota", callback);
		}
	});
	
	this.getCINClient().send(cinReq);
}

JIOClient.prototype.setDND = function(isOpen, dndStart, dndInterval, callback) {
	var cinReq = new CINRequest(CINRequestConts.SERVICE, CINRequestConts.EVENT_SET_DND);

	cinReq.addHeaderInt32(CINRequestConts.TYPE, isOpen ? 1 : 0);

	if (isOpen) {
		cinReq.addHeaderInt64(CINRequestConts.DATETIME, dndStart);
		cinReq.addHeaderInt64(CINRequestConts.EXPIRE, dndInterval);
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback,500));
	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.sendFeedback = function(content, version, callback){
	if(!content || content == undefined){
		JIOUtils.sendError(ErrorCodes.NO_CONTENT, "Provide your feedback", callback);
		return;
	}
	if(content.length > 200){
		JIOUtils.sendError(ErrorCodes.CONTENT_LIMIT, "Text limit is 200", callback);
		return;
	}
	var cinReq = new CINRequest(CINRequestConts.REPORT, CINRequestConts.EVENT_FEEDBACK);
	instance = UserModel.getInstance();
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderInt8(CINRequestConts.VERSION, version);
	cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(content));

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	this.getCINClient().send(cinReq);
};

JIOClient.prototype.uploadData = function(key, type, status, userIDs, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.EVENT);
	cinReq.addHeaderString(CINRequestConts.KEY, key);
	cinReq.addHeader(CINRequestConts.TYPE, type); // type is long
	cinReq.addHeaderInt8(CINRequestConts.STATUS, status); //  0 - yes , 1 - no 

	userIDs.forEach(function(user) {
		cinReq.addHeader(CINRequestConts.INDEX, user);
    });
    cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	CINClient.getInstance().send(cinReq);
};
