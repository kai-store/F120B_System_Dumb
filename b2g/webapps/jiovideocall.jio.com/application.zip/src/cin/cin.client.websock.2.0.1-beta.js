/**
* Supports multiple callbacks and nested callbacks.
* Auto logon and Challenge req.
* Support for multiple CMP address.
* Fixed random request not quequing issue.
*/
function CINClient(ipAddress){
    this.local_cseq_value = 1;
    this._isLogonRequired = true;
    this.webSockIP = ipAddress;
}
/**
 * Class is for creating CINResponse, and setting an appropriate values.
 */
CINClient.CONECTTING = 0;
CINClient.INIT_SOCK = -1;
CINClient.OPENED = 1;
CINClient.CLOSED = 2;
CINClient.ERROR = 3;
CINClient.SOCK_READY = 4;

//32 Bit Integer...
CINClient.MAX_CSEQ_VALUE = 2147483644;

CINClient.prototype = {
    constructor: CINClient,
    instance: null,
    callbackQ: new Array(),
    webSockIP : null,
    lastReqTime:0,
    //_socket: null,
    
    _getSocket: function(){
        if (!this.socket){

            if(!this.reqQueue){
                 this.reqQueue = new Array();
            }
            this.isReadyState = CINClient.CONECTTING;
            this.socket = this.initSock();
        }
        return this.socket;
    },
    initSock: function(){
        try{
            var ws = new Websock();
            ws.open(this.webSockIP);
            // ws.open('ws://10.87.68.105:8887');

            var that = this;
            ws.on('open', function () {
                that.isReadyState = CINClient.OPENED;
                var instance = UserModel.getInstance();

                if(that._isLogonRequired === true && instance.isLoggedIn() === true){
                    that.processCheckCredentials();
                    return;
                }
                that.isReadyState = CINClient.SOCK_READY;
                that.processQueue();

            });
            
            // window.addEventListener("offline", function(e) {
            //     debugger;
            //     var event={"code":1000};
            //     that.closeCINSocket(event)
            // }, false);

            ws.on('close', function () {
                var event={"code":1000};                
                that.closeCINSocket(event);
            });
            ws.on('error', function(event){
                console.log("[Error] "+event);
            });
            var that = this;
            ws.on('message', function(str) {
                // debugger;
                that.parseResponse(str);
            });
            
            return ws;
        } catch(e){
            // debugger;
            console.log("[Websock] Error:",e);        
        }
        return null;
    },
    parseResponse: function(str){
        try{
            var that = this;
            var callback = that.cinRequest.getCallback();

            console.log("Before CINResponse.getCINMessage ", str.length);
            var cinMessage = CINResponse.getCINMessage(str, callback);
            if(!cinMessage){
                console.log("Something went wrong...");
                return;
            }
            callback = that.pullCallback(cinMessage, callback);

            cinMessage._setCallback(callback);
            
            // console.log(cinMessage);
            var isCINObjectOut = that.cinRequest.isCINMessageObject();

            if(!cinMessage.isServerRequest()){
                cinMessage = undefined;
                that.processCINResponce(str, callback, isCINObjectOut);
                str = undefined;
                callback = undefined;
                return;
            }
            str = undefined;
            var cinRequestProxyCallback = new CinRequestProxyCallback(cinMessage);
            cinRequestProxyCallback.processRequest();
            cinRequestProxyCallback = undefined;
            callback = undefined;
        }catch(e){
            console.log("****** Error ******** "+e);
            console.log(e);
        }
    },
    /**
     * Method will send req.
     */
    send: function(cinRequest){
        var localSocket = this._getSocket();
        if(localSocket == null || localSocket == undefined){
            this.reqQueue.push(cinRequest);            
            this.closeCINSocket(event); 
            return;    
        }
        this.cinRequest = cinRequest;

        var that = this;

        if(this.isReadyState !== CINClient.SOCK_READY && cinRequest.getIsRefeshAfterLogon() === true){
            this.reqQueue.push(cinRequest);
            return;
        }

        localSocket.on('close', function(evt){
            // debugger;
            var event={"code":1000};            
            that.closeCINSocket(evt, cinRequest);
        });
        
        if(this.isReadyState === CINClient.SOCK_READY || 
            (this.isReadyState === CINClient.OPENED && !cinRequest.getIsRefeshAfterLogon())){
            console.log("Reqest to be sent, ["+this.webSockIP+"]");
            cinRequest = this.pushCallback(cinRequest);
            localSocket.send(cinRequest.convert());
            return;
        }
       
       if(cinRequest.isMaxRetryReached() === true){
            //Call error method, for error callback
            var callback = cinRequest.getCallback();
            this.sendErrorCallback(-1, callback);
        }

        this._waitForConnection(cinRequest);
        return false;
   },

    _waitForConnection: function(cinRequest){
        var that = this;
        //For incremental retry
        var delay = 1000 * (cinRequest.getRetryCount()+1);
        var timeOut = setTimeout(function () {
            if(cinRequest.isMaxRetryReached() === true){
                return;
            }
            cinRequest.retry();
            var result = that.send(cinRequest);

            // if(result === true){
            //     clearTimeout(timeOut);
            // }
        }, delay);
    },
    closeCINSocket: function(evt, cinRequest){
        // debugger;
        this.closeSock();
        this.isReadyState = CINClient.CLOSED; 
        var callback = null;
        if(cinRequest){
            callback = cinRequest.getCallback();
        }
        this.sendErrorCallback(evt, callback);
        this.socket = undefined;
    }
};
/**
 * Method will return web sock instance.
 * @args
 */
CINClient.getInstance = function(ipAddress){
    if(!ipAddress || ipAddress === null || ipAddress.length === 0){
        new Error("IP Address should not be an empty.");
        return;
    }

    if(!CINClient.instance){
        CINClient.instance = new Array();
    }
    ipAddress = JIOUtils.getSockAddess(ipAddress);
    var cinClientObject = CINClient.instance[ipAddress];
    if(!cinClientObject || cinClientObject === null){
        cinClientObject = new CINClient(ipAddress);
        CINClient.instance[ipAddress] = cinClientObject;
    }
    return cinClientObject;
};

CINClient.prototype.setLogonRequired = function(logonRequired){
    this._isLogonRequired = logonRequired;
}

CINClient.prototype.pushCallback = function(cinRequest){
    var seq = this.local_cseq_value;

    if(!cinRequest.containsHeader(CINRequestConts.CSEQUENCE)){
        cinRequest.addHeaderInt64(CINRequestConts.CSEQUENCE, seq);
    } else{
        seq = cinRequest.getInt(CINRequestConts.CSEQUENCE);
    }
    if(!isFinite(seq)){
        if(!isFinite(this.local_cseq_value)){
            this.local_cseq_value = 1;
        }
        seq = this.local_cseq_value;
    }
    seq = parseInt(seq);
    console.log("[Seq]:::::: "+seq);
    this.callbackQ.push({"cseq":seq, "callback":cinRequest.getCallback(), "args":cinRequest.getArgs()});

    this.local_cseq_value++;
    this.local_cseq_value = this.local_cseq_value % CINClient.MAX_CSEQ_VALUE;
    return cinRequest;
};
/**
 * This method will return, object.
 * @method
 * @argument cinResponse - response
 * @argument localCallback - callback
 */
CINClient.prototype.pullCallback = function(cinResponse, localCallback){
    if(!cinResponse){
        return localCallback;
    }
    var cseq = cinResponse.getHeader(CINRequestConts.CSEQUENCE);
    if(cseq === ""){
        return localCallback;
    }
    // this.localCallback = localCallback;
    // var that = this;
    var cseq = JIOUtils.toLong(cseq);
    // this.callbackQ.forEach(function(callbackQObj, index){
    //     if(callbackQObj.cseq === cseq){
    //         that.callbackQ.splice(index, 1);
    //         that.localCallback = callbackQObj.callback;
    //         console.log("[WebSock] Callback found....");
    //         return;
    //     }
    // });
    var isFound=false;
    for(var index=0;index<this.callbackQ.length;index++){
        callbackQObj = this.callbackQ[index];
        if(callbackQObj.cseq === cseq){
            this.callbackQ.splice(index, 1);
            localCallback = callbackQObj.callback;
            isFound=true;
            break;
        }
    };
    return localCallback;
};

CINClient.prototype.processCINRequest = function(cinMessage, callback, isCinObject){
    if(!isCinObject){
        isCinObject = false;
    }
};

CINClient.prototype.processCINResponce = function(str, callback, isCinObject){
    if(callback == null || !callback){
        return;
    }

    if(!isCinObject){
        isCinObject = false;
    }

    if(isCinObject){
        var cinMessage = CINResponse.getCINMessage(str, callback);
        if (cinMessage.isMethod(HTTPRequestConts.OK)){
            callback.onSuccess(cinMessage);
        }else{
            JIOUtils.sendError(100, cinMessage.getBody(), callback, cinMessage.getMethod());
            JIOUtils.trackEvent(cinMessage.getMethod(), cinMessage.getBody(), callback);
        }
        cinMessage = undefined;
        return;
    }
    // cinRes = new CINResponse(callback);
    // cinRes.convert(str);
};

CINClient.prototype.processQueue = function(){
 var that = this;
 this.reqQueue.forEach(function(req, index){
        if(that.isReadyState !== CINClient.SOCK_READY){
            return;
        }
        that.send(req);
  });
  this.resetRequestQ();
};

CINClient.prototype.processCheckCredentials = function(){
    var that = this;
    JIOClient.getInstance().challenge(new ChallengeProxyCallback({
        onSuccess: function(data){
            //UserModel.getInstance().setPushToken(null);
            that.onChallengeSuccess(data);
        },
        onError: function(data){
            // JIOUtils.sendError(100, cinMessage.getBody(), callback);
        }
    }, false));
}

CINClient.prototype.onChallengeSuccess = function(data){

    if(this.isReadyState !== CINClient.OPENED){
        return;
    }

    this.isReadyState = CINClient.SOCK_READY;
    var that = this;
    // for(index in  this.reqQueue){
    this.reqQueue.forEach(function(req, index){
        if(that.isReadyState !== CINClient.SOCK_READY || req.setRequestMethod() === CINRequestConts.LOGON){
            return;
        }
        // var req = that.reqQueue[index];
        callback = req.getCallback();

        var isRefeshAfterLogon = req.getIsRefeshAfterLogon();
        if(isRefeshAfterLogon !== true){
            callback.onSuccess(undefined, data);
            return;
        }
        var args = req.getArgs();
        if(args === null || !args){
            JIOUtils.sendError(ErrorCodes.REFRESH_REQUEST, "Please refresh page.", callback);
            return;
        }
        var argsArray = new Array();
        for(var prop in args) {
            argsArray.push(args[prop]);
        }
        args.callee.apply(args, argsArray);
            // continue;
    // }
    });
    this.resetRequestQ();
}

CINClient.prototype.resetRequestQ = function(){
    this.reqQueue = new Array();
}

CINClient.prototype.resetCallbackQ = function(){
    this.callbackQ = new Array();
}

CINClient.prototype.setSocketCallback = function(callback){
    this.socketCallback = callback;
}

CINClient.prototype.sendErrorCallback = function(event, callback){
    console.log("Socket close.... Above !callback");
    // if(!callback){
    //     return;
    // }
    console.log("Socket close.... Below !callback");
   var reason;
    // See http://tools.ietf.org/html/rfc6455#section-7.4.1
    switch (event.code){
        case 1000:
            reason = "Normal closure, meaning that the purpose for which the connection was established has been fulfilled.";
            reason = "No internet, please check your connection.";
            break;

        case 1001:
            reason = "An endpoint is \"going away\", such as a server going down or a browser having navigated away from a page.";
            reason = "No internet, please check your connection.";            
            break;

        case 1002:
            reason = "An endpoint is terminating the connection due to a protocol error";
            reason = "No internet, please check your connection.";
            break;

        case 1003:
            reason = "An endpoint is terminating the connection because it has received a type of data it cannot accept (e.g., an endpoint that understands only text data MAY send this if it receives a binary message).";
            reason = "No internet, please check your connection.";
            break;

        case 1004:
            reason = "Reserved. The specific meaning might be defined in the future.";
            reason = "No internet, please check your connection.";
            break;

        case 1005:
            reason = "No status code was actually present.";
            reason = "No internet, please check your connection.";            
            break;

        case 1006:
           reason = "The connection was closed abnormally, e.g., without sending or receiving a Close control frame";
           reason = "No internet, please check your connection.";
           break;

        case 1007:
           reason = "An endpoint is terminating the connection because it has received data within a message that was not consistent with the type of the message (e.g., non-UTF-8 [http://tools.ietf.org/html/rfc3629] data within a text message).";
           reason = "No internet, please check your connection.";
           break;

        case 1008:
            reason = "An endpoint is terminating the connection because it has received a message that \"violates its policy\". This reason is given either if there is no other sutible reason, or if there is a need to hide specific details about the policy.";
            reason = "No internet, please check your connection.";
            break;

        case 1009:
           reason = "An endpoint is terminating the connection because it has received a message that is too big for it to process.";
           reason = "No internet, please check your connection.";
           break;

        case 1010:  // Note that this status code is not used by the server, because it can fail the WebSocket handshake instead.
            reason = "An endpoint (client) is terminating the connection because it has expected the server to negotiate one or more extension, but the server didn't return them in the response message of the WebSocket handshake. <br /> Specifically, the extensions that are needed are: " + event.reason;
            reason = "No internet, please check your connection.";
            break;

        case 1011:
            reason = "A server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.";
            reason = "No internet, please check your connection.";
            break;

        case 1015:
            reason = "The connection was closed due to a failure to perform a TLS handshake (e.g., the server certificate can't be verified).";
            reason = "No internet, please check your connection.";
            break;
        case -1:
            reason = "Reached max retries.";
            break;

        default:
            reason = "Unknown reason";
    }
    console.log("Socket close.... Afer switch....");
    console.log("Trying to connect.... Above Navigator...");
    // var initCallback  = JIOClient.getInstance().getInitCallback();
    // if(event.code === 1000 && UserModel.getInstance().isLoggedIn()){
    //     console.log("Trying to reconnect account");
    //     JIOClient.getInstance().keepAliveReq();
    // }
    console.log("Socket close.... Navigator");
    // if(callback){
    //     JIOUtils.sendError(event.code, reason, callback);        
    // }
    this.reqQueue.forEach(function(req, index){
        JIOUtils.sendError(event.code, reason, req.getCallback());
    });
    this.resetRequestQ();
    
    if(this.socketCallback && this.socketCallback !== null){
        this.socketCallback.onSocketClose(event.code, reason);
    }

    // if(event.code === 1000 && navigator && navigator.onLine && UserModel.getInstance().isLoggedIn()){
    //     console.log("Trying to reconnect account");
    //     JIOClient.getInstance().getProfile(new EmptyResponseCallback(null));
    // }

    
    var rtmCallback = RTMManager.getInstance().getCallback();
    if(rtmCallback && rtmCallback.inCallCallback && typeof rtmCallback.inCallCallback.onError === "function"){
         JIOUtils.sendError(event.code, reason, rtmCallback.inCallCallback);
    }

    rtmCallback = RTMManager.getInstance().getInCallback();
    if(rtmCallback && typeof rtmCallback.onError === "function"){
         JIOUtils.sendError(event.code, reason, rtmCallback);
    }
}

CINClient.prototype.closeSock = function(){
    // debugger;
    if(this.isReadyState !== CINClient.CLOSED){
        try{
           var sock =  CINClient.instance[this.webSockIP].socket;
            sock.workerClose();
            sock.close();
        }catch(e){
            console.log("Socket close::"+e);
        }
    }
    CINClient.instance[this.webSockIP] =  undefined;
}
