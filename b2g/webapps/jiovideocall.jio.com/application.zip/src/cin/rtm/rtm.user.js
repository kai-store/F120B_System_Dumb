function RTMUser() {
	this.userID = null;
	this._isInSession = true;
	this._isOnShow = false;
	this.videoCapability = -1;
	this.mobileNumber = null;
	this.name = null;
	this.isCreator = false;
}

RTMUser.prototype.init = function(cinMessage){
	this.userID = cinMessage.getHeader(CINRequestConts.INDEX);
	this._isInSession = cinMessage.getInt(CINRequestConts.STATUS) === 2;
	
	if(cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		this.videoCapability = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}

	if(cinMessage.containsHeader(CINRequestConts.TYPE)) {
		this._isOnShow = cinMessage.getHeader(CINRequestConts.TYPE).getInt64() === 1;
	}
}

RTMUser.prototype.setUserID = function(userID) {
	this.userID = userID;
};
RTMUser.prototype.getUserID = function() {
	return this.userID;
};

RTMUser.prototype.setName = function(name) {
	this.name = name;
};
RTMUser.prototype.getName = function() {
	return this.name;
};

RTMUser.prototype.setUserID = function(userID) {
	this.userID = userID;
};
RTMUser.prototype.getUserID = function() {
	return this.userID;
};

RTMUser.prototype.setMobileNumber = function(mobileNumber) {
	this.mobileNumber = mobileNumber;
};
RTMUser.prototype.getMobileNumber = function() {
	return this.mobileNumber;
};

RTMUser.prototype.setIsInSession = function(_isInSession) {
	this._isInSession = _isInSession;
};
RTMUser.prototype.isInSession = function() {
	return this._isInSession;
};

RTMUser.prototype.isOnShow = function(_isOnShow) {
	this._isOnShow = _isOnShow;
};
RTMUser.prototype.setIsOnShow = function(_isOnShow) {
	return this._isOnShow;
};

RTMUser.prototype.setVideoCapability = function(videoCapability) {
	this.videoCapability = videoCapability;
};
RTMUser.prototype.getVideoCapability = function() {
	return this.videoCapability;
};

