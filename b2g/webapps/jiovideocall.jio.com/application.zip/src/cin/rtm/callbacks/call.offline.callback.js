function OfflineCallCallback(callback){
    this.uiCallback = callback;
}

OfflineCallCallback.prototype = {
    onSuccess: function(cinMessage){
        var cinBody = cinMessage.getBodys();
        var callLogs = new Array();
        var instance = JIOClient.getInstance();

        cinBody.forEach(function(callLogCin){
            var contactResponse = CINResponse.getCINMessage(callLogCin.val, null, false);
            var callLog = new Calllog();
            callLog.init(contactResponse);
            callLogs.push(callLog);
        });
        RTMManager.getInstance().clearOfflineCallLogs();
        var offlineCallback = instance.getOfflineCallback();
		if(offlineCallback && offlineCallback !== null){
			offlineCallback.onCallLogsRecived(callLogs);
            return;
		}
        if(this.uiCallback){
            this.uiCallback.onSuccess(callLogs);
        }
    },
    onError: function(error){
        if(this.uiCallback){
            JIOUtils.sendError(100, error, this.uiCallback);
        }
    }
}
