function HDCallProxyCallback(callback, index) {
	this.callback = callback;
	if(!index){
		index=-1;
	}
	this.index = index;
}

HDCallProxyCallback.prototype = {
	onSuccess: function(cinMessage, extraArgs){
		// debugger;
		rtmSession = RTMSession.getInstance();
		switch(this.index){
			case -1:
				// this.callback.onRingCall(cinMessage, arguments[1]);
				break;

			case 1:
				//Wait for turn info;
				this.index = 2;
				break;
				
			case 2:
				//Create session after hdCall created....
				// hdCall = rtmSession.getHDCall();
				// this.index = 3;
				// RTMManager.getInstance().createSession(hdCall, this);
				// break;

			// case 3:
				//Invite user...
				var userIds = new Array();
				userIds.push(cinMessage.getTo()); 
				// debugger;
				var hdCall = RTMSession.getInstance().getHDCall(cinMessage.getCallId());
				hdCall.userIds = userIds;
				RTMManager.getInstance().invite(cinMessage, this);
				this.index = -1;
				return;
		}
	},
	onError: function(cinMessage){
		// debugger;
		var callback = this.callback;
		if(!callback){
			callback = RTMManager.getInstance().getCallback().inCallCallback;
		}
		JIOUtils.sendError(100, cinMessage, callback);
	}
};

HDCallProxyCallback.prototype.getCallback = function(){
	return this.callback;
}

function AutoCreateSessionCallback(callback){
	this.autoCreateSessionCallback = callback;
}
AutoCreateSessionCallback.prototype = {
	onSuccess: function(hdCall){
		RTMManager.getInstance().setDeviceInfoRequest(hdCall, this);
		
	},
	onError: function(cinMessage){

	}
};