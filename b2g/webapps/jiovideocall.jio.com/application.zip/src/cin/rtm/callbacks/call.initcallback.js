function CallInitCallback(){
    
};

CallInitCallback.prototype = {
    onSocketClosed: function(errCode, errMsg){

    }
};
