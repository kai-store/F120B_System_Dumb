function RTMRequestConsts(){
}

RTMRequestConsts.SESSION_TYPE_AUDIO_P2P = CinBase64.getByte(0x04);
RTMRequestConsts.HD_CALL_VERSION = "1.0";

// RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO = CinBase64.getByte(0x00);
// RTMRequestConsts.CALL_TYPE_SINGLE_VIDEO = CinBase64.getByte(0x01);
// RTMRequestConsts.CALL_TYPE_MULTI_AUDIO = CinBase64.getByte(0x02);
// RTMRequestConsts.CALL_TYPE_MULTI_VIDEO = CinBase64.getByte(0x03);

RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO = CinBase64.getByte(0x01);
RTMRequestConsts.CALL_TYPE_SINGLE_VIDEO = CinBase64.getByte(0x02);
// RTMRequestConsts.CALL_TYPE_MULTI_AUDIO = CinBase64.getByte(0x02);
// RTMRequestConsts.CALL_TYPE_MULTI_VIDEO = CinBase64.getByte(0x03);
RTMRequestConsts.BUSY_STATE_BUSY = CinBase64.getByte(0x0);
RTMRequestConsts.BUSY_STATE_HOLD = CinBase64.getByte(0x01);
RTMRequestConsts.BUSY_STATE_RINGING  = CinBase64.getByte(0x02);
RTMRequestConsts.ICE_RESTART = CinBase64.getByte(0x0C);

RTMRequestConsts.EVENT_CREATE_SESSION = CinBase64.getByte(0x01);
RTMRequestConsts.EVENT_INVITE = CinBase64.getByte(0x02);
RTMRequestConsts.EVENT_KICK_MEMBER = CinBase64.getByte(0x03);
RTMRequestConsts.EVENT_GET_SESSION_INFO = CinBase64.getByte(0x04);
RTMRequestConsts.EVENT_SWITCH_NEGOTIATION = CinBase64.getByte(0x05);
RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP = CinBase64.getByte(0x06);
RTMRequestConsts.EVENT_ENTER_SESSION = CinBase64.getByte(0x07);
RTMRequestConsts.EVENT_USER_ONSHOW_APPLY = CinBase64.getByte(0x08);
RTMRequestConsts.EVENT_KEEP_OR_RESORE_SESSION = CinBase64.getByte(0x09);
RTMRequestConsts.EVENT_SWTICH_DEVICE_APPLY = CinBase64.getByte(0x0A);
RTMRequestConsts.EVENT_VIDOE_QUALITY_SETTING = CinBase64.getByte(0x0B);
RTMRequestConsts.EVENT_VIDOE_SENT_RTP_PACKAGE_COUNT = CinBase64.getByte(0x0C);
RTMRequestConsts.EVENT_VIDOE_IS_BUSY = CinBase64.getByte(0x0D);
RTMRequestConsts.EVENT_SEND_ICE_CANDIDATE = CinBase64.getByte(0x0E);
RTMRequestConsts.EVENT_JC_CALL_FEEDBACK = CinBase64.getByte(0x11);
RTMRequestConsts.EVENT_CHECK_P2P_ELIGIBILITY = CinBase64.getByte(0x12);
RTMRequestConsts.EVENT_SET_DEVICE_INFO = CinBase64.getByte(0x13);

RTMRequestConsts.FEEDBACK_QUALITY = CinBase64.getByte(0x0A);
RTMRequestConsts.FEEDBACK_SUBMIT_TYPE =CinBase64.getByte(0x17);
RTMRequestConsts.FEEDBACK_SESSION_INFO =CinBase64.getByte(0x13);
RTMRequestConsts.FEEDBACK_OTHER =CinBase64.getByte(0x20);

RTMRequestConsts.ELIGIBILITY_VERSION =CinBase64.getByte(0x15);
RTMRequestConsts.FEEDBACK_VERSION =CinBase64.getByte(0x15);

RTMRequestConsts.CALL_TYPE =CinBase64.getByte(0x1D);
RTMRequestConsts.REASON =CinBase64.getByte(0x1E);
RTMRequestConsts.MISCELLANEOUS_DETAILS =CinBase64.getByte(0x1F);

RTMRequestConsts.P2P_CALL_TYPE = CinBase64.getByte(0x16);
RTMRequestConsts.P2P_CALL_AUDIO_VIDEO_TYPE = CinBase64.getByte(0x1E);

RTMRequestConsts.VIDEO_SEND_STATS = CinBase64.getByte(0x30);
RTMRequestConsts.VIDEO_RECIVE_STATS = CinBase64.getByte(0x31);
RTMRequestConsts.VIDEO_SEND_STATS_VERSION = CinBase64.getByte(0x32);
RTMRequestConsts.VIDEO_RECIVE_STATS_VERSION = CinBase64.getByte(0x33);

RTMRequestConsts.EVENT_OFFLINE_AV_CALL_LOGS = CinBase64.getByte(0x0D);
RTMRequestConsts.EVENT_CLEAR_OFFLINE_AV_CALL_LOGS = CinBase64.getByte(0x0A);
