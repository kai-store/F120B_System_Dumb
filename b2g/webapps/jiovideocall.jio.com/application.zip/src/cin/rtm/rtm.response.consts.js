function RTMResponseConsts(){
}

RTMResponseConsts.PLATFORM_TYPE =  CinBase64.getByte(0x0B);

RTMResponseConsts.NOTIFY_INVITED = CinBase64.getByte(0x21);
RTMResponseConsts.NOTIFY_INVITED_USERS = CinBase64.getByte(0x22);
RTMResponseConsts.NOTIFY_KICK_MEMBER = CinBase64.getByte(0x23);
RTMResponseConsts.NOTIFY_SWITCH_NEGOTIATION = CinBase64.getByte(0x24);
RTMResponseConsts.NOTIFY_SWITCH_NEGOTIATION_RESP = CinBase64.getByte(0x25);
RTMResponseConsts.NOTIFY_USER_ENTER = CinBase64.getByte(0x26);
RTMResponseConsts.NOTIFY_USER_ONSHOW = CinBase64.getByte(0x27);
RTMResponseConsts.NOTIFY_KEEP_OR_RETURN_SESSION = CinBase64.getByte(0x28);
RTMResponseConsts.NOTIFY_SWITCH_DEVICE = CinBase64.getByte(0x29);
RTMResponseConsts.NOTIFY_DELETE_SESSION = CinBase64.getByte(0x2A);
RTMResponseConsts.NOTIFY_SENT_PACKAGE_COUNT = CinBase64.getByte(0x2B);
RTMResponseConsts.NOTIFY_PEER_BUSY = CinBase64.getByte(0x2C);
RTMResponseConsts.EVENT_GET_WAITED_SESSION = CinBase64.getByte(0x31);

RTMResponseConsts.NOTIFY_ICE_CANDEIDATE = CinBase64.getByte(0x2E);
RTMResponseConsts.NOTIFY_REQUIRE_DEVICE_INFO = CinBase64.getByte(0x32);
RTMResponseConsts.NOTIFY_ON_TURN_DETAILS = CinBase64.getByte(0x33);
