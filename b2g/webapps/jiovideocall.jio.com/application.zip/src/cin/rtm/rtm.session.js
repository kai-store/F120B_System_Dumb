function RTMSession() {
	this.hdCalls = new Array;
}

RTMSession.getInstance = function(){
	if(!RTMSession.instance || RTMSession.instance === null){
		RTMSession.instance = new RTMSession();
	}
	return RTMSession.instance;
}

RTMSession.prototype.initSession = function(key, address) {
	var hdCall = new HDCall();
	this.hdCalls.push(hdCall);
	// this.initSession(key,address);
};

RTMSession.prototype.setHDCall = function(hdCall) {
	for(var index=0;index<this.hdCalls.length;index++){
		var key = String(this.hdCalls[index].getKey());
		var to = String(this.hdCalls[index].getTo());
		var from =String(this.hdCalls[index].getFrom());
		var toFrom = to+from;
		var fromTo = from+to;
		if(key== String(hdCall.getKey()) || String(hdCall.getKey())==toFrom || String(hdCall.getKey())==fromTo){
			this.hdCalls[index] = hdCall;
			return;
		}
		var _to = String(hdCall.getTo());
		var _from =String(hdCall.getFrom());
		var _toFrom = _to + _from;
		var _fromTo = _from + _to;
		if(_toFrom === toFrom || _toFrom === fromTo || _fromTo == toFrom || _fromTo == fromTo){
			this.hdCalls[index] = hdCall;
			return;
		}

	}
	this.hdCalls.push(hdCall);
};

RTMSession.prototype.getHDCall = function(key) {
	key = String(key);
	for(var index=0;index<this.hdCalls.length;index++){
		var hdCall = this.hdCalls[index];
		var to = String(hdCall.getTo());
		var from = String(hdCall.getFrom());
		var toFrom = to + from;
		var fromTo = from + to;
		if(key === String(hdCall.getKey()) || key === toFrom || key === fromTo || key == hdCall.getKey()){
			return this.hdCalls[index];
		}

		if(String(key) === String(hdCall.getCallId())|| key === hdCall.getCallId()){
			return this.hdCalls[index];
		}
	}
	return null;
};


RTMSession.prototype.getKey = function(){
	if(!this.hdCall || this.hdCall === null){
		return null;
	}
	return this.hdCalls[0].getKey();
};

RTMSession.prototype.getUICallback = function(key){
	var hdCall = this.getHDCall(key);
	var instance = RTMManager.getInstance();
	if(hdCall === undefined || hdCall === null){
		return instance.getCallback();
	}

	var callback = hdCall.getUICallback();
	if(callback){
		return callback;
	}

	var callback = instance.getCallback().inCallCallback;
	if(hdCall.isIncoming()){
		callback = instance.getInCallback();
	}
	return callback;
}

RTMSession.prototype.endSession = function(key){
	key = String(key);
	for(var index=0;index<this.hdCalls.length;index++){
		var hdCall = this.hdCalls[index];
		var to = String(hdCall.getTo());
		var from = String(hdCall.getFrom());
		var toFrom = to + from;
		var fromTo = from + to;
		if(key === hdCall.getKey() || key === toFrom || key === fromTo){
			this.hdCalls.splice(index, 1);
			return;
		}
	}
};

RTMSession.prototype.isSessionActive = function() {
};

RTMSession.prototype.isInitiator = function(){

}
// function RTMSession() {
// 	this.hdCall = null;
// }

// RTMSession.getInstance = function(){
// 	if(!RTMSession.instance || RTMSession.instance === null){
// 		RTMSession.instance = new RTMSession();
// 	}
// 	return RTMSession.instance;
// }

// RTMSession.prototype.initSession = function(key, address) {
// 	this.hdCall = new HDCall();
// 	this.initSession(key,address);
// };

// RTMSession.prototype.setHDCall = function(hdCall) {
// 	this.hdCall = hdCall;
// };

// RTMSession.prototype.getHDCall = function(key) {
// 	return this.hdCall;
// };


// RTMSession.prototype.getKey = function(){

// 	if(!this.hdCall || this.hdCall === null){
// 		return null;
// 	}

// 	return this.hdCall.getKey();
// };

// RTMSession.prototype.getUICallback = function(key){
// 	var hdCall = this.getHDCall(key);
// 	var instance = RTMManager.getInstance();
// 	if(hdCall === undefined || hdCall === null){
// 		return instance.getCallback();
// 	}

// 	var callback = hdCall.getUICallback();
// 	if(callback){
// 		return callback;
// 	}

// 	var callback = instance.getCallback().inCallCallback;
// 	if(hdCall.isIncoming()){
// 		callback = instance.getInCallback();
// 	}
// 	return callback;
// }

// RTMSession.prototype.endSession = function(key){
// 	this.hdCall=null;
// };

// RTMSession.prototype.isSessionActive = function() {
// };

// RTMSession.prototype.isInitiator = function(){

// }