function UserDetails() {	
	this.name = null;
	this.key = null;
	this.pasword = null;
	this.auth = null;
	this.callType = null;	
	this.deviceToken = null;
	this.version = null;
	this.session = null;
}

UserDetails.prototype.setName = function(name) {
 this.name = name ;
};

UserDetails.prototype.getName = function() {
	return this.name;
};

UserDetails.prototype.setKey = function(key) {
	this.key = key ;
};


UserDetails.prototype.getKey = function(){
	return this.key;
};

UserDetails.prototype.setAuth = function(auth){
	this.auth = auth ;
}

UserDetails.prototype.getAuth = function(){
	return this.auth;
};

UserDetails.prototype.setDeviceToken = function(deviceToken) {
	this.deviceToken = deviceToken ;
};

UserDetails.prototype.getDeviceToken = function(){
   return this.deviceToken;
}

UserDetails.prototype.setVersion = function(version) {
	this.version = version ;
};

UserDetails.prototype.getVersion = function(){
	return this.version;
}


UserDetails.prototype.setSession = function(session) {
	this.session = session;
};

UserDetails.prototype.getSession = function(){
	return this.session;
}
