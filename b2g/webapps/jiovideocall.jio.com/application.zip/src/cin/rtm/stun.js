function STUNModel(turnInfoStr) {
	var turnInfo = turnInfoStr.split(",");
	this.stunIP = turnInfo[1];
	this.turnIP = turnInfo[3];
	this.userID = turnInfo[5];
	this.password  = turnInfo[7];
	this.turnInfoStr = turnInfoStr;
}

STUNModel.prototype.setSTUNIP = function(stunIP){
	this.stunIP = stunIP;
}
STUNModel.prototype.getSTUNIP = function(){
	return this.stunIP;
}

STUNModel.prototype.setTURNIP = function(turnIP){
	this.turnIP = turnIP;
}
STUNModel.prototype.getTURNIP = function(){
	return this.turnIP;
}

STUNModel.prototype.setUserID = function(userID){
	this.userID = userID;
}
STUNModel.prototype.getUserID = function(){
	return this.userID;
}

STUNModel.prototype.setPassword = function(password){
	this.password = password;
}
STUNModel.prototype.getPassword = function(){
	return this.password;
}
STUNModel.prototype.toString = function(){
	return this.turnInfoStr;
}
