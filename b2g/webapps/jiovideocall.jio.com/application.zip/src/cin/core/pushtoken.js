function PushToken(){
    this.endPoint = null;
    this.auth = null;
    this.privateString = null;
    // this.deviceID = window.deviceId; //HTTPRequestConts.DEV_ID; Hardcoding the device Id
	this.deviceID = window.deviceId; 
	this.OEM =  HTTPRequestConts.OEM;
	this.IMEI =  HTTPRequestConts.IMEI;
	this.BRAND =  "LYF";
	this.OS_VERSION =  HTTPRequestConts.OS_VERSION;
	this.NAV_C_VER = HTTPRequestConts.GET_NAV_C_VER_VAL;
}

PushToken.prototype.clone = function(pushObject){
	if(pushObject.endPoint){
		this.setEndPoint(pushObject.endPoint);
	}
	if(pushObject.auth){
		this.setAuth(pushObject.auth);
	}
	if(pushObject.privateString){
		this.setPrivateString(pushObject.privateString);
	}
	if(pushObject.deviceID){
		this.setDeviceID(pushObject.deviceID);
	}
	if(pushObject.OEM){
		this.setOEM(pushObject.OEM);
	}
	if(pushObject.IMEI){
		this.setIMEI(pushObject.IMEI);
	}
	if(pushObject.BRAND){
		this.setBRAND(pushObject.BRAND);
	}
	if(pushObject.OS_VERSION){
		this.setOS_VERSION(pushObject.OS_VERSION);
	}
	if(pushObject.NAV_C_VER){
		this.setNAV_C_VER(pushObject.NAV_C_VER);
	}
}
PushToken.prototype.setEndPoint = function(endPoint){
    this.endPoint = endPoint;

     // mushtaq added this code 
	// indexedDB
	var daoData = {
		deviceEndPoint: this.endPoint
	};
	this.updateLDB(daoData);
}

PushToken.prototype.getEndPoint = function(){
    return this.endPoint;
}

PushToken.prototype.setAuth = function(auth){
    this.auth = auth;

    // mushtaq added this code 
	// indexedDB
	var daoData = {
		deviceAuth: this.auth
	};
	this.updateLDB(daoData);
}

PushToken.prototype.getAuth = function(){
    return this.auth;
}

PushToken.prototype.setPrivateString = function(privateString){
    this.privateString = privateString;

    // mushtaq added this code 
	// indexedDB
	var daoData = {
		devicePrivateString: this.privateString
	};
	this.updateLDB(daoData);
}

PushToken.prototype.getPrivateString = function(){
    return this.privateString;
}

PushToken.prototype.setDeviceID = function(deviceID){
    this.deviceID = deviceID;

    // mushtaq added this code 
	// indexedDB
	var daoData = {
		deviceId: this.deviceID
	};
	this.updateLDB(daoData);
}

PushToken.prototype.getDeviceID = function(){
	if(!this.deviceID || this.deviceID == ""){
		return window.deviceId;
	}
    return this.deviceID;
}

PushToken.prototype.setOEM = function(oem){
	this.OEM = oem;
}

PushToken.prototype.getOEM = function(){
	return this.OEM;
}

PushToken.prototype.setIMEI = function(imei){
	this.IMEI = imei;
}

PushToken.prototype.getIMEI = function(){
	return this.IMEI;
}
PushToken.prototype.setBRAND = function(brand){
	this.BRAND = brand;
}

PushToken.prototype.getBRAND = function(){
	return this.BRAND;
}

PushToken.prototype.setOS_VERSION = function(osVer){
	this.OS_VERSION = osVer;
}
PushToken.prototype.getOSVersion = function(){
	return this.OS_VERSION;
}

PushToken.prototype.setNAV_C_VER = function(navVer){
	this.NAV_C_VER = navVer;
}
PushToken.prototype.getNAV_C_VER = function(){
	return this.NAV_C_VER ;
}

// mushtaq added this code
PushToken.prototype.clearAll = function() {
	this.endPoint = null;
    this.auth = null;
    this.privateString = null;
    this.deviceID = window.deviceId;
	this.OEM =  null;
	this.IMEI =  null;
	this.BRAND =  null;
	this.OS_VERSION =  null;
	this.NAV_C_VER = null;
}

PushToken.prototype.updateLDB = function(data) {
	DevicesDAO.getInstance().updateByDataToLDB(data, function(success) {
		console.log('[Model:: PushToken] Push token LDB updated:'+ success);	
	});
}

PushToken.getInstance = function(){
    if(PushToken.instance == null || PushToken.instance == undefined){
        PushToken.instance = new PushToken();
    }
	
    return PushToken.instance;
};
