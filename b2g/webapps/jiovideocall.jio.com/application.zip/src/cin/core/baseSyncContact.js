function BaseSyncContact () {
	this.name = "";
	this.nickname = "";
	this.birthday = "";
	this.note = "";
	this.contactid = "";
	this.synccontactdisplayname = "";
	this.emaillist = [];
	this.companylist = [];
	this.addresslist = [];
}

BaseSyncContact.prototype = {
	constructor: BaseSyncContact,

	setName: function(uname){
		this.name=uname;
	},

	getName: function(){
		return this.name;
	},

	setName: function(uname){
		this.nickname=uname;
	},

	getName: function(){
		return this.nickname;
	},

	setBirthday: function(birthday){
		this.birthday = birthday;
	},

	getBirthday: function(){
		return this.birthday;
	},

	setNote: function(note){
		this.note=note;
	},
	
	getNote: function(){
		return this.note;
	},

	setContactId: function(contactid){
		this.contactid=contactid;
	},
	getContactId: function(){
		this.contactid;
	},

	setDsiplayName: function(synccontactdisplayname){
		this.synccontactdisplayname=synccontactdisplayname;
	},
	getDsiplayName: function(){
		return this.synccontactdisplayname;
	}
};

