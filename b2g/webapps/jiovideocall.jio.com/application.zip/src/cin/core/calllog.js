function Calllog(){
    this.userID = null;
    this.sessionID = null;
    this.invitorName = null;
    this.type  = null;
    this.status = null;
    this.time = null;
    this.groupID = null;
}

Calllog.prototype.init = function(cinMessage){
    this.userID = cinMessage.getHeader(CINRequestConts.FROM);
    this.sessionID = cinMessage.getHeader(CINRequestConts.KEY);
    this.invitorName = cinMessage.getString(CINRequestConts.NAME);
    this.type = cinMessage.getInt(CINRequestConts.TYPE);
    this.status = cinMessage.getInt(CINRequestConts.STATUS);
    this.time = cinMessage.getInt(CINRequestConts.DATETIME);
    if(cinMessage.containsHeader(CINRequestConts.DEVICETOKEN)){
        this.groupID = cinMessage.getHeader(CINRequestConts.DEVICETOKEN);
    }
}

Calllog.prototype.getUserID = function(){
    return this.userID;
}

Calllog.prototype.getSessionID = function(){
    return this.sessionID;
}

Calllog.prototype.getInvitorName = function(){
    return this.invitorName;
}

Calllog.prototype.getType = function(){
    return this.type;
}

Calllog.prototype.getStatus = function(){
    return this.status;
}

Calllog.prototype.getTime = function(){
    return this.time;
}

Calllog.prototype.getGroupId = function(){
    return this.groupID;
}

Calllog.prototype.isGroupCall = function(){
    return this.getGroupId!==null;
}
