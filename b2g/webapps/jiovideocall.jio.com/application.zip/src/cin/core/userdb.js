function UserDB(){
	this.domain = null;
	this.cmpAddress = null;
	this.serverNumber = null;
	this.navResponse = null;
	this.userId = null;
	this.password = null;
	this.token = null;
	this.serverKey = null;
	this.phoneNumber = null;
	this.credential = null;
	this.dateTime = null;
	this.tokenExpiry = null;
	this.deviceModel = null;
	this.language = 0;

}

UserDB.getInstance= function(){
    if(UserDB.instance == null || UserDB.instance == undefined){
        UserDB.instance = new UserDB();
    }
    return UserDB.instance;
};

UserDB.prototype.init = function(cinMessage){
	this.userId = new Int8Array(cinMessage.getHeader(CINRequestConts.FROM));
	this.password = new Int8Array(cinMessage.getHeader(CINRequestConts.PASSWORD));
	this.token = new Int8Array(cinMessage.getHeader(CINRequestConts.TOKEN));
};

UserDB.prototype.setPhoneNumber = function(phoneNumber) {
	this.phoneNumber = phoneNumber;
};

UserDB.prototype.getPhoneNumber = function(phoneNumber) {
	return this.phoneNumber;
};

UserDB.prototype.getEPhoneNumber = function() {
	 return CinBase64.encode(this.phoneNumber);
	// return 'KzkxOTkwMTM5NjM0MA;;';
};

UserDB.prototype.isLoggedIn = function() {
	return this.userId !== null;
};

UserDB.prototype.getUserID = function(){
	return this.userId;
}

UserDB.prototype.getPassword = function(){
	return this.password;
}

UserDB.prototype.getToken = function(){
	return this.token;
}

UserDB.prototype.setServerKey = function(serverKey){
	this.serverKey = new Int8Array(serverKey);
}

UserDB.prototype.getServerKey = function(){
	return this.serverKey;
}

UserDB.prototype.setCredential = function(credential){
	this.credential=credential;
}

UserDB.prototype.getCredential = function(){
	return this.credential;
}

UserDB.prototype.setTokenExpiry = function(tokenExpiry){
	this.tokenExpiry=tokenExpiry;
}

UserDB.prototype.geTokenExpiry = function(){
	return this.tokenExpiry;
}

UserModel.prototype.setDeviceModel = function(deviceModel){
	this.deviceModel = deviceModel;
}

UserModel.prototype.getDeviceModel = function(){
	return this.deviceModel;
}

UserModel.prototype.setLanguage = function(language){
	return this.language=language;
};
 
UserModel.prototype.getLanguage = function(){
	return this.language;
};

UserDB.prototype.initNav = function(cinMessage){
	
	this.domain = JIOUtils.toString(cinMessage.getHeader(0x07));
	this.serverNumber = JIOUtils.toString(cinMessage.getHeader(0x08));
	this.navResponse = cinMessage.toString();
}

UserDB.prototype.initLogon = function(cinMessage){
	var token = cinMessage.getHeader(CINRequestConts.TOKEN);
	if(token.length >0){
		this.token = token;
	}
	this.tokenExpiry = cinMessage.getHeader(CINRequestConts.EXPIRE);
	this.credential = cinMessage.getHeader(CINRequestConts.CREDENTIAL);
	this.dateTime = cinMessage.getHeader(CINRequestConts.DATETIME);
}

UserDB.prototype.initKeepAlive = function(cinMessage){
	this.initLogon(cinMessage);
}


UserDB.prototype.getDateTime = function(){
	return this.dateTime;
}

UserDB.prototype.getNavResponse = function(){
	return this.navResponse;
} 

UserDB.prototype.getDomain = function(){
	return this.domain;
}

