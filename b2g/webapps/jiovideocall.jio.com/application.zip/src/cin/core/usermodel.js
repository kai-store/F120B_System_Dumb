function UserModel(){
    this.domain = null;
    this.cmpAddress = null;
    this.serverNumber = null;
    this.navResponse = null;
    this.userId = null;
    this.password = null;
    this.token = null;
    this.serverKey = null;
    this.phoneNumber = null;
    this.credential = null;
    this.dateTime = null;
    this.tokenExpiry = null;
    this.deviceModel = "LYF";
    this.language = 0;
    this.TClink = null;
    this.FAQlink = null;
    this.userName = null;
    this.pushToken = null;
    this.appType = 0;
    this.apps = {
        "JVC":false,
        "JC":false,
        "JCL":false,
        "JMS":false
    }
}
UserModel.retryCount=0;
UserModel.prototype.objToString = function(obj) { 
    try{
        var abc = Object.keys(obj).map(function(key){
            return obj[key];
        });
        return Int8Array.from(abc);
    }catch(ex){
        return obj;
    }
}

UserModel.prototype.initData = function(){
    var userObj = localStorage.getItem(AppConstants.SKEY_USER_MODEL);
    if(userObj){
        userObj = JSON.parse(userObj);
        this.domain = userObj.domain;
        this.cmpAddress = userObj.cmpAddress;
        this.serverNumber = userObj.serverNumber;
        this.navResponse = userObj.navResponse;
        this.userId = this.objToString(userObj.userId);
        this.password = this.objToString(userObj.password);
        this.token = this.objToString(userObj.token);
        this.serverKey = this.objToString(userObj.serverKey);
        this.phoneNumber = userObj.phoneNumber;
        this.credential = this.objToString(userObj.credential);
        this.dateTime = this.objToString(userObj.dateTime);
        this.tokenExpiry = this.objToString(userObj.tokenExpiry);
        if(userObj.deviceModel == undefined || userObj.deviceModel == null || userObj.deviceModel == ""){
            this.deviceModel = "LYF";
        }else{
            this.deviceModel = userObj.deviceModel;
        }
        this.language = userObj.language;
        this.TClink = userObj.TClink;
        this.FAQlink = userObj.FAQlink;
        this.userName = userObj.userName;
        this.pushToken = userObj.pushToken;

        localStorage.setItem('userId',this.userId);
    }
    this.appType = 1;
}

UserModel.getInstance= function(){
    if(UserModel.instance == null || UserModel.instance == undefined){
        UserModel.instance = new UserModel();
        UserModel.instance.initData();
    }
    return UserModel.instance;
};

UserModel.prototype.initAutoRegister = function(cinMessage){
    this.userId = new Int8Array(cinMessage.getHeader(0x02));
    this.token = new Int8Array(cinMessage.getHeader(0x03));
    this.password = new Int8Array(cinMessage.getHeader(0x04));
    var daoData = {
        userId: this.userId,
        pwd: this.password,
        token: this.token,
        mobileNumber: this.getPhoneNumber()
    };
    localStorage.setItem('userId',this.userId);
    console.log('[Model:: User] initAutoRegister');
    this.updateLDB(daoData, this.canSaveInToFile());
};

UserModel.prototype.init = function(cinMessage) {
    this.userId = new Int8Array(cinMessage.getHeader(CINRequestConts.FROM));
    this.password = new Int8Array(cinMessage.getHeader(CINRequestConts.PASSWORD));
    this.token = new Int8Array(cinMessage.getHeader(CINRequestConts.TOKEN));

    // mushtaq added this code 
    // indexedDB    
    var daoData = {
        userId: this.userId,
        pwd: this.password,
        token: this.token,
        mobileNumber: this.getPhoneNumber()
    };
    localStorage.setItem('userId',this.userId);
    this.updateLDB(daoData, this.canSaveInToFile());
};

UserModel.prototype.setPhoneNumber = function(phoneNumber) {
    this.phoneNumber = phoneNumber;

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        mobileNumber: this.phoneNumber
    };
    this.updateLDB(daoData);
};

UserModel.prototype.getPhoneNumber = function() {
    return this.phoneNumber;
};

UserModel.prototype.getEPhoneNumber = function() {
     return CinBase64.encode(this.getPhoneNumber());
    // return 'KzkxOTkwMTM5NjM0MA;;';
};

UserModel.prototype.isLoggedIn = function() {
    return this.getUserID() !== null;
};

UserModel.prototype.getUserID = function(){
    return this.userId;
}

UserModel.prototype.setUserName = function(username){ 
    this.userName = username;
    // mushtaq added this code 
    // indexedDB
    var daoData = {
        userName: this.userName
    };
    this.updateLDB(daoData);
}

UserModel.prototype.getUserName = function(){
    return this.userName;
}


UserModel.prototype.getPassword = function(){
    return this.password;
}

UserModel.prototype.getToken = function(){
    return this.token;
}

UserModel.prototype.setServerKey = function(serverKey){
    this.serverKey = new Int8Array(serverKey);

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        serverKey: this.serverKey,
        mobileNumber: this.getPhoneNumber()
    };
    this.updateLDB(daoData, this.canSaveInToFile());
}

UserModel.prototype.getServerKey = function(){
    return this.serverKey;
}

UserModel.prototype.setCredential = function(credential){
    this.credential=credential;

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        credential: this.credential,
        mobileNumber: this.getPhoneNumber()
    };
    this.updateLDB(daoData, this.canSaveInToFile());
}

UserModel.prototype.getCredential = function(){
    return this.credential;
}

UserModel.prototype.setTokenExpiry = function(tokenExpiry){
    this.tokenExpiry = tokenExpiry;

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        tokenExpiry: this.tokenExpiry,
        mobileNumber: this.getPhoneNumber()
    };
    this.updateLDB(daoData);
}

UserModel.prototype.geTokenExpiry = function(){
    // return this.tokenExpiry;
    return this.dateTime;
}

UserModel.prototype.initNav = function(cinMessage){
    this.domain = JIOUtils.toString(cinMessage.getHeader(0x07));
    this.serverNumber = JIOUtils.toString(cinMessage.getHeader(0x08));
    this.cmpAddress = cinMessage.getString(0x01);
    this.navResponse = cinMessage.toString();   
    // mushtaq added this code 
    // indexedDB
    var daoData = {
        domain: this.domain,
        serverNumber: this.serverNumber,
        cmpAddress: this.cmpAddress,
        navResponse: this.navResponse
    };
    console.log('[Model:: User] initNav');
    this.updateLDB(daoData);
    this.setFAQlink(cinMessage.getString(24));
}

UserModel.prototype.initLogon = function(cinMessage){
    console.log('[Model:: User] initLogon');
    var token = cinMessage.getHeader(CINRequestConts.TOKEN);
    if(token.length >0){
        this.token = token;
    }

    this.tokenExpiry = cinMessage.getHeader(CINRequestConts.EXPIRE);
    this.credential = cinMessage.getHeader(CINRequestConts.CREDENTIAL);
    this.dateTime = cinMessage.getHeader(CINRequestConts.DATETIME);

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        token: this.token,
        tokenExpiry: this.tokenExpiry,
        credential: this.credential,
        dateTime: this.dateTime,
        mobileNumber: this.getPhoneNumber()
    };

    this.updateLDB(daoData, this.canSaveInToFile());
}
UserModel.prototype.canSaveInToFile=function(){
    var canSaveData = false;
    var sdkInstance = JioChatSDK.getInstance();
    if(sdkInstance.isSDKMode()==JCSDKConstants.SDK_DISABLED_MODE && sdkInstance.isDeviceMode()){
        canSaveData = true;
    }
    return canSaveData;
}

UserModel.prototype.initKeepAlive = function(cinMessage){
    console.log('[Model:: User] initKeepAlive');
    this.initLogon(cinMessage);
}


UserModel.prototype.getDateTime = function(){
    return this.dateTime;
}

UserModel.prototype.getNavResponse = function(){
    return this.navResponse;
} 

UserModel.prototype.getDomain = function(){
    return this.domain;
}

UserModel.prototype.setDeviceModel = function(deviceModel){
    this.deviceModel = deviceModel;
    
    // mushtaq added this code 
    // indexedDB
    var daoData = {
        deviceModel: this.deviceModel,
        mobileNumber: this.getPhoneNumber()
    };
    this.updateLDB(daoData);
}

UserModel.prototype.getDeviceModel = function(){
    if(this.deviceModel == undefined || this.deviceModel == null || this.deviceModel == ""){
        return "LYF";
    }
    return this.deviceModel;
}

UserModel.prototype.setLanguage = function(language){
    // mushtaq added this code 
    // indexedDB
    var daoData = {
        language: language,
        mobileNumber: this.getPhoneNumber()
    };
    this.updateLDB(daoData);

    // Jitendra's code
    return this.language = language;
};

UserModel.prototype.setCMPIP = function(cmpAddress){
    this.cmpAddress = cmpAddress;
    // mushtaq added this code 
    // indexedDB
    var daoData = {
        cmpAddress: this.cmpAddress
    };
    this.updateLDB(daoData);
}
UserModel.prototype.getCMPIP = function(){
    return this.cmpAddress;
}

UserModel.prototype.getLanguage = function(){
    if(this.language == undefined || this.language == null || this.language == ""){
        return 0;
    }
    return this.language;
}

UserModel.prototype.setTClink = function(TClink){
    this.TClink = TClink;

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        termsConditions: this.TClink
    };
    this.updateLDB(daoData);
}

UserModel.prototype.getTClink = function(){
    return this.TClink;
}

UserModel.prototype.setFAQlink = function(FAQlink){
    this.FAQlink = FAQlink;

    // mushtaq added this code 
    // indexedDB
    var daoData = {
        faq: this.FAQlink
    };
    this.updateLDB(daoData);
}

UserModel.prototype.getFAQlink = function(){
    return this.FAQlink;
}

UserModel.prototype.clearAll = function() {
    this.userId = null;
    this.password = null;
    this.token = null;
    this.serverKey = null;
    this.phoneNumber = null;
    this.credential = null;
    this.dateTime = null;
    this.tokenExpiry = null;
    this.deviceModel = null;
    this.cmpAddress = null;
    this.FAQlink = null;
    this.TClink = null;
    this.language = 0;
    this.userName = null;
    localStorage.removeItem(AppConstants.SKEY_USER_MODEL);
    localStorage.removeItem('userId');
}

UserModel.prototype.resetAppFlag = function(value){
    
    if(value==undefined||value==null){
        value = false;
    }

    switch(this.getAppType()){
        case 1: 
            this.apps.JVC = value;
            break;
        case 4:
            this.apps.JC = value;
            break;
        case 2:
            this.apps.JCL = value;
            break;
        case 3:
            this.apps.JMS = value;
    }
}

UserModel.prototype.updateAppFlag = function(apps){
    if(apps==undefined||apps==null){
       this.resetAppFlag(true);
       return this.apps;
    }

    switch(this.getAppType()){
        case 1: 
            apps.JVC = this.apps.JVC;
            break;
        case 4:
            apps.JC = this.apps.JC;
            break;
        case 2:
            apps.JCL = this.apps.JCL;
            break;
        case 3:
            apps.JMS = this.apps.JMS;
    }
    return apps;
}

UserModel.prototype.updateLDB = function(data, canWriteFile) {
    this.resetAppFlag(true);
    var lsKey = AppConstants.SKEY_USER_MODEL;
    var userModel = localStorage.getItem(lsKey);
    if(userModel){
        userModel = JSON.parse(userModel);
        if(data.navResponse){
            userModel.navResponse = data.navResponse;
        }
        if(data.serverNumber){
            userModel.serverNumber = data.serverNumber;
        }
        if(data.domain){
            userModel.domain = data.domain;
        }
        if(data.userId){
            userModel.userId = data.userId;
            localStorage.setItem('userId',data.userId);
        
        }
        if(data.pwd){
            userModel.password = data.pwd;
        }
        if(data.token){
            userModel.token = data.token;
        }
        if(data.serverKey){
            userModel.serverKey = data.serverKey;
        }
        if(data.mobileNumber){
            userModel.phoneNumber = data.mobileNumber;
        }
        if(data.credential){
            userModel.credential = data.credential;
        }
        if(data.dateTime){
            userModel.dateTime = data.dateTime;
        }
        if(data.tokenExpiry){
            userModel.tokenExpiry = data.tokenExpiry;
        }
        if(data.deviceModel == undefined || data.deviceModel == null || data.deviceModel == ""){
            userModel.deviceModel = "LYF";
        }else{
            userModel.deviceModel = data.deviceModel;
        }

        if(data.cmpAddress){
            userModel.cmpAddress = data.cmpAddress;
        }
        if(data.faq){
            userModel.FAQlink = data.faq;
        }
        if(data.termsConditions){
            userModel.TClink = data.termsConditions;
        }
        if(data.language == undefined || data.language == null || data.language == ""){
            userModel.language = 0;
        }else{
            userModel.language = data.language;
        }

        if(data.userName){
            userModel.userName = data.userName;
        }
        localStorage.removeItem(lsKey);
    }else{
        userModel = data;
    }
    var strData = JSON.stringify(userModel);
    if(strData.length > 0){
        localStorage.setItem(lsKey, strData);
    }
    console.log('[Model:: User] User LDB updated req:'+ strData);   
    ActiveUser.getInstance().updateByDataToLDB(data, function(success) {
        console.log('[Model:: User] User LDB updated:'+ success);
        // if(canWriteFile){
        //     UserModel.getInstance().writeUserModelToFile(); 
        // }
    });
}

UserModel.prototype.writeUserModelToFile= function(callback){
    console.log("[Model:: User] Before writeUserModelToFile");
    ActiveUser.getInstance().updateByDataToLDB(this.toJSON(), function(success) {
        console.log('[Model:: User] User LDB updated:'+ success);
        // if(canWriteFile){
        //     UserModel.getInstance().writeUserModelToFile(); 
        // }
        UserModel.getInstance().initFileWrite(callback);
    });
    // DeviceModel.deleteJioFileFromDevice("userModel3.json",{
    //     onSuccess : function(){
            // console.log("[Model:: User] user model file deleted");
    //     },
    //     onError : function(){
    //         console.log("[Model:: User] error while deleting user model file");
    //         UserModel.getInstance().initFileWrite(callback);
    //     }
    // });
}
UserModel.prototype.getFileName = function(number){
    var str = number;
    if(!number){
        str= ""+this.getPhoneNumber();
    }
    str = str.replace(/\+/g, '');
    return str+".json";
    // return AppMode.TYPE;
}

UserModel.prototype.getMetaFileName = function(){
    return "Jio.json";
}

UserModel.prototype.initDataIntoFile = function(callback){
    console.log("[Model:: User] initFileWrite");
    
    if(!this.userId){
        callback.onError(null);
        return;
    }

    UserModel.prototype.readUserModelToFile(this.mobileNumber, {
        onSuccess: function(userObject){
            UserModel.getInstance().writeObject(userObject, callback);
        }, onError: function(error){
            UserModel.getInstance().writeObject(null, callback);
        }
    },true);
}

UserModel.prototype.writeObject = function(userObject, callback){
    var apps=null;
    if(userObject && userObject.apps){
        apps = userObject.apps;
    }
    var userObj = UserModel.getInstance();
    apps = userObj.updateAppFlag(apps);
    userObj.apps = apps;
    var json_str = JSON.stringify(userObj);
    console.log("[Model:: User] Active user info: "+json_str);

    json_str = EncryptionUtils.encryptFile(json_str);
    var blob = new Blob([json_str], {type:"data:application/json"});

    var fileName = UserModel.getInstance().getFileName();
    // DeviceModel.addFileToDevice(blob, fileName, {//addJioFileToDevice
    DeviceModel.addJioFileToDevice(blob, fileName, {//addJioFileToDevice
        onSuccess: function(filePath) {
            console.log("[Model:: User] addFileToDevice Success");
            if(callback){
                callback.onSuccess();
            }
        },
        onError : function(error){
            console.log("[Model:: User] Error while writing userModel file");
            if(callback){
                callback.onError(error);
            }
        }
    });
}
UserModel.prototype.initFileWrite = function(callback){
     ActiveUser.getInstance().updateByDataToLDB(this.toJSON(), function(success) {
        console.log('[Model:: User] User LDB updated:'+ success);
        // if(canWriteFile){
        //     UserModel.getInstance().writeUserModelToFile(); 
        // }
        UserModel.getInstance().initDataIntoFile(callback);
    });
   
}
UserModel.prototype.toJSON = function(){
    var data = {
        userId: this.userId,
        pwd: this.password,
        token: this.token,
        mobileNumber: this.getPhoneNumber(),
        userName: this.userName,
        serverKey: this.serverKey,
        tokenExpiry: this.tokenExpiry,
        credential: this.credential,
        dateTime: this.dateTime,      
        deviceModel: this.deviceModel,
        domain: this.domain,
        serverNumber: this.serverNumber,
        cmpAddress: this.cmpAddress,
        navResponse: this.navResponse,
        termsConditions: this.TClink,
        faq: this.FAQlink,
        apps: this.apps
    };
    return data;
}
UserModel.prototype.canCallAPI = function(){
    if(this.apps.JC || this.apps.JCL || this.apps.JMS || this.apps.JVC){
        return false;
    }
    return true;
}
UserModel.prototype.readUserModelToFile= function(userPhoneNumber, callback, canSendData){
    var sdkInstance = JioChatSDK.getInstance();
    // if(!(sdkInstance.isSDKMode()==JCSDKConstants.SDK_DISABLED_MODE && sdkInstance.isDeviceMode())){
    if(!sdkInstance.isDeviceMode()){
        if(callback){
            JIOUtils.sendError(100, "Not allowed this method. Please check your config.", callback);
        }
        return;
    }
    //If phone number not found... 
    if(!userPhoneNumber){
        this.readMetaData({
            onSuccess: function(data){
                var instance = UserModel.getInstance();
                data = instance.getFileName(data);
                instance.readActiveUserFile(data, callback, canSendData);
            },
            onError: function(error){
                JIOUtils.sendError(100, error, callback);
            }
        });
        return;
    }
    var fileName = UserModel.getInstance().getFileName(userPhoneNumber);
    this.readActiveUserFile(fileName, callback);
}

UserModel.prototype.readActiveUserFile = function(fileName, callback, canSendData){
    DeviceModel.getJioFileFromDevice(fileName,{
        onSuccess: function(fileObj) {
            console.log('[Model:: User] User model file fetched Successfully ');
            var reader = new window.FileReader();
            reader.readAsText(fileObj);
            reader.onloadend = function() {
                var fileContent = reader.result;
                fileContent = EncryptionUtils.deCryptFile(fileContent);
                console.log("[Model:: User] UserModel file as Text is :-"+fileContent);
                var fileObject = null;
                if(fileContent && fileContent.length>0){
                    fileObject = JSON.parse(fileContent);
                    var canILogin = UserModel.canAppLogin(fileObject.apps);
                    if(!canILogin){
                        fileObject = null;
                    }
                    if(canSendData){
                        fileObject = JSON.parse(fileContent);
                    }
                }
                if(callback){ 
                    callback.onSuccess(fileObject);                
                }
            }
        },
        onError: function(error) {
            console.log('[Model:: User] userModel file could not be viewed');
            console.log(error);
            if(callback){
                JIOUtils.sendError(100, error, callback);
            }
        }
    });
}

UserModel.canAppLogin = function(apps){
    var isLogedOut = false;
    var appType = UserModel.getInstance().getAppType();
    switch(appType){
        case 1: 
            isLogedOut = apps.JVC;
            break;
        case 4:
            isLogedOut = apps.JC;
            break;
        case 2:
            isLogedOut = apps.JCL;
            break;
        case 3:
            isLogedOut = apps.JMS;
    } 

    
    if(isLogedOut==null|| isLogedOut==undefined){
        isLogedOut=false;
    }
    return isLogedOut;
}
UserModel.prototype.getName = function(){
    return !this.userName?"":this.userName;
}

UserModel.prototype.getPushToken = function(){
    return PushToken.getInstance();
    // return this.pushToken;
}

UserModel.prototype.setPushToken = function(pushToken){
    PushToken.getInstance().clone(pushToken);
    this.pushToken = pushToken;
}

UserModel.prototype.setAppType = function(appType){
    this.appType = appType;
}

UserModel.prototype.getAppType = function(){
    return JioChatSDK.getInstance().getAppType();
}


UserModel.prototype.updateMetaData = function(phoneNumber, callback){
    if(!JioChatSDK.getInstance().isDeviceMode()){
        callback.onSuccess();
        return;
    }
    var blob = new Blob([phoneNumber], {type:"data:application/json"});
    DeviceModel.addJioFileToDevice(blob, this.getMetaFileName(), {
         onSuccess: function(filePath) {
             callback.onSuccess();
         },
         onError: function(){
            callback.onError();
         }
    });
}

UserModel.prototype.readMetaData = function(callback){
    DeviceModel.getJioFileFromDevice(this.getMetaFileName(),{
        onSuccess: function(fileObj) {
            var reader = new window.FileReader();
            reader.readAsText(fileObj);
            reader.onloadend = function() {
                var fileContent = reader.result;  
                callback.onSuccess(fileContent);
            }
        },
        onError: function(){
            callback.onError();
        }
    });
}

UserModel.prototype.clone = function(data){
    this.appType = JioChatSDK.getInstance().getAppType();
    if(!data){
        return;
    }
    if(data.navResponse){
        this.navResponse = data.navResponse;
    }
    if(data.serverNumber){
        this.serverNumber = data.serverNumber;
    }
    if(data.domain){
        this.domain = data.domain;
    }
    if(data.userId){
        this.userId = JIOUtils.toInt8Array(data.userId);
        localStorage.setItem('userId',this.userId);
    }
    if(data.pwd){
        this.password = JIOUtils.toInt8Array(data.pwd);
    }
    if(data.password){
        this.password = JIOUtils.toInt8Array(data.password);
    }
    if(data.token){
        this.token = JIOUtils.toInt8Array(data.token);
    }
    if(data.serverKey){
        this.serverKey = JIOUtils.toInt8Array(data.serverKey);
    }
    if(data.mobileNumber){
        this.phoneNumber = data.mobileNumber;
    }
    if(data.credential){
        this.credential = JIOUtils.toInt8Array(data.credential);
    }
    if(data.dateTime){
        this.dateTime = JIOUtils.toInt8Array(data.dateTime);
    }
    if(data.tokenExpiry){
        this.tokenExpiry = JIOUtils.toInt8Array(data.tokenExpiry);
    }
    if(this.deviceModel == undefined || this.deviceModel == null || this.deviceModel == ""){
        this.deviceModel = "LYF";
    }else{
        this.deviceModel = data.deviceModel;
    }

    if(data.cmpAddress){
        this.cmpAddress = data.cmpAddress;
    }
    if(data.faq){
        this.FAQlink = data.faq;
    }
    if(data.termsConditions){
        this.TClink = data.termsConditions;
    }

    if(data.language == undefined || data.language == null || data.language == ""){
        this.language = 0;
    } else{
        this.language = data.language;
    }

    if(this.userName){
        this.userName = data.userName;
    }
}