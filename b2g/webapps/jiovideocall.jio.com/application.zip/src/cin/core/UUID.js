function UUID() {

}
UUID.hexChar = ["0", "1", "2", "3", "4", "5", "6", "7","8", "9", "A", "B", "C", "D", "E", "F"];

UUID.randomUUID  = function(){
 	randomBytes = new Int8Array(16);
 	for(var index=0;index<16;index++){
 		randomBytes[index] = Math.random() * 10000;
 	}
    return randomBytes;
};

// UUID.randomUUIDHex = function() {
//   var byteArray = UUID.randomUUID();
//   return byteArray.map(function(byte) {
//     return ('0' + (byte & 0xFF).toString(16)).slice(-2);
//   }).join('')
// }

UUID.randomUUIDHex = function() {
  var byteArray = UUID.randomUUID();
  var str = "";
  for(var index=0;index<byteArray.length;index++){
	  var b = byteArray[index];
	  var val = UUID.hexChar[(b >> 4) & 0x0f] + UUID.hexChar[b & 0x0f];
	  str+=val;
  }
  return str;
}
