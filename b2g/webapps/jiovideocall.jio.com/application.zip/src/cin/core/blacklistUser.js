function BlackListUser(){
	this.mNumber = null;
	this.mood = null;
}

BlackListUser.prototype.setMNumber = function(mNumber){
	this.mNumber = mNumber;
}

BlackListUser.prototype.getMNumber = function(){
	return this.mNumber;
}

BlackListUser.prototype.setMood = function(mood){
	this.mood = mood;
}

BlackListUser.prototype.getMood = function(){
	return this.mood;
}
