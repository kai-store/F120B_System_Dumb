function CollectInfo(){   
    this.add = 1;
    this.mobileNo = '';
    this.md5 = null;
}

CollectInfo.prototype.init = function(cinMessage){ 
    this.md5 = cinMessage.getHeader(CinBase64.getByte(0x01));
    this.mobileNo = cinMessage.getString(CinBase64.getByte(0x02));      
}

CollectInfo.prototype.isAdd = function(){
    return this.add;
}

CollectInfo.prototype.setAdd = function(add){
    this.add = add;
}

CollectInfo.prototype.getMd5 = function(){
    return this.md5;
}

CollectInfo.prototype.setMd5 = function(md5){
    this.md5 = md5;
}

CollectInfo.prototype.getMobileNo = function(){
    return this.mobileNo;
}

CollectInfo.prototype.setMobileNo = function(mobileNo){
    this.mobileNo = mobileNo;
}
