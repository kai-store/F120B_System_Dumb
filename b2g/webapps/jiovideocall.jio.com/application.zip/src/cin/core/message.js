function Message () {
	this.to = null;
	this.index = null;
	this.seq = null;
	this.sessionID = null;
	this.peerID = null;
}

Message.prototype.initDelete = function(cinMessage){
	this.peerID = cinMessage.getHeader(CINRequestConts.TO);
	this.index = cinMessage.getHeader(CINRequestConts.INDEX);
	this.seq = cinMessage.getHeader(CINRequestConts.VERSION);
	this.sessionID = cinMessage.getHeader(CINRequestConts.TOKEN);
};
