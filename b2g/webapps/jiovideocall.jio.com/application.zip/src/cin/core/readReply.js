function ReadReply () {
	this.peerID = null;
}

ReadReply.prototype.initReadReply = function(cinMessage){
	this.peerID = cinMessage.getHeader(CINRequestConts.INDEX);
};
