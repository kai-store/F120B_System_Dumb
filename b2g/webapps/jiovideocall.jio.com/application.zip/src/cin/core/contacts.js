function Contacts(){
	this.phoneList = []; 
}

// 
	
Contacts.prototype.initDelete = function(cinMessage){
	 cinMessage.forEach(function(header) {
		this.phoneList.push(header.getHeader(CINRequestConts.MOBILENO));			
     });
};

Contacts.prototype.setphoneList = function(phoneList){
	this.phoneList = phoneList;
}

Contacts.prototype.getphoneList = function(){
	return this.phoneList;
}
