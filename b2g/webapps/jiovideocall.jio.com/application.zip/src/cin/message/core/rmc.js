function RMC(){
    this.imageId = null;
    this.title = null;
    this.imageSize = null;
    this.channelId = null;
    this.storyId = null;
}

RMC.prototype.setImageId = function(imageId){
    this.imageId = imageId;
}
RMC.prototype.getImageId = function(){
    return this.imageId;
}
RMC.prototype.setTitle = function(title){
    this.title = title;
}
RMC.prototype.getTitle = function(){
    return this.title;
}
RMC.prototype.setImageSize = function(imageSize){
    this.imageSize = imageSize;
}
RMC.prototype.getImageSize = function(){
   return this.imageSize;
}
RMC.prototype.setChannelId = function(channelId){
    this.channelId = channelId;
}
RMC.prototype.getChannelId = function(){
   return this.channelId;
}
RMC.prototype.setStoryId = function(storyId){
    this.storyId = storyId;
}
RMC.prototype.getStory = function(){
   return this.storyId;
}

RMC.prototype.init = function(cinResponse){
    this.imageId = cinResponse.getHeader(MessageConsts.RMCSHARE_IMAGE_ID);
    this.title = cinResponse.getString(MessageConsts.RMCSHARE_STORY_TITLE);
    this.imageSize = cinResponse.getInt(MessageConsts.RMCSHARE_IMAGE_SIZE);
    this.channelId = cinResponse.getHeader(MessageConsts.RMCSHARE_CHANNEL_ID);
    this.storyId = cinResponse.getInt(MessageConsts.RMCSHARE_STORY_ID);
}

RMC.prototype.getCinRequest=function(){
	var cinMsg = new CINRequest(CINRequestConts.MESSAGE);
    cinMsg.addHeaderString(MessageConsts.RMCSHARE_STORY_TITLE, this.title);

    if(this.imageId){
        cinMsg.addHeader(MessageConsts.RMCSHARE_IMAGE_ID, this.imageId);
        cinMsg.addHeaderInt64(MessageConsts.RMCSHARE_IMAGE_SIZE, this.imageSize);
    }
    
    cinMsg.addHeader(MessageConsts.RMCSHARE_CHANNEL_ID, this.channelId);
    cinMsg.addHeaderInt64(MessageConsts.RMCSHARE_STORY_ID, this.storyId);
	// cinMsg.addHeader(CinBase64.getByte(0x01), this.userId);
	// cinMsg.addHeaderString(CinBase64.getByte(0x02), this.name);
	// cinMsg.addHeaderString(CinBase64.getByte(0x03), this.portid);
	/*cinMsg.addHeader(CinBase64.getByte(0x04), dataInfo.getThumbId());
	cinMsg.addHeader(CinBase64.getByte(0x05), dataInfo.getThumbSize());
	cinMsg.addHeader(CinBase64.getByte(0x06), dataInfo.getOriginId());
	cinMsg.addHeader(CinBase64.getByte(0x07), dataInfo.getOriginSize());*/
	return cinMsg.convert();
}    
