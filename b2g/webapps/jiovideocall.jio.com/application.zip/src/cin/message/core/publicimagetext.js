function PublicImageText() {
	this.title = undefined;
	this.date = undefined;
	this.desc= undefined;
	this.url = undefined;
	this.publicMessageId = undefined;
	this.imageSize = 0;
	this.imageId = undefined;
	this.orderId = undefined;
	this.model = 0;
	this.imageTextType = 0;
	this.messageId = undefined;
}

PublicImageText.prototype.init = function(msgType, cinBody) {
	if(msgType === 0){
		this.title = cinBody.getString(0x01);
		this.date = cinBody.getInt(0x02);
		this.desc = cinBody.getString(0x03);
		this.url = JIOUtils.toString(cinBody.getBody());
		this.publicMessageId = JIOUtils.toString(0x10);
		return;
	}
	if(cinBody.containsHeader(0x01)){
		this.title =  cinBody.getString(0x01);
	}
	if(cinBody.containsHeader(0x02)){
		this.imageId =  cinBody.getString(0x02);
	}
	if(cinBody.containsHeader(0x03)){
		this.imageSize =  cinBody.getInt(0x03);
	}
	if(cinBody.containsHeader(0x04)){
		this.date =  cinBody.getInt(0x04);
	}
	if(cinBody.containsHeader(0x06)){
		this.orderId =  cinBody.getInt(0x06);
	}
	if(cinBody.containsHeader(0x07)){
		this.model =  cinBody.getInt(0x07);
	}
	if(cinBody.containsHeader(0x08)){
		this.imageTextType =  cinBody.getInt(0x08);
	}
	if(cinBody.containsHeader(0x10)){
		this.messageId =  cinBody.getString(0x10);
	}
	var bodys = cinBody.getBodys();
	var that = this;
	bodys.forEach(function(val){
   		
   		var response = CINResponse.getCINMessage(val.val, null, false);
		
		if(response.containsHeader(0x01)){
    		that.desc = JIOUtils.toString(response.getBody());
   		}

   		if(response.containsHeader(0x02)){
   			that.url = JIOUtils.toString(response.getBody());
   		}
	});

};
