function ImageInfo () {
	this.fileHEXId = UUID.randomUUIDHex();
	this.fileId = "";
	this.mFileSize = 0;
	this.mFileName = "";
	this.mThumbId = "";
	this.mThumbSize = 0;
	this.mOriginId = "";
	this.mOriginSize = 0 ;
	this.thumbnailObj = null;
}

ImageInfo.prototype = {
	constructor: ImageInfo,

	setFileId: function(fileId){
		this.fileId = fileId;
	},

	getFileId: function(){
		return this.fileId;
	},

	setFileSize: function(mFileSize){
		this.mFileSize = mFileSize;
	},

	getFileSize: function(){
		return this.mFileSize;
	},
	
	setFileName: function(mFileName){
		this.mFileName = mFileName;
		this.setFileId(this.fileHEXId+"_IMAGE");
		// this.setFileId(this.fileHEXId+"_IMAGE");
	},
	
	getFileName: function(){
		return this.mFileName;
	},

	setThumbId: function(mThumbId){
		this.mThumbId = mThumbId;
	},

	getThumbId: function(){
		return this.mThumbId;
	},

	setThumbSize: function(mThumbSize){
		this.mThumbSize = mThumbSize;
		this.mThumbId = this.fileHEXId+"_THUMB";
		
		this.thumbnailObj = new Thumbnail();
		this.thumbnailObj.setFileId(this.fileHEXId+"_THUMB");
		this.thumbnailObj.setFileSize(this.mThumbSize);
	},

	getThumbSize: function(){
		return this.mThumbSize;
	},

	setOriginId: function(mOriginId){
		this.mOriginId = mOriginId;
	},

	getOriginId: function(){
		return this.mOriginId;
	},

	setOriginSize: function(mOriginSize){
		this.mOriginSize = mOriginSize;
	},

	getOriginSize: function(){
		return this.mOriginSize;
	},

	init: function(response){
		this.fileId = response.getString(MessageConsts.FILEBODY_FILE_ID);
		this.mFileSize = response.getInt(MessageConsts.FILEBODY_FILE_SIZE);
		this.mFileName = response.getString(MessageConsts.FILEBODY_FILE_NAME);
		this.mThumbId = response.getString(MessageConsts.IMAGEBODY_THUMB_ID);
		this.mThumbSize = response.getInt(MessageConsts.IMAGEBODY_THUMB_SIZE);
		this.mOriginId = response.getString(MessageConsts.IMAGEBODY_ORIGIN_ID);
		this.mOriginSize = response.getInt(MessageConsts.IMAGEBODY_ORIGIN_SIZE);
	},
     
    getCinRequest: function(){
    	var cinMsg = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.TYPE_IMAGE);
		cinMsg.addHeaderString(CinBase64.getByte(0x01), this.fileId);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x02), this.mFileSize);
		if(this.mFileName !== undefined && this.mFileName !== ""){
			cinMsg.addHeaderString(CinBase64.getByte(0x03), this.mFileName);
		}
		
		if(this.mThumbSize>0 && this.mThumbSize){
			cinMsg.addHeaderString(CinBase64.getByte(0x04), this.mThumbId);
			cinMsg.addHeaderInt64(CinBase64.getByte(0x05), this.mThumbSize);
		}
		
		if(this.mOriginId && this.mOriginSize >0){
			cinMsg.addHeaderString(CinBase64.getByte(0x06), this.mOriginId);
			cinMsg.addHeaderInt64(CinBase64.getByte(0x07), this.mOriginSize);
		}			
		return cinMsg.convert();
	},
	
	getPPMCINRequest: function(){
		var cinMsg = new CINRequest(CINRequestConts.SERVICE);
		cinMsg.addHeaderString(CINRequestConts.FROM, this.fileId);
		cinMsg.addHeaderInt64(CINRequestConts.TO, this.mFileSize);
		if(this.mFileName !== undefined && this.mFileName !== ""){
			cinMsg.addHeaderString(CINRequestConts.CALLID, this.mFileName);
		}
		if(this.mThumbSize>0 && this.mThumbSize){
			cinMsg.addHeaderString(CINRequestConts.CSEQUENCE, this.mThumbId);
			cinMsg.addHeaderInt64(CINRequestConts.MESSAGEID, this.mThumbSize);
		}
		cinMsg.addHeaderInt64(CINRequestConts.TOKEN, 0x0);		
		return cinMsg.convert();
	}
};
