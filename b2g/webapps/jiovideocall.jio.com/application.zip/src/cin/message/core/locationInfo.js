function LocationCard () {
	this.fileHEXId = UUID.randomUUIDHex();
	this.fileDesc = "";
	this.mThumbId = "";
	this.mThumbSize = 0;
	this.latitude = null;
	this.longitude = null;
	this.thumbnailObj = null;
}

LocationCard.prototype = {
	constructor: LocationCard,

	setFleDesc: function(fileDesc){
		this.fileDesc=fileDesc;
	},

	getFleDesc: function(){
		return this.fileDesc;
	},
	
	setFileId: function(mThumbId){
		this.mThumbId = mThumbId;
	},

	getFileId: function(){
		return this.mThumbId;
	},

	setThumbSize: function(mThumbSize){
		this.mThumbSize = mThumbSize;
		this.mThumbId = this.fileHEXId+"_THUMB";

		this.thumbnailObj = new Thumbnail();
		this.thumbnailObj.setFileId(this.mThumbId);
		this.thumbnailObj.setFileSize(this.mThumbSize);
	},

	getThumbSize: function(){
		return this.mThumbSize;
	},	

	setLatitude: function(latitude){
		this.latitude = latitude;
	},

	getLatitude: function(){
		return this.latitude;
	},

	setLongitude: function(longitude){
		this.longitude = longitude;
	},

	getLongitude: function(){
		return this.longitude;
	},

	init: function(response){
		this.fileDesc = response.getString(MessageConsts.LOCATIONBODY_DESC);
		this.mThumbId = response.getString(MessageConsts.LOCATIONBODY_THUMB_ID);
		this.mThumbSize = response.getInt(MessageConsts.LOCATIONBODY_THUMB_SIZE);
		this.latitude = response.getFloat(MessageConsts.LOCATIONBODY_LATITUDE);
		this.longitude = response.getFloat(MessageConsts.LOCATIONBODY_LONGITUDE);
	},
     
    getCinRequest: function(){
    	cinMsg = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.TYPE_LOCATION);
		cinMsg.addHeaderDouble(MessageConsts.LOCATIONBODY_LATITUDE,  this.latitude);
		cinMsg.addHeaderDouble(MessageConsts.LOCATIONBODY_LONGITUDE, this.longitude);
		
		if(this.mThumbSize!==null && this.mThumbSize>0){
			cinMsg.addHeaderString(MessageConsts.LOCATIONBODY_THUMB_ID, this.mThumbId);
			cinMsg.addHeaderInt64(MessageConsts.LOCATIONBODY_THUMB_SIZE, this.mThumbSize);
		}
		
		if(this.fileDesc==null || this.fileDesc=== undefined){
			this.fileDesc = "";
		}
		cinMsg.addHeaderString(MessageConsts.LOCATIONBODY_DESC, this.fileDesc);
		return cinMsg.convert();
    } 
};
