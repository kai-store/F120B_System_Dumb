function AlbumInfo () {
	this.fileHEXId = UUID.randomUUIDHex();
	this.fileId = "";
	this.mFileSize = 0;
	this.mFileName = "";
	this.mThumbId = "";
	this.mThumbSize = 0;
	this.mOriginId = "";
	this.mOriginSize = 0 ;
}

AlbumInfo.prototype = {
	constructor: AlbumInfo,

	setFileId: function(fileId){
		this.fileId=fileId;
	},

	getFileId: function(){
		return this.fileId;
	},

	setFileSize: function(mFileSize){
		this.mFileSize = mFileSize;
	},

	getFileSize: function(){
		return this.mFileSize;
	},
	
	setFileName: function(mFileName){
		this.mFileName = mFileName;
	},
	
	getFileName: function(){
		return this.mFileName;
	},

	setThumbId: function(mThumbId){
		this.mThumbId = mThumbId;
	},

	getThumbId: function(){
		return this.mThumbId;
	},

	setThumbSize: function(mThumbSize){
		this.mThumbSize = mThumbSize;
	},

	getThumbSize: function(){
		return this.mThumbSize;
	},

	setOriginId: function(mOriginId){
		this.mOriginId = mOriginId;
	},

	getOriginId: function(){
		return this.mOriginId;
	},

	setOriginSize: function(mOriginSize){
		this.mOriginSize = mOriginSize;
	},

	getOriginSize: function(){
		return this.mOriginSize;
	},

	init: function(response){
		this.fileId = response.getString(MessageConsts.FILEBODY_FILE_ID);
		this.mFileSize = response.getInt(MessageConsts.FILEBODY_FILE_SIZE);
		this.mFileName = response.getString(MessageConsts.FILEBODY_FILE_NAME);
		this.mThumbId = response.getString(MessageConsts.IMAGEBODY_THUMB_ID);
		this.mThumbSize = response.getInt(MessageConsts.IMAGEBODY_THUMB_SIZE);
		this.mOriginId = response.getString(MessageConsts.IMAGEBODY_ORIGIN_ID);
		this.mOriginSize = response.getInt(MessageConsts.IMAGEBODY_ORIGIN_SIZE);
	},
     
    getCinRequest: function(){
    	cinMsg = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.TYPE_GRAFFI);
		cinMsg.addHeaderString(CinBase64.getByte(0x01), this.fileId);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x02), this.mFileSize);
		cinMsg.addHeaderString(CinBase64.getByte(0x03), this.mFileName);
		return cinMsg.convert();
    }
};
