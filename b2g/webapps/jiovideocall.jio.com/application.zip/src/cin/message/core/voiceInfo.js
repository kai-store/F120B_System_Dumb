
function VoiceInfo () {
	this.fileHEXId = UUID.randomUUIDHex();
	this.fileId = "";
	this.mFileSize = 0;
	this.type = null;
	this.bitRate = null;
	this.totalTime = null; // seconds

	this.mFileName = "";
	this.msgId = "";
	this.msgType = "";
}

VoiceInfo.prototype = {
	constructor: VoiceInfo,

	setFileId: function(fileId){
		this.fileId=fileId;
	},

	getFileId: function(){
		return this.fileId;
	},

	setFileSize: function(mFileSize){
		this.mFileSize = mFileSize;
		this.setFileId(this.fileHEXId+"_SOUND");
	},

	getFileSize: function(){
		return this.mFileSize;
	},

	setType: function(type){
		this.type = type;
	},

	getType: function(){
		return this.type;
	},

	setBitRate: function(bitRate){
		this.bitRate = bitRate;
	},

	getBitRate: function(){
		return this.bitRate;
	},

	setTotalTime: function(totalTime){
		this.totalTime = totalTime;
	},

	getTotalTime: function(){
		return this.totalTime;
	},

	setFileName: function(mFileName){
		this.mFileName = mFileName;
	},

	getFileName: function(){
		return this.mFileName;
	},

	setMsgId: function(msgId){
		this.msgId = msgId;
	},

	getMsgId: function(){
		return this.msgId;
	},

	setMsgType: function(msgType){
		this.msgType = msgType;
	},

	getMsgType: function(){
		return this.msgType;
	},

	init: function(response){
		this.fileId = response.getString(MessageConsts.FILEBODY_FILE_ID);
		this.mFileSize = response.getInt(MessageConsts.FILEBODY_FILE_SIZE);
		//this.type = response.getString(MessageConsts.VOICEBODY_BITRATE);
		this.bitRate = response.getInt(MessageConsts.VOICEBODY_BITRATE);
		this.totalTime = response.getInt(MessageConsts.VOICEBODY_TOTAL_TIME);
	},
     
    getCinRequest: function(){
    	var cinMsg = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.TYPE_VOICE);
		cinMsg.addHeaderString(CinBase64.getByte(0x01), this.fileId);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x02), this.mFileSize);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x03), CinBase64.getByte(0x01)); // VOICE_TYPE_AMR 
		cinMsg.addHeaderInt64(CinBase64.getByte(0x04), this.bitRate);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x05), this.totalTime);
		return cinMsg.convert();
	},

	getPPMCINRequest: function(){
 		var cinMsg = new CINRequest(CINRequestConts.SERVICE);
		cinMsg.addHeaderString(CINRequestConts.FROM, this.fileId);
		cinMsg.addHeaderInt64(CINRequestConts.TO, this.mFileSize);
		cinMsg.addHeaderInt64(CINRequestConts.CALLID, CinBase64.getByte(0x01)); // VOICE_TYPE_AMR 
		cinMsg.addHeaderInt64(CINRequestConts.CSEQUENCE, this.bitRate);
		cinMsg.addHeaderInt64(CINRequestConts.MESSAGEID, this.totalTime);
		return cinMsg.convert();
	}
};
