function Emoticons () {
	this.msgType = "";// Added by kaal
	this.key = "";
	this.version = 0;
	this.sequence = "";
	this.token = null;
	this.name = null;
	this.developer = null;
	this.description = null;
	this.pkgSize = null;
	this.price = null;
	this.payType = null;
	this.status = null;
	this.portraituuid = null;
	this.portraitSize = null;
	this.largeImguuid = null;
	this.largeImgSize = null;
	this.pcThumbImguuid = null;
	this.pcThumbImgSize = null;
	this.pcLargeImguuid = null;
	this.pcLargeImgSize = null;
}

Emoticons.prototype = {
	constructor: Emoticons,
	
	// Added by kaal
	setMsgType: function(msgType){
		this.msgType = msgType;
	},

	// Added by kaal
	getMsgType: function(){
		return msgType;
	},

	setKey: function(key){
		this.key=key;
	},

	getKey: function(){
		return this.key;
	},

	setVersion: function(version){
		this.version = version;
	},

	getVersion: function(){
		return this.version;
	},
	
	setSequence: function(sequence){
		this.sequence = sequence;
	},
	
	getSequence: function(){
		return this.sequence;
	},

	setName: function(name){
		this.name = name;
	},
	
	getName: function(){
		return this.name;
	},

	setToken: function(token){
		this.token=token;
	},

	getToken: function(){
		return this.token;
	},
	
	setDeveloper: function(developer){
		this.developer=developer;
	},

	getDeveloper: function(){
		return this.developer;
	},
	
	setDescription: function(description){
		this.description=description;
	},

	getDescription: function(){
		return this.description;
	},

	setPkgSize: function(pkgSize){
		this.pkgSize=pkgSize;
	},

	getPkgSize: function(){
		return this.pkgSize;
	},

	setPrice: function(price){
		this.price=price;
	},

	getPrice: function(){
		return this.price;
	},

	setPayType: function(payType){
		this.payType=payType;
	},

	getPayType: function(){
		return this.payType;
	},

	setStatus: function(status){
		this.status=status;
	},

	getStatus: function(){
		return this.status;
	},

	setPortraituuid: function(portraituuid){
		this.portraituuid=portraituuid;
	},

	getPortraituuid: function(){
		return this.portraituuid;
	},

	setPortraitSize: function(portraitSize){
		this.portraitSize=portraitSize;
	},

	getPortraitSize: function(){
		return this.portraitSize;
	},
	
	setLargeImguuid: function(largeImguuid){
		this.largeImguuid=largeImguuid;
	},

	getLargeImguuid: function(){
		return this.largeImguuid;
	},
	
	setLargeImgSize: function(largeImgSize){
		this.largeImgSize=largeImgSize;
	},

	getLargeImgSize: function(){
		return this.largeImgSize;
	},

	init: function(response){
		this.key = response.getInt(CinBase64.getByte(0x01));
		this.version = response.getInt(CinBase64.getByte(0x02));
		this.sequence = response.getInt(CinBase64.getByte(0x03));
	},

	initDetails: function(response){
		this.key = response.getInt(CinBase64.getByte(0x01));
		this.token = response.getString(CinBase64.getByte(0x02));
		this.version = response.getInt(CinBase64.getByte(0x03));
		this.sequence = response.getInt(CinBase64.getByte(0x04));
		this.name = response.getString(CinBase64.getByte(0x05));
		this.developer = response.getString(CinBase64.getByte(0x06));
		this.description = response.getString(CinBase64.getByte(0x07));
		this.pkgSize = response.getInt(CinBase64.getByte(0x08));
		this.price = response.getString(CinBase64.getByte(0x09));
		this.payType = response.getString(CinBase64.getByte(0x0A));
		this.status = response.getInt(CinBase64.getByte(0x0B));
		this.portraituuid = response.getString(CinBase64.getByte(0x0C));
		this.portraitSize = response.getInt(CinBase64.getByte(0x0D));
		this.largeImguuid = response.getString(CinBase64.getByte(0x0E));
		this.largeImgSize = response.getInt(CinBase64.getByte(0x0F));
		this.pcThumbImguuid = response.getString(CinBase64.getByte(0x10));
		this.pcThumbImgSize = response.getInt(CinBase64.getByte(0x11));
		this.pcLargeImguuid = response.getString(CinBase64.getByte(0x12));
		this.pcLargeImgSize = response.getInt(CinBase64.getByte(0x13));
	},
	downloadThumbnail: function(key){
		// debugger;
		var fileName = String(key) + "_EMOTICON_THUMB"; 
		var thumbnail = new Thumbnail(); 
		thumbnail.setFileId(this.portraituuid);
		thumbnail.setFileSize(this.portraitSize);
		thumbnail.isDownloadAsBatch = true;
		thumbnail.setEmoticonId(key);//added by shubham
		thumbnail.setFileName(fileName);//Added by shubham //to differentiate between emoticon and other files
		DataManager.getInstance().downloadStart(thumbnail);
	},
	downloadLargeImg: function(key){
		var thumbnail = new Thumbnail(); 
		thumbnail.setFileId(this.largeImguuid);
		thumbnail.setFileSize(this.largeImgSize);
		thumbnail.setFileName("EMOTICON_DESC_IMAGE");
		thumbnail.setEmoticonId(key);//added by shubham
		DataManager.getInstance().downloadStart(thumbnail);
	}
};
