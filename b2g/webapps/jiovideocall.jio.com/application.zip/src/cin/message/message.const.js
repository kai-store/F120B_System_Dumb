function MessageConsts(argument) {
	// body...
}

MessageConsts.PAGE_SIZE = 50;

MessageConsts.TYPE_TEXT = CinBase64.getByte(0x7F);
MessageConsts.TYPE_IMAGE = CinBase64.getByte(0x00);
MessageConsts.TYPE_VOICE = CinBase64.getByte(0x01);
MessageConsts.TYPE_FILE = CinBase64.getByte(0x02);
MessageConsts.TYPE_VIDEO = CinBase64.getByte(0x03);
MessageConsts.TYPE_EMOTICON = CinBase64.getByte(0x04);
MessageConsts.TYPE_GRAFFI = CinBase64.getByte(0x05);
MessageConsts.TYPE_CARD = CinBase64.getByte(0x06);
MessageConsts.TYPE_LOCATION = CinBase64.getByte(0x07);
MessageConsts.TYPE_FREE_SMS = CinBase64.getByte(0x08);
MessageConsts.TYPE_PP = CinBase64.getByte(0x0D);
MessageConsts.TYPE_PUBLIC_IMAGETEXT = CinBase64.getByte(0x0C);
MessageConsts.TYPE_CLIENT_FORWARD_IMAGETEXT = CinBase64.getByte(0x0D);
MessageConsts.TYPE_CLIENT_FORWARD_PUBLICACCOUNT_CARD = CinBase64.getByte(0x0E);
MessageConsts.TYPE_RMCSHARE_STORY = CinBase64.getByte(0x1E);
MessageConsts.TYPE_JIOMONEY = CinBase64.getByte(0x0F);
MessageConsts.TYPE_UPDATE_STATUS = CinBase64.getByte(0x14);
MessageConsts.TYPE_UNREAD_MESSAGE = "100";

MessageConsts.EMOTICON_PACKAGE_TOKEN = CinBase64.getByte(0x01);
MessageConsts.EMOTICON_FILE_ID = CinBase64.getByte(0x02);
MessageConsts.EMOTICON_FILE_SIZE = CinBase64.getByte(0x03);
MessageConsts.EMOTICON_WIDTH = CinBase64.getByte(0x04);
MessageConsts.EMOTICON_HEIGHT = CinBase64.getByte(0x05);
MessageConsts.EMOTICON_THUMB_ID = CinBase64.getByte(0x06);
MessageConsts.EMOTICON_THUMB_SIZE = CinBase64.getByte(0x07);
MessageConsts.EMOTICON_PACKAGE_ID = CinBase64.getByte(0x08);
MessageConsts.EMOTICON_DOWNLOAD =  CinBase64.getByte(0x68);
MessageConsts.EMOTICON_PACKAGE_DOWNLOAD =  CinBase64.getByte(0x70);

MessageConsts.RMCSHARE_STORY_TITLE = CinBase64.getByte(0x01);
MessageConsts.RMCSHARE_IMAGE_ID = CinBase64.getByte(0x02);
MessageConsts.RMCSHARE_IMAGE_SIZE = CinBase64.getByte(0x03);
MessageConsts.RMCSHARE_CHANNEL_ID = CinBase64.getByte(0x04);
MessageConsts.RMCSHARE_STORY_ID = CinBase64.getByte(0x05);	

MessageConsts.CLEAR_RECORDS = CinBase64.getByte(0x0B);	
MessageConsts.MESSAGE_READREPLY = CinBase64.getByte(0x01);	
MessageConsts.READ_REPLY_TYPE_NOMAL = CinBase64.getByte(0);
MessageConsts.READ_REPLY_TYPE_DELETE_SESSION = CinBase64.getByte(1);

MessageConsts.STATUS_UNKNOWN = 0;
MessageConsts.STATUS_SENT = 1;
MessageConsts.STATUS_ARRIVED = 2;
MessageConsts.STATUS_FAILED = 3;
MessageConsts.STATUS_DRAFT = 4;
MessageConsts.STATUS_SENDING = 5;
MessageConsts.STATUS_READBYFRIEND = 6;
MessageConsts.STATUS_IGNORE = 404;
MessageConsts.STATUS_DOWNLOAD_FAILED = 11;

// In- message for Image

MessageConsts.IMAGEBODY_THUMB_ID = CinBase64.getByte(0x04);
MessageConsts.IMAGEBODY_THUMB_SIZE = CinBase64.getByte(0x05);
MessageConsts.IMAGEBODY_ORIGIN_ID = CinBase64.getByte(0x06);
MessageConsts.IMAGEBODY_ORIGIN_SIZE = CinBase64.getByte(0x07);
MessageConsts.FILEBODY_FILE_ID = CinBase64.getByte(0x01);
MessageConsts.FILEBODY_FILE_SIZE = CinBase64.getByte(0x02);
MessageConsts.FILEBODY_FILE_NAME = CinBase64.getByte(0x03);

MessageConsts.CARDBODY_USERID = CinBase64.getByte(0x01);
MessageConsts.CARDBODY_MOBILENUM = CinBase64.getByte(0x02);
MessageConsts.CARDBODY_NAME = CinBase64.getByte(0x03);

//location
MessageConsts.LOCATIONBODY_LATITUDE = CinBase64.getByte(0x01);
MessageConsts.LOCATIONBODY_LONGITUDE = CinBase64.getByte(0x02);
MessageConsts.LOCATIONBODY_THUMB_ID = CinBase64.getByte(0x03);
MessageConsts.LOCATIONBODY_THUMB_SIZE = CinBase64.getByte(0x04);
MessageConsts.LOCATIONBODY_DESC = CinBase64.getByte(0x05);

MessageConsts.VOICEBODY_TYPE = CinBase64.getByte(0x03);
MessageConsts.VOICEBODY_BITRATE = CinBase64.getByte(0x04);
MessageConsts.VOICEBODY_TOTAL_TIME = CinBase64.getByte(0x05);


//siva added for native message
MessageConsts.NATIVE_MESSAGE = '200';
// Added by kaal for Nanorep only for channels
MessageConsts.TYPE_NANOREP = "300";

MessageConsts.ATTACHMENT_QUEUE = 1;
MessageConsts.ATTACHMENT_PREPARING_DOWNLOAD = 2;
MessageConsts.ATTACHMENT_DOWNLOADING = 3;
MessageConsts.ATTACHMENT_NOT_FOUND = 10;
MessageConsts.ATTACHMENT_CANCELING = 4;
MessageConsts.ATTACHMENT_UNKNOWN_STAUS = 100;
MessageConsts.ATTACHMENT_FAIL = -1;
// MessageConsts.ATTACHMENT_CANCELED = 1;



