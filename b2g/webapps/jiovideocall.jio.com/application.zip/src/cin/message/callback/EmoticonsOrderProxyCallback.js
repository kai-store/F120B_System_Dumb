function EmoticonsOrderProxyCallback(emoticon, callback) {
	this.emoticon = emoticon;
	this.callback = callback;
}

EmoticonsOrderProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		// debugger;
		DataManager.getInstance().checkOrderEmoticon(this.emoticon, this.callback);
	},
	onError: function(cinMessage){
		if(!this.callback){
			return;
		}
		JIOUtils.sendError(100,cinMessage, this.callback);
	}
};
