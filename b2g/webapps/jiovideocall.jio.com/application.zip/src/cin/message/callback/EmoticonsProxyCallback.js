function EmoticonsProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

EmoticonsProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		var emoticonKeys = [];
		var info = cinMessage.getBodys();
		info.forEach(function(cinMessageBody,index){
			var response = CINResponse.getCINMessage(cinMessageBody.val, null, false);
			icons = new Emoticons();
			icons.init(response);
			emoticonKeys.push(icons.getKey());
		});
		var version = cinMessage.getInt(CINRequestConts.VERSION);
		this.uiCallback.onVersion(version);
		
		if(emoticonKeys.length>0){
			DataManager.getInstance().getEmoticonInfo(emoticonKeys, this.uiCallback);
			return;
		}
		this.uiCallback.onSuccess(emoticonKeys);
		// var emoticons = [];
		// var allKeys = [];
		// var keys = cinMessage.getHeaders(CINRequestConts.KEY);
		// keys.forEach(function(key){
		// 	allKeys.push(JIOUtils.toLong(key));
		// });
		// var version = cinMessage.getInt(CINRequestConts.VERSION);
		// try{
		// 	var info = cinMessage.getBodys();
		// 	info.forEach(function(cinMessageBody,index){
		// 		var response = CINResponse.getCINMessage(cinMessageBody.val, null, false);
		// 		icons = new Emoticons();
		// 		icons.init(response);
		// 		emoticons.push(icons);
		// 	});
		// 	emoticons.keys = allKeys;
		// 	emoticons.ver = ver;
		// 	console.log(emoticons.toString());
		// }catch(err){

		// }			
		// this.uiCallback.onSuccess(emoticons);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
