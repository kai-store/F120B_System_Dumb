function DownloadStartCallback(fileDetails, callback){
    this.fileDetails = fileDetails; 
    this.callback = callback;
}

DownloadStartCallback.prototype = {
    onSuccess: function(data){
        console.log("[DM] Download start (Success): ", JSON.stringify(this.fileDetails));
        DataManager.getInstance().updateStatus(this.fileDetails, MessageConsts.ATTACHMENT_PREPARING_DOWNLOAD);
        if(this.callback && this.callback.onSuccess)
            this.callback.onSuccess(data);
    },
    onError: function(error){
        console.log("[DM] Download start (Error): ", JSON.stringify(this.fileDetails));
        DataManager.getInstance().updateStatus(this.fileDetails, MessageConsts.ATTACHMENT_FAIL);
        JIOUtils.sendError(100, error, this.callback);

    }
}