function UploadAttachmentData(attachment){
    this.attachment = attachment;
}

UploadAttachmentData.prototype = {
    onSuccess: function(cinMessage){
        var callback = DataManager.getInstance().getUploadCallback();
        
        var fileSize = this.attachment.getFileSize();

        if(fileSize===0){
            callback.onError(this.attachment);
            return;
        }

        var offset = this.attachment.fileOffset;  
        offset+= this.attachment.chunkSize;
        var percentage = ((offset/fileSize)*100);
        if(parseInt(percentage)>=100){
            percentage = 99.9;
            this.fileUploadCompleted(percentage, this.attachment);
            return;
        }
        callback.onProgressChanged(this.attachment, percentage);
        
        this.attachment.fileOffset+= this.attachment.chunkSize;
        var isThumnail = this.attachment.getFileId().endsWith("_THUMB");
        if(!isThumnail){
            callback.onReqFile(this.attachment);
        }else{
            callback.onReqThumb(this.attachment);
        }
    },
    onError: function(error){
        var callback = DataManager.getInstance().getUploadCallback();
        if(callback!==null && callback){
            callback.onError(error);
        }
        DataManager.getInstance().fileUploadCompled(false);
    },
    fileUploadCompleted: function(percentage, attachment){
        var callback = DataManager.getInstance().getUploadCallback();
        callback.onProgressChanged(this.attachment, percentage);

        DataManager.getInstance().confirm(this.attachment, {
                onSuccess: function(){
                    callback.onProgressChanged(attachment, 100);
                    callback.onSuccess(attachment);
                    DataManager.getInstance().fileUploadCompled(true);
                },
                onError: function(){
                    callback.onError(attachment);
                    DataManager.getInstance().fileUploadCompled(false);                    
                }
         });
    }
}
