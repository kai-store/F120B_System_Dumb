function ProfileProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

ProfileProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		// debugger;
		var profile = new Profile();
		profile.init(cinMessage);
		this.value =  cinMessage.getBody();
		if(this.value){
			var contactResponse = CINResponse.getCINMessage(this.value);
			profile.setMobileNo(contactResponse.getString(CINRequestConts.HEADER_PHONE_NUMBER));
			profile.setName(contactResponse.getString(CINRequestConts.HEADER_RCS_NAME));
			profile.setMood(contactResponse.getString(CINRequestConts.HEADER_RCS_MOOD));
			profile.setExpression(contactResponse.getInt(CINRequestConts.HEADER_RCS_EXPRESSION));
			profile.setGender(contactResponse.getInt(CINRequestConts.HEADER_RCS_GENDER));
			profile.setPortraitId(contactResponse.getString(CINRequestConts.HEADER_RCS_PORTRAIT_ID));
		}
		this.uiCallback.onSuccess(profile);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
