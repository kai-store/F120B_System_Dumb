function InComingMessageProxyCallback(callback) {
	this.messageCallback = callback;
}


InComingMessageProxyCallback.prototype.parse = function(cinMessage) {
	switch (cinMessage.getMethod()) {		
		case CinRequestMethod.Message:
			var event = cinMessage.getEvent();
			event = parseInt(String(event));
			switch (event) {
				case CINRequestConts.EVENT_MESSAGE:
				// case CINRequestConts.TYPE_IMAGE:
				// case MessageConsts.TYPE_JIOMONEY:
					console.log("Incoming CINRequestConts.EVENT_MESSAGE cinMessage:" + cinMessage);
				    chat = new ChatMessage();
					chat.init(cinMessage);
					console.log("Chat MessageProxyCallback: ");
					console.log(chat);
					this.messageCallback.onTextMessage(chat);
					break;
				case MessageConsts.EMOTICON_PACKAGE_DOWNLOAD:
					var emoticont = new Emoticons();
					emoticon.setToken(cinMessage.getString(CINRequestConts.TOKEN));
					emoticon.setPkgSize(cinMessage.getInt(CINRequestConts.INDEX));
					emoticon.setKey(cinMessage.getInt(CINRequestConts.KEY));
					var isForceDelete = cinMessage.containsHeader(CINRequestConts,SUBVERSION);
					DataManager.getInstance().downloadEmoticonPackage(emoticon, isForceDelete);
					break;
				/*default:
					chat = new ChatMessage();
					chat.init(cinMessage);
					this.messageCallback.onTextMessage(chat);*/
			}
			break;

		case CinRequestMethod.PPMessage: 
		// debugger;
			var chat = this.getChatMessage(CINRequestConts.SESSIONPUBLIC, cinMessage);
			// this.messageCallback.onTextMessage(chat);
			// chat =  new ChatMessage();
			// chat.setSessionType(CINRequestConts.SESSIONPUBLIC);
			// chat.init(cinMessage);
			// if(chat.attachment && typeof chat.attachment === 'string'){
			// 	chat.setMessageBody(chat.attachment);
			// 	chat.attachment = undefined;
			// }
			if(!cinMessage.containsHeader(CINRequestConts.TYPE)){
				var msg = cinMessage.getBody();
				msg = JIOUtils.toString(msg);
				chat.setMessageBody(msg);
			}
			try{
				console.log("[PPM]", JSON.stringify(chat));
			}catch(e){
				
			}
			this.messageCallback.onTextMessage(chat);
			break;	
		
		case CinRequestMethod.GroupMessage:
			chat = new ChatMessage();
			chat.setSessionType(CINRequestConts.SESSIONGROUP);
			chat.init(cinMessage);
			this.messageCallback.onTextMessage(chat);
			break;

		case CinRequestMethod.Typing: 
			this.messageCallback.onTyping(cinMessage.getHeader(CINRequestConts.FROM));
			break;

		case CinRequestMethod.ReadReply: 
			isReadOtherOne = false;
			if (cinMessage.getEvent() === CINRequestConts.MESSAGE_READREPLY) {
				isReadOtherOne = true;
				peerId = cinMessage.getHeader(CINRequestConts.FROM);
				lastReadSeq = cinMessage.getInt(CINRequestConts.CSEQUENCE);
			}else {
				peerId = cinMessage.getHeader(CINRequestConts.INDEX);
			}
			chat = new ChatMessage();
			chat.init(cinMessage);
			this.messageCallback.onReadReply(peerId, isReadOtherOne, lastReadSeq, chat);
			break;

		case CinRequestMethod.Reply: 
			peerId = cinMessage.getHeader(CINRequestConts.FROM);
			var messageId = cinMessage.getHeader(CINRequestConts.MESSAGEID);
			chat = new ChatMessage();
			chat.init(cinMessage);
			this.messageCallback.onReply(peerId, messageId, chat);
			break;
			
		case CinRequestMethod.Data: 
			console.log("[DM] onDataReceived,");
			var event = cinMessage.getEvent();
			if (event == CINRequestConts.EVENT_TRANSPORT) {
				var fileId = cinMessage.getString(CINRequestConts.KEY);
				var index = 0;

				if (cinMessage.containsHeader(CINRequestConts.INDEX)) {
					index = cinMessage.getInt(CINRequestConts.INDEX);
				}
				var data = cinMessage.getBody();
				var instance  = DataManager.getInstance();
				var length = data.length;
				instance.getDownloadCallback().onFileDownload(fileId, data, index);
				instance.updateDownloadProgress(fileId, index, length);
				data = null;
			}else{
				console.log("** EXAMPLE **");
			}
			break;
		case CinRequestMethod.RobotMessage: 
			var chat = this.getChatMessage(CINRequestConts.SESSIONROBOT, cinMessage);
			this.messageCallback.onTextMessage(chat);
			break;
	}
};
InComingMessageProxyCallback.prototype.getChatMessage = function(sessionType, cinMessage){
	var chat =  new ChatMessage();
	chat.setSessionType(sessionType);
	chat.init(cinMessage);
	if(chat.attachment && typeof chat.attachment === 'string'){
		chat.setMessageBody(chat.attachment);
		chat.attachment = undefined;
	}
	return chat;
}
