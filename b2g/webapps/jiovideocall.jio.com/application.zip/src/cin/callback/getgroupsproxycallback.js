function GetGroupsProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

GetGroupsProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		var cinBody = cinResponse.getBodys();
		var groups = new Array();
		cinBody.forEach(function(item){
			cinItem = CINResponse.getCINMessage(item.val);
			var grpId = cinItem.getHeader(CINRequestConts.FROM);
			group = new GroupModel();
			group.setGroupId(grpId);
			var version = cinItem.getInt(CINRequestConts.TO);
			group.setVersion(version);
			groups.push(group);
		});
		console.log("Un comment....");
		this.uiCallback.onSuccess(groups);

		// new StatshThisGroupCode(groups, this.uiCallback).init();
	},
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.GROUP_INFO, "Unable to get group details.", callback);
	}
}

function StatshThisGroupCode(groups, callback){
	console.log("stash called");
	this.groups = groups;
	this.uiCallback = callback;
	this.groupInfo = new Array();
}

StatshThisGroupCode.prototype = {
	init: function(){
		console.log("stash inited");
		if(this.groups.length === 0){
			this.uiCallback.onSuccess(this.groups);
			return;
		}
		
		instance = JIOClient.getInstance();

		for(i=0; i<this.groups.length; i++){
			var grpID = this.groups[i].getGroupId();
			if(grpID && grpID!==null)
				instance.getGroupInfo(grpID, this);
		}
	},
	onSuccess: function(group){
		if(group.getGroupId()!==null && group.getGroupTitle()!==null){
			var that = this;
			// StatshThisGroupCode.groupInfo.forEach(function(groupInfo, index){

			// 	if(String(new Array(groupInfo.getGroupId())) == String(new Array(group.getGroupId()))){
			// 		this.groupInfo.pop();
			// 	}
			// });
			console.log("got response for groupcount"+this.groupInfo.length);

			this.groupInfo.push(group);
		}

		if(this.groupInfo.length === this.groups.length){
			console.log("got all the group data");

			this.uiCallback.onSuccess(this.groupInfo);
		}
	},

	onError: function(cinResponse){
		this.uiCallback.onError(cinResponse);
	}
};
