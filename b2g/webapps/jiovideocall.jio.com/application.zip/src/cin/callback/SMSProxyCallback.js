function SMSProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

SMSProxyCallback.prototype =  {
	onSuccess: function(data){
		this.uiCallback.onSuccess(data);
	},
	onError: function(cinMessage){
		if(!cinMessage.resHeaders || cinMessage.resHeaders === null){
			JIOUtils.sendError(100, "Please check your number.", this.uiCallback);
			return;	
		}

		if(cinMessage.isMethod(CINResponceConts.NeedVerifycation)){
			var messageId = cinMessage.getHeader(0x01);
			var imageData = cinMessage.getBody();
			
			this.uiCallback.onCaptcha(messageId, JIOUtils.toImage(imageData));
			return;
		}

		var msg = cinMessage.getBody();
		if(cinMessage.isMethod(CINResponceConts.NotAvailable)){
			msg = "Not Available";
		}
		
		JIOUtils.sendError(100, msg, this.uiCallback);
	}
}
