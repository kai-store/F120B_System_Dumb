function ReadReplyProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

ReadReplyProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		chatMessage = new ChatMessage();
		chatMessage.init(cinResponse);		
		this.uiCallback.onSuccess(chatMessage);
	},
	onError: function(cinMessage){
		this.uiCallback.onError(cinMessage);
	}
}
