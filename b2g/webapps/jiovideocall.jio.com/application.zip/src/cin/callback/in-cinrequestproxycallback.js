function CinRequestProxyCallback(cinMessage) {
	// this.uiCallback = uiCallback;
	this.cinMessage = cinMessage;
}

CinRequestProxyCallback.prototype =  {

	processRequest: function(){
		switch(this.cinMessage.getMethod()){
			case CinRequestMethod.Notify:
			// debugger; 
				this.parseNotification();
				return;
			
			case CinRequestMethod.JM_SIGNUP:
			case CinRequestMethod.JM_TRANSACTION:
			case CinRequestMethod.JM_LOADMONEY:
			case CinRequestMethod.Typing:
			case CinRequestMethod.ReadReply:
			case CinRequestMethod.Reply:
			case CinRequestMethod.Message:
			case CinRequestMethod.Data:
			case CinRequestMethod.PPMessage: 
			case CinRequestMethod.GroupMessage: 
			case CinRequestMethod.RobotMessage:
				this.parseMessage();
				return;

			case CinRequestMethod.Group: 
				this.parseGroup();
				break;

			case CinRequestMethod.Video: 
				this.parseVideo();
				break;

			case CinRequestMethod.Logon: 
				this.parseLogon();
				break;

			case CinRequestMethod.ChannelNotify:
				this.parseChannelNotify();
				break;
			
			case CinRequestMethod.IdamToken:
				this.parseToken();
				break;
		}

	}
}

CinRequestProxyCallback.prototype.parseNotification = function(){
	if(JioChatSDK && !JioChatSDK.getInstance().getSettings().isNotificationEnabled){
		return;
	}
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
	instance = JIOClient.getInstance();
	callback = instance.getNotificationCallback();
	// debugger;
	if(!callback || callback === null){
		return;
	}
	callback.parse(this.cinMessage);
}

CinRequestProxyCallback.prototype.parseMessage = function(){
	if(JioChatSDK && !JioChatSDK.getInstance().getSettings().isMessagesEnabled()){
		return;
	}

	instance = JIOClient.getInstance();
	callback = instance.getMessageCallback();
	if(!callback || callback === null){
		return;
	}
	callback.parse(this.cinMessage);
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
}

CinRequestProxyCallback.prototype.parseGroup = function(){
	if(JioChatSDK && !JioChatSDK.getInstance().getSettings().isGroupEnabled()){
		return;
	}
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
	instance = JIOClient.getInstance();
	callback = instance.getGroupCallback();
	if(!callback || callback === null){
		return;
	}
	callback.parse(this.cinMessage);
}

CinRequestProxyCallback.prototype.parseVideo = function(){
	if(JioChatSDK && !JioChatSDK.getInstance().getSettings().isCallEnabled()){
		return;
	}
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
	rtmcallback = RTMManager.getInstance().getCallback();
	if(rtmcallback && rtmcallback !== null)
		rtmcallback.parse(this.cinMessage);
}

CinRequestProxyCallback.prototype.parseLogon = function(){
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
	instance = JIOClient.getInstance();
	callback = instance.getNotificationCallback();
	if(!callback || callback === null){
		return;
	}

    if (this.cinMessage.getEvent() == CINRequestConts.EVENT_LOGOFF) {
     	callback.onLogoff();
     	return;
	}
	callback.onLogon(this.cinMessage);
}

CinRequestProxyCallback.prototype.parseChannelNotify = function(){
	if(JioChatSDK && !JioChatSDK.getInstance().getSettings().isChannelsEnabled()){
		return;
	}
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
	instance = JIOClient.getInstance();
	callback = instance.getMessageCallback();
	if(!callback || callback === null){
		return;
	}
	callback.parse(this.cinMessage);
}

CinRequestProxyCallback.prototype.parseToken = function(){
	try{
		JIOClient.getInstance().getCINClient().send(this.cinMessage.toRequest());
	}catch(e){
		console.log("Reply Error:");
		console.log(e);
	}
	instance = JIOClient.getInstance();
	callback = instance.getMessageCallback();
	if(!callback || callback === null){
		return;
	}
	callback.parse(this.cinMessage);	
}
