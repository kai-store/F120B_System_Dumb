function InComingGroupProxyCallback(callback) {
	this.messageCallback = callback;
}


InComingGroupProxyCallback.prototype.parse = function(request) {
	switch (request.getEvent()) {
		case CinRequestMethod.EVENT_GROUP_JOINED: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM)); //long
			groupModel.setInviter(request.getHeader(CINRequestConts.KEY));   // long
			groupModel.setName(request.getString(CINRequestConts.NAME));
			groupModel.setInviterName(request.getString(CINRequestConts.INDEX));
			groupModel.setGroupMaxMember(request.getInt(CINRequestConts.STATUS)); // int
			this.messageCallback.onGroupJoined(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_INFO_CHANGED: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setSourceID(request.getHeader(CINRequestConts.KEY));   // long
			groupModel.setName(request.getString(CINRequestConts.NAME));
			groupModel.setVersion(request.getInt(CINRequestConts.VERSION));
			groupModel.setGroupMaxMember(request.getInt(CINRequestConts.STATUS)); // int
			//verify the index value
			groupModel.setUserName(request.getString(CINRequestConts.INDEX));
			this.messageCallback.onGroupInfoChanged(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_BUDDY_UPDATE: 
		
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setVersion(request.getInt(CINRequestConts.VERSION));
			groupModel.setSourceID(request.getHeader(CINRequestConts.KEY));
			groupModel.setSourceName(request.getString(CINRequestConts.NAME));
			var keys = request.getBodys();
			var newMembers = [];
			keys.forEach(function(cinMessageBody,index){
				contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, true);
				userId = contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_PHONE);
				name = JIOUtils.toString(contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_NAME));					
				newMembers.push({'key':userId, "value":name});					
			});
			groupModel.setNewMembers(newMembers);
			groupModel.setIsFromInvite(request.getInt(CINRequestConts.TYPE) === 1);
			this.messageCallback.onGroupBuddyUpdate(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_BUDDY_LEAVE: 
		
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setVersion(request.getInt(CINRequestConts.VERSION));
			groupModel.setSourceID(request.getHeader(CINRequestConts.KEY));
			groupModel.setSourceName(request.getString(CINRequestConts.NAME));
			var keys = request.getBodys();
			var newMembers = [];
			keys.forEach(function(cinMessageBody,index){
				contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, true);
				userId = contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_PHONE);
				name = JIOUtils.toString(contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_NAME));					
				newMembers.push({'key':userId, "value":name});					
			});
			groupModel.setNewMembers(newMembers);
			this.messageCallback.onGroupBuddyLeave(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_SET_CHANGED: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setMsgType(request.getInt(CINRequestConts.TYPE));
			this.messageCallback.onGroupSetChanged(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_JOIN_NOTIFY: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			this.messageCallback.onGroupJoinedSyncNotify(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_OTHER_CHANGE_PORTRAIT: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setVersion(request.getInt(CINRequestConts.VERSION));
			groupModel.setSourceID(request.getHeader(CINRequestConts.INDEX));
			groupModel.setPortraitId(request.getString(CINRequestConts.TOKEN));
			groupModel.setPortraitSize(request.getHeader(CINRequestConts.DEVICETOKEN)); //long 
			var thumb = request.getBody();
			this.messageCallback.onGroupPortraitChanged(groupModel,thumb);
		break;

		case CinRequestMethod.EVENT_GROUP_ADMIN_UPDATE: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setVersion(request.getInt(CINRequestConts.VERSION));
			groupModel.setAdminUserId(request.getHeader(CINRequestConts.STATUS)); //long
			groupModel.setAdminName(request.getString(CINRequestConts.NAME));
			this.messageCallback.onGroupAdminUpdated(groupModel);
		break;

		case CinRequestMethod.EVENT_GROUP_ADMIN_UPDATE_FOR_NEW_ADMIN: 
			groupModel = new GroupModel();
			groupModel.setGroupId(request.getHeader(CINRequestConts.FROM));
			groupModel.setVersion(request.getInt(CINRequestConts.VERSION));
			this.messageCallback.onGroupAdminUpdatedForNewAdmin(groupModel);
		break;
	};
};
