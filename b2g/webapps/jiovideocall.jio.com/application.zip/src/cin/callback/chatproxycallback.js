function ChatProxyCallback(uiCallback, chatObject){
	this.uiCallback = uiCallback;
	this.chatObject  = chatObject;
}

ChatProxyCallback.prototype = {

	onSuccess: function(cinMessage){
		chatMessage = new ChatMessage();

		chatMessage.init(cinMessage);

		if(this.chatObject && this.chatObject!==null){

			var messageId = this.chatObject.getMessageId();

			chatMessage.setMessageId(messageId);
			
			type = this.chatObject.getMessageType();
			chatMessage.setMessageType(type);

			if(type && type === CINRequestConts.TYPE_FREE_SMS){
				chatMessage.dayQuota = cinMessage.getInt(CINRequestConts.KEY);
				chatMessage.monthQuota = cinMessage.getHeader(CINRequestConts.INDEX);
			}

			// var to = this.chatObject.getTo();
			// var peerIds = new Array();
			// peerIds.push(to);
			// var mainAttachment = this.chatObject.getAttachment();
			
			// switch(type){
			// 	case MessageConsts.TYPE_IMAGE:
			// 	case MessageConsts.TYPE_VOICE:
			// 	case MessageConsts.TYPE_VIDEO:
			// 	// case MessageConsts.TYPE_EMOTICON:
			// 	case MessageConsts.TYPE_GRAFFI:
			// 	case MessageConsts.TYPE_FILE:
			// 		mainAttachment.peerIds = peerIds;
			// 		DataManager.getInstance().addAttachmet(mainAttachment);
			// 		break;
			// 	case MessageConsts.TYPE_LOCATION:
			// 		if(mainAttachment.thumbnailObj!==null){
			// 			mainAttachment.peerIds = peerIds;
			// 			DataManager.getInstance().addAttachmet(mainAttachment.thumbnailObj);
			// 		}
			// 		break;

			// }
		}		
		this.uiCallback.onSuccess(chatMessage);
	},
	
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.SEND_MSG, "Unable to send Message.", callback);
	}
}
