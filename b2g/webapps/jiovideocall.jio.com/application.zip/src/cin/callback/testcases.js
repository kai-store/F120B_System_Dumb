function TestCase(callback) {
	this.uiCallback = callback;
}

TestCase.prototype.run = function() {

    RMCManager.getInstance().getChannelList(1,{
        onSuccess: function(msg){            
            console.log("getChannelList ---- "+ JSON.stringify(msg));
        },
        onError: function(msg){
           console.log('getChannelList Error' + JSON.stringify(msg));
        },
    })

    //this.call();
//   JIOClient.getInstance().getFreeSmsQuota({
//                 onSuccess: function(msg){            
//                     console.log("getFreeSmsQuota ---- "+ JSON.stringify(msg));
//                 },
//                 onError: function(msg){
//                    console.log('getFreeSmsQuota Error' + JSON.stringify(msg));
//                 },
//             });
	// JIOClient.getInstance().keepAlive();
	/* var profile = new Profile();
	profile.setName('aaa');
	JIOClient.getInstance().updateProfile(profile, this.uiCallback);*/
	// JIOClient.getInstance().getProfile(this.uiCallback);

	// LogonProxyCallback.uploadContacts();


	//this.chatTest();
	//LogonProxyCallback.uploadContacts();

	// LogonProxyCallback.createGroupTest();
	// LogonProxyCallback.createGroupTest();
	// LogonProxyCallback.chatTest();
	// LogonProxyCallback.uploadContacts();


	//this.syncUpContacts();
    // this.createGroupTest();

   // this.getContactProfileInfo();
	//this.syncUpContacts();


    //this.createGroupTest();
     var profiles = [];
    var groupId = [61,54,46,-116,-47];
    var userId = [110,1,103,30,2];
    var userId2 = [-52,1,103,30,2]
    var profile = new Profile();
    profile.setName('sushma');
    profile.setUserID(userId);   
    profiles.push(profile);
    var profile = new Profile();
    profile.setName('test');
    profile.setUserID(userId2);
    profiles.push(profile);

   /* JIOClient.getInstance().groupInvite(groupId, 'test',profiles,{
        onSuccess: function(msg){            
            console.log("Clear ---> HIS ---- "+msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });*/

    this.getGroupList();
  //  var userID = UserModel.getInstance().getUserID();
  /*  JIOClient.getInstance().getGroupProfile(groupId,{
        onSuccess: function(msg){            
            console.log("Clear ---> HIS ---- "+ msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });*/
    // var userID = [92,-7,83,101];
    // JIOClient.getInstance().getUserCard(userID,1,1,{
    /*DataManager.getInstance().getEmoticons(1,{
        onSuccess: function(msg){            
            console.log("getprofile ---- "+ msg);
        },
        onError: function(msg){
           console.log('Error' + msg);
        },
    });
    });*/
};

function getEmoticonsdetails(keys){
    DataManager.getInstance().getEmoticonInfo(keys,{
        onSuccess: function(msg){            
            console.log("getEmoticons keys---- "+ msg.toString()); 
        },
        onError: function(msg){
           console.log('getEmoticons keys Error' + msg.toString());
        },
    }); 
}

};
TestCase.prototype.invite = function(){
    tinyInstance = TinyUrl.getInstance();
    var url = tinyInstance.getUrl();
     if (url && url.length > 0){
        callInvite(url);
     }else{
        JIOClient.getInstance().getTinyUrl({
            onSuccess: function(url){
                callInvite(url);
                console.log(msg);
            },
            onError: function(msg){
               console.log('Error');
            },
        });
     }    
}

function callInvite(url){
    /* JIOClient.getInstance().inviteViaEmail('sushma@divum.in',url,{
        onSuccess: function(msg){
            console.log(msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });*/
    JIOClient.getInstance().inviteViaSMS('+919513193889',url,{
        onSuccess: function(msg){
            console.log(msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });
}

TestCase.prototype.getContactProfileInfo = function(){
    // var userId = [110,1,103,30,2];
     var profile = new Profile();
     profile.setName('sush das');
     profile.setMood('liked jio');
     profile.setExpression(1);
     profile.setGender(1);
    /* var phonebook = [];
     phonebook.push('+918259275281');*/

    JIOClient.getInstance().updateProfile(profile,{
        onSuccess: function(msg){
            console.log(msg);
            JIOClient.getInstance().getProfile({
                onSuccess: function(msg){
                    console.log('getProfile'+ msg);
                },
                onError: function(msg){
                   console.log('getProfile'+'Error' + msg);
                },
            });
        },
        onError: function(msg){
           console.log('Error');
        },
    });
};

TestCase.prototype.call = function(hdCall){
    hdCall = new HDCall();
    hdCall.setTo(new Int8Array(16,-41,-102,59))
    hdCall.setFrom(UserModel.getInstance().getUserID());
    RTMManager.getInstance().call(hdCall, {
        onSuccess: function(){

        },
        onError: function(){
            
        }
    });

}; 
TestCase.prototype.syncUpContacts = function(){
    var phonebook = [];

    var obj = {};
    obj.name = 'sushma';
    obj.mobileNo = '+918259275281';
    phonebook.push(obj);

    var obj = {};
    obj.name = 'test12';
    obj.mobileNo = '+919259275281';
    phonebook.push(obj);
    var index = 1,isLast = 1;

   instance1.contactSync(phonebook,index,isLast,{
        onError: function(errorJSON){
            console.log(errorJSON);
        },
        onSuccess: function(response){
           console.log(response);           
        }
    });

   /* var phoneList = [];
            var obj = {};
            obj.name = 'das';
            obj.mobileNo = '+919259275281';
            obj.userId = [-50,1,103,30,2];
            phoneList.push(obj);
            instance1.handleBlackList(phoneList,2,{
                onError: function(errorJSON){
                    console.log('handleBlackList error '+ errorJSON);
                },
                onSuccess: function(version, userId,phonebook){
                   console.log('handleBlackList response '+ version.toString() + " " + userId.toString());
                }
            });*/

    /*var phoneList = [];
    phoneList.push('+919259275281');
    instance1.deleteContact(phoneList,{
        onError: function(errorJSON){
            console.log('delete contact error '+ errorJSON);
        },
        onSuccess: function(response){
           console.log('delete contact response '+ response);
        }
    });*/

   
     /*instance1.getAllBlackListContacts({
        onError: function(errorJSON){
            console.log('getAllBlackListContacts error '+ errorJSON);
        },
        onSuccess: function(response){
           console.log('getAllBlackListContacts response '+ response.toString());
        }
    });*/
}

TestCase.prototype.chatTest = function(){
    userIDs = new Array();

     userID = [-75,85,36,24,1];
    userIDs.push(userID);
    JIOClient.getInstance().sendRawMessage(null, userIDs,
     MessageConsts.TYPE_TEXT,"hi",{
        onSuccess: function(msg){
            console.log('---- Sent message Success chatTest---- ');
            // TestCase.prototype.chatTest();
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
}

TestCase.prototype.getGroupList = function(){
    userId = UserModel.getInstance().getUserID();
    userID = [110,1,103,30,2];
    JIOClient.getInstance().getGroupList(userId, {
        onSuccess: function(msg){
            var groupId = msg.getTo();
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
}

TestCase.prototype.updateGroupTest = function(groupId){
    userId = UserModel.getInstance().getUserID();
    var array = new Array();
    var pratima = [58,44,29,-77,1];
    array.push(userId);
    array.push(pratima);
    var group = new Group();
    var groupId = group.getGroupId();
    JIOClient.getInstance().updateGroup(groupId, "new Testing Group","new Testing Group" ,{
        onSuccess: function(msg){
            console.log('update Group list Success');
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
}


TestCase.prototype.createGroupTest = function(){
    userId = UserModel.getInstance().getUserID();
    user1 = [122,-76,-12,-54,1];
    user2 = [41,-76,-12,-54,1];
    user3 = [88,-115,-19,101,2];
    var array = new Array();
    array.push(user1);
    array.push(user2);
    array.push(user3);
    that = this;

    JIOClient.getInstance().createGroup(userId, "sushma","sushma 345" ,array,{
        onSuccess: function(msg){
           // this.getGroupListTest();
           console.log('create Group Success' + msg);
           that.getGroupInformation(msg.groupId);
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
};

TestCase.prototype.getGroupInformation = function(groupId){
    // var groupId = [65,55,46,-116-47];

    JIOClient.getInstance().getGroupInfo(groupId, {
        onSuccess: function(msg){
            console.log(msg.toString());
        },
        onError: function(msg){
           console.log('Error');
        },
    });
 };
