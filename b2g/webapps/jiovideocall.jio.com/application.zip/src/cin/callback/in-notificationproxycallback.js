function InComingNotificationProxyCallback(callback) {
	this.notifyCallback = callback;
}

InComingNotificationProxyCallback.prototype.parse = function(request) {
	// debugger;
	switch (request.getEvent()) {
		case CinRequestMethod.EVENT_CONTACT_LIST_CHANGED: 
			this.contactListChanged(request);				
			break;

		case CinRequestMethod.EVENT_NOTIFY_CONTACT_LIST: 
			this.contactListNotify(request);
			break;

		case CinRequestMethod.EVENT_BLACK_LIST_CHANGED: 
			this.blackListChanged(request);
			break;

		case CinRequestMethod.EVENT_FAVORITE_CONTACT_CHANGED:
			var version = request.getInt(CINRequestConts.VERSION); 
			this.notifyCallback.onFavoriteContactChanged();
			break;

		case CinRequestMethod.EVENT_SELECTED_MSG_CHANGED: 
			var keys = request.getBodys();
			var value,isAdd,key,dateTime;
			keys.forEach(function(cinMessageBody,index){
				value = CINResponse.getCINMessage(cinMessageBody.val, null, true);
				isAdd =  JIOUtils.toLong(contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_PHONE)) === 1;
				key = contactResponse.getHeader(CinBase64.getByte(0x02));					
				dateTime = JIOUtils.toLong(contactResponse.getHeader(CinBase64.getByte(0x03)));				
			});
			this.notifyCallback.onFavoriteMsgChanged();
			break;

		case CinRequestMethod.EVENT_REVERSE_CONTACT_VERSION_CHANGED : 
			var version = JIOUtils.toLong(request.getHeader(CINRequestConts.VERSION)); 
			var body = request.getBody();
			body = CINResponse.getCINMessage(body.val, null, true);
			var userId = body.getHeader(CinBase64.getByte(CINRequestConts.GET_USER_ID_BODY_PHONE));
			var mobile = JIOUtils.toString(body.getHeader(CINRequestConts.MOBILE));
			var name = null;
			if(JIOUtils.toString(body.getHeader(CinBase64.getByte(0x03) != ""))) {
				name = JIOUtils.toString(body.getHeader(CinBase64.getByte(0x03)));
			};
			profile = new Profile();
			profile.setMobileNo(mobile);
			profile.setName(name);
			profile.setUserID(userId);
			this.notifyCallback.reverseContactChanged(profile);
			break;

		case CinRequestMethod.EVENT_SELF_AVATAR_CHANGED: 
			var avatarId =  JIOUtils.toLong(request.getHeader(CINRequestConts.VERSION));
			var data = request.getBody();
			this.notifyCallback.selfAvatarChanged(avatarId, data);
			break;

		case CinRequestMethod.EVENT_DND_CHANGED: 
			var type = JIOUtils.toLong(request.getHeader(CinHeaderType.TYPE));
			var dndStart = -1;
			var dndInterval = -1;
			if (type == 1) {
				dndStart = JIOUtils.toLong(request.getHeader(CinHeaderType.DATETIME));
				dndInterval =  JIOUtils.toLong(request.getHeader(CinHeaderType.EXPIRE));
			}
			this.notifyCallback.onDNDSettingChanged();
			break;

		case CinRequestMethod.EVENT_PHONE_BOOK_CHANGED:
			var serverVersion = JIOUtils.toLong(request.getHeader(CINRequestConts.VERSION));
			this.notifyCallback.onPhoneBookChanged();
			break;

		case CinRequestMethod.EVENT_SET_LAST_SEEN: 
			var lastSeen = JIOUtils.toLong(request.getHeader(CINRequestConts.STATUS)) == CinBase64.getByte(0x01);
			this.notifyCallback.onSetLastSeenChanged(lastSeenlastSeen);
			break;

		case CinRequestMethod.EVENT_SET_MESSAGE_PREVIEW: 
			var lastSeen = JIOUtils.toLong(request.getHeader(CINRequestConts.STATUS)) == CinBase64.getByte(0x01);
			this.notifyCallback.onMessagePreviewChanged(lastSeen);
			break;

		case CinRequestMethod.EVENT_SET_SOCIAL_RECIEVE_NOTIFY: 
			var msg = CINResponse.getCINMessage(request.getBody());
			var type = JIOUtils.toLong(msg.getHeader(CinBase64.getByte(0x0A)));
			var resNotify =	JIOUtils.toLong(request.getHeader(CinBase64.getByte(0x12))) == CinBase64.getByte(0x01);
			if (type == CinRequestMethod.TYPE_RECEIVE_CONTENT) {					
				this.notifyCallback.onSetReceiveContentChanged(resNotify);
			} else if (type == CinRequestMethod.TYPE_RECEIVE_FRIEND) {
				this.notifyCallback.onSetReceiveFriendChanged(resNotify);
			}				
			break;

		case CinRequestMethod.EVENT_NOTIFY_CLIENT_STATUS:
			var isOnLine = false;
			var dateTime = 0;
			var userId = request.getHeader(CINRequestConts.FROM);
			if (request.getHeader(CINRequestConts.DATETIME)) {
				isOnLine = false;
				dateTime = JIOUtils.toLong(request.getHeader(CINRequestConts.DATETIME));
			}else {
				isOnLine = true;
			} 
			console.log("User changed status....");
			if(this.notifyCallback && this.notifyCallback.onClientStatusChanged){
				this.notifyCallback.onClientStatusChanged(userId, dateTime, isOnLine);
			}
			break;

		case CinRequestMethod.EVENT_NOTIFY_FREE_SMS_QUOTA_CHANGED: 
			var dayQuota = JIOUtils.toLong(request.getHeader(CINRequestConts.KEY));
			var monthQuota = JIOUtils.toLong(request.getHeader(CINRequestConts.INDEX));
			this.notifyCallback.onFreeSmsQuotaChange(dayQuota,monthQuota);
			break;

		/*case CinRequestMethod.EVENT_PC_UPLOAD_CONTACT_NOTIFY: 
				this.callback.onPCUploadContactNotify();
		break;

		case CinRequestMethod.EVENT_PC_OFFLINE_UPLOAD_CONTACT_NOTIFY: 
				this.callback.onPCOfflineUploadContactNotify();
		break;

		case CinRequestMethod.EVENT_PC_CANCRL_UPLOAD_CONTACT_NOTIFY: 
				this.callback.onPCCancelUploadContactNotify();
		break;

		case CinRequestMethod.EVENT_PC_NOTIFY_READREPLY: 
				this.callback.onNotifyReadReply();
		break;*/

		case CinRequestMethod.EVENT_NOTIFY_PUBLIC_SET_FOUCS: 
			if (CINRequestConts.HAS_PUBLIC_FUNCTION) {
				var publicId = request.getHeader(CINRequestConts.FROM);
				var isAttentive = JIOUtils.toLong(request.getHeader(CINRequestConts.TYPE)) == 1;
				this.notifyCallback.onPublicSetFocus(publicId, isAttentive);
			}			
			break;

		case CinRequestMethod.EVENT_NOTIFY_MESSAGE_READREPLY_CHANGE: 
			messageReadReply = JIOUtils.toLong(request.getHeader(CINRequestConts.STATUS));

			if (this.notifyCallback && typeof this.notifyCallback.onMessaageReadReplyChange ===  "function"){
				this.notifyCallback.onMessaageReadReplyChange(messageReadReply == 0 ? false : true);
			}
			break;
	}
};

InComingNotificationProxyCallback.prototype.contactListChanged = function(request){
	var version = JIOUtils.toLong(request.getHeader(CINRequestConts.VERSION));
	var uids = [];
	var updateContacts = [];
	var deletedUIDs = [];
	var keys = request.getBodys();
	var uid = null;
	keys.forEach(function(cinMessageBody, index){
		contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, false);
		uid = contactResponse.getHeader(CinBase64.getByte(0x01));
		handleType = JIOUtils.toLong(contactResponse.getHeader(CinBase64.getByte(0x02)));					
		if (handleType == 0) {// Delete
			deletedUIDs.push(uid);
		}else {
			uids.push(uid);
			// updateContacts.push(CINResponse.getCINMessage(contactResponse.getBody()));
		}				
	});
	console.log("Contact list changed in InComingNotificationProxyCallback");
	if (this.notifyCallback && typeof this.notifyCallback.onContactListChanged ===  "function"){
		this.notifyCallback.onContactListChanged(uids, deletedUIDs);
	}
};

InComingNotificationProxyCallback.prototype.contactListNotify = function(request) {
	if (request != null && request.getHeader(CINRequestConts.TYPE)) {
		var type = JIOUtils.toLong(request.getHeader(CINRequestConts.TYPE));
		if (type !== 0) {
			this.notifyCallback.onGetUserIdNotify();
			return;
		}

		var profiles = new Array();

		var keys = request.getBodys();
		keys.forEach(function(cinMessageBody, index){
			var msg = CINResponse.getCINMessage(cinMessageBody.val, null, true);
			if (!msg.containsHeader(CinBase64.getByte(0x01)) || !msg.containsHeader(CinBase64.getByte(0x02))) {
				return;
			}
			var userId = msg.getHeader(CinBase64.getByte(0x01));
			var mobile = msg.getString(CinBase64.getByte(0x02));
			var name = null;
			if (msg.getHeader(CinBase64.getByte(0x03))) {
				name = msg.getString(CinBase64.getByte(0x03));
			}
			profile = new Profile();
			profile.setUserID(userId);
			profile.setName(name);
			profile.setMobileNo(mobile);
			profiles.push(profile);
		});
		console.log("in contact list notify"+JSON.stringify(profiles));
		if (this.notifyCallback && typeof this.notifyCallback.onContactListNotify ===  "function"){
			this.notifyCallback.onContactListNotify(profiles);
		}
	}
};

InComingNotificationProxyCallback.prototype.blackListChanged = function(request){
	var version = JIOUtils.toLong(request.getHeader(CINRequestConts.VERSION));
	var msg = CINResponse.getCINMessage(request.getBody());
	var type = JIOUtils.toLong(msg.getHeader(CINRequestConts.TYPE));
	if (type == 2) {
		if (this.notifyCallback && typeof this.notifyCallback.blacklistChanged === "function"){
			this.notifyCallback.onBlacklistChanged(true, version, true, -1, null, null);
		}
		return;
	}
	// else {
	var keys = msg.getBodys();
	keys.forEach(function(cinMessageBody,index){
		message = CINResponse.getCINMessage(cinMessageBody.val, null, true);
		var userId = JIOUtils.toLong(message.getHeader(CinBase64.getByte(0x01)));
		var name = JIOUtils.toString(message.getHeader(CinBase64.getByte(0x02)));
		var mobileNum = JIOUtils.toString(message.getHeader(CinBase64.getByte(0x03)));
		var blackListChnaged = true;
		
		if (type == 0) {
			blackListChnaged = false;
		}
		if(type == 0 || type == 1){
			if (this.notifyCallback && typeof this.notifyCallback.onBlacklistChanged === "function"){
				this.notifyCallback.onBlacklistChanged(false, version, blackListChnaged, userId, name, mobileNum);
			}
		}

	});
	// }
};

InComingNotificationProxyCallback.prototype.onLogoff = function(cinMessage) {
	// debugger;
	//var errMsg = cinMessage.getBody() == null ? null : cinMessage.getBody();
	if (this.notifyCallback && typeof this.notifyCallback.logout === "function") { 
		this.notifyCallback.logout();
	}

};
