function AutoregisterbymobilenoCallback(callback){
    this.uiCallback = callback;
}

AutoregisterbymobilenoCallback.prototype = {
    onSuccess: function(cinResponse){
        UserModel.getInstance().initAutoRegister(cinResponse); 
		JIOClient.getInstance().getProfile(this.uiCallback);
    },
    onError: function(error){
        console.log('Auto logon err '+ JSON.stringify(error));
        JIOUtils.sendError(100, error, this.uiCallback);
    }
}
