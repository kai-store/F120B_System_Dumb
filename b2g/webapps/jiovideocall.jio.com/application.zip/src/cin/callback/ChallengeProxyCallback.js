function ChallengeProxyCallback(uiCallback, isFirstTime) {
	this.uiCallback = uiCallback;
	
	if(isFirstTime === undefined || isFirstTime === null){
		isFirstTime=true;
	}

	this.isFirstTime = isFirstTime;
}

ChallengeProxyCallback.prototype =  {
	onSuccess: function(cinMessage, data){
		//Need to test
		// debugger;
		if(!cinMessage){
			this.uiCallback.onSuccess(data);
			return;
		}

		sKey = cinMessage.getHeader(CINRequestConts.KEY);

		if(sKey === null || sKey.length === 0){
			JIOUtils.sendError(200, "Challenge request", this.uiCallback);
			return;
		}
		UserModel.getInstance().setServerKey(sKey);
		// debugger
		JIOClient.getInstance().logon(new LogonProxyCallback(this.uiCallback, this.isFirstTime));
	},
	onError: function(error){

		this.uiCallback.onError(error);
	}
}
