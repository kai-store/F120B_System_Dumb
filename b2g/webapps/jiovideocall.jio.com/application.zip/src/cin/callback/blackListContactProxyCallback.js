function BlackListContactProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

BlackListContactProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		console.log(cinMessage);		
		var version = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.VERSION));
		var userId = cinMessage.getHeader(CINRequestConts.FROM);
		var keys = cinMessage.getBodys();
		var phoneBook = [];
		if(keys){
			keys.forEach(function(cinMessageBody,index){
				contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, false);
				profileObj = new Profile();
				profileObj.setUserID(contactResponse.getHeader(CINRequestConts.HEADER_USER_ID));
				profileObj.setMobileNo(JIOUtils.toString(contactResponse.getHeader(CINRequestConts.HEADER_MOBILE)));
				profileObj.setName(JIOUtils.toString(contactResponse.getHeader(CINRequestConts.HEADER_NAME)));
				phoneBook.push(profileObj);
		   });	
		}		
		this.uiCallback.onSuccess(version,userId,phoneBook);
	},
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.BLACK_LIST, "Unable to block/unblock contact.", callback);
	}
}
