function GroupPortraitProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

GroupPortraitProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		group = new GroupModel();
		group.setGroupId(cinMessage.getHeader(CINRequestConts.TO));
		group.setPortraitId(cinMessage.getString(CINRequestConts.TOKEN));
		group.setPortraitSize(cinMessage.getInt(CINRequestConts.DEVICETOKEN));
		group.setVersion(cinMessage.getInt(CINRequestConts.VERSION));
		group.setThumb(JIOUtils.toImage(cinMessage.getBody()));
		this.uiCallback.onSuccess(group);
	},
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.CAPTCHA_CODE, "Unable to get captcha.", callback);
	}
}
