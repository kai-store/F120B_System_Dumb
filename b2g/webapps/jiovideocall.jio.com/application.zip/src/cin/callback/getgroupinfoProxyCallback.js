function GetGroupInfoProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

GetGroupInfoProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		var group = new GroupModel();
		group.setGroupId(cinResponse.getHeader(CINRequestConts.TO));
		group.setGroupTitle(cinResponse.getString(CINRequestConts.NAME));
		group.setGroupMaxMember(cinResponse.getInt(CINRequestConts.STATUS));
		group.setNewMembers(cinResponse.getHeaders(CINRequestConts.INDEX));
		group.setVersion(cinResponse.getInt(CINRequestConts.VERSION));		
		this.uiCallback.onSuccess(group);
	},
	onError: function(cinMessage){
		this.uiCallback.onError(cinMessage);
	}
}
