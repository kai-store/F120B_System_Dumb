function LogonProxyCallback(uiCallback, isFirstTime) {
	
	if(isFirstTime === undefined || isFirstTime === null){
		isFirstTime = true;
	}

	this.uiCallback = uiCallback;
	this.isFirstTime = isFirstTime;
}

LogonProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		UserModel.getInstance().initLogon(cinMessage);

		this.uiCallback.onSuccess(cinMessage);

		var instance = JIOClient.getInstance();
		var sockCallback = instance.getSocketCallback();
		if(sockCallback && sockCallback.onReConnect){
			sockCallback.onReConnect();
		}
	    // if(this.isFirstTime === true){
		instance.stopKeepAlive();
		instance.keepAlive();
		// if(!AppMode.TYPE=="JVC"){
			// // RTMManager.getInstance().getOfflineCallLogs();
			// 	instance.getAllOfflineMessages();
			// }
			// instance.getAllOfflineMessages();
			// RTMManager.getInstance().getOfflineCallLogs();
			// new TestCase(this.uiCallback).run();
			// return;
     	// }
     	// this.uiCallback.onSuccess(cinMessage);
    },

	onError: function(cinMessage){
		this.uiCallback.onError(cinMessage);
	}
}
