function CINResponceConts(){
}
	
CINResponceConts.OK = CinBase64.getByte(0x80); //0x80);
CINResponceConts.NotAvailable = CinBase64.getByte(0x81); //0x81); //-127); 
CINResponceConts.Error = CinBase64.getByte(0x82);
CINResponceConts.Busy = CinBase64.getByte(0x83);
CINResponceConts.NotExist = CinBase64.getByte(0x84);
CINResponceConts.NotSupport = CinBase64.getByte(0x85);
CINResponceConts.NeedVerifycation = CinBase64.getByte(0x86); //0x86); //-122); 
CINResponceConts.Trying = CinBase64.getByte(0xB0);
CINResponceConts.Processing = CinBase64.getByte(0xB1);
CINResponceConts.Pending = CinBase64.getByte(0xB2);
CINResponceConts.ClientOffLine = CinBase64.getByte(0xFD);
CINResponceConts.Unknown = CinBase64.getByte(0xFE);
