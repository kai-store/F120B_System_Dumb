function HTTPRequestConts() {
    
}


//-----------setting enviornment prod, pre-prod or IOT ------
HTTPRequestConts.setIOT = function () {
    HTTPRequestConts.BASE_URL = 'https://iotnav.rsocial.net:8011/';
    HTTPRequestConts.BASE_URL_ACP = 'https://iotacp.rsocial.net:8091/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://iotacp.rsocial.net:8091/';
    HTTPRequestConts.initBaseURLS();
    console.log("HTTP links are pointing to IOT");
}

HTTPRequestConts.setProduction = function () {
    HTTPRequestConts.BASE_URL = 'https://nav.jiobuzz.com/';
    HTTPRequestConts.BASE_URL_ACP = 'https://acp.jiobuzz.com/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://acp.jiobuzz.com/';
    HTTPRequestConts.initBaseURLS();
    console.log("HTTP links are pointing to Production");
    HTTPRequestConts.isProd = true;
}

HTTPRequestConts.setPreProduction = function () {
    HTTPRequestConts.BASE_URL = 'https://preprod.rsocial.net:9000/';
    HTTPRequestConts.BASE_URL_ACP = 'https://preprod.rsocial.net:9001/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://preprod.rsocial.net:9001/';
    HTTPRequestConts.initBaseURLS();
    console.log("HTTP links are pointing to pre-Production");
    HTTPRequestConts.isProd = false;

}

HTTPRequestConts.setReplica = function () {
    HTTPRequestConts.BASE_URL = 'https://navreplica.rsocial.net:8010/';
    HTTPRequestConts.BASE_URL_ACP = 'https://acpreplica.rsocial.net:8020/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://acpreplica.rsocial.net:8020/';
    HTTPRequestConts.initBaseURLS();
    console.log("HTTP links are pointing to Replica");
}

HTTPRequestConts.initBaseURLS = function(){
    HTTPRequestConts.GET_NAV = HTTPRequestConts.BASE_URL + "nav/nav";
    HTTPRequestConts.SMS_ACP = HTTPRequestConts.BASE_URL_ACP + 'acp/getrandomcodeforregister';
    HTTPRequestConts.VALIDATE_OTP = HTTPRequestConts.BASE_URL_ACP + 'acp/registeruserbytoken';
    HTTPRequestConts.GEN_CAPTCHA_CODE = HTTPRequestConts.BASE_URL_ACP + 'acp/getpiccode';
    HTTPRequestConts.AUTO_LOGIN_DETAILS = HTTPRequestConts.BASE_URL_ACP_LOGIN + 'acp/autoregisterbymobileno';
}
// HTTPRequestConts.setProduction();

// HTTPRequestConts.isProd = true;
// if(!HTTPRequestConts.isProd && HTTPRequestConts.isProd !== undefined){
//     ServerConfig.setPreProduction();

//     // HTTPRequestConts.BASE_URL = 'https://preprod.rsocial.net:9000/';
//     // HTTPRequestConts.BASE_URL_ACP = 'https://preprod.rsocial.net:9001/';
//     // HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://preprod.rsocial.net:9001/';

//      //IOT 

//     // HTTPRequestConts.BASE_URL = 'https://iotnav.rsocial.net:8011/';
//     // HTTPRequestConts.BASE_URL_ACP = 'https://iotacp.rsocial.net:8091/';
//     // HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://iotacp.rsocial.net:8091/';
// }else if(HTTPRequestConts.isProd){// && HTTPRequestConts.isProd !== undefined
//     ServerConfig.setProduction();

//     // HTTPRequestConts.BASE_URL = 'https://nav.jiobuzz.com/';
//     // HTTPRequestConts.BASE_URL_ACP = 'https://acp.jiobuzz.com/';
//     // HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://acp.jiobuzz.com/';


//     //Replica
//     // HTTPRequestConts.BASE_URL = 'https://navreplica.rsocial.net:8010/';
//     // HTTPRequestConts.BASE_URL_ACP = 'https://acpreplica.rsocial.net:8020/';
//     // HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://acpreplica.rsocial.net:8020/';
// }else if(HTTPRequestConts.isProd === undefined){
//     ServerConfig.setIOT();
// }
//-----------setting enviornment prod, pre-prod or IOT end------

// HTTPRequestConts.BASE_URL = 'https://preprod.rsocial.net:9000/';
// HTTPRequestConts.BASE_URL_ACP = 'https://preprod.rsocial.net:9001/';
// HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://preprod.rsocial.net:9001/';
// HTTPRequestConts.BASE_URL = 'http://49.40.2.134:8000/';
// HTTPRequestConts.BASE_URL_ACP = 'http://49.40.2.134:8020/';

// HTTPRequestConts.DOMAIN = '49.40.2.134';

HTTPRequestConts.TINY_URL = 'https://tinyurl.com/api-create.php?apikey=A9007FC1A77A00A59DBG&url=https://teu24.app.goo.gl/?link=https://jiochat.com/get&amp;utm_source=JIO_bdlxnoxi&amp;ibi=com.jiochatapp.jiochat&amp;apn=com.jiochat.jiochatapp';
HTTPRequestConts.AUTO_LOGIN = 'http://api.ril.com/v2/users/me?profile=basic&attributes=msisdn,imei,imsi';
HTTPRequestConts.QR_CODE = 'http://cacheqrcode';
HTTPRequestConts.GET = 'GET';
HTTPRequestConts.GET_NAV_C_VER = 'cver';
HTTPRequestConts.GET_NAV_C_VER_VAL = 'featurephone_1.0.0';
HTTPRequestConts.GET_NAV_C_VER_VAL_LATEST = 'featurephone_1.0.0';
//  HTTPRequestConts.GET_NAV_C_VER_VAL = 'android_2.1.7';
//  HTTPRequestConts.GET_NAV_C_VER_VAL_LATEST = 'android_2.1.8';
HTTPRequestConts.GET_NAV_ID = 'id';
HTTPRequestConts.GET_NAV_R_VER = 'rver';
HTTPRequestConts.GET_NAV_R_VER_VAL = '43';
HTTPRequestConts.GET_NAV_END = 'ES';

// otp validation 
HTTPRequestConts.OS_VERSION = '6.0.1';
HTTPRequestConts.OEM = 100001;
HTTPRequestConts.BRAND = 'Mortorola';
HTTPRequestConts.IMEI = '913885466388121';
HTTPRequestConts.DEV_ID = 'B2B9EF551EA3755CEEC0C76813944330';

HTTPRequestConts.LOGIN_ID = 'X-API-Key';
HTTPRequestConts.LOGIN_VALUE = 'l7xx08997cdbfc2a4a4ca3e03e859a9022e0';

HTTPRequestConts.OK = CinBase64.getByte(0x80); //