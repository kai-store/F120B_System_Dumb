function FileTransferManager() {
}


FileTransferManager.getInstance= function(){
	 if(FileTransferManager.instance == null || FileTransferManager.instance == undefined){
        FileTransferManager.instance = new FileTransferManager();
    }
	return FileTransferManager.instance;
};

FileTransferManager.prototype.getAttachments = function(cinBody, uuid, token) {
	/*if(uuid == '' && token == '')
		var bodyBytes = EncryptionUtils.decrypt(msg);*/
	var res = Attachment.parseBody(cinBody);
	return res;
};

FileTransferManager.prototype.getDataInfo = function(type, cinMessage){
	switch(type){
		case MessageConsts.TYPE_EMOTICON:
			cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new DynamicEmoticonsInfo();
			info.init(response);
			return info;
		break;
		case MessageConsts.TYPE_IMAGE:
			msgs = cinMessage.getBodys();
			info = [];		
			
			msgs.forEach(function(cinMessageBody){
				var imageInfo = new ImageInfo();
				var response = CINResponse.getCINMessage(cinMessageBody.val, null, false);	
				imageInfo.init(response);	
				info.push(imageInfo);
			});	
			return info;
		break;
		case MessageConsts.TYPE_CARD:
			//cinMessageBody = cinMessage.getBody();
			//var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new CardInfo();
			//info.init(response);
			return info;
		break;

		/*case MessageConsts.TYPE_FILE:
			cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new FileInfo();
			info.init(response);
			return info;
		break;

		case MessageConsts.TYPE_LOCATION:
			cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new LocationInfo();
			info.init(response);
			return info;
		break;

		case MessageConsts.TYPE_VOICE:
			cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new VoiceInfo();
			info.init(response);
			return info;
		break;

		case MessageConsts.TYPE_VIDEO:
			cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new VideoInfo();
			info.init(response);
			return info;
		break;*/
	}
}
