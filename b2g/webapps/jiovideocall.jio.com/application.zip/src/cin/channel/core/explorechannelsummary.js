function ExploreChannelSummaryInfo(){
    this.channelId = 0;
    this.profileVersion = 0;
    this.channelContentVersion = 0;
    this.serialNumber = 0;
}

ExploreChannelSummaryInfo.prototype.setChannelId = function(channelId){
    this.channelId = channelId;
}

ExploreChannelSummaryInfo.prototype.getChannelId = function(){
    return this.channelId;
}

ExploreChannelSummaryInfo.prototype.setProfileVersion = function(profileVersion){
    this.profileVersion = profileVersion;
}

ExploreChannelSummaryInfo.prototype.getProfileVersion = function(){
    return this.profileVersion;
}

ExploreChannelSummaryInfo.prototype.setChannelContentVersion = function(channelContentVersion){
    this.channelContentVersion = channelContentVersion;
}

ExploreChannelSummaryInfo.prototype.getChannelContentVersion = function(){
    return this.channelContentVersion;
}

ExploreChannelSummaryInfo.prototype.setSerialNumber = function(serialNumber){
    this.serialNumber = serialNumber;
}

ExploreChannelSummaryInfo.prototype.getSerialNumber = function(){
    return this.serialNumber;
}

ExploreChannelSummaryInfo.prototype.init = function(cinMessage){
   this.channelId =  cinMessage.getHeader(ChannelConst.CHANNEL_INDEX);
   this.profileVersion = cinMessage.getInt(ChannelConst.CHANNEL_VERSION);
   this.channelContentVersion = cinMessage.getInt(ChannelConst.CHANNEL_CONTENT_VERSION);
   this.serialNumber = cinMessage.getInt(ChannelConst.CHANNEL_SERIAL_NUMBER);
}
