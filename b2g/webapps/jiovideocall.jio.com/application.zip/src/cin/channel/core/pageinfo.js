function PageInfo(){
  this.locPageIndex;
  this.locColIndex;
  this.contentType;
  this.videoID;
  this.pageId;
  this.resourceURI = "";
  this.MEDIA_VIDEO = 1;
  this.MEDIA_STREAM = 2;
  this.MEDIA_HTML = 3;
}

PageInfo.prototype.setPageId = function(pageId){
    this.pageId = pageId;
}

PageInfo.prototype.getPageId = function(){
    return this.pageId;
}

PageInfo.prototype.setLocPageIndex = function(locPageIndex){
    this.locPageIndex = locPageIndex;
}

PageInfo.prototype.getLocPageIndex = function(){
    return this.locPageIndex;
}

PageInfo.prototype.setLocColIndex = function(locColIndex){
    this.locColIndex = locColIndex;
}

PageInfo.prototype.getLocColIndex = function(){
    return this.locColIndex;
}

PageInfo.prototype.setContentType = function(contentType){
    this.contentType = contentType;
}

PageInfo.prototype.getContentType = function(){
    return this.contentType;
}

PageInfo.prototype.setVideoID = function(videoID){
    this.videoID = videoID;
}

PageInfo.prototype.getVideoID = function(){
    return this.videoID;
}

PageInfo.prototype.setResourceURI = function(resourceURI){
    this.resourceURI = resourceURI;
}

PageInfo.prototype.getResourceURI = function(){
    return this.resourceURI;
}

PageInfo.prototype.init = function(cinMessage){
   // this.channelId =  cinMessage.getInt(ChannelConst.CHANNEL_INDEX);
   // this.profileVersion = cinMessage.getInt(ChannelConst.CHANNEL_VERSION);
   // this.channelContentVersion = cinMessage.getInt(ChannelConst.CHANNEL_CONTENT_VERSION);
   // this.serialNumber = cinMessage.getInt(ChannelConst.CHANNEL_SERIAL_NUMBER);
}

PageInfo.prototype.parseFromMsg = function(cinMessage){
    var that = this;
    var headers = cinMessage.getHeaders();
    headers.forEach(function(header){
       if(header.key == ChannelConst.HEADER_LOCATION_PAGE_INDEX) {
           that.locPageIndex = JIOUtils.toLong(header.val);
       }else if(header.key == ChannelConst.HEADER_LOCATION_COLUMN_INDEX) {
          that.locColIndex = JIOUtils.toLong(header.val);
       }else if(header.key == ChannelConst.HEADER_CONTENT_TYPE) {
          that.contentType = JIOUtils.toLong(header.val);
       }else if(header.key == ChannelConst.HEADER_VIDEO_ID) {
          that.videoID = JIOUtils.toLong(header.val);
       }else if(header.key == ChannelConst.HEADER_PAGE_ID) {
          that.pageId = JIOUtils.toLong(header.val);
       }
    });
    var pageBody = cinMessage.getBody();
    if(pageBody){
      that.resourceURI = JIOUtils.toString(cinMessage.getBody());
    }
}

PageInfo.prototype.isVideo = function(contentType){ 
  return this.contentType === this.MEDIA_VIDEO;
}
