function ContentInfo(){
  this.contentID;
  this.locColumnIndex;
  this.contentVersion;
  this.contentTitle = "";
  this.pageInfos = [];
}

ContentInfo.prototype.setContentTitle = function(contentTitle){
    this.contentTitle = contentTitle;
}

ContentInfo.prototype.getContentTitle = function(){
    return this.contentTitle;
}

ContentInfo.prototype.setContentVersion = function(contentVersion){
    this.contentVersion = contentVersion;
}

ContentInfo.prototype.getContentVersion = function(){
    return this.contentVersion;
}

ContentInfo.prototype.setContentID = function(contentID){
    this.contentID = contentID;
}

ContentInfo.prototype.getContentID = function(){
    return this.contentID;
}

ContentInfo.prototype.setLocColumnIndex = function(locColumnIndex){
    this.locColumnIndex = locColumnIndex;
}

ContentInfo.prototype.getLocColumnIndex = function(){
    return this.locColumnIndex;
}

ContentInfo.prototype.setPageInfo = function(pageInfo){
    this.pageInfo = pageInfo;
}

ContentInfo.prototype.getPageInfo = function(){
    return this.pageInfo;
}

ContentInfo.prototype.init = function(cinMessage){
   // this.channelId =  cinMessage.getInt(ChannelConst.CHANNEL_INDEX);
   // this.profileVersion = cinMessage.getInt(ChannelConst.CHANNEL_VERSION);
   // this.channelContentVersion = cinMessage.getInt(ChannelConst.CHANNEL_CONTENT_VERSION);
   // this.serialNumber = cinMessage.getInt(ChannelConst.CHANNEL_SERIAL_NUMBER);
}

ContentInfo.prototype.getFirstVideoId = function(){
  if(this.pageInfos != null && this.pageInfos.size() > 0)
    {
      return this.pageInfos.get(0).getVideoID();
    }
    return 0;
}

ContentInfo.prototype.isFirstVideo = function(){
  if(this.pageInfos != null && this.pageInfos.size() > 0)
    {
      return this.pageInfos.get(0).getContentType();
    }
    return false;
}

ContentInfo.prototype.parseFromMsg = function(cinMessage){
    var that = this;
    var keys = cinMessage.getHeaders();    
    keys.forEach(function(header){
        if(header.key == ChannelConst.HEADER_CHANNEL_ID){
            that.contentID = JIOUtils.toLong(header.val);
        }else if(header.key == ChannelConst.HEADER_CHANNEL_PROFILE_VERSION){
            that.locColumnIndex = JIOUtils.toLong(header.val);
        }else if(header.key == ChannelConst.HEADER_CHANNEL_NAME){
            that.contentTitle = JIOUtils.toString(header.val);
        }
    });

    var bodys = cinMessage.getBodys();
    this.pageInfos = [];
    bodys.forEach(function(body){
        var cinMsg = CINResponse.getCINMessage(body.val, null, false); 
        info = new PageInfo();
        info.parseFromMsg(cinMsg);
        that.pageInfos.push(info);
    });
}
