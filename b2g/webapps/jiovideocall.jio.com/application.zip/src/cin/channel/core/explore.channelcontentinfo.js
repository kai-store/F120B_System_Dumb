function ExploreChannelContentInfo(){
    this.serChContentVer;
    this.contInf = [];
    this.channel_preview_content = "";
}

ExploreChannelContentInfo.prototype.setSerChContentVer = function(serChContentVer){
    this.serChContentVer = serChContentVer;
}

ExploreChannelContentInfo.prototype.getSerChContentVer = function(){
    return this.serChContentVer;
}

ExploreChannelContentInfo.prototype.setContInf = function(contInf){
    this.contInf = contInf;
}

ExploreChannelContentInfo.prototype.getContInf = function(){
    return this.contInf;
}

ExploreChannelContentInfo.prototype.setChannel_preview_content = function(channel_preview_content){
    this.channel_preview_content = channel_preview_content;
}

ExploreChannelContentInfo.prototype.getChannel_preview_content = function(){
    return this.channel_preview_content;
}

ExploreChannelContentInfo.prototype.init = function(cinMessage){
    // this.channelId =  cinMessage.getInt(ChannelConst.CHANNEL_INDEX);
    // this.profileVersion = cinMessage.getInt(ChannelConst.CHANNEL_VERSION);
    // this.channelContentVersion = cinMessage.getInt(ChannelConst.CHANNEL_CONTENT_VERSION);
    // this.serialNumber = cinMessage.getInt(ChannelConst.CHANNEL_SERIAL_NUMBER);
}

ExploreChannelContentInfo.prototype.parseFromMsg = function(cinMessage) {
    this.serChContentVer = JIOUtils.toLong(cinMessage.getHeader(ChannelConst.HEADER_CHANNEL_CONTENT_VERSION));
    var bodys = cinMessage.getBodys(); 
    var that = this;
    bodys.forEach(function(cinBody){
        var cinMsg = CINResponse.getCINMessage(cinBody.val, null, false);   
        var typeHeader = JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x01)));
        switch(typeHeader){
            case ChannelConst.TYPE_HEADER1:
                that.channel_preview_content = JIOUtils.toString(cinMsg.getBody());
                break;
            case ChannelConst.TYPE_HEADER2: 
                entityCont = new ContentInfo();
                entityCont.parseFromMsg(cinMsg);
                that.contInf.push(entityCont);
                break;
        }
    });
}
