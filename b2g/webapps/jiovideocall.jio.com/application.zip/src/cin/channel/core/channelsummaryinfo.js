function ChannelSummaryInfo(){
    this.publicId = 0;
    this.profileVersion = 0;
    this.channelContentVersion = 0;
    this.serialNumber = 0;
}

ChannelSummaryInfo.prototype.setChannelId = function(channelId){
    this.publicId = channelId;
}

ChannelSummaryInfo.prototype.getChannelId = function(){
    return this.publicId;
}

ChannelSummaryInfo.prototype.setProfileVersion = function(profileVersion){
    this.profileVersion = profileVersion;
}

ChannelSummaryInfo.prototype.getProfileVersion = function(){
    return this.profileVersion;
}

ChannelSummaryInfo.prototype.setChannelContentVersion = function(channelContentVersion){
    this.channelContentVersion = channelContentVersion;
}

ChannelSummaryInfo.prototype.getChannelContentVersion = function(){
    return this.channelContentVersion;
}

ChannelSummaryInfo.prototype.setSerialNumber = function(serialNumber){
    this.serialNumber = serialNumber;
}

ChannelSummaryInfo.prototype.getSerialNumber = function(){
    return this.serialNumber;
}

ChannelSummaryInfo.prototype.init = function(cinMessage){
   this.publicId =  cinMessage.getHeader(ChannelConst.CHANNEL_INDEX);
   this.profileVersion = cinMessage.getInt(ChannelConst.CHANNEL_VERSION);
   this.channelContentVersion = cinMessage.getInt(ChannelConst.CHANNEL_CONTENT_VERSION);
   this.serialNumber = cinMessage.getHeader(ChannelConst.CHANNEL_SERIAL_NUMBER);
}
