function ChannelProfileInfo(){
  this.channelID;
  this.channelName;
  this.serChProfileVer;
  this.introduceVideoID;
  this.transitionVideoID;
  this.endVideoID;
  this.redCode;
  this.greenCode;
  this.blueCode;
  this.channelLogoUrl;
  this.channelSumm;
  this.channelRead;
  this.avaliable=false;
  this.downloadStatus = false;
  this.logourlStatus = true;
  this.isReady=false;
  this.shareFlag = true;
  this.shareImageFlag = true;
  this.shareIconFlag = true;
  this.index;
}

ChannelProfileInfo.prototype.isShareFlag = function(){
  return this.isShareFlag;
}

ChannelProfileInfo.prototype.setShareFlag = function(isShareFlag){
    this.isShareFlag = isShareFlag;
}

ChannelProfileInfo.prototype.isShareImageFlag = function(){
    return this.shareImageFlag;
}

ChannelProfileInfo.prototype.setShareImageFlag = function(shareImageFlag){
    this.shareImageFlag = shareImageFlag;
}

ChannelProfileInfo.prototype.isShareIconFlag = function(){
    return this.shareIconFlag;
}

ChannelProfileInfo.prototype.setShareIconFlag = function(shareIconFlag){
    this.shareIconFlag = shareIconFlag;
}

ChannelProfileInfo.prototype.isReady = function(){
    return this.isReady;
}

ChannelProfileInfo.prototype.setReady = function(isReady){
    this.isReady = isReady;
}

ChannelProfileInfo.prototype.isLogourlStatus = function(){
    return this.logourlStatus;
}

ChannelProfileInfo.prototype.setLogourlStatus = function(logourlStatus){
    this.logourlStatus = logourlStatus;
}

ChannelProfileInfo.prototype.getIndex = function(){
    return this.index;
}

ChannelProfileInfo.prototype.setIndex = function(index){
    this.index = index;
}

ChannelProfileInfo.prototype.isDownloadStatus = function(){
    return this.downloadStatus;
}

ChannelProfileInfo.prototype.setDownloadStatus = function(downloadStatus){
    this.downloadStatus = downloadStatus;
}

ChannelProfileInfo.prototype.isAvaliable = function(){
    return this.avaliable;
}

ChannelProfileInfo.prototype.setAvaliable = function(avaliable){
    this.avaliable = avaliable;
}

ChannelProfileInfo.prototype.init = function(cinMessage){
   this.channelId =  cinMessage.getInt(ChannelConst.CHANNEL_INDEX);
   this.profileVersion = cinMessage.getInt(ChannelConst.CHANNEL_VERSION);
   this.channelContentVersion = cinMessage.getInt(ChannelConst.CHANNEL_CONTENT_VERSION);
   this.serialNumber = cinMessage.getInt(ChannelConst.CHANNEL_SERIAL_NUMBER);
}

ChannelProfileInfo.prototype.parseFromMsg = function(cinMessage){
  var that  = this;
    var keys = cinMessage.getHeaders();    
    keys.forEach(function(header){
        switch(header.key){
          case ChannelConst.HEADER_CHANNEL_ID:
              that.channelID = JIOUtils.toLong(header.val);
              break;
          case ChannelConst.HEADER_CHANNEL_PROFILE_VERSION:
              that.serChProfileVer = JIOUtils.toLong(header.val);
              break;
          case ChannelConst.HEADER_CHANNEL_NAME:
              that.channelName = JIOUtils.toString(header.val);
              break;
          case ChannelConst.HEADER_CHANNEL_FLAG_SHARE:
              that.shareFlag = (JIOUtils.toLong(header.val) == 1);
              break;
          case ChannelConst.HEADER_CHANNEL_FLAG_IMAGE_SHARE:
              that.shareImageFlag = (JIOUtils.toLong(header.val) == 1);
              break;
          case ChannelConst.HEADER_CHANNEL_FLAG_ICON_SHARE:
              that.shareIconFlag = (JIOUtils.toLong(header.val) == 1);
              break;
        } 
    });

    var bodys = cinMessage.getBodys();
    bodys.forEach(function(body){
        var cinMsg = CINResponse.getCINMessage(body.val, null, false);   
        var typeHeader = JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x01)));
        switch(typeHeader){
            case CinBase64.getByte(0x01):
              that.introduceVideoID =  JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x02)));      
              break;
            case CinBase64.getByte(0x02): 
              that.transitionVideoID =  JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x02)));        
              break;
           case CinBase64.getByte(0x03): 
              that.endVideoID =  JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x02)));         
              break;  
          case CinBase64.getByte(0x04): 
               that.redCode =  JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x02)));  
               that.greenCode =  JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x03)));   
               that.blueCode =  JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x04))); 
               that.channelLogoUrl = JIOUtils.toString(cinMsg.getBody());        
              break;
          case CinBase64.getByte(0x05): 
              that.channelSumm = JIOUtils.toString(cinMsg.getBody());   
              break;             
        }
    });
}

ChannelProfileInfo.prototype.initColors = function(redCode, greenCode, blueCode){
  this.redCode = redCode;
  this.greenCode = greenCode;
  this.blueCode = blueCode;
}

ChannelProfileInfo.prototype.getChannelRead = function(){
    return this.channelRead;
}

ChannelProfileInfo.prototype.setChannelRead = function(channelRead){
    this.channelRead = channelRead;
}

ChannelProfileInfo.prototype.getIntroduceVideoID = function(){
    return this.introduceVideoID;
}

ChannelProfileInfo.prototype.setIntroduceVideoID = function(introduceVideoID){
    this.introduceVideoID = introduceVideoID;
}

ChannelProfileInfo.prototype.getTransitionVideoID = function(){
    return this.transitionVideoID;
}

ChannelProfileInfo.prototype.setTransitionVideoID = function(transitionVideoID){
    this.transitionVideoID = transitionVideoID;
}

ChannelProfileInfo.prototype.getEndVideoID = function(){
    return this.endVideoID;
}

ChannelProfileInfo.prototype.setEndVideoID = function(endVideoID){
    this.endVideoID = endVideoID;
}

ChannelProfileInfo.prototype.getChannelLogoUrl = function(){
    return this.channelLogoUrl;
}

ChannelProfileInfo.prototype.setChannelLogoUrl = function(channelLogoUrl){
    this.channelLogoUrl = channelLogoUrl;
}

ChannelProfileInfo.prototype.getChannelID = function(){
    return this.channelID;
}

ChannelProfileInfo.prototype.setChannelID = function(transitionVideoID){
    this.channelID = channelID;
}

ChannelProfileInfo.prototype.getChannelName = function(){
    return this.channelName;
}

ChannelProfileInfo.prototype.setChannelName = function(channelName){
    this.channelName = channelName;
}

ChannelProfileInfo.prototype.getSerChProfileVer = function(){
    return this.serChProfileVer;
}

ChannelProfileInfo.prototype.setSerChProfileVer = function(serChProfileVer){
    this.serChProfileVer = serChProfileVer;
}

ChannelProfileInfo.prototype.getRedCode = function(){
    return this.redCode;
}

ChannelProfileInfo.prototype.setRedCode = function(redCode){
    this.redCode = redCode;
}

ChannelProfileInfo.prototype.getBlueCode = function(){
    return this.blueCode;
}

ChannelProfileInfo.prototype.setBlueCode = function(blueCode){
    this.blueCode = blueCode;
}

ChannelProfileInfo.prototype.getGreenCode = function(){
    return this.greenCode;
}

ChannelProfileInfo.prototype.setGreenCode = function(greenCode){
    this.greenCode = greenCode;
}

ChannelProfileInfo.prototype.getChannelSumm = function(){
    return this.channelSumm;
}

ChannelProfileInfo.prototype.setChannelSumm = function(channelSumm){
    this.channelSumm = channelSumm;
}
