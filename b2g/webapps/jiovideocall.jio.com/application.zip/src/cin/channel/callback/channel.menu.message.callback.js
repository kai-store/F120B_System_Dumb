function ChannelMenuMessageCallback(callback) {
	this.callback = callback;
}

ChannelMenuMessageCallback.prototype = {
	onSuccess: function(cinResponse){
		var message = cinResponse.getString(CINRequestConts.KEY);
		var channel = new Channel();
		channel.setPublicId(cinResponse.getHeader(CINRequestConts.TO));
		this.callback.onSuccess(channel, message);
	},
	onError: function(error){
       	    JIOUtils.sendError(100, error, this.callback);
	}
}
