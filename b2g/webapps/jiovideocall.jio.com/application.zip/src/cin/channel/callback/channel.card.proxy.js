function ChannelCardProxyCallback(callback, canGetMenus) {
	this.callback = callback;
	this.channelCard = null;
	this.canGetMenus = canGetMenus;
}

ChannelCardProxyCallback.prototype = {
	onSuccess: function(cinResponce){	
		if(!this.callback){
			return;
		}
		var version = cinResponce.getHeader(CINRequestConts.VERSION);
		console.log("[Channel] Channel info version:", version);
		var body = cinResponce.getBody();
		this.channelCard = new Channel();
		this.channelCard.setCardVersion(version);
		if(body){
			this.channelCard.init(CINResponse.getCINMessage(body, null, true));
			this.channelCard.setCardVersion(version);	
			// if(this.canGetMenus){
			RMCManager.getInstance().getChannelMenus(this.channelCard, this.callback);
			return;
			// }
		}
		this.callback.onSuccess(this.channelCard);
	},
	onError: function(cinResponce){
        JIOUtils.sendError(100, cinResponce, this.callback);
	}
};
