function ExploreChannelsListProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

ExploreChannelsListProxyCallback.prototype = {
	onSuccess: function(cinMessage){
        var bodys = cinMessage.getBodys();
        var channelSummaryInfos = new Array();
        bodys.forEach(function(cinVal, index){
            var response = CINResponse.getCINMessage(cinVal.val, null, false);
			var channel = new ExploreChannelSummaryInfo();
			channel.init(response);
			channelSummaryInfos.push(channel);
        });
        this.uiCallback.onSuccess(channelSummaryInfos);
	},
	onError: function(error){
		JIOUtils.sendError(101, error, this.uiCallback);
	}
};
