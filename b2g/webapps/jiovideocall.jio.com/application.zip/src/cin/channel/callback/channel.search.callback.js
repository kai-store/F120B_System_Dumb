function ChannelSearchProxyCallback(callback, index, numberOfRecords) {
	this.callback = callback;
	this.index = index;
	this.numberOfRecords = numberOfRecords;
}

ChannelSearchProxyCallback.prototype = {
	onSuccess: function(cinResponse){
		var totalCount = 0;
		if(cinResponse.containsHeader(CINRequestConts.KEY)){
			totalCount = cinResponse.getInt(CINRequestConts.KEY);
		}
		// var channels = RMCManager.getChannels(cinResponse);
		var response = CINResponse.getCINMessage(cinResponse.getBody(), null, false);

		var channels = RMCManager.getChannels(response);
		
		var isEndResults = false;
		var nextIndex = this.index+channels.length;

		if(totalCount === 0 || nextIndex >= totalCount){
			isEndResults = true;
		}
		this.numberOfRecords = Math.min(this.numberOfRecords, totalCount-nextIndex);
		
		this.callback.onSuccess(channels, totalCount, nextIndex, this.numberOfRecords, isEndResults);
	},
	onError: function(error){
        JIOUtils.sendError(100, error, this.callback);
	}
};
