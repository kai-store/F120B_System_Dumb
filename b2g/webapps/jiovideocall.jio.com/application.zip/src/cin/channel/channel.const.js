function ChannelConst(){

}

ChannelConst.FOLLOW_NORMAL = 0;
ChannelConst.FOLLOW_AN_TO_FOLLOW = 1;
ChannelConst.FOLLOW_PRIVATE_CHANNEL = 2;

ChannelConst.MENU_REQ_MSG = 0;
ChannelConst.MENU_REQ_WEB_VIEW = 1;
ChannelConst.MENU_REQ_SUB_MENU = 2;

ChannelConst.HEADER_PUBLIC_ID = 0x01;
ChannelConst.HEADER_PUBLIC_NAME = 0x02;
ChannelConst.HEADER_PUBLIC_PORT_ID = 0x03;
ChannelConst.HEADER_PUBLIC_IS_RECEIVE_MSG = 0x05;
ChannelConst.HEADER_PUBLIC_IS_OFFICIAL = 0x07;
ChannelConst.HEADER_PUBLIC_VERSION = 0x08;
ChannelConst.HEADER_PUBLIC_FOLLOW_TYPE = 0x09;
ChannelConst.HEADER_PUBLIC_PIN_TO_CHAT = 0x10;

ChannelConst.CHANNEL_INDEX = CinBase64.getByte(0x01);
ChannelConst.CHANNEL_VERSION = CinBase64.getByte(0x02);
ChannelConst.CHANNEL_CONTENT_VERSION = CinBase64.getByte(0x03);
ChannelConst.CHANNEL_SERIAL_NUMBER = CinBase64.getByte(0x04);

ChannelConst.EVENT_LIST_CHANNNELS = CinBase64.getByte(0x01);
ChannelConst.EVENT_GET_INFO = CinBase64.getByte(0x02);

ChannelConst.RMC =  CinBase64.getByte(0x21);
ChannelConst.EVENT_RMC_CHANNEL_LIST = CinBase64.getByte(0x01);
ChannelConst.EVENT_RMC_CHANNEL_INFO = CinBase64.getByte(0x02);
ChannelConst.EVENT_RMC_CHANNEL_NOTIFICATION = CinBase64.getByte(0x03);
ChannelConst.EVENT_RMC_LIKE_INFO = CinBase64.getByte(0x04);
ChannelConst.EVENT_RMC_CHECK_STORY = CinBase64.getByte(0x05);
ChannelConst.EVENT_PPM_OFFLINE = CinBase64.getByte(0x02);


// channel info
ChannelConst.HEADER_CHANNEL_ID = CinBase64.getByte(0x03);
ChannelConst.HEADER_CHANNEL_PROFILE_VERSION = CinBase64.getByte(0x02);
ChannelConst.HEADER_CHANNEL_NAME = CinBase64.getByte(0x04);
ChannelConst.HEADER_CHANNEL_FLAG_SHARE = CinBase64.getByte(0x05);
ChannelConst.HEADER_CHANNEL_FLAG_IMAGE_SHARE = CinBase64.getByte(0x06);
ChannelConst.HEADER_CHANNEL_FLAG_ICON_SHARE = CinBase64.getByte(0x07);

// channel content
ChannelConst.HEADER_CHANNEL_CONTENT_SUMMARY_INFO = CinBase64.getByte(0x01);
ChannelConst.HEADER_CHANNEL_CONTENT_VERSION = CinBase64.getByte(0x02);

//stroy
ChannelConst.HEADER_LOCATION_PAGE_INDEX = CinBase64.getByte(0x01);
ChannelConst.HEADER_LOCATION_COLUMN_INDEX = CinBase64.getByte(0x02);
ChannelConst.HEADER_CONTENT_TYPE = CinBase64.getByte(0x03);
ChannelConst.HEADER_VIDEO_ID = CinBase64.getByte(0x04);
ChannelConst.HEADER_PAGE_ID = CinBase64.getByte(0x05);

ChannelConst.TYPE_HEADER1 = CinBase64.getByte(0x01);
ChannelConst.TYPE_HEADER2 = CinBase64.getByte(0x02);

ChannelConst.HEADER_RESOURCE_URI = CinBase64.getByte(0x05);


ChannelConst.EVENT_PUBLIC_GET_ALL = CinBase64.getByte(0x01);
ChannelConst.EVENT_PUBLIC_GET_MENU = CinBase64.getByte(0x03);
ChannelConst.EVENT_PUBLIC_SEARCH = CinBase64.getByte(0x04);
ChannelConst.EVENT_PUBLIC_SET_FOCUS = CinBase64.getByte(0x05);
ChannelConst.EVENT_PUBLIC_SET_RECEIVE = CinBase64.getByte(0x06);
ChannelConst.EVENT_PUBLIC_MENU_MSG = CinBase64.getByte(0x07);
ChannelConst.EVENT_PUBLIC_CARD_INFO = CinBase64.getByte(0x08);
ChannelConst.EVENT_PUBLIC_GET_RECOMMENDED_ACCOUNT = CinBase64.getByte(0x10);
ChannelConst.EVENT_PUBLIC_GET_FOCUS = CinBase64.getByte(0x11);
ChannelConst.EVENT_PUBLIC_REMOVE_WHITELIST= CinBase64.getByte(0X20);
ChannelConst.EVENT_PUBLIC_REPORT = CinBase64.getByte(0x21);
ChannelConst.EVENT_PUBLIC_LAST_UPDATETIME = CinBase64.getByte(0x72);

ChannelConst.HEADER_TYPE = CinBase64.getByte(0x01);
ChannelConst.HEADER_TITLE = CinBase64.getByte(0x02);
ChannelConst.HEADER_KEY = CinBase64.getByte(0x03);
ChannelConst.HEADER_URL = CinBase64.getByte(0x04);
