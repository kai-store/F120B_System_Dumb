function HTTPClient(){
}
/**
 * Class is for creating http cilent, and setting an appropriate values.
 */
HTTPClient.prototype = {

    //var _httpClient = null;
    send : function(httpRequest,type){
        var xhttp = new XMLHttpRequest({'mozSystem': true});        
        xhttp.onreadystatechange = function() {
            HTTPClient.getInstance().parseResponse(xhttp, httpRequest);
        }
      xhttp = httpRequest.prepareHTTPRequest(xhttp,type);
      xhttp.send();
    }
};

HTTPClient.getInstance= function(){
    if(HTTPClient.instance == null || HTTPClient.instance == undefined){
        HTTPClient.instance = new HTTPClient();
    }
    return HTTPClient.instance;
};

HTTPClient.prototype.parseResponse = function(xhttp, httpRequest){

    if (xhttp.readyState != 4){
        return;
    }

    var callback = httpRequest.getCallback();
    if(!callback){
        return;
    }

    if(xhttp.status === 200){
        if(httpRequest.isCINResponseParser()){
            data = CinBase64.decode(xhttp.responseText);
            var cinMessage = CINResponse.getCINMessage(data, callback, true);
            if (cinMessage.isMethod(HTTPRequestConts.OK )) {
              if(httpRequest.isCINMessageObject()){
                callback.onSuccess(cinMessage);
                return;
              }
                callback.onSuccess(cinMessage.toString());
                return;
            }

            var errMsg = null;
            var errorCode = 0;
            if (cinMessage.hasBody()) {
                errorCode = cinMessage.getMethod();
                if(httpRequest.isCINMessageObject()){                    
                    callback.onError(cinMessage);
                    JIOUtils.trackEvent(errorCode, cinMessage.getBody(), callback);
                    return;
                }
                errMsg = JIOUtils.toString(cinMessage.getBody());
                errorCode = cinMessage.getBodys()[0].key;
            }
            JIOUtils.sendError(errorCode, errMsg, callback);            
            JIOUtils.trackEvent(errorCode, errMsg, callback);
            return;
        }

       var response = new HTTPResponse(callback);
       response.convert(xhttp);
       return;
    }

    this.sendErrorCallback(xhttp.status, callback);
};

HTTPClient.prototype.sendErrorCallback=function(errorCode, callback){
   if(callback == null){
        return;
    }
    var reason = "Unknown error";
    if(errorCode == 1)
        errorCode = 0;
    switch(errorCode){
        case 0:
            reason = "No internet connection."
            break;

    }
    JIOUtils.sendError(errorCode, reason, callback);
}

HTTPClient._arrayBufferToBase64 = function( buffer ) {
    var binary = '';
    var bytes = new Uint8Array( buffer );
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode( bytes[ i ] );
    }
    return window.btoa( binary );
}
