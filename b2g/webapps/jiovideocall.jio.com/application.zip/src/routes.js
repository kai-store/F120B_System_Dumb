import React from 'react';
import ReactDOM from 'react-dom';
import EnhanceAnimation from './lib/enhance-animation'
import RegistrationView from './component/onboarding/registration-view';
import SplashView from './component/onboarding/splash-screen';

import CountryListView from './component/onboarding/countrylist-view';
import ChatListView from './component/chat/chatlist-view';
import ChatDetailView from './component/chat/chatdetail-view';
import DummyView from './component/chat/dummy-view';
import BroadcastDetailView from './component/chat/broadcast-detail-view';
import MultiRichMedia from './component/chat/multi-richmedia-view';
import DoodleView from './component/chat/doodle-view';
import MobileWebView from './component/chat/mobile-web-view';

import AddProfileView from './component/onboarding/addprofile-view';
import GenderList from './component/onboarding/select-gender';

import OtpVerifyView from './component/onboarding/otp-verify-view';
import CaptchaView from './component/onboarding/captcha-view';
import CameraView from './component/onboarding/camera-view';

import ContactsView from './component/contacts/contacts-view';
import ContactsDetailView from './component/contacts/contacts-detail-view';
import ContactsPicker from './component/contacts/contacts-picker';
import ContactSelect from './component/contacts/contact-select';
import BlockedContacts from './component/contacts/blocked-contacts';
import ContactSearch from './component/contacts/contact-search';


import TermsView from './component/onboarding/terms-condition';
import WelcomeZLAUserView from './component/onboarding/welcomeZLAuser-view';
import HomeView from './component/home-view';
import MoreView from './component/more/more-list';
import QRCode from './component/more/qr-code';

import SettingList from './component/settings/setting-list';
import ChatSettings from './component/settings/chat-settings';
import SecurityPolicySettings from './component/settings/security-policy-settings';
import Account from './component/settings/account';
import About from './component/settings/about';
import FAQ from './component/settings/faq';
// import QRScannerView from './component/settings/qr-scanner-view';
import Feedback from './component/settings/feedback';
import Personalization from './component/settings/personalization';
import LanguageChange from './component/settings/language-change';
import DoNotDisturb from './component/settings/donot-disturb';
import DNDFromList from './component/settings/dnd-from';
import DNDToList from './component/settings/dnd-to';
import DelaySending from './component/settings/delay-sending';

import MyProfileView from './component/myprofile/myprofile-view';
import EditProfile from './component/myprofile/edit-profile';
import MoodView from './component/myprofile/mood-view';
import ProfilePreview from './component/myprofile/profile-preview';


import Invite from './component/contacts/invite-friend';
import FriendProfile from './component/contacts/friend-profile';

import CreateGroup from './component/group/create-group';
import GroupInformation from './component/group/group-information';
import GroupList from './component/group/group-list';

import ReplyView from './component/chat/reply-view';
import EmojiView from './component/emoji/emoji-view';
import ReadMoreView from './component/chat/readmore-view';
import ImagePreviewView from './component/chat/image-preview';
import AudioRecordView from './component/chat/audio-record-view';
import BroadcastReplyView from './component/chat/broadcast-reply-view';

import VoiceCall from './component/call/voice-call';
import VideoCall from './component/call/video-call';

import ChannelsListView from './component/channels/channelslist-view';
import ChannelDetails from './component/channels/channel-details';
import ChannelSearchListView from './component/channels/search-channel';
import ChannelsRecord from './component/channels/record-view';
import SubmenuListView from './component/channels/submenuList';
import ChannelsRecentView from './component/channels/channels-recent-view';


import RecentListView from './component/chat/recentvideo-view';

//Phase 3
import LocationView from './component/location/location-view';
import StickersStoreView from './component/sticker/stickersstore-view';
import Stickers from './component/sticker/stickers';
import MyStickers from './component/sticker/my-stickers';
import StickerSendView from './component/sticker/stickers-send-view';
import RotateImageView from './component/chat/rotate-image-view';

// import ImagePreview from './component/contents/image-preview';
// import FileManager from './component/contents/file-manager';
// import ImageQualitySelector from './component/contents/image-quality-selector';

import ScanQRCode from './component/more/scan-qr-code';

// import VideoRecorder from './component/contents/video-recorder';

import FilesList from './component/sharefiles/fileslist-view';
import DesktopHomeView from './component/desktop-home-view';
import DesktopRegistrationView from './component/onboarding/desktop-registration-view';
import DesktopOTPVerifyView from './component/onboarding/desktop-otp-verify-view';
import DesktopCaptchaView from './component/onboarding/desktop-captcha-view';
import DesktopAddProfileView from './component/onboarding/desktop-addprofile-view';
import DesktopContactsView from './component/contacts/desktop-contacts-view';


import ExploreDetail from './component/explore/explore-detail';
import ExploreListView from './component/explore/explorelist-view';

//mobile
import MobileHomeView from './component/mobile-home-view';
import BroadcastRecipientView from './component/chat/broadcast-recipients';

// const userObj = [
//   {
//     userId: UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date()
//   }
// ];

const routes = [
  {
    path: '/splash',
    action:() => {
      let Composed = EnhanceAnimation(SplashView, 'left-to-center', 'center-to-left');
      return <Composed ref={"splash"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/register',
    action:() => {
      let Composed = EnhanceAnimation(RegistrationView, 'left-to-center', 'center-to-left');
      return <Composed ref={"register"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/country',
     action:() => {
      let Composed = EnhanceAnimation(CountryListView, 'left-to-center', 'center-to-left');
      return <Composed ref="countrylist" exitOnClose={true} />
    }
  },
  {
    path: '/addprofile',
     action:() => {
      
      let Composed = EnhanceAnimation(AddProfileView, 'left-to-center', 'center-to-left');
      return <Composed ref={"addprofile"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
     }
  },
   {
    path: '/genderList',
     action:() => {
      let Composed = EnhanceAnimation(GenderList, 'left-to-center', 'center-to-left');
      return <Composed ref={"genderList"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
     }
  },  
  {
    path: '/verify',
     action:() => {
      let Composed = EnhanceAnimation(OtpVerifyView, 'left-to-center', 'center-to-left');
      return <Composed ref={"otpverify" + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/captchaView/:source',
     action:(params) => {
      let Composed = EnhanceAnimation(CaptchaView, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"captchaView/" + params.source + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
    {
    path: '/camera',
     action:() => {
      let Composed = EnhanceAnimation(CameraView, 'left-to-center', 'center-to-left');
      return <Composed ref="cameradummy" exitOnClose={true} />
    }
  },
   {
    path: '/contacts/:id/:groupId',
     action:(params) => {
      let Composed = EnhanceAnimation(ContactsView, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"contacts/"+ params.id + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
   {
    path: '/contactsDetail',
     action:() => {
      let Composed = EnhanceAnimation(ContactsDetailView, 'left-to-center', 'center-to-left');
      return <Composed ref="contactsDetail" exitOnClose={true} />
    }
  },
   {
    path: '/contactsPicker',
     action:() => {
      let Composed = EnhanceAnimation(ContactsPicker, 'left-to-center', 'center-to-left');
      return <Composed ref="contactsPicker" exitOnClose={true} />
    }
  },
  {
    path: '/contactSelect',
     action:() => {
      let Composed = EnhanceAnimation(ContactSelect, 'left-to-center', 'center-to-left');
      return <Composed ref="contactSelect" exitOnClose={true} />
    }
  },
  {
    path: '/contactSearch',
     action:() => {
      let Composed = EnhanceAnimation(ContactSearch, 'left-to-center', 'center-to-left');
      return <Composed ref="contactSearch" exitOnClose={true} />
    }
  },
  {
    path: '/blockedContacts',
     action:() => {
      let Composed = EnhanceAnimation(BlockedContacts, 'left-to-center', 'center-to-left');
      return <Composed ref="blockedContacts" exitOnClose={true} />
    }
  },
  {
    path: '/friendProfile/:isJioUser',
     action:(params) => {
      let Composed = EnhanceAnimation(FriendProfile, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"friendProfile" + params.isJioUser + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
   {
    path: '/invite/:id',
     action:(params) => {
      let Composed = EnhanceAnimation(Invite, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"invite" + params.id} exitOnClose={true} />
    }
  },
  {
    path: '/createGroup/:id/:groupId/:groupName',
     action:(params) => {
      let Composed = EnhanceAnimation(CreateGroup, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"createGroup" + ( new Date().getTime() / 3000 ) } exitOnClose={true} />
    }
  },
  {
    path: '/groupInformation/:sessionType/:id',
     action:(params) => {
      let Composed = EnhanceAnimation(GroupInformation, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"groupInformation" + params.id + new Date().getTime()} exitOnClose={true} />
    }
  },
  {
    path: '/groupList/:id',
     action:(params) => {
      let Composed = EnhanceAnimation(GroupList, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"groupList" + new Date().getTime()} exitOnClose={true} />
    }
  },
 {
    path: '/terms',
    action:() => {
      let Composed = EnhanceAnimation(TermsView, 'left-to-center', 'center-to-left');
      return <Composed ref='terms' exitOnClose={true} />
    }
  },
  {
    path: '/welcomeZLAUser',
    action:() => {
      let Composed = EnhanceAnimation(WelcomeZLAUserView, 'left-to-center', 'center-to-left');
      return <Composed ref='welcomeZLAUser' exitOnClose={true} />
    }
  },
  {
    path: '/home',
    action:() => {
      // var userId = userObj[0].userId;
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      let Composed = EnhanceAnimation(HomeView, 'left-to-center', 'center-to-left');
      // return <Composed ref={'home'+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
      // return <Composed ref={'home'} exitOnClose={true} />
      return <Composed ref={'home_' + userId} exitOnClose={true} />
    }
  },
  {
    path: '/homevideo',
    action:() => {
      let Composed = EnhanceAnimation(HomeView, 'left-to-center', 'center-to-left');
      return <Composed ref={'homevideo'+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/recentvideo',
    action:() => {
      let Composed = EnhanceAnimation(RecentListView, 'left-to-center', 'center-to-left');
      return <Composed ref={'recentvideo'+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/list',
    action: () => {
      //let Composed = EnhanceAnimation(ListView, 'left-to-center', 'center-to-left');
      //return <Composed ref="list" />
    }
  },
  {
    path: '/todo/:id',
    action: (params) => {
      //let Composed = EnhanceAnimation(DetailView, 'right-to-center', 'center-to-right');
      //return <Composed {...params} ref={"todo/"+params.id} exitOnClose={true} />
    }
  },
  {
    path: '/edit/:id',
    action: (params) => {
      //let Composed = EnhanceAnimation(EditView, 'right-to-center', 'center-to-right');
      //return <Composed {...params} ref={"edit/"+params.id} exitOnClose={true} />
    }
  },
  {
    path: '/new',
    action: () => {
      //let Composed = EnhanceAnimation(NewView, 'right-to-center', 'center-to-right');
      //return <Composed ref="new" />
    }
  },
  {
    path: '/chatList',
    action: (params) => {
      // var userId = userObj[0].userId;
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      console.log("[APP:::ROUTES] " + userId);
      let Composed = EnhanceAnimation(ChatListView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"chatlist_" + userId} exitOnClose={true} />
    }
  },
  {
    path: '/chatDetail/:id/:number/:pageType',
    action: (params) => {
      // var userId = userObj[0].userId;
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      if(!userId || userId == "") userId = "";
      let Composed = EnhanceAnimation(ChatDetailView, 'right-to-center', 'center-to-right');
      // return <Composed {...params} ref={"chatdetail" + params.id + ' ' + params.number + ' ' + params.pageType + ' ' + new Date()} exitOnClose={true} />
      // return <Composed {...params} ref={ "chatdetail_" + params.id + '_' + params.number } exitOnClose={true} />
      return <Composed {...params} ref={ "chatdetail_" + userId + "_" + params.number } exitOnClose={true} />
    }
  },
  {
    path: '/doodle',
    action: (params) => {
      let Composed = EnhanceAnimation(DoodleView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={ "DoodleView" } exitOnClose={true} />
    }
  },
  /*{
    path: '/broadcastDetailView/:id/:number',
    action: (params) => {
      let Composed = EnhanceAnimation(BroadcastDetailView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"broadcastDetailView" + params.id + ' ' + params.number + new Date()} exitOnClose={true} />
    }
  },*/
  {
    path: '/broadcastDetailView',
    action: () => {
      let Composed = EnhanceAnimation(BroadcastDetailView, 'right-to-center', 'center-to-right');
      return <Composed ref={"broadcastDetailView"} exitOnClose={true} />
      // return <Composed ref={"broadcastDetailView" + ' ' + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/more',
    action: () => {
      let Composed = EnhanceAnimation(MoreView, 'right-to-center', 'center-to-right');
      return <Composed ref="more" exitOnClose={true} />
    }
  },
  {
    path: '/qrCode',
    action: () => {
      let Composed = EnhanceAnimation(QRCode, 'right-to-center', 'center-to-right');
      return <Composed ref="qrCode" exitOnClose={true} />
    }
  },
  {
    path: '/settings',
    action: () => {
      let Composed = EnhanceAnimation(SettingList, 'right-to-center', 'center-to-right');
      return <Composed ref="setting" exitOnClose={true} />
    }
  },
  {
  path: '/chatSettings',
    action: () => {
      let Composed = EnhanceAnimation(ChatSettings, 'right-to-center', 'center-to-right');
      return <Composed ref="chatSettings" exitOnClose={true} />
    }
  },
  {
  path: '/securityPolicySettings',
    action: () => {
      let Composed = EnhanceAnimation(SecurityPolicySettings, 'right-to-center', 'center-to-right');
      return <Composed ref="securityPolicySettings" exitOnClose={true} />
    }
  },
   {
    path: '/languageChange',
    action: () => {
      let Composed = EnhanceAnimation(LanguageChange, 'right-to-center', 'center-to-right');
      return <Composed ref={"languageChange" + new Date()} exitOnClose={true} />
    }
  },
  {
  path: '/about',
    action: () => {
      let Composed = EnhanceAnimation(About, 'right-to-center', 'center-to-right');
      return <Composed ref="about" exitOnClose={true} />
    }
  },
  {
  path: '/faq',
    action: () => {
      let Composed = EnhanceAnimation(FAQ, 'right-to-center', 'center-to-right');
      return <Composed ref="faq" exitOnClose={true} />
    }
  },//
  // {
  // path: '/qrScannerView',
  //   action: () => {
  //     let Composed = EnhanceAnimation(QRScannerView, 'right-to-center', 'center-to-right');
  //     return <Composed ref="faq" exitOnClose={true} />
  //   }
  // },
  {
  path: '/feedback',
    action: () => {
      let Composed = EnhanceAnimation(Feedback, 'right-to-center', 'center-to-right');
      return <Composed ref="feedback" exitOnClose={true} />
    }
  },
  {
   path: '/account',
    action: () => {
      let Composed = EnhanceAnimation(Account, 'right-to-center', 'center-to-right');
      return <Composed ref="account" exitOnClose={true} />
    }
  },
  {
   path: '/doNotDisturb',
    action: () => {
      let Composed = EnhanceAnimation(DoNotDisturb, 'right-to-center', 'center-to-right');
      return <Composed ref="doNotDisturb" exitOnClose={true} />
    }
  },
  {
   path: '/dndFromList',
    action: () => {
      let Composed = EnhanceAnimation(DNDFromList, 'right-to-center', 'center-to-right');
      return <Composed ref="dndFromList" exitOnClose={true} />
    }
  },
  {
   path: '/dndToList',
    action: () => {
      let Composed = EnhanceAnimation(DNDToList, 'right-to-center', 'center-to-right');
      return <Composed ref="dndToList" exitOnClose={true} />
    }
  },
  {
   path: '/delaySending',
    action: () => {
      let Composed = EnhanceAnimation(DelaySending, 'right-to-center', 'center-to-right');
      return <Composed ref="delaySending" exitOnClose={true} />
    }
  },
  {
   path: '/personalization',
    action: () => {
      let Composed = EnhanceAnimation(Personalization, 'right-to-center', 'center-to-right');
      return <Composed ref="personalization" exitOnClose={true} />
    }
  },
  {
    path: '/profileView',
    action: () => {
      let Composed = EnhanceAnimation(MyProfileView, 'right-to-center', 'center-to-right');
      return <Composed ref={"profileView"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/editProfile',
    action: () => {
      let Composed = EnhanceAnimation(EditProfile, 'right-to-center', 'center-to-right');
      return <Composed ref={"editProfile" + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/moodView',
    action: () => {
      let Composed = EnhanceAnimation(MoodView, 'right-to-center', 'center-to-right');
      return <Composed ref="moodView" exitOnClose={true} />
    }
  },
  {
    path: '/profilePreview/:name',
    action: (params) => {
      let Composed = EnhanceAnimation(ProfilePreview, 'right-to-center', 'center-to-right');
      return <Composed {...params} params={params} ref={"profilePreview/"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/replyView/:sessionType/:peerId/:msgType',
    action: (params) => {
      let Composed = EnhanceAnimation(ReplyView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"replyView" + params.sessionType + ' ' + params.peerId + ' ' + params.msgType} exitOnClose={true} />
      // return <Composed {...params} ref={"replyView" + params.sessionType + ' ' + params.peerId + ' ' + params.msgType + new Date().getTime()} exitOnClose={true} />
    }
  },
  {
    path: '/broadcastReplyView/:peerId/:users',
    action: (params) => {
      let Composed = EnhanceAnimation(BroadcastReplyView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"broadcastReplyView" + ' ' + params.peerId + ' ' + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/voiceCall/:type/:id',
    action: (params) => {
      let Composed = EnhanceAnimation(VoiceCall, 'right-to-center', 'center-to-right');
      return <Composed {...params} params={params} ref={"voiceCall/"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/videoCall/:type/:id',
    action: (params) => {
      let Composed = EnhanceAnimation(VideoCall, 'right-to-center', 'center-to-right');
      return <Composed {...params} params={params} ref={"videoCall/"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/emoji',
    action: (params) => {
      let Composed = EnhanceAnimation(EmojiView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"emojiView "} exitOnClose={true} />
    }
  },
  {
    path: '/readMore/:peerName/:msgType/:msgDirection',
    action: (params) => {
      let Composed = EnhanceAnimation(ReadMoreView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"readMoreView " + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/imagePreview/:sessionId/:thumbId',
    action: (params) => {
      let Composed = EnhanceAnimation(ImagePreviewView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"imagePreviewView " + params.sessionId + ' ' + params.thumbId + ' ' + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/StickersStoreView',
      action: () => {
        let Composed = EnhanceAnimation(StickersStoreView, 'right-to-center', 'center-to-right');
        return <Composed ref="StickersStoreView" exitOnClose={true} />
      }
  },
  {
    path: '/MyStickers',
      action: () => {
        let Composed = EnhanceAnimation(MyStickers, 'right-to-center', 'center-to-right');
        return <Composed ref="MyStickers" exitOnClose={true} />
      }
  },
  {
    path: '/StickerSendView/:sessionType/:peerId',
      action: (params) => {
        let Composed = EnhanceAnimation(StickerSendView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"StickerSendView" + params.sessionType + ' ' + params.peerId }  exitOnClose={true} />
      }
  },
  {
    path: '/stickers/:id/:isDownloading',
      action: (params) => {
        let Composed = EnhanceAnimation(Stickers, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"stickers" + params.id + ' ' +params.isDownloading} exitOnClose={true} />
      }
   },
   {
    path: '/RotateImageView/:sessionType/:peerId',
      action: (params) => {
        let Composed = EnhanceAnimation(RotateImageView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"RotateImageView" + params.sessionType + ' ' + params.peerId  }  exitOnClose={true} />
      }
  },
  /*{
    path: '/imagePreview',
    action: () => {
      let Composed = EnhanceAnimation(ImagePreview, 'right-to-center', 'center-to-right');
      return <Composed ref="imagePreview" exitOnClose={true} />
    }
  },*/
  {
    path: '/scanQRCode',
    action: () => {
      let Composed = EnhanceAnimation(ScanQRCode, 'right-to-center', 'center-to-right');
      return <Composed ref="scanQRCode" exitOnClose={true} />
    }
  },
  {
    path: '/fileManager',
    action: () => {
      let Composed = EnhanceAnimation(FileManager, 'right-to-center', 'center-to-right');
      return <Composed ref="fileManager" exitOnClose={true} />
    }
  },
  /*{
    path: '/imageQuality',
    action: () => {
      let Composed = EnhanceAnimation(ImageQualitySelector, 'right-to-center', 'center-to-right');
      return <Composed ref="imageQuality" exitOnClose={true} />
    }
  },
  {
    path: '/videoRecorder',
    action: () => {
      let Composed = EnhanceAnimation(VideoRecorder, 'right-to-center', 'center-to-right');
      return <Composed ref="videoRecorder" exitOnClose={true} />
    }
  },
   {
    path: '/insertContent',
    action: () => {
      let Composed = EnhanceAnimation(InsertContent, 'right-to-center', 'center-to-right');
      return <Composed ref="insertContent" exitOnClose={true} />
    }
  },
  {
    path: '/shareContact',
    action: () => {
      let Composed = EnhanceAnimation(ShareContact, 'right-to-center', 'center-to-right');
      return <Composed ref="shareContact" exitOnClose={true} />
    }
  },
  {
    path: '/voiceRecorder',
    action: () => {
      let Composed = EnhanceAnimation(VoiceRecorder, 'right-to-center', 'center-to-right');
      return <Composed ref="voiceRecorder" exitOnClose={true} />
    }
  },*/
  {
    path: '/locationView',
    action: () => {
      let Composed = EnhanceAnimation(LocationView, 'right-to-center', 'center-to-right');
      return <Composed ref="locationView" exitOnClose={true} />
    }
  },
  {
    path: '/filesList',
      action: () => {
        let Composed = EnhanceAnimation(FilesList, 'right-to-center', 'center-to-right');
        return <Composed ref="filesList" exitOnClose={true} />
      }
   },
   {
    path: '/audioRecordView/:sessionId/:msgId/:pageType/:sessionType/:users',
      action: (params) => {
        let Composed = EnhanceAnimation(AudioRecordView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"audioRecordView " + params.sessionId + ' ' +params.msgId + ' ' + params.pageType + ' ' + params.sessionType + ' ' + params.users + ' ' + new Date()} exitOnClose={true} />
      }
   },
  {
    path: '/channelsListView',
      action: (params) => {
        let Composed = EnhanceAnimation(ChannelsListView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"channelsListView" + params.channelId + ' ' + new Date()} exitOnClose={true} />
    } 
  },
  {
    path: '/channelDetails/:pageFrom/:channelId',
      action: (params) => {
        let Composed = EnhanceAnimation(ChannelDetails, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"channelDetails" + params.channelId + ' ' + new Date()}  exitOnClose={true} />
    } 
  },
  {
    path: '/channelsRecord',
      action: () => {
        let Composed = EnhanceAnimation(ChannelsRecord, 'right-to-center', 'center-to-right');
        return <Composed ref="channelsRecord" exitOnClose={true} />
    } 
  },
  {
    path: '/desktopHomeView/',
      action: () => {
        let Composed = EnhanceAnimation(DesktopHomeView, 'right-to-center', 'center-to-right');
        return <Composed ref="desktopHomeView" exitOnClose={true} />
      }
  },
  {
    path: '/desktopRegistrationView',
    action: () => {
        let Composed = EnhanceAnimation(DesktopRegistrationView, 'right-to-center', 'center-to-right');
        return <Composed ref="desktopRegistrationView" exitOnClose={true} />
    }
  },
   {
    path: '/desktopOtpVerifyView',
    action: () => {
        let Composed = EnhanceAnimation(DesktopOTPVerifyView, 'right-to-center', 'center-to-right');
        return <Composed ref="desktopOtpVerifyView" exitOnClose={true} />
    }
  },
  {
    path: '/desktopCaptchaView',
    action: () => {
        let Composed = EnhanceAnimation(DesktopCaptchaView, 'right-to-center', 'center-to-right');
        return <Composed ref="desktopCaptchaView" exitOnClose={true} />
    }
  },
   {
    path: '/desktopAddProfileView',
    action: () => {
        let Composed = EnhanceAnimation(DesktopAddProfileView, 'right-to-center', 'center-to-right');
        return <Composed ref="desktopAddProfileView" exitOnClose={true} />
    }
  },
  {
    path: '/desktopContactsView/:pagefrom',
    action: (params) => {
        let Composed = EnhanceAnimation(DesktopContactsView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref="desktopContactsView" exitOnClose={true} />
    }
  },
  //  {
  //   path: '/desktopExplore',
  //   action: () => {
  //       let Composed = EnhanceAnimation(DesktopExploreView, 'right-to-center', 'center-to-right');
  //       return <Composed ref="desktopExplore" exitOnClose={true} />
  //   }
  // },
  {
    path: '/searchChannel',
      action: () => {
        let Composed = EnhanceAnimation(ChannelSearchListView, 'right-to-center', 'center-to-right');
        return <Composed ref="ChannelSearchListView" exitOnClose={true} />
    } 
  },
  {
    path: '/recommendedChannel',
      action: () => {
        let Composed = EnhanceAnimation(ChannelSearchListView, 'right-to-center', 'center-to-right');
        return <Composed ref="ChannelSearchListView" exitOnClose={true} />
    } 
  },
  {

    path: '/exploreListView',
      action: () => {
        let Composed = EnhanceAnimation(ExploreListView, 'right-to-center', 'center-to-right');
        return <Composed ref="exploreListView" exitOnClose={true} />
    } 
  },
  {
    path: '/exploreDetail/:channelId',
      action: (params) => {
        let Composed = EnhanceAnimation(ExploreDetail, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"exploreDetail" + params.channelId + ' ' + new Date()}  exitOnClose={true} />
    } 
   },
     {
    path: '/displaySubmenu/:subMenuChannelId',
      action: (params) => {
        let Composed = EnhanceAnimation(SubmenuListView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"SubmenuListView" + params.subMenuChannelId + ' ' + new Date()} exitOnClose={true} />
    } 
  },
  
  {
    path: '/recentChannelsView/:pageType',
      action: (params) => {
        // var userId = userObj[0].userId;
        var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
        let Composed = EnhanceAnimation(ChannelsRecentView, 'right-to-center', 'center-to-right');
        // return <Composed {...params} ref={"recentChannelsView" + params.pageType + ' ' + new Date()} exitOnClose={true} />
        return <Composed {...params} ref={"recentChannelsView_" + userId} exitOnClose={true} />
    }
  }, 
  {
    path: '/mobileHomeView',
      action: () => {
        let Composed = EnhanceAnimation(MobileHomeView, 'right-to-center', 'center-to-right');
        return <Composed ref="mobileHomeView" exitOnClose={true} />
      }
  },
  {
    path: '/broadcastRecipientView/:msgId',
      action: (params) => {
        let Composed = EnhanceAnimation(BroadcastRecipientView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"broadcastRecipientView" + params.msgId + ' ' + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/dummyView/:id/:number/:pageType/:date',
    action: (params) => {
      let Composed = EnhanceAnimation(DummyView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"dummyView" + params.id + ' ' + params.number + ' ' + params.pageType} exitOnClose={true} />
    }
  },
  {
    path: '/multiRichMedia/:channelId/:msgId',
    action: (params) => {
      // var userId = userObj[0].userId;
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      let Composed = EnhanceAnimation(MultiRichMedia, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"multiRichMedia_" + userId + "_" + params.channelId + "_" + params.msgId}  exitOnClose={true} />
    }
  },
   {
    path: '/mobileWebView',
      action: () => {
        let Composed = EnhanceAnimation(MobileWebView, 'right-to-center', 'center-to-right');
        return <Composed ref="mobileWebView" exitOnClose={true} />
      }
  },
];

export default routes;
