/* global NavigationHelper */
'use strict';

(function(exports) {
  var NavigationMap = {
    init: function() {
      window.addEventListener('panelready', this.panelReadyHandler.bind(this));
    },

    registerPanelNavigation: function(navInfo) {
      var bootFocusElement = NavigationHelper.reset(
          navInfo.navigator,
          navInfo.controls,
          navInfo.defaultFocusIndex,
          navInfo.curViewId,
          navInfo.noSetfocus
      );

      return bootFocusElement;
    },

    focusChanged: function(element) {
      element.focus();
      element.scrollIntoView(true);
    },

    scrollToElement: function(element, event) {
      NavigationHelper.scrollToElement(element, event);
    },


    panelReadyHandler: function(event) {
      var navInfo = event.detail;
      var panel = navInfo.panel;
      this.focusedElement = this.registerPanelNavigation(navInfo);
      if (this.focusedElement) {
        this.focusChanged(this.focusedElement);

        if (panel.CLASS_NAME !== 'BasePanel') {
          panel.ready = true;
        }
      }
    }
  };

  exports.NavigationMap = NavigationMap;
}(window));
