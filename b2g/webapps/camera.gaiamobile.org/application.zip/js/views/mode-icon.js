define(['require','exports','module','debug','view','lib/bind'],function(require, exports, module) {


/**
 * Dependencies
 */

var debug = require('debug')('view:mode-icon');
var View = require('view');
var bind = require('lib/bind');

/**
 * Locals
 */

module.exports = View.extend({
  name: 'modeicon-ctrl',

  initialize: function () {
    this.render();
  },

  render: function() {
    this.el.innerHTML = this.template();
    this.els.cameraShutterIcon = this.find('.camera-shutter-icon');
    this.els.videoModeIcon = this.find('.video-mode-icon');
    this.els.selfTimerIcon = this.find('.self-timer-icon');
    delete this.template;
    debug('rendered');
    return this.bindEvents();
  },

  bindEvents: function () {
    return this;
  },

  template: function () {
    return `
      <div class ="mode-icon camera-shutter-icon">
        <img src="style/images/touchless/camera_shutter_icon.png"></img>
      </div>
      <div class="mode-icon video-mode-icon">
        <img src="style/images/touchless/camera_videomode_icon.png"></img>
      </div>
      <div class='mode-icon self-timer-display'>
        <img class='self-timer-icon'></img>
      </div>
      `;
  },

  selfTimerMode: function (seconds) {
    if (seconds === 0) {
      this.selfTimerModeHide();
      return;
    }
    this.selfTimerModeShow();
    if (seconds === 3) {
      this.els.selfTimerIcon.src = 'style/images/touchless/camera_selftimer_3s_icon.png';
    } else if (seconds === 5) {
      this.els.selfTimerIcon.src = 'style/images/touchless/camera_selftimer_5s_icon.png';
    } else if (seconds === 10) {
      this.els.selfTimerIcon.src = 'style/images/touchless/camera_selftimer_10s_icon.png';
    }
  },

  selfTimerModeShow: function () {
    this.els.selfTimerIcon.style.display = 'block';
  },
  
  selfTimerModeHide: function () {
    this.els.selfTimerIcon.style.display = 'none';
  },
  
  pictureMode: function () {
    this.els.cameraShutterIcon.classList.add('current-mode');
    this.els.videoModeIcon.classList.remove('current-mode');
  },

  videoMode: function () {
    this.els.videoModeIcon.classList.add('current-mode');
    this.els.cameraShutterIcon.classList.remove('current-mode');
  },
  
  show: function () {
    this.el.hidden = false;
  },

  hide: function () {
    this.el.hidden = true;
  }
});

});

