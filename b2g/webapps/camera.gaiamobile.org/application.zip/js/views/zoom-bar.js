define(['require','exports','module','debug','view','lib/bind','lib/orientation'],function(require, exports, module) {


/**
 * Dependencies
 */

var debug = require('debug')('view:zoom-bar');
var View = require('view');
var bind = require('lib/bind');
var orientation = require('lib/orientation');

/**
 * Locals
 */

var lastTouch = null;

var clamp = function(value, minimum, maximum) {
  return Math.min(Math.max(value, minimum), maximum);
};

module.exports = View.extend({
  name: 'zoom-ctrl',
  _value: 0,         // zoom value

  initialize: function() {
    this.render();

    this.slider = this.el.querySelector('.zoom-bar-slider gaia-slider');
    this.slider.setRange(0, 100);
    this.slider.value = 0;

    // Amount (%) to adjust the Zoom Bar by when tapping the min/max indicators
    this.zoomBarIndicatorInterval = 10;

    this.keyEventHandler = this.keyEvent.bind(this);
  },

  render: function() {
    this.el.innerHTML = this.template();
    delete this.template;
    debug('rendered');
    return this.bindEvents();
  },

  bindEvents: function() {
    return this;
  },

  template: function () {
    return `
      <div class ="zoom-bar-slider">
        <img class='zoom-in-out zoom-in-display' src="style/images/touchless/zoom_in.png"><img>
        <gaia-slider transparent="true"></gaia-slider>
        <img class='zoom-in-out zoom-out-display' src="style/images/touchless/zoom_out.png"><img>
      </div>
      `;
  },

  increment: function () {
    this.setValue(this._value + this.zoomBarIndicatorInterval, true);
  },

  decrement: function () {
    this.setValue(this._value - this.zoomBarIndicatorInterval, true);
  },

  setValue: function(value, emitChange) {
    var lastValue = this._value;
    this._value = clamp(value, 0, 100);
    if (this._value === lastValue) {
      return false;
    }
    if (emitChange) {
      this.emit('change', this._value);
    }
    this.slider.value = this._value;
    return true;
  },

  show: function () {
    console.log("zoom-bar: show");
    window.addEventListener('keydown', this.keyEventHandler);
    this.el.hidden = false;
  },

  hide: function () {
    console.log("zoom-bar: hide");
    window.removeEventListener('keydown', this.keyEventHandler);
    this.el.hidden = true;
  },

  addEventListenerInRecording: function () {
    window.addEventListener('keydown', this.keyEventHandler);
  },

  keyEvent: function (evt) {
    switch (evt.key) {
      case 'ArrowUp':
        this.increment();
        break;
      case 'ArrowDown':
        this.decrement();
        break;
    }
  }
});

});
