
(function(exports)
{var gUnit='px';var gMenuInstanceId=0;var gMenuBarInstanceId=0;var gAttriSelected='selected';var gSelectedSelector='.selected';var clsMenubar='popmenu-bar';var clsPopmenu='popmenu';var clsPopmenuIndicator='popmenu-indicator';var clsPopmenuWrap='popmenu-warp';var clsPopmenuTitleWrap='popmenu-title-wrap';var clsPopmenuTitle='popmenu-title';var clsPopmenuItemsContainer='popmenu-items-container';var clsPopmenuItemWrap='popmenu-item-wrap';var clsPopmenuItem='popmenu-item';var clsPopmenuBackIcon='popmenu-back-icon';var msgNewItemSelected='new-item-selected';var msgDefaultSelected='default-item-selected';var msgPopmenuCanceled='canceled';var PopmenuEvent='PopmenuBar-Event';function getElemHeight(ele){if(typeof(ele)==='object'){return ele.offsetHeight;}};function getElemWidth(ele){if(typeof(ele)==='object'){return ele.offsetWidth;}};function nameToSelector(name){return'.'+name;};function PopupMenuBar(menuContent,parentWindow,callback){var _instanceId="pop-menu-bar-"+gMenuBarInstanceId++;var _menus=new Array;var _selected_id=0;var _self=this;var _callback=callback;this._els=false;function _init(menuContent,parentWindow){if(typeof(_callback)!=='function'){console.warn("PopmenuBar: No callback was set!");}
_self._els=_createMenuBar();_initBarObserver();if(parentWindow)
parentWindow.appendChild(_self._els);else
document.body.appendChild(_self._els);if(!menuContent)
return;var number=menuContent.length;for(var i=0;i<number;++i){_self.insertMenu(menuContent[i]);}
_updateSelectedMenu(0);_self.hide();};function _createMenuBar(){var bar=document.createElement('div');bar.classList.add(clsMenubar);bar.id=_instanceId;return bar;};function _barObserverCallback(Records)
{var children=_self._els.children;var number=children.length;var width=(getElemWidth(_self._els)/number).toString()+gUnit;var height=getElemHeight(_self._els).toString()+gUnit;for(var i=0;i<number;++i){children[i].style.width=width;children[i].style.height=height;}};function _initBarObserver(){if(_self._els){var observer=new MutationObserver(_barObserverCallback);observer.observe(_self._els,{childList:true,subtree:false});}};function _updateSelectedMenu(selected){if(_menus.length<=0)
return;if(selected<0)
selected=_menus.length-1;else if(selected>=_menus.length)
selected=0;_menus[_selected_id].selected(false);_menus[selected].selected(true);_selected_id=selected;};this.keyEvent=function(evt){if(_menus.length<=0)
return;var selected=_selected_id;let arrowKeys=document.documentElement.dir==='rtl'?['ArrowRight','ArrowLeft']:['ArrowLeft','ArrowRight'];switch(evt.key?evt.key:evt.keyIdentifier){case arrowKeys[0]:case'Left':_updateSelectedMenu(--selected);break;case arrowKeys[1]:case'Right':_updateSelectedMenu(++selected);break;case'Backspace':case"BrowserBack":var detail={type:msgPopmenuCanceled,};if(_callback)
_callback(detail);else
window.dispatchEvent(new CustomEvent(PopmenuEvent,detail));break;}};this.registerKeyEvent=function(){window.addEventListener('keyup',this.keyEvent);};this.unregisterKeyEvent=function(){window.removeEventListener('keyup',this.keyEvent);};this.getMenus=function(){return _menus;};this.getSelectId=function(){return _selected_id;}
this.setSelectId=function(selecteId){if(selecteId<0&&selecteId>=_menus.length){console.warn("PopmenuBar: invalid selected_id");return;}
_selected_id=selecteId;}
this.getCallBack=function(){return _callback;}
PopupMenuBar.prototype.select=function(selected_id){if(arguments[0]===undefined)
selected_id=0;this.setSelectId(selected_id);this.show();};PopupMenuBar.prototype.show=function(){this._els.style.visibility='visible';this.registerKeyEvent();this.getMenus()[this.getSelectId()].selected();if(this.getMenus().length===1){this._els.firstChild.classList.add('nohighlight');}};PopupMenuBar.prototype.hide=function(){this._els.style.visibility='hidden';this.unregisterKeyEvent();this.getMenus()[this.getSelectId()].selected(false);};PopupMenuBar.prototype.insertMenu=function(menuContent){var menu=new PopMenu(menuContent,this._els,this.getCallBack());if(menu)
this.getMenus().push(menu);};PopupMenuBar.prototype.clear=function(){this.unregisterKeyEvent();while(this._els.firstChild)
this._els.removeChild(this._els.firstChild);this.getMenus().length=0;};_init(menuContent,parentWindow);};function PopMenu(menuContent,barEls,callback){if(!_verfiyInputParam(menuContent)||typeof(barEls)!=='object')
{console.log("menuContent or bar is invalid  !!!");return false;}
var _self=this;var _el={menu:false,indicator:false,wrap:false,title:false,items:false,};this._el=_el;var _internal={selected:menuContent.selected,source:menuContent.source,itemModel:new Array(),};var _callback=callback;var _instanceId='popmenu-'+gMenuInstanceId++;function _verfiyInputParam(menuContent){if(typeof(menuContent.title)!=='string'){console.error("menuContent.title must be string");return false;}
if(typeof(menuContent.menu)==='undefined'){console.error("menuContent.menu must not be undefined");return false;}
if(typeof(menuContent.items)==='undefined'||menuContent.items.length===0){console.error("menuContent.items must have at least on element");return false;}
if(typeof(menuContent.selected)==='undefined'||typeof(menuContent.selected)!=='number'){console.warn("menuContent.selected was set to default value: 0");menuContent.selected=0;return true;}
return true;};function _templete(){return`
        <div class = "${clsPopmenuIndicator}"></div>
        <div class = "${clsPopmenuWrap}">
            <div class ="${clsPopmenuTitleWrap} h1">
               <div class = "${clsPopmenuTitle}">
               </div>
            </div>
            <ul class = "${clsPopmenuItemsContainer}"></ul>
        </div>
        `;};function _initHtml(){_el.menu=document.createElement('div');_el.menu.innerHTML=_templete();_el.menu.id=_instanceId;_el.menu.classList.add(clsPopmenu);_el.menu.setAttribute('tabindex',0);_el.menu.setAttribute('role','heading');_el.title=_el.menu.querySelector(nameToSelector(clsPopmenuTitle));_el.items=_el.menu.querySelector(nameToSelector(clsPopmenuItemsContainer));_el.items.setAttribute('role','menu');_el.wrap=_el.menu.querySelector(nameToSelector(clsPopmenuWrap));_el.indicator=_el.menu.querySelector(nameToSelector(clsPopmenuIndicator));var value=_instanceId.replace(/[^0-9]/ig,"");_el.menu.setAttribute('aria-labelledby','popmenuTitle'+value);_el.title.setAttribute('id','popmenuTitle'+value);};function _menuHeightObserver(records){_el.wrap.style.left=0;_el.wrap.style.bottom=records[0].target.style.height;};function _initObserver(){if(_el.menu)
{var heightOb=new MutationObserver(_menuHeightObserver);heightOb.observe(_el.menu,{attributes:true,attributeFilter:["style"]});_el.menu.addEventListener('keydown',(e)=>{if(e.key==='Backspace'){e.preventDefault();callback&&callback({type:''});_el.menu.blur();}});}};function _initMenu(content,title){_el.title.innerHTML=title;var temp=document.createElement('div');temp.innerHTML=content;var node=temp.getElementsByTagName('img');if(node&&node.length>0)
{_el.indicator.style.backgroundImage='url('+node[0].src+')';}
else
{_el.indicator.innerHTML=content;}
temp=null;};function _initItems(items){var itemNum=items.length;var bTagged=itemNum>1;for(var i=0;i<itemNum;++i){var item=_createItem(items[i].title,menuContent.items[i].tag,bTagged,_internal.selected===i);_internal.itemModel.push(items[i]);_el.items.appendChild(item);}
NavigationPropHelper.addVertNavProperty(_el.items.children,_instanceId);};function _createItem(title,icon,bTagged,bSelected){var eleItemWrap=document.createElement('li');eleItemWrap.classList.add(clsPopmenuItemWrap);eleItemWrap.setAttribute('role','menuitem');eleItemWrap.setAttribute('tabindex',0);var eleItem=document.createElement('div');eleItem.innerHTML=title;eleItem.classList.add(clsPopmenuItem);eleItem.classList.add('p-pri');eleItemWrap.appendChild(eleItem);var eleBackIcon=document.createElement('div');eleBackIcon.classList.add(clsPopmenuBackIcon);eleItemWrap.appendChild(eleBackIcon);if(bTagged){if(bSelected){eleBackIcon.setAttribute('data-icon','radio-on');}
else{eleBackIcon.setAttribute('data-icon','radio-off');}}
return eleItemWrap;};function _init(menuContent,barEls){_initHtml();_initObserver();_internal.menuTitle=menuContent.title;_initMenu(menuContent.menu,menuContent.title);_initItems(menuContent.items);_el.wrap.hidden=true;barEls.appendChild(_el.menu);};this.keyEvent=function(evt){console.log("Popmenu keyEvent:"+evt.key);switch(evt.key?evt.key:evt.keyIdentifier){case'Enter':case'Accept':var focused_index=_getFocusedIndex();if(focused_index===_internal.selected)
{var detail={type:msgDefaultSelected,source:_internal.source,target:_internal.itemModel[focused_index]};if(typeof _callback!=='function')
window.dispatchEvent(new CustomEvent(PopmenuEvent,detail));else
_callback(detail);}
else
{var detail={type:msgNewItemSelected,source:_internal.source,target:_internal.itemModel[focused_index],};if(typeof _callback!=='function')
window.dispatchEvent(new CustomEvent(PopmenuEvent,detail));else
_callback(detail);}
break;}};function _getFocusedIndex(){var focused=NavigationPropHelper.getFocused();if(!focused)
return-1;var number=_el.items.children.length;for(var i=0;i<number;++i){if(_el.items.children[i]===focused)
return i;}
return-1;};this.registerKeyEvent=function(){window.addEventListener('keyup',this.keyEvent);};this.unregisterKeyEvent=function(){window.removeEventListener('keyup',this.keyEvent);};this._onSelected=function(){this.registerKeyEvent();_el.menu.classList.add(gAttriSelected);_el.wrap.hidden=false;let elements=_el.items.children;let elemToFocus=elements[0];for(let i=0;i<elements.length;i++){if(elements[i].children[1].getAttribute('data-icon')==='radio-on'){elemToFocus=elements[i];break;}}
NavigationPropHelper.setFocus(elemToFocus);};this._onUnselected=function(){this.unregisterKeyEvent();_el.menu.classList.remove(gAttriSelected);NavigationPropHelper.clearFocus();_el.wrap.hidden=true;};PopMenu.prototype.selected=function(bSelected){if(arguments[0]===undefined)
bSelected=true;if(bSelected)
this._onSelected();else
this._onUnselected();};_init(menuContent,barEls);};exports.PopupMenuBar=PopupMenuBar;})(window);