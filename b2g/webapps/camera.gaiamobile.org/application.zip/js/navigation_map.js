
!function(t){var e={currentActivatedLength:0};t.NavigationMap=e}(window);