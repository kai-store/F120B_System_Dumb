'use strict'

function debug(s) {
  if (DEBUG) {
    dump('<mmitest> ------: [version.js] = ' + s + '\n');
  }
}

function $(id) {
  return document.getElementById(id);
}

var VersionTest = new TestItem();

VersionTest.onHandleEvent = function(evt) {
  evt.preventDefault();
  return false;
};

VersionTest.onInit = function() {
  //debug("VersionTest");
	var lock = window.navigator.mozSettings.createLock();
	var build_number = lock.get('deviceinfo.build_number');
	//document.getElementById("version_out").innerHTML = navigator.buildID;
  //debug(navigator.buildID);
  build_number.onsuccess = function() {
        var json = JSON.stringify(build_number.result),
            obj = JSON.parse(json);
		$("version_output").innerHTML = obj["deviceinfo.build_number"];
	}
	this.passButton.disabled = '';
  this.failButton.disabled = '';
}

VersionTest.onDeinit = function() {
  
};

window.addEventListener('load', VersionTest.init.bind(VersionTest));
window.addEventListener('beforeunload', VersionTest.uninit.bind(VersionTest));
window.addEventListener('keydown', VersionTest.handleKeydown.bind(VersionTest));