/*© 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED, all rights reserved.*/
// ************************************************************************
// * File Name: accessories.js
// * Description: mmitest -> test item: accessories(headset).
// * Note:
// ************************************************************************

/* global DEBUG, dump, TestItem */
'use strict';

function debug(s) {
  if (DEBUG) {
    dump('<mmitest> ------: [accessories.js] = ' + s + '\n');
  }
}

function $(id) {
  return document.getElementById(id);
}

function click(event) {
  //click fail to close test item, need time to stop headset...
  setTimeout(function() {
    if (parent.ManuTest !== undefined) {
      parent.ManuTest.handleEvent.call(parent.ManuTest, event);
    } else {
      parent.AutoTest.handleEvent.call(parent.AutoTest, event);
    }
  }, 800);
}

var AccessoriesTest = new TestItem();

AccessoriesTest.step = 0;
AccessoriesTest.plugFlag = true;

AccessoriesTest.onHeadsetStatusChanged = function() {
  debug('onHeadsetStatusChanged');
  var acm = navigator.mozAudioChannelManager;
  if (acm.headphones) {
    $('centertext').innerHTML = 'Headset detected';
    this.plugFlag = true;

    AccessoriesTest.step = 0;
    this.leftChannelTest();
  } else {
    this.plugFlag = false;
    setTimeout(function() {
      AccessoriesTest.clearTestItem();
      $('centertext').innerHTML = 'Please plug in headset';
      self.passButton.disabled = 'disabled';
      self.failButton.disabled = '';
    }, 850);
  }
};

//the following are inherit functions
AccessoriesTest.onInit = function() {
  var self = this;

  AccessoriesTest.step = 0;

  var acm = navigator.mozAudioChannelManager;
  if (acm.headphones) {
    $('centertext').innerHTML = 'Headset detected';
    this.plugFlag = true;
  } else {
    $('centertext').innerHTML = 'Please plug in headset';
    this.plugFlag = false;
    self.passButton.disabled = 'disabled';
    self.failButton.disabled = '';
  }

  if (acm) {
    acm.addEventListener('headphoneschange',
        this.onHeadsetStatusChanged.bind(this));
  } else {
    $('centertext').innerHTML = 'mozAudioChannelManager not supported';
  }
};

AccessoriesTest.leftChannelTest = function() {
  $('centertext').innerHTML = 'headset left discrete test';

  navigator.engmodeExtension.startAudioLoopTest('headset-left');
  this._timer = window.setTimeout(this.timeoutCallback.bind(this), 3000);
  AccessoriesTest.step++;
  this.passButton.disabled = 'disabled';
  this.failButton.disabled = 'disabled';
  this.passButton.style.visibility = 'visible';
  this.failButton.style.visibility = 'visible';
};

AccessoriesTest.leftChannelTestClose = function() {
  debug('stopAudio left');
  navigator.engmodeExtension.stopAudioLoopTest();
  setTimeout(function() {
    navigator.engmodeExtension.startAudioLoopTest('headset-left-stop');
  }, 500);
  navigator.engmodeExtension.stopAudioLoopTest();
};

AccessoriesTest.rightChannelTest = function() {
  $('centertext').innerHTML = 'headset right discrete test';
  setTimeout(function() {
    navigator.engmodeExtension.startAudioLoopTest('headset-right');
  }, 1000);

  AccessoriesTest.step++;
  this.passButton.disabled = 'disabled';
  this.failButton.disabled = 'disabled';
  this.passButton.style.visibility = 'visible';
  this.failButton.style.visibility = 'visible';
  this._timer = window.setTimeout(this.timeoutCallback.bind(this), 4000);
};

AccessoriesTest.rightChannelTestClose = function() {
  debug('stopAudio right');
  navigator.engmodeExtension.stopAudioLoopTest();
  setTimeout(function() {
    navigator.engmodeExtension.startAudioLoopTest('headset-right-stop');
  }, 500);
  navigator.engmodeExtension.stopAudioLoopTest();
};

AccessoriesTest.micTest = function() {
  $('centertext').innerHTML = 'preparing ...';

  var self = this;
  self.passButton.disabled = 'disabled';
  self.failButton.disabled = 'disabled';
  self.passButton.style.visibility = 'visible';
  self.failButton.style.visibility = 'visible';
  AccessoriesTest.step++;
  setTimeout(function() {
    $('centertext').innerHTML = 'headset mic test';
    navigator.engmodeExtension.startAudioLoopTest('headset-mic');
    self._timer = window.setTimeout(self.timeoutCallback.bind(self), 3000);
  }, 1000);
};

AccessoriesTest.micTestClose = function() {
  debug('stopAudio headset');
  navigator.engmodeExtension.stopAudioLoopTest();
  setTimeout(function() {
    navigator.engmodeExtension.startAudioLoopTest('stop-headset-mic');
  }, 500);
};

AccessoriesTest.removeHeadsetTest = function() {
  $('centertext').innerHTML = 'Please remove headset';
  AccessoriesTest.step++;
  this.passButton.disabled = 'disabled';
  this.failButton.disabled = '';
  this.passButton.style.visibility = 'visible';
  this.failButton.style.visibility = 'visible';
};

AccessoriesTest.timeoutCallback = function() {
  if (this.plugFlag) {
    this.passButton.disabled = '';
    this.failButton.disabled = '';
    this.passButton.style.visibility = 'visible';
    this.failButton.style.visibility = 'visible';
  } else {
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = '';
    this.passButton.style.visibility = 'invisible';
    this.failButton.style.visibility = 'visible';
  }
};

AccessoriesTest.clearTestItem = function() {
  if (AccessoriesTest.step === 1) {
    this.leftChannelTestClose();
  } else if (AccessoriesTest.step === 2) {
    this.rightChannelTestClose();
  } else if (AccessoriesTest.step === 3) {
    this.micTestClose();
  }
};

AccessoriesTest.onHandleEvent = function(evt) {
  evt.preventDefault();
  if (evt.type === 'keydown') {
    switch (evt.key) {
      case 'SoftLeft':
        if (this.passButton.disabled) {
          return false;
        }

        if (AccessoriesTest.step == 0) {
          this.leftChannelTest();
        } else if (AccessoriesTest.step == 1) {
          this.leftChannelTestClose();
          setTimeout(this.rightChannelTest.bind(this), 800);
        } else if (AccessoriesTest.step == 2) {
          this.rightChannelTestClose();
          setTimeout(this.micTest.bind(this), 800);
        } else if (AccessoriesTest.step == 3) { //close mic and start fm test
          this.micTestClose();
          click({type: 'click', name: 'pass'});
          return true;
        } else {
          return false;
        }
        return true;
      case 'SoftRight':
        if (this.failButton.disabled) {
          return false;
        }
        this.clearTestItem();
        if (AccessoriesTest.step <= 3) {
          click({type: 'click', name: 'fail'});
          return true;
        }
        break;

      default:
        break;
    }
  }
  return false;
};

window.addEventListener('load', AccessoriesTest.init.bind(AccessoriesTest));
window.addEventListener('keydown', AccessoriesTest.handleKeydown.bind(AccessoriesTest));
