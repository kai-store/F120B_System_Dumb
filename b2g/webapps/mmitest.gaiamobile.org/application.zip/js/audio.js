/*© 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED, all rights reserved.*/
// ************************************************************************
// * File Name: audio.js
// * Description: mmitest -> test item: audio test.
// * Note:
// ************************************************************************

/* global DEBUG, dump, TestItem */
'use strict';

function debug(s) {
  if (DEBUG) {
    dump('<mmitest> ------: [audio.js] = ' + s + '\n');
  }
}

function $(id) {
  return document.getElementById(id);
}

var AudioTest = new TestItem();

AudioTest.audio = $('audio-element-id');

AudioTest.isAudioPlaying = false;
AudioTest.isAudioLoopProcessing = false;

AudioTest.testIndex = 0;
AudioTest.testItems = [
  'receiver',
  'speaker',
  'mic',
  //'sub-mic'  // no sub mic
];

AudioTest.setDefaultVolume = function() {
  // set to default volume to make sure we can test
  var settings = window.navigator.mozSettings;
  if (settings) {
    settings.createLock().set({'audio.volume.telephony': 5});
    settings.createLock().set({'audio.volume.content': 15});
  }
};

AudioTest.resumeVolume = function() {
  var settings = window.navigator.mozSettings;
  if (settings) {
    settings.createLock().set({'audio.volume.content': 8});
  }
};

AudioTest.checkStartAudio = function(speakerEnabled) {
  debug('AudioTest.checkStartAudio');
  this.checkStopAudioLoop();
  navigator.mozTelephony.speakerEnabled = speakerEnabled;

  if (!this.isAudioPlaying) {
    if (navigator.engmodeExtension) {
      navigator.engmodeExtension.startForceInCall();
    }
    debug('AudioTest: startForceInCall');
    try {
      this.audio.play();
      this.isAudioPlaying = true;
    } catch (e) {
      debug(e);
    }
  }
};

AudioTest.checkStopAudio = function() {
  debug('AudioTest.checkStopAudio this.isAudioPlaying = ' +this.isAudioPlaying);
  if (this.isAudioPlaying) {
    this.audio.pause();
    this.audio.removeAttribute('src');
    if (navigator.engmodeExtension) {
      navigator.engmodeExtension.stopForceInCall();
    }
    debug('AudioTest: stopForceInCall');
    this.isAudioPlaying = false;
  }
};

AudioTest.checkStartAudioLoop = function(type) {
  debug('AudioTest.checkStartAudioLoop');
  this.checkStopAudio();
  this.checkStopAudioLoop();
  this.isAudioLoopProcessing = true;
  window.setTimeout(function() {
    debug('AudioTest.checkStartAudioLoop.setTimeout');
    if (navigator.engmodeExtension) {
      navigator.engmodeExtension.startAudioLoopTest(type);
    }
  }, 3000);
};

AudioTest.stopMicOrSubMic = function(type) {
  this.checkStopAudio();
  this.checkStopAudioLoop();
  this.isAudioLoopProcessing = true;
  if (navigator.engmodeExtension) {
    navigator.engmodeExtension.startAudioLoopTest(type);
  }
};

AudioTest.checkStopAudioLoop = function() {
  debug('AudioTest.checkStopAudioLoop');
  if (this.isAudioLoopProcessing) {
    if (navigator.engmodeExtension) {
      //navigator.engmodeExtension.startAudioLoopTest('stop-sub-mic');
      //navigator.engmodeExtension.stopAudioLoopTest();
 	setTimeout(function() {
      navigator.engmodeExtension.startAudioLoopTest('stop-mic');
     }, 1000);
    }
    this.isAudioLoopProcessing = false;
  }
};

AudioTest.checkStartReceiverOrSpeaker = function(type) {
  debug('AudioTest.checkStartReceiverOrSpeaker');
  this.isAudioLoopProcessing = true;
  if (navigator.engmodeExtension) {
  	debug('AudioTest.checkStartReceiverOrSpeaker start type = ' + type);
		
		setTimeout(function() {
    			navigator.engmodeExtension.startAudioLoopTest(type);
  		}, 3000);
  	}
};

AudioTest.checkStopReceiverOrSpeaker = function(type) {
  debug('AudioTest.checkStopReceiverOrSpeaker ');
  if (this.isAudioLoopProcessing) {
    if (navigator.engmodeExtension) {
		navigator.engmodeExtension.stopAudioLoopTest();
		
	  	debug('AudioTest.checkStopReceiverOrSpeaker stop type = ' + type);
		  setTimeout(function() {
    			navigator.engmodeExtension.startAudioLoopTest(type);
  		}, 1000);
		

    }
    this.isAudioLoopProcessing = false;
  }
};

AudioTest.doTest = function() {
  debug('AudioTest.doTest');
  this.passButton.disabled = 'disabled';
  this.failButton.disabled = 'disabled';
  switch (this.testItems[this.testIndex]) {
    case 'receiver':
      debug('AudioTest.doTest = receiver');
      this._timer = window.setTimeout(this.timeoutCallback.bind(this), 6000);
      $('centertext').innerHTML = 'receiver test';
      //this.checkStartAudio(false); //speakerEnabled false.
      this.checkStartReceiverOrSpeaker('sub-mic');//open receiver
      break;

    case 'speaker':
      this._timer = window.setTimeout(this.timeoutCallback.bind(this), 5500);
      debug('AudioTest.doTest = speaker');
      $('centertext').innerHTML = 'speaker test';
      //this.checkStartAudio(true); //speakerEnabled true.
      this.checkStartReceiverOrSpeaker('enable-headphone'); //open speaker
      break;

    case 'mic':
      debug('AudioTest.doTest = mic');
	  $('centertext').innerHTML = 'loop from MIC test';
      //$('centertext').innerHTML = 'loop from MIC test<br>Please plug in headset';
      clearTimeout(this._timer);
      this._timer = window.setTimeout(this.timeoutCallback.bind(this), 6500);
      this.checkStartAudioLoop('mic');
      break;

    case 'sub-mic':
      debug('AudioTest.doTest = sub-mic');
      $('centertext').innerHTML = 'loop from Sub MIC test';
      clearTimeout(this._timer);
      this._timer = window.setTimeout(this.timeoutCallback.bind(this), 5500);
      this.checkStartAudioLoop('sub-mic');
      break;

    default:
      break;
  }
};

AudioTest.timeoutCallback = function() {
  this.passButton.disabled = '';
  this.failButton.disabled = '';
  this.passButton.style.visibility = 'visible';
  this.failButton.style.visibility = 'visible';
};

AudioTest.visibilityChange = function() {
  debug('AudioTest.visibilityChange');
  if (document.mozHidden) {
    debug('AudioTest: visibilityChange-hide');
    this.checkStopAudio();
    this.checkStopAudioLoop();
  } else {
    debug('AudioTest: visibilityChange-visible');
    this.doTest();
  }
};

//the following are inherit functions
AudioTest.onInit = function() {
  debug('AudioTest.onInit');
  if (!navigator.engmodeExtension) {
    $('centertext').innerHTML = 'not support engmodeExtension';
    return;
  }

  this.setDefaultVolume();
  this.doTest();
};

AudioTest.onDeinit = function() {
  debug('AudioTest.onDeinit');
  this.checkStopAudio();
  this.checkStopAudioLoop();
  this.resumeVolume();
};

AudioTest.clearTestItem = function() {
  var currentTestItem = this.testItems[this.testIndex];
  debug('AudioTest.clearTestItem currentTestItem = ' + currentTestItem);
  if (currentTestItem === 'receiver') {
	this.checkStopReceiverOrSpeaker('stop-sub-mic');//stop receiver
  } else if(currentTestItem === 'speaker'){
    this.checkStopReceiverOrSpeaker('disable-headphone');//stop speaker
  } else if(currentTestItem === 'mic'){
    this.stopMicOrSubMic('stop-mic');
  }
};

function click(event) {
  //click fail to close test item, need time to stop ...
  setTimeout(function() {
    if (parent.ManuTest !== undefined) {
      parent.ManuTest.handleEvent.call(parent.ManuTest, event);
    } else {
      parent.AutoTest.handleEvent.call(parent.AutoTest, event);
    }
  }, 800);
}

AudioTest.onHandleEvent = function(evt) {
  evt.preventDefault();
  debug('AudioTest.onHandleEvent this.testItems.length = ' + this.testItems.length);
  switch (evt.type) {
    case 'keydown':
      switch (evt.key) {
        case 'SoftLeft':
          if (this.passButton.disabled) {
            return;
          }
          this.handleMicOrSubMic();
          this.testIndex++;
          if (this.testIndex < this.testItems.length) {
            this.doTest();
            return true;
          }
		  debug('AudioTest.onHandleEvent SoftLeft this.testIndex = ' + this.testIndex);
		  if (this.testIndex === 3){
		  	debug('AudioTest.onHandleEvent SoftLeft in');
		    click({type: 'click', name: 'pass'});
			return true;
		  }
          break;
       case 'SoftRight':   
         if (this.failButton.disabled) {
          return false;
         }
		 this.clearTestItem();
		 debug('AudioTest.onHandleEvent SoftRight this.testIndex = ' + this.testIndex);
         if (this.testIndex <= 3) {
		 debug('AudioTest.onHandleEvent SoftRight in ');
          click({type: 'click', name: 'fail'});
          return true;
        }
		 break;
		 
        default:
          break;
      }
      break;
    default:
      break;
  }
  return false;
};

AudioTest.handleMicOrSubMic = function() {
  var currentTestItem = this.testItems[this.testIndex];
  debug('AudioTest.onHandleEvent handleMicOrSubMic currentTestItem = ' + currentTestItem);

  if (currentTestItem === 'receiver') {
	this.checkStopReceiverOrSpeaker('stop-sub-mic');//stop receiver
  }
  
  if (currentTestItem === 'speaker') {
	this.checkStopReceiverOrSpeaker('disable-headphone');//stop speaker
  }
	
  if (currentTestItem === 'mic') {
    this.stopMicOrSubMic('stop-mic');
  }
  if (currentTestItem === 'sub-mic') {
    this.stopMicOrSubMic('stop-sub-mic');
  }
};

window.addEventListener('load', AudioTest.init.bind(AudioTest));
window.addEventListener('beforeunload', AudioTest.uninit.bind(AudioTest));
window.addEventListener('mozvisibilitychange', AudioTest.visibilityChange.bind(AudioTest));
window.addEventListener('keydown', AudioTest.handleKeydown.bind(AudioTest));
