/*© 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED, all rights reserved.*/
// ************************************************************************
// * File Name: auto.js
// * Description: mmitest -> auto test part.
// * Note: When you want to add a new test item, just add the html file
// *       name in array testList
// ************************************************************************

/* global dump, asyncStorage */
'use strict';

const RESULT_LIST = 'result_list';

const DEBUG = true;
function debug(s) {
  if (DEBUG) {
    dump('<mmitest> ------: [auto.js] = ' + s + '\n');
  }
}
//-------------------------------------------------------------------------

var AutoTest = {

  testList: [],
  index: 0,
  // 'start', 'next', the start button will be used in two cases.
  autoStartButtonStatus: 'start',

  resultList: [],

  getResultList: function AutoTest_geResultList(callback) {
    asyncStorage.getItem(RESULT_LIST, (value) => {
      debug('get test result list:' + value);
      value && callback(value);
    });
  },

  setResultList: function AutoTest_setResult() {
    var resultList = this.resultList.toString();
    asyncStorage.setItem(RESULT_LIST, resultList);
    debug('setResult, result list:' + resultList);
  },

  restartAutoTest: function AutoTest_restartAutoTest() {
    this.index = 0;
    this.resultList = [];
    this.startAutoTest();
  },

  startAutoTest: function AutoTest_startAutoTest() {
    //if end , show end play
    if (this.index >= this.testList.length) {
      this.autoStartButtonStatus = 'end';
      this.displayResultList();
      return;
    }

    this.resultPanel.classList.add('hidden');

    // add class 'test' for page animation, detail refer to auto.css
    document.body.classList.add('test');
    this.autoStartButton.innerHTML = 'Start';
    this.autoStartButtonStatus = 'start';
    this.retestButton.style.visibility = 'hidden';

    this.iframe.src = this.testList[this.index] + '.html';
    this.iframe.focus();
  },

  endAutoTest: function AutoTest_endAutoTest() {
    this.stopGps();
    this.stopNfc();
    this.setResultList();
    window.location = '../index.html';
  },

  goToNextTest: function AutoTest_goToNextTest() {
    debug('goToNextTest ==================== ');
    this.setResultList();//liujinrui add 
	this.index += 1;
    if (this.index < this.testList.length) {
      this.iframe.src = this.testList[this.index] + '.html';
    } else {
      this.displayResultList();
      this.autoStartButtonStatus = 'end';
    }
  },

  failAutoTest: function AutoTest_failAutoTest() {
    debug('failAutoTest ==================== ');
    this.setResultList();

    this.autoStartButton.innerHTML = 'Next';
    this.autoStartButtonStatus = 'next';
    this.retestButton.style.visibility = 'visible';

    this.centerContext.innerHTML =
        this.getItemName(this.testList[this.index]) +
        ' test failed <br > Press Next or Retest';

    // add class 'test' for page animation, detail refer to auto.css
    document.body.classList.remove('test');
    this.iframe.blur();
  },

  displayResultList: function AutoTest_displayResultList(list) {
    this.resultPanel.classList.remove('hidden');
    this.iframe.blur();

    if (list) {
      this.resultList = list.split(',');
    }

    debug(this.resultList);
    var result = '';
    for (var i = 0; i < this.testList.length; i++) {
      result += '<p class=' + this.resultList[i] + '>' + this.testList[i] + ': ' +
       (this.resultList[i] === undefined || this.resultList[i] === '' ?
        'not test' : (this.resultList[i] === 'true' ? 'pass': 'fail')) + '</p>' ;
    }
	debug("get result" + result);

	//liujinrui add output txt.

	var result2 = '';
    for (var i = 0; i < this.testList.length; i++) {
      result2 +=
       (this.resultList[i] === undefined || this.resultList[i] === '' ?
        '0' : (this.resultList[i] === 'true' ? '1': '0'));
    }
	result2 = result2 + '\n';
	debug("get result2" + result2);
	
	this.getResultFile(result2);
	//liujinrui add end
    this.resultText.innerHTML = result;
  },
  
  //liujinrui add function start
  addResultFileToSdcard: function AutoTest_addResultFileToSdcard(result){
     var sdcard = navigator.getDeviceStorage("sdcard");
     var file   = new Blob([result], {type: "text/plain"});
     var request = sdcard.addNamed(file, "cittestresult.txt");
	 
     request.onsuccess = function () {
       var name = this.result;
       console.log('File "' + name + '" successfully wrote on the sdcard storage area');
     }
     // An error typically occur if a file with the same name already exist
     request.onerror = function () {
       console.warn('Unable to write the file: ' + this.error);
     }
  },

  getResultFile: function AutoTest_getResultFile(result){
     var sdcard = navigator.getDeviceStorage('sdcard');
     var request = sdcard.get("cittestresult.txt");
	 
     request.onsuccess = function () {
       var file = this.result;
       console.log("Get the file: " + file.name);
	   AutoTest.deleteResultFile(result);
     }

     request.onerror = function () {
       console.warn("Unable to get the file: " + this.error);
	   AutoTest.addResultFileToSdcard(result);
     }
  },

  deleteResultFile: function Auto_deleteResultFile(result){
    var sdcard = navigator.getDeviceStorage('sdcard');
    var request = sdcard.delete("cittestresult.txt");

	request.onsuccess = function () {
	  console.log("File deleted");
	  AutoTest.addResultFileToSdcard(result);
	}

	request.onerror = function () {
	  console.log("Unable to delete the file: " + this.error);
	}
  },
  //liujinrui add function end
  get autoStartButton() {
    return document.getElementById('autoStartButton');
  },

  get autoEndButton() {
    return document.getElementById('autoEndButton');
  },

  get retestButton() {
    return document.getElementById('retestButton');
  },

  get resultText() {
    return document.getElementById('result-text');
  },

  get centerContext() {
    return document.getElementById('centertext');
  },

  get iframe() {
    return document.getElementById('test-iframe');
  },

  get restartYes() {
    return document.getElementById('restartYes');
  },

  get restartNo() {
    return document.getElementById('restartNo');
  },

  // according to file name, get the item name.
  getItemName: function AutoTest_getItemName(fileName) {
    var item = fileName;
    switch (fileName) {
      case 'version':
        item = "Version Code";
		break;
      case 'lcd':
        item = 'LCD display';
        break;
      case 'keypad':
        item = 'Keypad';
        break;
      case 'keypad_led':
        item = 'KeypadLED';
        break;
      case 'backlight':
        item = 'LCD backlight';
        break;
      case 'camera':
        item = 'Camera';
        break;
      case 'camera_front':
        item = 'Front Camera';
        break;
      case 'flashlight':
        item = 'Flashlight';
        break;
      case 'audio':
        item = 'Audio Test';
        break;
      case 'vibrate':
        item = 'Vibrator';
        break;
      case 'accessories':
        item = 'Accessories';
        break;
      case 'charger':
        item = 'Charging';
        break;
      case 'usb':
        item = 'USB';
        break;
      case 'gsensor':
        item = 'G-sensor';
        break;
      case 'sim':
        item = 'SIM';
        break;
      case 'sdcard':
        item = 'Micro SD card';
        break;
      case 'battery':
        item = 'Battery Temperature';
        break;
      case 'nfc':
        item = 'NFC';
        break;
      case 'bluetooth':
        item = 'Bluetooth';
        break;
      case 'wifi':
        item = 'Wi-Fi';
        break;
      case 'fm':
        item = 'FM';
        break;
      case 'gps':
        item = 'GPS';
        break;
      case 'dialer':
        item = 'Call';
        break;
    }

    return item;
  },

  loadConfig: function ut_loadConfig() {
    var xhr = new XMLHttpRequest();
    xhr.overrideMimeType('application/json');
    xhr.open('GET', '../resource/config.json', true);
    xhr.send(null);
    xhr.onreadystatechange = function cc_loadConfiguration() {
      if (xhr.readyState !== 4) {
        return;
      }
      if (xhr.status === 0 || xhr.status === 200) {
        var list = JSON.parse(xhr.responseText);
        for (var i = 0, j = 0; i < list.testItems.length; i++) {
          debug('name = ' + list.testItems[i].itemName + ' | ' + list.testItems[i].itemInfo);
          if ('true' === list.testItems[i].autoTest[0].testFlag) {
            AutoTest.testList[j++] = list.testItems[i].itemName;
          }
        }
      }
    };
  },

  loadTestItems: function AutoTest_loadTestItems() {
    AutoTest.testList = ['lcd', 'keypad', 'backlight',
      'camera', 'flashlight', 'audio', 'vibrate', 'accessories', 'fm', 'charger', 'sim',
      'sdcard', 'battery', 'nfc', 'bluetooth', 'wifi', 'gps'];
    var cameras = navigator.mozCameras.getListOfCameras();
    if (cameras.length == 2) {
      var index = AutoTest.testList.indexOf('camera');
      if (index > 0 && index < AutoTest.testList.length) {
        AutoTest.testList.splice(index + 1, 0, 'camera_front');
      }
    }

    // Hiding the NFC testing if device not support it.
    if (!navigator.mozNfc) {
      debug('AutoTest: device don\'t support NFC.');
      var index = AutoTest.testList.indexOf('nfc');
      AutoTest.testList.splice(index, 1);
    }
  },

  startGps: function _startGps() {
    if (navigator.engmodeExtension) {
      navigator.engmodeExtension.startGpsTest();
    }
  },

  stopGps: function _stopGps() {
    if (navigator.engmodeExtension) {
      navigator.engmodeExtension.stopGpsTest();
    }
  },

  stopNfc: function() {
    if (navigator.engmodeExtension) {
      navigator.engmodeExtension.execCmdLE(['nfc_stop'], 1);
    }
  },

  init: function AutoTest_init() {
    this.resultPanel = document.getElementById('result-screen');

    // XXX, let's load config later ..
    // this.loadConfig();
    this.loadTestItems();

    // start gps_test module when enter test.
    this.startGps();
    this.iframe.addEventListener('load', this);
    this.iframe.addEventListener('unload', this);
    this.retestButton.addEventListener('click', this);
    this.retestButton.style.visibility = 'hidden';
    this.restartYes.addEventListener('click', this);
    this.restartNo.addEventListener('click', this);

    this.getResultList((list) => {
      this.displayResultList(list);
    });

  },

  handleEvent: function AutoTest_handleEvent(evt) {
    switch (evt.type) {
      case 'click':
        if (evt.name === 'pass') {
          this.resultList[this.index] = 'true';
          if (this.testList[this.index] === 'audio') {
            this.iframe.blur();
            window.focus();
            var self = this;
            setTimeout(function() {
              self.index += 1;
              self.startAutoTest();
            }, 500);
            return;
          }
          this.goToNextTest();
        } else if (evt.name === 'fail') {
          this.resultList[this.index] = false;
          this.failAutoTest();
        }
        break;
      case 'retestButton':
        if (this.retestButton.style.visibility !== 'hidden') {
          this.startAutoTest();
        }
        break;
      default:
        break;
    }
  },

  handleKeydown: function AutoTest_handleKeydown(evt){
    evt.preventDefault();
    switch(evt.key){
      case 'SoftRight':
        this.endAutoTest();
        break;

      case 'SoftLeft':
        if (!this.resultPanel.classList.contains('hidden') &&
            this.autoStartButtonStatus === 'end') {
          this.restartAutoTest();
          return;
        }
        if (this.autoStartButtonStatus === 'next') {
          this.index += 1;
        }
        this.startAutoTest();
        break;

      case 'ArrowUp':
        if (!this.resultPanel.classList.contains('hidden')) {
          this.resultText.scrollTop -= 60;
        } else {
          this.startAutoTest();
        }
        break;

      case 'ArrowDown':
        if (!this.resultPanel.classList.contains('hidden')) {
          this.resultText.scrollTop += 60;
        }
        break;

      default:
        break;
    }
  }
};

window.onload = AutoTest.init.bind(AutoTest);
window.addEventListener('keydown', AutoTest.handleKeydown.bind(AutoTest));
