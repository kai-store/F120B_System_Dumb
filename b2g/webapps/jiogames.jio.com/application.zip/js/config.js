var configObject = {
	baseUrl : 'http://GajmeisoLoaB24.jio.com/'
}