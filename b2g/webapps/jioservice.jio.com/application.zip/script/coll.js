/* File containing fuctions which have all the statistics collection functions */

/* Global variables for device info */
var firmware_global;
var hardware_global;
var os_global;
var platformId_global;
var platform_ver_global;
var soft_global;
var model_global;

function dummyPromise(){
	return new Promise((resolve, reject) => {
		resolve();
	});
}

/**
* Function to get Date from system.
*
* @name getDateStamp
*
* @function
*/
function getDateStamp() {
	var date = new Date(); 
	var date_string = date.toString();
	var dd = ("0" + date.getDate()).slice(-2);
	var mm = ("0" + (date.getMonth() + 1)).slice(-2);
	var yyyy = ("" + date.getFullYear()).slice(-2);
	var time = date_string.slice(16, 24);          
	return dd + "-" + mm + "-" + yyyy + " "+time; 
}

/**
* Function to Read the device language settings from API inside a Promise function.
*
* @name collectLanguage
*
* @function
*/
function collectLanguage(){
	return new Promise((resolve, reject) => {
		var lock = navigator.mozSettings.createLock();
		var req_lang  = lock.get('language.current');
		var lang;

		req_lang.onsuccess = function () {
			lang = req_lang.result['language.current'];
			resolve(lang);
		}

		req_lang.onerror = function () {
			console.log("collectLanguage An Lock error occured:");
			reject();
		}
	});
}

/**
* Function to Read the device IME settings from API inside a Promise function.
*
* @name collectIME
*
* @function
*/
function collectIME(){
	return new Promise((resolve, reject) => {
		var lock = navigator.mozSettings.createLock();
		var req_key  = lock.get('keyboard.current');
		var ime_no;

		req_key.onsuccess = function () {
			ime_no = req_key.result['keyboard.current'];
			resolve(ime_no);
		}
		req_key.onerror = function () {
			console.log("collectIME An Lock error occured:");
			reject();
		}
	});
}

/**
* Function to collect Data Usage Statistics from API inside a Promise function for LTE connection.
* The function provides the number of KiloBytes exchanged in Rx and Tx directions
*
* @name collectDataUsageStats
*
* @function
*/
function collectDataUsageStats()
{
	var datausage_temp = { rxBytes:0, txBytes:0 };

	return new Promise((resolve, reject) => {


		//Get stores
		var dataConnection  = navigator.mozMobileConnections[0].data.connected; 
		if (dataConnection) {
			var networks = navigator.mozNetworkStats.getAvailableNetworks();
			networks.onsuccess = function() {
				var network = this.result[1]; // 1 for Cellular ; returns a mozNetworkInterface object
				
				if(network)
				{

					var end = new Date();
					var start = new Date();

					var samples = navigator.mozNetworkStats.getSamples(network, start, end); 							
					if (samples) {
						samples.onsuccess = function () {									

							//Append new data to Datausage temporary object
							datausage_temp.rxBytes = Math.round(samples.result.data[0].rxBytes /1024);
							datausage_temp.txBytes = Math.round(samples.result.data[0].txBytes /1024);
							resolve(datausage_temp);
						}

						samples.onerror = function () {
							console.log("collectDataUsageStats Samples Error");
							reject();
						}
					}
                    else
					{
						console.log("collectDataUsageStats Samples Undefined");
						reject();
					}
				}
				else
				{
					console.log("collectDataUsageStats Network Undefined");
					reject();
				}

			}

			networks.onerror = function () {
				console.log("collectDataUsageStats Network Error");
				reject();
			}
		}else
		{
			console.log("collectDataUsageStats No data connection");
			reject();
		}

	});

}

/**
* Function to collect Wifi connection information along with the usage statistics inside a Promise function.
*
* @name collectWifiStats
*
* @function
*/
function collectWifiStats()
{	
	var wifi_temp = { ssid:0, relSignalStrength:0, rxBytes:0, txBytes:0 };
	return new Promise((resolve, reject) => {
		//Get stores
		if (wifiEnabled) {
			var wifi = navigator.mozWifiManager;
			var networks = navigator.mozNetworkStats.getAvailableNetworks();								
			networks.onsuccess = function() {
				var network = this.result[0]; // 0 for Wifi; returns a mozNetworkInterface object													
				
				if(network)
				{

				var end = new Date();
				var start = new Date();

				var samples = navigator.mozNetworkStats.getSamples(network, start, end); 					
				if (samples) {
					samples.onsuccess = function () {						
						//get length of elements in the array
						var ssid = wifi.connection.network.ssid;
						var relSignalStrength = wifi.connectionInformation.relSignalStrength;
						//Append new data to wifi temporary object
						wifi_temp.ssid = ssid;
						wifi_temp.relSignalStrength = relSignalStrength;
						wifi_temp.rxBytes = Math.round(samples.result.data[0].rxBytes /1024);
						wifi_temp.txBytes = Math.round(samples.result.data[0].txBytes /1024);
						resolve(wifi_temp);

					}
					samples.onerror = function () {
						console.log("collectWifiStats Samples Error");
						reject();
						}
					}
					else
					{
						console.log("collectWifiStats Samples Undefined");
						reject();
					}	
				}
				else
				{
					console.log("collectWifiStats Network Undefined");
					reject();
				}
			}

			networks.onerror = function () {
				console.log("collectWifiStats Network Error");
				reject();
			}
		}
		else
		{
			reject();
		}
	});
}

/**
* Function to collect Call Statistics from API inside a Promise function.
* <p>
* The function will be used to collect parameters falling under "Voice Activity" profile.
* <p>
* Parameters: NumberOfCalls, Outgoind Calls, Incoming Calls.
* <p>
*
* @name collectCallStats
*
* @function
*/
function collectCallStats()
{
	//Get stores
	//Read Voice Category into temporary object
	//Append new data to Voice temporary object
	voice_global.NumberOfCalls = call_count;
	voice_global.OutgoingCalls = outgoing_count;
	voice_global.IncomingCalls = incoming_count;

	//Getting current time and date	
	var length;
	length = voice_global.coll_time.length;
	//getGeolocation( "VOICE", length);
	voice_global.coll_time[length] = getTimeStamp();
	voice_global.date = getDateStamp();


}


var geo_flag = 0;
/**
* Collect Geolocation Information inside a Promise function.
* <p>
* The function will be used to collect parameters falling under "Geo Location Statistics" profile.
* <p>
* Parameters: latitude, longitude.
* <p>
*
* @name collectGeolocation
*
* @function
*/
function collectGeolocation(){	
	return new Promise((resolve, reject) => {
		var lock = navigator.mozSettings.createLock();
		var req  = lock.get('geolocation.enabled');
		req.onsuccess = function () {
			if (req.result['geolocation.enabled'] == false) {

				jiodc_geo_enable = true;

				var res = lock.set({
					'geolocation.enabled': true
				});

				res.onsuccess = function () { 
					//console.log("turned on geolocation explicitly");
					geo_flag = 1;
					geoFindMe().then(function(data){
						resolve(data);

					});	
				}

				res.onerror = function () {
					jiodc_geo_enable = false;
					console.log("collectGeolocation An error occured, the settings remain unchanged");
					reject();
				}
			}
			else {
				//console.log("geolocation is already on");
				geoFindMe().then(function(data){
					resolve(data);

				});	
			}

		}
		
		req.onerror = function () {
			console.log("collectGeolocation An Lock error occured");
			reject();
		}
	});

}

var geo = {latitude:0, longitude:0 , gps_col:0}
/**
* Get Geo Location from API inside a Promise function.
*
* @name geoFindMe
*
* @function
*/
function geoFindMe() 
{
	return new Promise((resolve, reject) => {
		if (!navigator.geolocation){
			resolve(geo);
		}
		geo.gps_col = 0;

		function success(position) {
			//console.log("success");

			//store latitude and longitude

			geo.latitude  = position.coords.latitude;
			geo.longitude = position.coords.longitude;
			geo.gps_col = 1;

			if( geo_flag == 1)
			{
				var lock = navigator.mozSettings.createLock();
				jiodc_geo_enable = true;
				var result = lock.set({
					'geolocation.enabled': false
				});

				result.onsuccess = function () {
					geo_flag = 0;
					//console.log("turned off geolocation explicitly");
				}

				result.onerror = function () {
					geo_flag = 0;
					jiodc_geo_enable = false;
					console.log("geoFindMe An error occure while disabling, the settings remain unchanged");

				}
			}
			resolve(geo);
			//console.log("latitude "+latitude+"longitude" +longitude);

		}

		function error() 
		{
			console.log("error: Unable to retrieve your location");
			if( geo_flag == 1)
			{
				jiodc_geo_enable = true;
				var lock = navigator.mozSettings.createLock();
				var result = lock.set({
					'geolocation.enabled': false
				});

				result.onsuccess = function () {
					geo_flag = 0;
					//console.log("turned off geolocation explicitly");
				}

				result.onerror = function () {
					geo_flag = 0;
					jiodc_geo_enable = false;
					console.log("geoFindMe An error occure while disabling, the settings remain unchanged");
				}
			}
			geo.gps_col = 0;
			resolve(geo);
		}
		var options = {
			enableHighAccuracy: true,
			timeout: 120000,
			maximumAge: 0
		};
		//console.log("Locating...");

		//console.log("geolocation.getCurrentPosition");
		navigator.geolocation.getCurrentPosition(success, error, options);
	});
}

function collectDeviceSpecificInfo()
{
    //build_number
	var lock = navigator.mozSettings.createLock();
	var req_build  = lock.get('deviceinfo.build_number');
	var build_number;

	req_build.onsuccess = function () {
		build_number = req_build.result['deviceinfo.build_number'];
		soft_global = build_number;
	}

	req_build.onerror = function () {
		soft_global = "";
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}

	//hardware Info
	var lock = navigator.mozSettings.createLock();
	var req_hard  = lock.get('deviceinfo.product_model'); //'deviceinfo.hardware'
	var hardware;

	req_hard.onsuccess = function () {
		hardware = req_hard.result['deviceinfo.product_model'];
		model_global = hardware;
	}

	req_hard.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}

	// os_name
	var lock = navigator.mozSettings.createLock();
	var req_os  = lock.get('deviceinfo.os');
	var os;

	req_os.onsuccess = function () {
		os = req_os.result['deviceinfo.os'];
	}

	req_os.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}

	//platform_build_id
	var lock = navigator.mozSettings.createLock();
	var req_plt_build  = lock.get('deviceinfo.platform_build_id');
	var platformId;

	req_plt_build.onsuccess = function () {
		platformId = req_plt_build.result['deviceinfo.platform_build_id'];
	}

	req_plt_build.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}

	//platform_version
	var lock = navigator.mozSettings.createLock();
	var req_ver  = lock.get('deviceinfo.platform_version');
	var platform_ver;

	req_ver.onsuccess = function () {
		platform_ver = req_ver.result['deviceinfo.platform_version'];
	}

	req_ver.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}

		//firmware_revision
	var lock = navigator.mozSettings.createLock();
	var req_firm  = lock.get('deviceinfo.firmware_revision');
	var firmware;

	req_firm.onsuccess = function () {
		firmware = req_firm.result['deviceinfo.firmware_revision'];
	}

	req_firm.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}
		
	//Device hash_ID
	var lock = navigator.mozSettings.createLock();
	var req_device  = lock.get('deviceinfo.hash_id');
	var deviceID;

	req_device.onsuccess = function () {
		deviceID = req_device.result['deviceinfo.hash_id'];
		//console.log(deviceID);
	}

	req_device.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}
	
	//software
	var lock = navigator.mozSettings.createLock();
	var req_soft  = lock.get('deviceinfo.software');
	var soft;

	req_soft.onsuccess = function () {
		soft = req_soft.result['deviceinfo.software'];
		store_name.then(function(stores) {		
			//Read Geolocation Category into temporary object
			stores[0].get(DEVICE_INFO_DSINDEX).then(function(deviceinfo_temp) {
				//get length of elements in the array
				var length;
				length = deviceinfo_temp.os_name.length;
				//Append new data to Datausage temporary object
				deviceinfo_temp.firmware_revision = firmware;
				deviceinfo_temp.hardware_info = hardware;
				deviceinfo_temp.os_name = os;
				deviceinfo_temp.platform_build_id = platformId;
				deviceinfo_temp.platform_version = platform_ver;
				deviceinfo_temp.software = soft;
				deviceinfo_temp.device_Id = deviceID;
				deviceinfo_temp.user_agent = navigator.userAgent;
				
	
				//Write back changes made in geolocation temporary object to datastore
				stores[0].put(deviceinfo_temp, DEVICE_INFO_DSINDEX).then(function(id){});
			});
		});
	}

	req_soft.onerror = function () {
		console.log("collectDeviceSpecificInfo An Lock error occured");
	}
}

