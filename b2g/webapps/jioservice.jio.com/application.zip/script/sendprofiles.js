/**
* Function to send event data to MQTT server.
*
* @name sendEventProfileToMQTT
*
* @function
*/
function sendEventProfileToMQTT()
{

	//console.log("Number Event Types to report: "+reporting_events_remaining);
	
	if(event_buffer_global_NE.length != 0)
	{
		//console.log("reporting Network event json count: "+count_NE);
		//event_buffer_global_NE[count_NE]= '{"NC1":'+outgoing_count+','+'"NC2":'+incoming_count+'}';
		//console.log("Network_Event JSON: "+event_buffer_global_NE);
		message_NE = new Paho.MQTT.Message('['+event_buffer_global_NE+']');
		
		//message_NE.destinationName = "Testtopic/Network_Event";
		message_NE.destinationName = Network_Event_Topic;
		//message_NE.qos = 1;
		event_buffer_NE_flag = 1;
		mqtt_client.send(message_NE);
		
	}
	
	if(event_buffer_global_DE.length != 0)
	{
		//console.log("reporting Device event json count: "+count_DE);
		//console.log("Device_Event JSON: "+event_buffer_global_DE);
		message_DE = new Paho.MQTT.Message('['+event_buffer_global_DE+']');
		
		//message_DE.destinationName = "Testtopic/Device_Event";
		message_DE.destinationName = Device_Event_Topic;
		//message_DE.qos = 1;
		event_buffer_DE_flag = 1;
		mqtt_client.send(message_DE);
	}
	
	if(event_buffer_global_AE.length != 0)
	{
		//console.log("reporting Application event json count: "+count_AE);
		//console.log("Application_Event JSON: "+event_buffer_global_AE);
		
		message_AE = new Paho.MQTT.Message('['+event_buffer_global_AE+']');
		
		message_AE.destinationName = Application_Event_Topic;
		//message_AE.qos = 1;
		event_buffer_AE_flag = 1;
		mqtt_client.send(message_AE);
	}
		
	//JSON_string = '{ "d" :['+event_buffer_global+']}';
	//console.log("JSON_string: "+JSON_string);
	//create message using JSON string for Profile
	//Set the destination token name for Profile
	//message.destinationName = "iot-2/evt/Network_Info/fmt/json";
	//Send the message to MQTT server
	//console.log("Send the message to MQTT server");
	//mqtt_client.send(message);
}

/**
* Function to send event data to MQTT server.
*
* @name sendCounterProfileToMQTT
*
* @function
*/
function sendCounterProfileToMQTT()
{
	
	console.log("Inside sendCounterProfileToMQTT");

	//console.log("Number Event Types to report: "+reporting_events_remaining);
	
	if(counter_buffer_NC_has_data != 0)
	{
		//console.log("reporting Network event json count: "+count_NE);
		//event_buffer_global_NE[count_NE]= '{"NC1":'+outgoing_count+','+'"NC2":'+incoming_count+'}';
		//console.log("Network_Event JSON: "+event_buffer_global_NE);
		message_NC = new Paho.MQTT.Message('['+counter_buffer_global_NC+']');
		
		//message_NE.destinationName = "Testtopic/Network_Event";
		message_NC.destinationName = Network_Counter_Topic;
		//message_NC.qos = 1;
		counter_buffer_NC_flag = 1;
		mqtt_client.send(message_NC);
		
	}
	
	if(counter_buffer_DC_has_data != 0)
	{
		//console.log("reporting Device event json count: "+count_DE);
		//console.log("Device_Event JSON: "+event_buffer_global_DE);
		message_DC = new Paho.MQTT.Message('['+counter_buffer_global_DC+']');
		
		//message_DE.destinationName = "Testtopic/Device_Event";
		message_DC.destinationName = Device_Counter_Topic;
		//message_DC.qos = 1;
		counter_buffer_DC_flag = 1;
		mqtt_client.send(message_DC);
	}
	
	if(counter_buffer_AC_has_data != 0)
	{
		//console.log("reporting Device event json count: "+count_DE);
		//console.log("Device_Event JSON: "+event_buffer_global_DE);
		message_AC = new Paho.MQTT.Message('['+counter_buffer_global_AC+']');
		
		//message_DE.destinationName = "Testtopic/Device_Event";
		message_AC.destinationName = Application_Counter_Topic;
		//message_AC.qos = 1;
		counter_buffer_AC_flag = 1;
		mqtt_client.send(message_AC);
	}
}
