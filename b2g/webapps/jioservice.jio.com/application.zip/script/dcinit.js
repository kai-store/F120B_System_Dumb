/* File Contains all the Data Collector Profile creations and MQTT connect/retry functions */

/**
 * Record for Device Information
 * 
 * @name Category_Device_Info
 * @class
 * @param {Array} coll_time - Array for Collection Time Stamp
 * @param {Array} language - Array for language
 * @param {Array} IME - Array for IME 
 * @param {Array} firmware_revision - 
 * @param {Array} hardware_info - 
 * @param {Array} os_name - 
 * @param {Array} platform_build_id -
 * @param {Array} platform_version - 
 * @param {Array} software - 
 */
var Category_Device_Info = {firmware_revision:"", hardware_info:"", os_name:"", platform_build_id:"", platform_version:"", software:"", device_Id:"", user_agent:"" };

//Temporary varialbes used to retrieve data from data store
var deviceinfo_temp = null;

/**
 * Global variable for IMEI number (not implemented)
 * @global
 */
var imei_global = 0;
var imsi_global = 0;
var msisdn_global = 0;

/**
 * Global flag variable for wifi (To check whether wifi connected or not)
 * @global
 */
var wifiEnabled;

/**
 * MQTT connect Exponential Timer max retries.
 * <p>
 * Value = 4
 * @global
 */
var exp_timer_max = 4;
var max_retries = 0;
var mqtt_lost_retry_counter = 0; 
var max_mqtt_lost_retry_counter = 5;
/**
 * MQTT reporting interval.
 * <p>
 * Value = 4
 * @global
 */
// const reporting_time_interval = 60; //in minutes
//const reporting_time_interval = 1441;
// var reporting_time = new Date();
// reporting_time.setMinutes(reporting_time.getMinutes() + reporting_time_interval);

//1am - 4am code
var reporting_time;
var imei_extracted;

/**
 * Global variable for MQTT client
 * @global
 */
var mqtt_client = 0; 

/**
 * Global variable to check the connection status of MQTT
 * @global
 */
var mqtt_connected = 0;

/* Callback function when connection is established to MQTT Server */
function mqttOnConnect() {
	//console.log("Inside mqttOnConnect");
	/* Set connection status of MQTT to TRUE */
	console.log('connected to server');
	mqtt_connected = 1;
	max_retries = 0;
	reporting_events_remaining = 0;
	if(event_buffer_global_NE.length != 0)
	{
		reporting_events_remaining++;
	}
	if(event_buffer_global_DE.length != 0)
	{
		reporting_events_remaining++;	
	}
	if(event_buffer_global_AE.length != 0)
	{
		reporting_events_remaining++;		
	}
	if(counter_buffer_NC_has_data != 0)
	{
		reporting_events_remaining++;
	}
	if(counter_buffer_DC_has_data != 0)
	{
		reporting_events_remaining++;	
	}
	if(counter_buffer_AC_has_data != 0)
	{
		reporting_events_remaining++;	
	}

	/* Sending the collected data set for all the events */	
	sendEventProfileToMQTT();


	if(counter_buffer_NC_has_data != 0 || counter_buffer_NC_has_data != 0 || counter_buffer_AC_has_data != 0)
		sendCounterProfileToMQTT();

}

/* Callback function when the connection attempt to MQTT server fails */
function mqttOnConnectFail(e) {
	//console.log("Inside mqttOnConnectFail");
	/* Set connection status of MQTT to FALSE */
	mqtt_connected = 0;
	console.log('Failed to connect to MQTT server: '+e.errorMessage);

	if (max_retries < exp_timer_max)
	{
		/* Creating an alarm to trigger after an exponential time to retrigger the MQTT connection and send the stored data */
		var timeout = (exp_timer[max_retries]);
		var mqttConnect_time = new Date();
		mqttConnect_time.setMinutes(mqttConnect_time.getMinutes() + timeout);

		var request3 = navigator.mozAlarms.add(mqttConnect_time, "ignoreTimezone", {func:"mqttConnect"});
		request3.onsuccess = function () {
			console.log("The alarm for function mqttConnect has been re-scheduled");
		};
		max_retries++;
	}
	else
	{
		console.log("mqtt connect max retries done");
		max_retries = 0;
	} 	
}

/**
 * The function is called to connect with the MQTT server to send all the data information.
 * <p>
 * If there is no prior connection then it will try to establish a fresh connection with the server else it will trigger the MQTT call back function where all the data parameters to be reported will be sent.
 * <p>
 *If triggering of MQTT connection fails then this function will be called in the error event handler after a pre-defined timer expires. The timing will be increased exponentially for each retry.
 * <p>
 * This function will also be called if there is any data to be reported on MQTT connection loss
 *   
 */
function mqttConnect()
{
	if(navigator.mozWifiManager.enabled == false)
	{
		//console.log("Inside mqttConnect");
		//if(event_buffer_global_NE.length != 0 || event_buffer_global_DE.length != 0 || event_buffer_global_AE.length != 0)
		if(event_buffer_global_NE.length != 0 || event_buffer_global_DE.length != 0 || event_buffer_global_AE.length != 0 || counter_buffer_NC_has_data != 0 || counter_buffer_DC_has_data != 0 || counter_buffer_AC_has_data != 0)
		{
			
			if (mqtt_connected == 0)
			{	
				//console.log("Calling mqtt_client.connect");
				if (mqtt_client)
				{
					mqtt_client.connect({onFailure:mqttOnConnectFail, onSuccess:mqttOnConnect, userName: user_name, password: user_password, useSSL : true});
				}
				else
				{
					console.log("mqtt_client not constructed");
				}
					
			}
			else
			{
				//console.log("Calling mqttOnConnect");
				mqttOnConnect();
			}
			
		}
	}
	else
	{
		max_retries = 0;
		console.log("wifi is enabled , Mqtt is not connecting");
	}
}

/* Callback function when the connection to MQTT server breaks */
function mqttOnConnectionLost(responseObject) {
	//console.log("Inside mqttOnConnectionLost");
	
	/* Set connection status of MQTT to FALSE */
	mqtt_connected = 0;
	if (responseObject.errorCode !== 0) {
		console.log("onConnectionLost:" + responseObject.errorMessage);
		/* Reattempt to connect to MQTT server */
		if(mqtt_lost_retry_counter < max_mqtt_lost_retry_counter)
		{
			mqttConnect();
			mqtt_lost_retry_counter++;
		}
		else
		{
			console.log("mqttOnConnectionLost max retries done");
			mqtt_lost_retry_counter = 0;
		}
	}
	else
	{
		mqtt_lost_retry_counter = 0;
	}
}

/* Callback function when the message is delivered successfully to MQTT server */
function mqttMsgDelivered(delivered_payload)
{

	//console.log("Inside mqttMsgDelivered");
 /* Reset the global buffer containing all stored data */
 if(delivered_payload._getDestinationName() == Network_Event_Topic)
 {
	event_buffer_global_NE = []; 
	count_NE = 0;
	//event_buffer_NE_flag = 0;
	console.log("Network Event Message delivered");
	reporting_events_remaining--;
 }
 
  if(delivered_payload._getDestinationName() == Device_Event_Topic)
 {
	event_buffer_global_DE = []; 
	count_DE = 0;
	//event_buffer_DE_flag = 0;
	console.log("Device Event Message delivered");
	reporting_events_remaining--;
 }
 
  if(delivered_payload._getDestinationName() == Application_Event_Topic)
 {
	event_buffer_global_AE = []; 
	count_AE = 0;
	//event_buffer_AE_flag = 0;
	console.log("Application Event Message delivered");
	reporting_events_remaining--;
 }
 
  if(delivered_payload._getDestinationName() == Network_Counter_Topic)
 {
	counter_buffer_global_NC = []; 
	count_NC = 0;
	//counter_buffer_NC_flag = 0;
	counter_buffer_NC_has_data = 0;
	console.log("Network Count Message delivered");
	outgoing_count = 0;
	incoming_count = 0;
	reporting_events_remaining--;
 }
 
  if(delivered_payload._getDestinationName() == Device_Counter_Topic)
 {
	counter_buffer_global_DC = []; 
	count_DC = 0;
	//counter_buffer_DC_flag = 0;
	counter_buffer_DC_has_data = 0;
	console.log("Device Count Message delivered");
	reporting_events_remaining--;
 }
 
   if(delivered_payload._getDestinationName() == Application_Counter_Topic)
 {
	counter_buffer_global_AC = []; 
	count_AC = 0;
	//counter_buffer_AC_flag = 0;
	counter_buffer_AC_has_data = 0;
	console.log("Application Count Message delivered");
	reporting_events_remaining--;
 }
	if(reporting_events_remaining == 0)
	{
		
		setTimeout(function(){ myDisconnectfunction() }, 1000);
	}
}

function myDisconnectfunction()
{
	console.log("All events reported calling disconnect");
	mqtt_client.disconnect();
}

/**
* The function creates alarms to report the collected data set for different events happened between 2 consecutive reporting periods.
*
* @name reportingAlarm
*
* @function
*/

function reportingAlarm() {
	//console.log("Inside Reporting Alarm");
	updateConfig(config_from_server,1);
	reporting_ongoing_flag = 1;
	
	reportingEventFunction().then(function(){
		reportingCounterFunction().then(function(){
			if(max_retries == 0)
			{
				mqttConnect();
			}
			else
			{
				console.log("reportingAlarm retry on going , so not connecting");
			}
			//updateConfigFromServer();
			//updateConfigFromFile();
		});
		reporting_ongoing_flag = 0;
	});
}

//Global variable Initializing function
function initGlobalVariable(){

	MQTTServer_IP = init_config_settings["Upload characteristics"].MQTTServer_IP;
	Port_No = init_config_settings["Upload characteristics"].MQTT_port;
	user_name = init_config_settings["Upload characteristics"].Username;
	user_password = init_config_settings["Upload characteristics"].Password;
	Network_Event_Topic = init_config_settings["Upload characteristics"].Network_Event_Topic;
	Device_Event_Topic = init_config_settings["Upload characteristics"].Device_Event_Topic;
	Application_Event_Topic = init_config_settings["Upload characteristics"].Application_Event_Topic;
	Network_Counter_Topic = init_config_settings["Upload characteristics"].Network_Counter_Topic;
	Device_Counter_Topic = init_config_settings["Upload characteristics"].Device_Counter_Topic;
	Application_Counter_Topic = init_config_settings["Upload characteristics"].Application_Counter_Topic;

	DC_enable_config = init_config_settings.DC_enable;
	CD_config = init_config_settings.CD;
	ND_config = init_config_settings.ND;
	NE_config = init_config_settings.NE;
	NC_config = init_config_settings.NC;
	DD_config = init_config_settings.DD;
	DE_config = init_config_settings.DE;
	DC_config = init_config_settings.DC;
	AD_config = init_config_settings.AD;
	AE_config = init_config_settings.AE;
}
/**
* Initialization Function for Data Collector.
* <p>
* Data Store is reset.
* <p>
* Basic Timer Initialization

* @name init
*
* @function
*/
function init()
{
	console.log("Initializing Data Collector Profiles");

	/* Remove all pending alarms during the initialization */	
	var request = navigator.mozAlarms.getAll();

	request.onsuccess = function () {
		this.result.forEach(function(alarm) {
			navigator.mozAlarms.remove(alarm.id);
		});
	}

	store_name.then(function(stores) {
		stores[0].put(Category_Device_Info, DEVICE_INFO_DSINDEX).then(function(id) {});
	});
	
	/* Data store initialization */
	store_name.then(function(stores) {
		datastore_lock = 1;
		var config_settings1,config_settings2, current_datastore_version;
		var crc32_gen,crc32_gen1,crc32_gen2;
		var crc32_ds1, crc32_ds2;
		
		//stores[0].clear().then(function() {
		//	console.log('Store Cleared successfully');
		//});
		
		stores[0].get(PRIVACY_KEY_INDEX).then(function(tempKey) {
			if (tempKey == undefined)
			{
				setTimeout(function(){ getPrivacyKey();}, 60000);
			}
			else
			{
				 lyfPrivacyKey_global = tempKey;
			}
		});
		
		//DSIndex code for wifi
		if (navigator.mozWifiManager.enabled == true)
		{
			console.log("wifi ON ");
			if (navigator.mozWifiManager.connection.status == "disconnected")
			{
				console.log("wifi ON disconnected");
					store_name.then(function(stores) {
						stores[0].put(0, WIFI_STATUS_DSINDEX).then(function(wifi) {
						});
					});
			}
			else if (navigator.mozWifiManager.connection.status == "connected")
			{
				console.log("wifi ON connected");
					 store_name.then(function(stores) {
						stores[0].put(1, WIFI_STATUS_DSINDEX).then(function(wifi) {
						});
					});
			}
			else
			{
				console.log("No Network On wifi");
			}
		}
		else {
			console.log("wifi OFF ");
			store_name.then(function(stores) {
				stores[0].put(0, WIFI_STATUS_DSINDEX).then(function(wifi) {
				});
			});
		}
		
		
		stores[0].get(DATASTORE_VERSION_DSINDEX).then(function(current_datastore_version) {
		   if ((current_datastore_version == undefined) || (current_datastore_version != Datastore_version_fromconfig))
		   {
			    console.log("Updating Datastore");
				//console.log(init_config_settings);
				//console.log("config_settings1 initialized: "+init_config_settings);
				stores[0].put(init_config_settings, CONFIG_SETTING1_DSINDEX).then(function(id){});
				stores[0].put(init_config_settings, CONFIG_SETTING2_DSINDEX).then(function(id){});
				crc32_gen = crc32(JSON.stringify(init_config_settings));
				//console.log("Init CRC generated: "+crc32_gen);
				stores[0].put(crc32_gen, CONFIG_CRC1_DSINDEX).then(function(id){});
				stores[0].put(crc32_gen, CONFIG_CRC2_DSINDEX).then(function(id){});
                stores[0].put(Datastore_version_fromconfig, DATASTORE_VERSION_DSINDEX).then(function(id){});
				updateConfig(init_config_settings,0);
		   }
			else
			{
				//console.log("config_settings1 available: "+config_settings1);
				stores[0].get(CONFIG_SETTING1_DSINDEX).then(function(config_settings1) {
				stores[0].get(CONFIG_CRC1_DSINDEX).then(function(crc32_ds1) {
					crc32_gen1 = crc32(JSON.stringify(config_settings1));
					if(crc32_gen1 == crc32_ds1)
					{
						//console.log("1st CRC matches 1st record");
						updateConfig(config_settings1,0);
					}
					else
					{
						stores[0].get(CONFIG_CRC2_DSINDEX).then(function(crc32_ds2) {
							if(crc32_gen1 == crc32_ds2)
							{
								//console.log("2nd CRC match 1st record");
								updateConfig(config_settings1,0);
							}
							else
							{
								stores[0].get(CONFIG_SETTING2_DSINDEX).then(function(config_settings2) {
									crc32_gen2 = crc32(JSON.stringify(config_settings2));
									if(crc32_gen2 == crc32_ds1)
									{
										//console.log("1st CRC matches 2nd record");
										updateConfig(config_settings2,0);
									}
									else
									{
										if(crc32_gen2 == crc32_ds2)
										{
											//console.log("2nd CRC match 2nd record");
											updateConfig(config_settings2,0);
										}
										else
										{
											//console.log("no CRC record match using Init settings");
											stores[0].put(init_config_settings, CONFIG_SETTING1_DSINDEX).then(function(id){});
											stores[0].put(init_config_settings, CONFIG_SETTING2_DSINDEX).then(function(id){});
											crc32_gen = crc32(JSON.stringify(init_config_settings));
											stores[0].put(crc32_gen, CONFIG_CRC1_DSINDEX).then(function(id){});
											stores[0].put(crc32_gen, CONFIG_CRC2_DSINDEX).then(function(id){});
											updateConfig(init_config_settings,0);
										}
										
									}
								});
							}
						});
					}
				});
			  });	
				
			}
		});
		stores[0].get(NETWORK_COUNTER_DSINDEX).then(function(buffer) {
			if (buffer == undefined)
			{
				stores[0].put(init_Network_Count_Buffer, NETWORK_COUNTER_DSINDEX).then(function(id){});
			}
			else
			{
				incoming_count = buffer["NC2"];
				outgoing_count = buffer["NC1"];
			}
		});
		stores[0].get(DEVICE_COUNTER_DSINDEX).then(function(buffer) {
			if (buffer == undefined)
			{
				stores[0].put(init_Device_Count_Buffer, DEVICE_COUNTER_DSINDEX).then(function(id){});
			}
			else
			{
				buffer["DC1"] = buffer["DC1"] + 1;
				stores[0].put(buffer, DEVICE_COUNTER_DSINDEX).then(function(id){});
				console.log("Reboot recorded");
			}
		});
		stores[0].get(APPLICATION_COUNTER_DSINDEX).then(function(buffer) {
			if (buffer == undefined)
			{
				stores[0].put(init_Application_Count_Buffer, APPLICATION_COUNTER_DSINDEX).then(function(id){});
			}
		});
			
		stores[0].get(BUFFER_DATA_DSINDEX).then(function(buffer_data_indicies) {
			if (buffer_data_indicies == undefined)
			{

				//console.log(init_buffer_data_indicies);
				stores[0].put(init_buffer_data_indicies, BUFFER_DATA_DSINDEX).then(function(id){});
			}
			else
			{
				//console.log("buffer_data_indicies available: "+buffer_data_indicies);
			}
			datastore_lock = 0;
		});
	});
	Call_listen();
}

/**
* Fill the data conter parameters.
* @name initCommonDataCounters
*
* @function
*/
function initCommonDataCounters()
{
	store_name.then(function(stores) {
		datastore_lock = 1;
		stores[0].get(NETWORK_COUNTER_DSINDEX).then(function(buffer) {
				buffer["DI1"] = imei_global;
				buffer["DI2"] = imsi_global;
				buffer["DI3"] = msisdn_global;
				buffer["DI4"] = model_global;
				buffer["DI5"] = soft_global;					
				init_Network_Count_Buffer["DI1"] = imei_global;
				init_Network_Count_Buffer["DI2"] = imsi_global;
				init_Network_Count_Buffer["DI3"] = msisdn_global;
				init_Network_Count_Buffer["DI4"] = model_global;
				init_Network_Count_Buffer["DI5"] = soft_global;
				stores[0].put(buffer, NETWORK_COUNTER_DSINDEX).then(function(id){});		
		});
		stores[0].get(DEVICE_COUNTER_DSINDEX).then(function(buffer) {
				buffer["DI1"] = imei_global;
				buffer["DI2"] = imsi_global;
				buffer["DI3"] = msisdn_global;
				buffer["DI4"] = model_global;
				buffer["DI5"] = soft_global;
				init_Device_Count_Buffer["DI1"] = imei_global;
				init_Device_Count_Buffer["DI2"] = imsi_global;
				init_Device_Count_Buffer["DI3"] = msisdn_global;
				init_Device_Count_Buffer["DI4"] = model_global;
				init_Device_Count_Buffer["DI5"] = soft_global;
				stores[0].put(buffer, DEVICE_COUNTER_DSINDEX).then(function(id){
					datastore_lock = 0;
				});
		});
	});

}

/**
* Update event and data flag configuration.
* @name updateConfig
*
* @function
*/
function updateConfig(config_settings, system_boot)
{
	let update_mqtt_flag = 0;
	


	if(lyfPrivacyKey_global == true)
	{
		if(DC_enable_config != config_settings["DC_enable"])
		{
			DC_enable_config = config_settings["DC_enable"];
			//console.log("DC_enable_config: "+DC_enable_config);
			enable_lwzcompression = (DC_enable_config & 0x02);
		}
	}
	else
	{
		DC_enable_config = 0;
	}
	
	if(system_boot == 0)
	{
		config_from_server = config_settings;
		update_mqtt_flag = 1;
		
		if((DC_enable_config & 0x01) != 0)
		{
			
			/*
			var request2 = navigator.mozAlarms.add(reporting_time, "ignoreTimezone", {func:"reportingAlarm"});
			request2.onsuccess = function () {
				console.log("The reportingAlarm has been scheduled at " + reporting_time);
			};
			*/
		
			
			//1am - 4am code
			var req_imei = navigator.mozMobileConnections[0].getDeviceIdentities();
			req_imei.onsuccess = function() 
			{
				var imei = req_imei.result.imei;
				var start_time = config_settings["Upload characteristics"]["Pseudo random time"][0];
				var duration_secs = (config_settings["Upload characteristics"]["Pseudo random time"][1] - start_time) * 3600;
				imei_extracted = imei.substring(9);
				//console.log('imei_extracted: '+imei_extracted);
				reporting_time = new Date();
				reporting_time.setDate(reporting_time.getDate() + 1);
				reporting_time.setHours(start_time);
				reporting_time.setMinutes(0);
				if(Number(imei_extracted) < duration_secs)
				{
					reporting_time.setSeconds(Number(imei_extracted));
				}
				else
				{
					reporting_time.setSeconds(Number(imei_extracted) % duration_secs);
				}
				var request2 = navigator.mozAlarms.add(reporting_time, "ignoreTimezone", {func:"reportingAlarm"});
				request2.onsuccess = function () 
				{
					console.log("The alarm for reportingAlarm has been scheduled at " + reporting_time);
				};

			}
		}
					
	}
	else
	{
		
		if((DC_enable_config & 0x01) != 0)
		{
			
			/*
			reporting_time = new Date();
			reporting_time.setMinutes(reporting_time.getMinutes() + reporting_time_interval);
		
			var request2 = navigator.mozAlarms.add(reporting_time, "ignoreTimezone", {func:"reportingAlarm"});
			request2.onsuccess = function () {
				console.log("The reportingAlarm has been re-scheduled at " + reporting_time);
			};
		
			*/
		
			//1am - 4am code
			var start_time = config_settings["Upload characteristics"]["Pseudo random time"][0];
			var duration_secs = (config_settings["Upload characteristics"]["Pseudo random time"][1] - start_time) * 3600;
			reporting_time = new Date();
			reporting_time.setDate(reporting_time.getDate() + 1);
			reporting_time.setHours(start_time);
			reporting_time.setMinutes(0);
			if(Number(imei_extracted) < duration_secs)
			{
				reporting_time.setSeconds(Number(imei_extracted));
			}
			else
			{
				reporting_time.setSeconds(Number(imei_extracted) % duration_secs);
			}

			var request2 = navigator.mozAlarms.add(reporting_time, "ignoreTimezone", {func:"reportingAlarm"});
			request2.onsuccess = function () 
			{
				console.log("The alarm for reportingAlarm has been re-scheduled at " + reporting_time);
			};
		}
		
	}
	

	if(CD_config != config_settings["CD"])
	{
		CD_config = config_settings["CD"];
		//console.log("CD_config: "+CD_config);
	}
	if(ND_config != config_settings["ND"])
	{
		ND_config = config_settings["ND"];
		//console.log("ND_config: "+ND_config);
	}
	if(NE_config != config_settings["NE"])
	{
		NE_config = config_settings["NE"];
		//console.log("NE_config: "+NE_config);
	}
	if(NC_config != config_settings["NC"])
	{
		NC_config = config_settings["NC"];
		//console.log("NC_config: "+NC_config);
	}
	if(DD_config != config_settings["DD"])
	{
		DD_config = config_settings["DD"];
		//console.log("DD_config: "+DD_config);
	}
	if(DE_config != config_settings["DE"])
	{
		DE_config = config_settings["DE"];
		//console.log("DE_config: "+DE_config);
	}
	if(DC_config != config_settings["DC"])
	{
		DC_config = config_settings["DC"];
		//console.log("DC_config: "+DC_config);
	}
	if(AD_config != config_settings["AD"])
	{
		AD_config = config_settings["AD"];
		//console.log("AD_config: "+AD_config);
	}
	if(AE_config != config_settings["AE"])
	{
		AE_config = config_settings["AE"];
		//console.log("AE_config: "+AE_config);
	}
	
	
	if (MQTTServer_IP != config_settings["Upload characteristics"]["MQTTServer_IP"])
	{	
		MQTTServer_IP = config_settings["Upload characteristics"]["MQTTServer_IP"];
		update_mqtt_flag = 1;
	}
	if (Port_No != config_settings["Upload characteristics"]["MQTT_port"])
	{	
		Port_No = config_settings["Upload characteristics"]["MQTT_port"];
		update_mqtt_flag = 1;
	}
/* 	if (clientID != config_settings["Upload characteristics"]["Client ID"])
	{	
		clientID = config_settings["Upload characteristics"]["Client ID"];
		update_mqtt_flag = 1;
	} */
	if (Network_Event_Topic != config_settings["Upload characteristics"]["Network_Event_Topic"])
	{	
		Network_Event_Topic = config_settings["Upload characteristics"]["Network_Event_Topic"];
	}
	if (Device_Event_Topic != config_settings["Upload characteristics"]["Device_Event_Topic"])
	{	
		Device_Event_Topic = config_settings["Upload characteristics"]["Device_Event_Topic"];
	}
	if (Application_Event_Topic != config_settings["Upload characteristics"]["Application_Event_Topic"])
	{	
		Application_Event_Topic = config_settings["Upload characteristics"]["Application_Event_Topic"];
	}
	if (Network_Counter_Topic != config_settings["Upload characteristics"]["Network_Counter_Topic"])
	{	
		Network_Counter_Topic = config_settings["Upload characteristics"]["Network_Counter_Topic"];
	}
	if (Device_Counter_Topic != config_settings["Upload characteristics"]["Device_Counter_Topic"])
	{	
		Device_Counter_Topic = config_settings["Upload characteristics"]["Device_Counter_Topic"];
	}
	if (Application_Counter_Topic != config_settings["Upload characteristics"]["Application_Counter_Topic"])
	{	
		Application_Counter_Topic = config_settings["Upload characteristics"]["Application_Counter_Topic"];
	}
	
	if(system_boot != 0)
	{
		if(update_mqtt_flag == 1)
		{
			/* Creating the new MQTT client instance */
			clientID = imei_global;	
			mqtt_client = new Paho.MQTT.Client(MQTTServer_IP, Number(Port_No), clientID);
				
			/* Function assignment on MQTT Server Connection Lost */
			mqtt_client.onConnectionLost = mqttOnConnectionLost;
			/* Function assignment on MQTT Server when a message is delivered successfully */
			mqtt_client.onMessageDelivered = mqttMsgDelivered;
			update_mqtt_flag = 0;
		}
	}

}

function mqttLinkEst()
{
			/* Creating the new MQTT client instance */	
		console.log("mqttLinkEst: Creating the new MQTT client instance");
		clientID = imei_global;
		mqtt_client = new Paho.MQTT.Client(MQTTServer_IP, Number(Port_No), clientID);
			
		/* Function assignment on MQTT Server Connection Lost */
		mqtt_client.onConnectionLost = mqttOnConnectionLost;
		/* Function assignment on MQTT Server when a message is delivered successfully */
		mqtt_client.onMessageDelivered = mqttMsgDelivered;
}

function updateConfigToDS(config_settings){
	
	store_name.then(function(stores) {	
		stores[0].put(config_settings, CONFIG_SETTING1_DSINDEX).then(function(id){});
		stores[0].put(config_settings, CONFIG_SETTING2_DSINDEX).then(function(id){});
		var crc32_gen = crc32(JSON.stringify(config_settings));
		console.log("CRC generated: "+crc32_gen);
		stores[0].put(crc32_gen, CONFIG_CRC1_DSINDEX).then(function(id){});
		stores[0].put(crc32_gen, CONFIG_CRC2_DSINDEX).then(function(id){});
		console.log("Configuration Updated to Data Store");
	});
}
