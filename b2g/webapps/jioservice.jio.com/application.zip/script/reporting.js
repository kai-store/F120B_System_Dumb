/**
 * Data Store Lock flag 
 * @global
 */
var datastore_lock = 0;

/**
* Function to generate a delay using Promise function.
* <p>
* The function is called when multiple events try to access the datastore simultaneously. The function delays the datastore access if an event is already accessing the datastore
*
* @name delayPromise
*
* @function
*/
function delayPromise(duration) {
	return new Promise(function(resolve, reject){
		setTimeout(function(){
			resolve();
		}, duration)
	});
}

/**
* Function to write event data to buffer.
*
* @name writeEventBufferData
*
* @function
*/
function writeEventBufferData(event_type,data)
{
	return new Promise(function(resolve, reject) {
		if(datastore_lock == 1)
		{
			delayPromise(5000).then(function(){
				writeEventBufferData(event_type,data).then(function(){
					resolve();
				});
			});
		}
		else
		{
			
			datastore_lock = 1;
			
			store_name.then(function(stores) {
					stores[0].get(BUFFER_DATA_DSINDEX).then(function(buffer_data_indicies) {
						stores[0].put(data, buffer_data_indicies.current_add).then(function(id){
							//console.log("current address: "+buffer_data_indicies.current_add);
							//console.log("read address: "+buffer_data_indicies.read_add);
							
							buffer_data_indicies.current_add++;
							
							if(buffer_data_indicies.current_add > buffer_data_indicies.end_add)
							{
								buffer_data_indicies.current_add = buffer_data_indicies.start_add;
							}
							
							if(reporting_ongoing_flag == 0)
							{
								if(buffer_data_indicies.current_add < buffer_data_indicies.read_add)
								{
									if((buffer_data_indicies.read_add - buffer_data_indicies.current_add) < reporting_threshold)
									{
										reporting_ongoing_flag = 1;
										//console.log("calling reporting for type 2");
										delayPromise(2000).then(function(){
											reportingEventFunction().then(function(){
												if(max_retries == 0)
												{
													mqttConnect();
												}
												reporting_ongoing_flag = 0;
											});
										});
									}
								}
								else if(((buffer_data_indicies.read_add + buffer_data_indicies.end_add - buffer_data_indicies.start_add) - buffer_data_indicies.current_add) < reporting_threshold)
								{
									reporting_ongoing_flag = 1;
									//console.log("calling reporting for type 3");
									delayPromise(2000).then(function(){
										reportingEventFunction().then(function(){
											if(max_retries == 0)
											{
												mqttConnect();
											}
											reporting_ongoing_flag = 0;
										});
									});
								}
							}
							stores[0].put(buffer_data_indicies, BUFFER_DATA_DSINDEX).then(function(id){
								datastore_lock = 0;
								resolve();

							});
						});
					});
			});
		}

	});

}

/**
* Function to write event data to buffer.
*
* @name writeCounterBufferData
*
* @function
*/
function writeCounterBufferData(event_type,field,data)
{
	return new Promise(function(resolve, reject) {
		if(datastore_lock == 1)
		{
			delayPromise(5000).then(function(){
				writeCounterBufferData(event_type,data).then(function(){
					resolve();
				});
			});
		}
		else
		{
			
			datastore_lock = 1;
			var BUFFER_TO_USE;
			
			if(event_type == "NC")
				BUFFER_TO_USE = NETWORK_COUNTER_DSINDEX;
			else if(event_type == "DC")
				BUFFER_TO_USE = DEVICE_COUNTER_DSINDEX;
			else
				BUFFER_TO_USE = APPLICATION_COUNTER_DSINDEX;
			
			store_name.then(function(stores) {
					stores[0].get(BUFFER_TO_USE).then(function(count_buffer) {
						count_buffer[field] = data;
						stores[0].put(count_buffer, BUFFER_TO_USE).then(function(id){
							datastore_lock = 0;		
							resolve();													
						});
					});
			});
		}
	});

}

/**
* Function to read event data to buffer during reporting.
*
* @name reportingEventFunction
*
* @function
*/
function reportingEventFunction()
{
	return new Promise(function(resolve, reject) {
		if(datastore_lock == 1)
		{
			/* If the datastore is already being in use then delay the reporting function be 2 Secs */
			delayPromise(2000).then(function(){
				reportingEventFunction().then(function(){
					resolve();
				});
			});
		}
		else
		{
			var json_tmp;
			var name_str;
			datastore_lock = 1;
			store_name.then(function(stores) {
				stores[0].get(BUFFER_DATA_DSINDEX).then(function(buffer_data_indicies) {
					if(buffer_data_indicies.read_add <= buffer_data_indicies.current_add){
						var temp_add = buffer_data_indicies.current_add;                                                        
					}
					else{
						var temp_add = buffer_data_indicies.current_add + buffer_data_indicies.end_add - buffer_data_indicies.start_add + 1; 
					}
					if(buffer_data_indicies.read_add != buffer_data_indicies.current_add)
					{
						for( var i = buffer_data_indicies.read_add; i < temp_add; i++){
							
							var temp_add1 = i;
							if (i > buffer_data_indicies.end_add)
							{
								temp_add1 = (i % buffer_data_indicies.end_add) + buffer_data_indicies.start_add - 1 ;
							}
													
							stores[0].get(temp_add1).then(function(temp_event_data){
								json_tmp = JSON.parse(temp_event_data);
								name_str = json_tmp["Name"];
								if("NE" == name_str.slice(0,2))
								{
									if( count_NE > global_buffer_size){
										count_NE = global_buffer_size;
										event_buffer_global_NE.shift();
									}
									//console.log("Network Event");
									event_buffer_global_NE[count_NE] = temp_event_data;
									count_NE++;
									
								}
								else if("DE" == name_str.slice(0,2))
								{
									if( count_DE > global_buffer_size){
										count_DE = global_buffer_size;
										event_buffer_global_DE.shift();
									}
									//console.log("Device Event");
									event_buffer_global_DE[count_DE] = temp_event_data;
									count_DE++;
									
								}
								else if("AE" == name_str.slice(0,2))
								{
									if( count_AE > global_buffer_size){
										count_AE = global_buffer_size;
										event_buffer_global_AE.shift();
									}
									//console.log("Application Event");
									event_buffer_global_AE[count_AE] = temp_event_data;
									count_AE++;
									
								}
								else
									console.log("Undefined Event");
							});
						}
					}
					if(buffer_data_indicies.read_add <= buffer_data_indicies.current_add)
					{
						buffer_data_indicies.read_add = temp_add;                                                        
					}
					else
					{
						buffer_data_indicies.read_add = (temp_add % buffer_data_indicies.end_add)+buffer_data_indicies.start_add-1;
					}
					stores[0].put(buffer_data_indicies, BUFFER_DATA_DSINDEX).then(function(){
						datastore_lock = 0;
						resolve();
					});
				});
			});                           
		}
	});
}

/**
* Function to read event data to buffer during reporting.
*
* @name reportingCounterFunction
*
* @function
*/
function reportingCounterFunction()
{
	console.log("Inside reportingCounterFunction");
	return new Promise(function(resolve, reject) {
		if(datastore_lock == 1)
		{
			/* If the datastore is already being in use then delay the reporting function be 2 Secs */
			delayPromise(2000).then(function(){
				reportingCounterFunction().then(function(){
					resolve();
				});
			});
		}
		else
		{
			datastore_lock = 1;
			store_name.then(function(stores) {
				stores[0].get(NETWORK_COUNTER_DSINDEX).then(function(network_count_buffer) {
					counter_buffer_global_NC = JSON.stringify(network_count_buffer);
					counter_buffer_NC_has_data = 1;
					stores[0].put(init_Network_Count_Buffer, NETWORK_COUNTER_DSINDEX).then(function(id){});
				});
				stores[0].get(DEVICE_COUNTER_DSINDEX).then(function(device_count_buffer) {
					counter_buffer_global_DC = JSON.stringify(device_count_buffer);
					counter_buffer_DC_has_data = 1;
					stores[0].put(init_Device_Count_Buffer, DEVICE_COUNTER_DSINDEX).then(function(id){});
				});
				stores[0].get(APPLICATION_COUNTER_DSINDEX).then(function(application_count_buffer) {
					counter_buffer_global_AC = JSON.stringify(application_count_buffer);
					counter_buffer_AC_has_data = 0;
					stores[0].put(init_Application_Count_Buffer, APPLICATION_COUNTER_DSINDEX).then(function(id){});
					datastore_lock = 0;
					resolve();
				});
			});
		}
	});
}

/*
function reqListener () {
   console.log("Configuration Recieved from server:");
   var raw_config_from_server = this.responseText;
   console.log(config_from_server);
   config_from_server = JSON.parse(raw_config_from_server);
   updateConfig(config_from_server,1);
   updateConfigToDS(config_from_server);
   write_file(config_from_server);
}

function reqTimeout () {
   console.log("Configuration server Timeout:");
   updateConfig(config_from_server,1);
}

function updateConfigFromServer(){
	var oReq = new XMLHttpRequest();
	oReq.timeout = 3000; // 3 second timeout
	oReq.addEventListener("load", reqListener);
	oReq.addEventListener("timeout", reqTimeout);
	oReq.open("GET", "http://www.example.com");
	oReq.send();
	
}

function updateConfigFromFile(){
	var raw_config_from_server;
	read_file().then(function(raw_config_from_server){
		if(config_from_server != JSON.parse(raw_config_from_server))
		{
			console.log(raw_config_from_server);
			//updateConfigToDS(config_from_server);
		}
		config_from_server = JSON.parse(raw_config_from_server);
	  //updateConfigToDS(config_from_server);
		updateConfig(config_from_server,1);
		
    }).catch(function(){
	  updateConfig(config_from_server,1);
  });
}

var sdcard = navigator.getDeviceStorage("sdcard");
var request;

function read_file(){

  return new Promise((resolve, reject) => {

    console.log("Inside Read File");

    //var read_string;
    request = sdcard.get("config_settings.txt");

    //console.log(request);

    request.onsuccess = function (e) {
      //console.log(e);
      var reader = new FileReader();
      reader.readAsText(e.target.result);
      //console.log(reader);
      function onloadend(e) {
        read_string = e.target.result;
        //console.log(read_string);
        resolve(read_string);
      };
      reader.onloadend = onloadend.bind(this);
      var name = this.result.name;
      //console.log('File "' + name + '" successfully retrieved from the sdcard storage area');
    }

    request.onerror = function () {
      console.log('Unable to get the file: ' + this.error);
      reject(this.error);
    }
  });
}
*/
