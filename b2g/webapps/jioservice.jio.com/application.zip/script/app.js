console.log("Jio Service Launched");

//open handle to jio data Store
var store_name = navigator.getDataStores('jio_service_store');
var retryCount = 0;
var expireTimer = [60, 180, 300];
var expireTimerMax = 3;
var retryBoolIMEI = 0;

//Initialize SSO engine
function startSSO() {
	//console.log("startSSO started");
	var config = new Config();
	config.app_name ='JioAdvApp';
	initSsoConfig(config);
}

function generateICCID() {
	let iccMgr = navigator.mozIccManager;
	let iccId = iccMgr && iccMgr.iccIds[0]; // index 0 for slot 1
	
	if (iccId) 
	{
		store_name.then(function(stores) {
			stores[0].get(ICCID_DSINDEX).then(function(tempIccid) {
				if (tempIccid == undefined)
				{
					//generates IMSI from SSO
					generateIMSI();
				}
				else if ( tempIccid != iccId)
				{
					//generates IMSI from SSO
					generateIMSI();
				}
				else
				{
					//console.log("imsi, iccid, msisdn and adid is already generated");
					stores[0].get(IMSI_DSINDEX).then(function(tempImsi) {
						imsi_global = tempImsi;				
					});
					stores[0].get(MSISDN_DSINDEX).then(function(tempMsisdn) {						
						// msisdn_global = tempMsisdn;
						msisdn_global = 0;
					});
				}
			});
		});
	}
	else
	{
		console.log("sim not ready");
	}
}

function getIMSIFromSSO(){
	//console.log("getIMSIFromSSO started");
	var spinner = false;
	
	forceZlaRequest(function(successResponse){ 
						var KEY_IMSI = successResponse.KEY_DEVICE_INFO.KEY_IMSI;
						var KEY_MSISDN = successResponse.KEY_DEVICE_INFO.KEY_MSISDN;
						//console.log("startSSOEngine Success imsi is: "+KEY_IMSI);    
						//console.log("startSSOEngine Success msisdn is: "+KEY_MSISDN);						
						var imsi = KEY_IMSI.toString(); 
						var msisdn = KEY_MSISDN.toString();						
						//console.log("new imsi is: " + imsi);
						//console.log("new msisdn is: " + msisdn);
						
						storeAdIdImsiMsisdn(imsi, msisdn);
					},
					function(errorResponse){
						//console.log("startSSOEngine errorResponse"+errorResponse);    
						if (retryCount == expireTimerMax)
						{ 
							//console.log("generateIMSI max retries done");
							return;
						}
				
						setTimeout(generateIMSI, (expireTimer[retryCount] * 1000));
						retryCount++;

						//console.log("generateIMSI retry started");
					},spinner);
}

//gets imsi from sso
function generateIMSI() {
    //variable to check network connection
	var dataState  = navigator.mozMobileConnections[0].data.state;

	if (dataState == 'registered')
	{
		getIMSIFromSSO();
	}
	else if (dataState != 'registered')
	{
		if (retryCount == expireTimerMax)
	    { 
            //console.log("generateIMSI max retries done");
	        return;
        }
		
		setTimeout(generateIMSI, (expireTimer[retryCount] * 1000));
		retryCount++;

		//console.log("generateIMSI retry started");
	}
	else
	{
		//console.log("imsi and adid is already generated");
	}
}

//stores adid and imsi recevied from sso to jio data store
function storeAdIdImsiMsisdn(imsiToStore, msisdnToStore) {
	var adid = Imsi2AdId(imsiToStore);
	let iccMgr = navigator.mozIccManager;
	let iccId = iccMgr && iccMgr.iccIds[0]; // index 0 for slot 1
	//console.log(iccId);
	
	if (adid.length > 0 && msisdnToStore.length > 0)
	{
		imsi_global = imsiToStore;
		//msisdn_global = msisdnToStore;
		msisdn_global = 0;
		store_name.then(function(stores) {
			stores[0].put(iccId, ICCID_DSINDEX).then(function(index) {
			});

			stores[0].put(adid, ADID_DSINDEX).then(function(index) {
			});
			
			stores[0].put(imsiToStore, IMSI_DSINDEX).then(function(index) {
			});

			stores[0].put(msisdnToStore, MSISDN_DSINDEX).then(function(index) {
			});
		});
	}
	else
	{
		if (retryCount == expireTimerMax)
	    { 
            console.log("generateIMSI max retries done");
	        return;
        }
		
		setTimeout(generateIMSI, (expireTimer[retryCount] * 1000));
		retryCount++;

		//console.log("generateIMSI retry started");
	}
}

/**
* Function to check if valid IMEI is present in the data store.
* If there is no valid IMEI stored in the data store then it will call a function to read the IMEI.
*
* @name generateIMEI
*
* @function
*/
function generateIMEI() {
	store_name.then(function(stores) {
		stores[0].get(IMEI_DSINDEX).then(function(imei) {
			if (imei == undefined)
			{
				getIMEI();
			}
			else
			{
				imei_global = imei;
			}
		});
	});
}

/**
* Function to Read the device IMEI from API and store it in data store.
* The function also creates the unique ID for the MQTT client using the part of IMEI.
*
* @name getIMEI
*
* @function
*/
function getIMEI()
{
	//console.log("Generating IMEI");
	var req = navigator.mozMobileConnections[0].getDeviceIdentities(); 

	req.onsuccess = function() {
		var imei = req.result.imei;
		
		if(((imei == 0)||(imei==undefined))&&(retryBoolIMEI == 0))
		{
			setTimeout(getIMEI, 15000);
			retryBoolIMEI = 1;
		}
		else
		{
		//var clientID1 = clientID + imei.substring(11);
		imei_global = imei;
		
		store_name.then(function(stores) {
			stores[0].add(imei, IMEI_DSINDEX).then(function(index) {
			});
		});
		}
	};

	req.onerror = function() {
		if (retryBoolIMEI == 0)
		{
			setTimeout(getIMEI, 15000);
			retryBoolIMEI = 1;
		}
		console.log("failed to get imei");
	}
}



//Initilization function call to Data Store
store_name.then(function(stores) {
	stores[0].get(DATASTORE_VERSION_DSINDEX).then(function(current_datastore_version) {
				console.log("Got datastore index");
			   if (current_datastore_version == undefined)
			   {
				    console.log("datastore index undefined");
					stores[0].clear().then(function(success) {
						console.log("datastore cleared");
						//Initializing global variable
						initGlobalVariable();

						//Initialize SSO engine
						startSSO();

						//generates ICCID
						generateICCID();

						//call to generate imei and create mqtt client object
						generateIMEI();
						
						init();
					});
			   }
			   else
			   {
					console.log("datastore index defined");
					//Initializing global variable
					initGlobalVariable();

					//Initialize SSO engine
					startSSO();

					//generates ICCID
					generateICCID();

					//call to generate imei and create mqtt client object
					generateIMEI();
					
					init();
			   }
	})
});


//Collect DeviceSpecificInfo at init
setTimeout(function(){ collectDeviceSpecificInfo();}, 60000);

setTimeout(function(){initCommonDataCounters();}, 90000);

setTimeout(mqttLinkEst, 45000);

var AdvId;

function reverse(a) {
	return a.split("").reverse().join("");
}

function AdId2ImsiId(a) {
	for(var b="",c=3;32>=c;c+=3)20==c&&(c+=2),9!=c&&16!=c&&25!=c||c++,b+=a.substr(c-1,1);a=reverse(b);
	//console.log("IMSI After = "+a)
}

function generateUUID() {
	var a=(new Date).getTime();"undefined"!==typeof performance&&"function"===typeof performance.now&&(a+=performance.now());return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(b){var c=(a+16*Math.random())%16|0;a=Math.floor(a/16);return("x"===b?c:c&3|8).toString(16)})
}

function replaceAt(a,b,c) {
	return a.substr(0,b)+c+a.substr(b+c.length);
}

function Imsi2AdId(Imsi) { 
	var a=Imsi.substr(6,9),a=reverse(a),b=generateUUID(),b=replaceAt(b,2,a.substr(0,1)),b=replaceAt(b,5,a.substr(1,1)),b=replaceAt(b,9,a.substr(2,1)),b=replaceAt(b,12,a.substr(3,1)),b=replaceAt(b,16,a.substr(4,1)),b=replaceAt(b,21,a.substr(5,1)),b=replaceAt(b,25,a.substr(6,1)),b=replaceAt(b,28,a.substr(7,1));
	AdvId=a=b=replaceAt(b,31,a.substr(8,1));
	//console.log("Advertisement id:"+AdvId);
	return AdvId;
}
