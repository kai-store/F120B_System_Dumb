/**
* Network data collection.
* <p>
* The function will be used to collect parameters falling under "Network Data" profile.
* <p>
* Parameters: 
* <p>
*    event_type: The event occured for which the data set is being collected
* <p>
*    CD_config: Common Data set to be collected
* <p>
*    ND_config: Network Data set to be collected
* <p>
*
* @name networkDataCollector
*
* @function
*/
function networkDataCollector(event_type, CD_config, ND_config)
{
	//CD_config masks
	const IMEI_mask               = 0x00000002;
	const IMSI_mask               = 0x00000004;
	const MSISDN_mask             = 0x00000008;
	const Model_mask              = 0x00000010;
	const SW_ver_mask             = 0x00000020;
	const PLMN_mask               = 0x00000040;
	const TAC_mask                = 0x00000080;
	const Cell_ID_mask            = 0x00000100;
	const PCI_mask                = 0x00000200;
	const Latitude_mask           = 0x00000400;
	const Longitude_mask          = 0x00000800;
	const Gps_Col_mask			  = 0x00001000;
	const Battery_Level_mask      = 0x00002000;  
	const CPU_mask                = 0x00004000;  
	const RAM_mask                = 0x00008000;  
	const Device_Temperature_mask = 0x00010000;
	const Battery_Temp_mask       = 0x00020000;								  

	//ND_config masks
	const RSRP_mask                     = 0x00000001;
	const RSRQ_mask                     = 0x00000002;
	const SINR_mask                     = 0x00000004;
	const CQI_mask                      = 0x00000008;
	const Rank_Indicator_mask           = 0x00000010;
	const Band_Indication_mask          = 0x00000020;
	const EARFCN_mask                   = 0x00000040;
	const Service_Indication_mask       = 0x00000080;
	const RRC_Connection_cause_mask     = 0x00000100;
	const RRC_Release_cause_mask        = 0x00000200;
	const RACH_Max_Power_mask           = 0x00000400;
	const BLER_mask                     = 0x00000800;
	const TA_mask                       = 0x00001000;
	const Tx_Power_mask                 = 0x00002000;
	const Neighbor_cell_info_mask       = 0x00004000;
	const Roaming_state_mask            = 0x00008000;
	const ATTACH_fail_causes_mask       = 0x00010000;
	const TAC_update_failures_mask      = 0x00020000;
	const EPS_Details_mask              = 0x00040000;
	const OTDOA_mask                    = 0x00080000;
	const SIP_registration_Status_mask  = 0x00100000;
	const SIP_Session_End_mask          = 0x00200000;
	const Mute_related_parameters_mask  = 0x00400000;
	const RTP_Packet_Loss_mask          = 0x00800000;
	const Rx_bytes_mask                 = 0x01000000;
	const Tx_bytes_mask                 = 0x02000000;
	


	var json = '';
	
	json+= '"Name":"'+event_type+'",';

	var time_data = getDateStamp();
	json+= '"DT":"'+time_data+'",';

	if((CD_config & IMEI_mask)!=0 ){
		json+= '"DI1":'+imei_global+',';
	}
	if((CD_config & IMSI_mask)!=0 ){
		json+= '"DI2":'+imsi_global+',';
	}
	if((CD_config & MSISDN_mask)!=0 ){
		json+= '"DI3":'+msisdn_global+',';
	}	
	if((CD_config & Model_mask)!=0 ){
		json+= '"DI4":"'+model_global+'",';
	}
	if((CD_config & SW_ver_mask)!=0 ){
		json+= '"DI5":"'+soft_global+'",';
	}

	var dataState =  navigator.mozMobileConnections[0].data.state;
	//Add the data state to the coverage temporary object
	if (dataState  == 'registered' ) {
		if((CD_config & PLMN_mask)!=0){
			//Calculate PLMN using MCC and MNC
			var MNC_calc = navigator.mozMobileConnections[0].data.network.mnc;
			var MCC_calc = navigator.mozMobileConnections[0].data.network.mcc;
			

			//Append new data to the location temporary object
			let PLMN = MCC_calc + MNC_calc;
			json+= '"LI1":'+PLMN+',';
		}
		
		if((CD_config & TAC_mask)!=0){
			TAC = navigator.mozMobileConnections[0].data.cell.gsmLocationAreaCode;
			json+= '"LI2":'+TAC+',';
		}
		if( CD_config & Cell_ID_mask){
			let Cell_Id = navigator.mozMobileConnections[0].data.cell.gsmCellId;
			json+= '"LI3":'+Cell_Id+',';	
		}
		if((ND_config & Roaming_state_mask)!=0){
				var dataRoaming  = navigator.mozMobileConnections[0].data.roaming;
				var voiceRoaming = navigator.mozMobileConnections[0].voice.roaming;
				if(dataRoaming || voiceRoaming)
				{
					json+= '"NI1":false,';
				}else
				{	
					json+= '"NI1":true,';
				}	
		}
		if((ND_config & Service_Indication_mask)!=0){
			json+= '"RI8":true,';
		}
				
	}
	else
	{
		if((ND_config & Service_Indication_mask)!=0){
			json+= '"RI8":false,';
		}
	}
	if((CD_config & Battery_Level_mask)!=0){
		let Battery = Math.round(navigator.battery.level*100);
		json+= '"SI1":'+Battery+',';
	}

	//Append new data to the coverage temporary object
	if((ND_config & RSRP_mask)!=0 )
	{	
		var Avg_RSRP;
		if(navigator.mozMobileConnections[0].data.signalStrength == 0)
		{
			Avg_RSRP = navigator.mozMobileConnections[0].data.signalStrength;
		}
		else
		{
			if(navigator.mozMobileConnections[0].data.signalStrength > 0)
            {
                Avg_RSRP = 140 - navigator.mozMobileConnections[0].data.signalStrength;
            }
            else
            {
				Avg_RSRP = 140 + navigator.mozMobileConnections[0].data.signalStrength;
            }
		}
		
	if (Avg_RSRP < 0)
	{
		Avg_RSRP = 0;
	}
	if (Avg_RSRP > 97)
	{
		Avg_RSRP = 97;
	}
		json+= '"RI1":'+Avg_RSRP+',';
	}
	
	/*if(event_type == "NE4")
	{
		if((ND_config & SIP_Session_End_mask)!=0){
			var reason = disconnect_reasonarray.indexOf(disconnect_reason);
			//console.log("disconnect reason: "+disconnect_reason);
			json+= '"VI2":'+reason+',';
			disconnect_reason = [];
		}
	}*/
	
	//console.log("networkDataCollector json static data: "+json);
	
	//promises
	dummyPromise().then(function(){
		return new Promise((resolve, reject) => {
			var rxByte_temp = (ND_config & Rx_bytes_mask );
			var txByte_temp = (ND_config & Tx_bytes_mask);
			if( (rxByte_temp | txByte_temp)!=0){
				collectDataUsageStats().then(function(data){
					if((rxByte_temp)!=0){
						json+= '"HI1":'+data.rxBytes+',';
					}
					if((txByte_temp)!=0){
						json+= '"HI2":'+data.txBytes+',';
					}
					resolve();
				}).catch(function(){
					//console.log("this is catch for data_usage");     
					resolve();
				})
			}else{
				resolve();
			}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {
			var Lat_temp = (CD_config & Latitude_mask );
			var Long_temp = (CD_config & Longitude_mask);
			var GPS_available_temp = (CD_config & Gps_Col_mask);
			if( (Lat_temp | Long_temp)!=0){
				collectGeolocation().then(function(data){
					if((Lat_temp)!=0){
						json+= '"LI5":'+data.latitude+',';
					}
					if((Long_temp)!=0){
						json+= '"LI6":'+data.longitude+',';
					}
					if((GPS_available_temp)!=0){
						json+= '"LI7":'+data.gps_col+',';
					}					
					resolve();
				}).catch(function(){
					console.log("this is catch for geo");
					resolve();
				})
			}else{
				if((GPS_available_temp)!=0){
					json+= '"LI7":0,';
					}
				resolve();
			}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {

			json="{"+json.slice(0,-1)+"}";
			//console.log(json)
			writeEventBufferData(event_type, json);
			resolve();
		})
	});

}

/**
* Network data collection Socket.
* <p>
* The function will be used to collect parameters falling under "Network Data" profile.
* <p>
* Parameters: 
* <p>
*    event_type: The event occured for which the data set is being collected
* <p>
*    CD_config: Common Data set to be collected
* <p>
*    ND_config: Network Data set to be collected
* <p>
*
* @name networkDataCollectorSocket
*
* @function
*/
function networkDataCollectorSocket(event_type, CD_config, Data_NW)
{
	//CD_config masks
	const IMEI_mask               = 0x00000002;
	const IMSI_mask               = 0x00000004;
	const MSISDN_mask             = 0x00000008;
	const Model_mask              = 0x00000010;
	const SW_ver_mask             = 0x00000020;
	const PLMN_mask               = 0x00000040;
	const TAC_mask                = 0x00000080;
	const Cell_ID_mask            = 0x00000100;
	const PCI_mask                = 0x00000200;
	const Latitude_mask           = 0x00000400;
	const Longitude_mask          = 0x00000800;
	const Gps_Col_mask			  = 0x00001000;
	const Battery_Level_mask      = 0x00002000;  
	const CPU_mask                = 0x00004000;  
	const RAM_mask                = 0x00008000;  
	const Device_Temperature_mask = 0x00010000;
	const Battery_Temp_mask       = 0x00020000;								  

	//ND_config masks
	const RSRP_mask                     = 0x00000001;
	const RSRQ_mask                     = 0x00000002;
	const SINR_mask                     = 0x00000004;
	const CQI_mask                      = 0x00000008;
	const Rank_Indicator_mask           = 0x00000010;
	const Band_Indication_mask          = 0x00000020;
	const EARFCN_mask                   = 0x00000040;
	const Service_Indication_mask       = 0x00000080;
	const RRC_Connection_cause_mask     = 0x00000100;
	const RRC_Release_cause_mask        = 0x00000200;
	const RACH_Max_Power_mask           = 0x00000400;
	const BLER_mask                     = 0x00000800;
	const TA_mask                       = 0x00001000;
	const Tx_Power_mask                 = 0x00002000;
	const Neighbor_cell_info_mask       = 0x00004000;
	const Roaming_state_mask            = 0x00008000;
	const ATTACH_fail_causes_mask       = 0x00010000;
	const TAC_update_failures_mask      = 0x00020000;
	const EPS_Details_mask              = 0x00040000;
	const OTDOA_mask                    = 0x00080000;
	const SIP_registration_Status_mask  = 0x00100000;
	const SIP_Session_End_mask          = 0x00200000;
	const Mute_related_parameters_mask  = 0x00400000;
	const RTP_Packet_Loss_mask          = 0x00800000;
	const Rx_bytes_mask                 = 0x01000000;
	const Tx_bytes_mask                 = 0x02000000;
	


	var json = '';
	
	json+= '"Name":"'+event_type+'",';

	var time_data = getDateStamp();
	json+= '"DT":"'+time_data+'",';

	if((CD_config & IMEI_mask)!=0 ){
		json+= '"DI1":'+imei_global+',';
	}
	if((CD_config & IMSI_mask)!=0 ){
		json+= '"DI2":'+imsi_global+',';
	}
	if((CD_config & MSISDN_mask)!=0 ){
		json+= '"DI3":'+msisdn_global+',';
	}	
	if((CD_config & Model_mask)!=0 ){
		json+= '"DI4":"'+model_global+'",';
	}
	if((CD_config & SW_ver_mask)!=0 ){
		json+= '"DI5":"'+soft_global+'",';
	}

	var dataState =  navigator.mozMobileConnections[0].data.state;
	//Add the data state to the coverage temporary object
	if (dataState  == 'registered' ) {
		if((CD_config & PLMN_mask)!=0){
			//Calculate PLMN using MCC and MNC
			var MNC_calc = navigator.mozMobileConnections[0].data.network.mnc;
			var MCC_calc = navigator.mozMobileConnections[0].data.network.mcc;
			

			//Append new data to the location temporary object
			let PLMN = MCC_calc + MNC_calc;
			json+= '"LI1":'+PLMN+',';
		}
		
		if((CD_config & TAC_mask)!=0){
			TAC = navigator.mozMobileConnections[0].data.cell.gsmLocationAreaCode;
			json+= '"LI2":'+TAC+',';
		}
		if( CD_config & Cell_ID_mask){
			let Cell_Id = navigator.mozMobileConnections[0].data.cell.gsmCellId;
			json+= '"LI3":'+Cell_Id+',';	
		}
		/*
		if((ND_config & Roaming_state_mask)!=0){
				var dataRoaming  = navigator.mozMobileConnections[0].data.roaming;
				var voiceRoaming = navigator.mozMobileConnections[0].voice.roaming;
				if(dataRoaming || voiceRoaming)
				{
					json+= '"NI1":1,';
				}else
				{	
					json+= '"NI1":0,';
				}	
		}
		*/
	}
	if((CD_config & Battery_Level_mask)!=0){
		let Battery = Math.round(navigator.battery.level*100);
		json+= '"SI1":'+Battery+',';
	}

	/*if(event_type == "NE4")
	{
		if((ND_config & SIP_Session_End_mask)!=0){
			var reason = disconnect_reasonarray.indexOf(disconnect_reason);
			//console.log("disconnect reason: "+disconnect_reason);
			json+= '"VI2":'+reason+',';
			disconnect_reason = [];
		}
	}*/
	
	//console.log("networkDataCollector json static data: "+json);
	
	//promises
	dummyPromise().then(function(){
		return new Promise((resolve, reject) => {
			var rxByte_temp = (ND_config & Rx_bytes_mask );
			var txByte_temp = (ND_config & Tx_bytes_mask);
			if( (rxByte_temp | txByte_temp)!=0){
				collectDataUsageStats().then(function(data){
					if((rxByte_temp)!=0){
						json+= '"HI1":'+data.rxBytes+',';
					}
					if((txByte_temp)!=0){
						json+= '"HI2":'+data.txBytes+',';
					}
					resolve();
				}).catch(function(){
					//console.log("this is catch for data_usage");     
					resolve();
				})
			}else{
				resolve();
			}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {
			var Lat_temp = (CD_config & Latitude_mask );
			var Long_temp = (CD_config & Longitude_mask);
			var GPS_available_temp = (CD_config & Gps_Col_mask);
			if( (Lat_temp | Long_temp)!=0){
				if( (event_type == 'NE2') || (event_type == 'NE4') || (event_type == 'NE5'))
				{
					collectGeolocation().then(function(data){
						if((Lat_temp)!=0){
							json+= '"LI5":'+data.latitude+',';
						}
						if((Long_temp)!=0){
							json+= '"LI6":'+data.longitude+',';
						}
						if((GPS_available_temp)!=0){
							json+= '"LI7":'+data.gps_col+',';
						}					
						resolve();
					}).catch(function(){
						console.log("this is catch for geo");
						resolve();
					})
				}else{
					if((GPS_available_temp)!=0){
						json+= '"LI7":0,';
					}
					resolve();
				}
			}else{
				if((GPS_available_temp)!=0){
					json+= '"LI7":0,';
					}
				resolve();
			}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {

			var data_tmp = JSON.stringify(Data_NW);
			console.log("Data Tmp: "+data_tmp);
			data_tmp = data_tmp.slice(1,-1);
			//json = json + data_tmp;
			//json="{"+json.slice(0,-1)+"}";
			json="{"+json + data_tmp+"}";
			console.log("New JSON: "+json)
			writeEventBufferData(event_type, json);
			resolve();
		})
	});

}

/**
* Device data collection.
* <p>
* The function will be used to collect parameters falling under "Device Data" profile.
* <p>
* Parameters: 
* <p>
*    event_type: The event occured for which the data set is being collected
* <p>
*    CD_config: Common Data set to be collected
* <p>
*    DD_config: Network Data set to be collected
* <p>
*
* @name DeviceDataCollector
*
* @function
*/
function DeviceDataCollector(event_type, CD_config, DD_config)
{

	//CD_config masks
	const IMEI_mask               = 0x00000002;
	const IMSI_mask               = 0x00000004;
	const MSISDN_mask             = 0x00000008;
	const Model_mask              = 0x00000010;
	const SW_ver_mask             = 0x00000020;
	const PLMN_mask               = 0x00000040;
	const TAC_mask                = 0x00000080;
	const Cell_ID_mask            = 0x00000100;
	const PCI_mask                = 0x00000200;
	const Latitude_mask           = 0x00000400;
	const Longitude_mask          = 0x00000800;
	const Gps_Col_mask			  = 0x00001000;
	const Battery_Level_mask      = 0x00002000;  
	const CPU_mask                = 0x00004000;  
	const RAM_mask                = 0x00008000;  
	const Device_Temperature_mask = 0x00010000;
	const Battery_Temp_mask       = 0x00020000;								  

	//DD_config masks
	const Device_active_mask     = 0x00000001
	const IME_mask               = 0x00000002
	const lang_mask              = 0x00000004
	const Browser_history_mask   = 0x00000008
	const ssid_mask              = 0x00000010
	const relSignalStrength_mask = 0x00000020
	const w_rxBytes_mask         = 0x00000040
	const w_txBytes_mask         = 0x00000080


	var json = '';

	json+= '"Name":"'+event_type+'",';
	
	var time_data = getDateStamp();
	json+= '"DT":"'+time_data+'",';

	if((CD_config & IMEI_mask)!=0 ){
		json+= '"DI1":'+imei_global+',';
	}
	if((CD_config & IMSI_mask)!=0 ){
		json+= '"DI2":'+imsi_global+',';
	}
	if((CD_config & MSISDN_mask)!=0 ){
		json+= '"DI3":'+msisdn_global+',';
	}	
	if((CD_config & Model_mask)!=0 ){
		json+= '"DI4":"'+model_global+'",';
	}
	if((CD_config & SW_ver_mask)!=0 ){
		json+= '"DI5":"'+soft_global+'",';
	}

	var dataState =  navigator.mozMobileConnections[0].data.state;
	//Add the data state to the coverage temporary object
	if (dataState  == 'registered' ) {
		if((CD_config & PLMN_mask)!=0){
			//Calculate PLMN using MCC and MNC
			var MNC_calc = navigator.mozMobileConnections[0].data.network.mnc;
			var MCC_calc = navigator.mozMobileConnections[0].data.network.mcc;
			//Append new data to the location temporary object
			let PLMN = MCC_calc + MNC_calc;
			json+= '"LI1":'+PLMN+',';
		}
		if((CD_config & TAC_mask)!=0){
			let TAC = navigator.mozMobileConnections[0].data.cell.gsmLocationAreaCode;
			json+= '"LI2":'+TAC+',';
		}
		if( CD_config & Cell_ID_mask){
			let Cell_Id = navigator.mozMobileConnections[0].data.cell.gsmCellId;
			json+= '"LI3":'+Cell_Id+',';
		}
	}
	if((CD_config & Battery_Level_mask)!=0){
		let Battery = Math.round(navigator.battery.level*100);
		json+= '"SI1":'+Battery+',';
	}
	//console.log("DeviceDataCollector json static data: "+json);
	//promises
	dummyPromise().then(function(){
		return new Promise((resolve, reject) => {
			if((DD_config & IME_mask)!=0){
				collectIME().then(function(data){
					json+= '"PI2":"'+data+'",';
					resolve();					
				}).catch(function(){
					console.log("this is catch for IME"); 
					resolve();
				})
			}else{
				resolve();
			}
		});			
	}).then(function(){
		return new Promise((resolve, reject) => {
			if((DD_config & lang_mask)!=0){
				collectLanguage().then(function(data){
					json+= '"PI3":"'+data+'",';
					resolve();					
				}).catch(function(){
					console.log("this is catch for Lang");     
					resolve();
				})
			}else{
				resolve();
			}
		});			
	}).then(function(){
		return new Promise((resolve, reject) => {
			var rxByte_temp = (DD_config & w_rxBytes_mask);
			var txByte_temp = (DD_config & w_txBytes_mask);
			var ssid_temp = (DD_config & ssid_mask);
			var relSig_temp = (DD_config & relSignalStrength_mask);
			if( (rxByte_temp | txByte_temp | ssid_temp |relSig_temp)!=0){
				collectWifiStats().then(function(data){
					if((ssid_temp)!=0){
						json+= '"WI1":"'+data.ssid+'",';
					}
					if((relSig_temp)!=0){
						json+= '"WI2":'+data.relSignalStrength+',';
					}
					if((rxByte_temp)!=0){
						json+= '"WI3":'+data.rxBytes+',';
					}
					if((txByte_temp)!=0){
						json+= '"WI4":'+data.txBytes+',';
					}
					resolve();
				}).catch(function(){
					//console.log("this is catch for wifi_usage");
					resolve();
				})
			}
			else
			{
				resolve();
			}
		});			
	}).then(function(){
		return new Promise((resolve, reject) => {
			if(event_type != "DE15")
			{
				var Lat_temp = (CD_config & Latitude_mask );
				var Long_temp = (CD_config & Longitude_mask);
				var GPS_available_temp = (CD_config & Gps_Col_mask);
				if( (Lat_temp | Long_temp)!=0){
					collectGeolocation().then(function(data){
						if((Lat_temp)!=0){
							json+= '"LI5":'+data.latitude+',';
						}
						if((Long_temp)!=0){
							json+= '"LI6":'+data.longitude+',';
						}
						if((GPS_available_temp)!=0){
						json+= '"LI7":'+data.gps_col+',';
						}
						resolve();
					}).catch(function(){
						console.log("this is catch for geo");     
						resolve();
					})
				}else{
					if((GPS_available_temp)!=0){
					json+= '"LI7":0,';
					}
					resolve();
				}
			}else{
					if((GPS_available_temp)!=0){
					json+= '"LI7":0,';
					}
					resolve();
				}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {
			json='{'+json.slice(0,-1)+'}';
			//console.log(json)
			writeEventBufferData(event_type, json).then(function(){
				
			})
		})
	});
}

/**
* Application data collection.
* <p>
* The function will be used to collect parameters falling under "Application Data" profile.
* <p>
* Parameters: 
* <p>
*    event_type: The event occured for which the data set is being collected
* <p>
*    CD_config: Common Data set to be collected
* <p>
*    AD_config: Application Data set to be collected
* <p>
*
* @name AppDataCollector
*
* @function
*/
function AppDataCollector(event_type, CD_config, AD_config)
{
	//CD_config masks
	const IMEI_mask               = 0x00000002;
	const IMSI_mask               = 0x00000004;
	const MSISDN_mask             = 0x00000008;
	const Model_mask              = 0x00000010;
	const SW_ver_mask             = 0x00000020;
	const PLMN_mask               = 0x00000040;
	const TAC_mask                = 0x00000080;
	const Cell_ID_mask            = 0x00000100;
	const PCI_mask                = 0x00000200;
	const Latitude_mask           = 0x00000400;
	const Longitude_mask          = 0x00000800;
	const Gps_Col_mask			  = 0x00001000;
	const Battery_Level_mask      = 0x00002000;  
	const CPU_mask                = 0x00004000;  
	const RAM_mask                = 0x00008000;  
	const Device_Temperature_mask = 0x00010000;
	const Battery_Temp_mask       = 0x00020000;								  	

	//AD_config masks
	const Apps_mask = 0x01;

	var json = '';
	
	json += '"Name":"'+event_type+'",';
	
	var time_data = getDateStamp();
	json+= '"DT":"'+time_data+'",';

	if((CD_config & IMEI_mask)!=0 ){
		json+= '"DI1":'+imei_global+',';
	}
	if((CD_config & IMSI_mask)!=0 ){
		json+= '"DI2":'+imsi_global+',';
	}
	if((CD_config & MSISDN_mask)!=0 ){
		json+= '"DI3":'+msisdn_global+',';
	}
	if((CD_config & Model_mask)!=0 ){
		json+= '"DI4":"'+model_global+'",';
	}
	if((CD_config & SW_ver_mask)!=0 ){
		json+= '"DI5":"'+soft_global+'",';
	}

	var dataState =  navigator.mozMobileConnections[0].data.state;
	//Add the data state to the coverage temporary object
	if (dataState  == 'registered' ) {
		if((CD_config & PLMN_mask)!=0){
			//Calculate PLMN using MCC and MNC
			var MNC_calc = navigator.mozMobileConnections[0].data.network.mnc;
			var MCC_calc = navigator.mozMobileConnections[0].data.network.mcc;
			//Append new data to the location temporary object
			let PLMN = MCC_calc + MNC_calc;
			json+= '"LI1":'+PLMN+',';
		}
		if((CD_config & TAC_mask)!=0){
			let TAC = navigator.mozMobileConnections[0].data.cell.gsmLocationAreaCode;
			json+= '"LI2":'+TAC+',';
		}
		if( CD_config & Cell_ID_mask){
			let Cell_Id = navigator.mozMobileConnections[0].data.cell.gsmCellId;
			json+= '"LI3":'+Cell_Id+',';
		}
	}
	if((CD_config & Battery_Level_mask)!=0){
		let Battery = Math.round(navigator.battery.level*100);
		json+= '"SI1":'+Battery+',';
	}
	if((AD_config & Apps_mask)!=0){
		if(event_type == "AE2")
		{
			json+= '"AI1":"'+installedApp_global+'",';
		}else if(event_type == "AE3"){
			json+= '"AI1":"'+uninstalledApp_global+'",';
			}
	}
	//promises

	dummyPromise().then(function(){
		return new Promise((resolve, reject) => {
			var Lat_temp = (CD_config & Latitude_mask );
			var Long_temp = (CD_config & Longitude_mask);
			var GPS_available_temp = (CD_config & Gps_Col_mask);
			if( (Lat_temp | Long_temp)!=0){
				collectGeolocation().then(function(data){
					if((Lat_temp)!=0){
						json+= '"LI5":'+data.latitude+',';
					}
					if((Long_temp)!=0){
						json+= '"LI6":'+data.longitude+',';
					}
					if((GPS_available_temp)!=0){
						json+= '"LI7":'+data.gps_col+',';
					}
					resolve();
				}).catch(function(){
					console.log("this is catch for geo");     
					resolve();
				})
			}else{
				if((GPS_available_temp)!=0){
				json+= '"LI7":0,';
				}
				resolve();
			}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {
			json="{"+json.slice(0,-1)+"}";
			//console.log(json)
			writeEventBufferData(event_type, json).then(function(){
				
			})
		})
	});
}


/**
* Application data collection.
* <p>
* The function will be used to collect parameters falling under "Application Data" profile.
* <p>
* Parameters: 
* <p>
*    event_type: The event occured for which the data set is being collected
* <p>
*    CD_config: Common Data set to be collected
* <p>
*    AD_config: Application Data set to be collected
* <p>
*
* @name AppDataCollectorObject
*
* @function
*/
function AppDataCollectorObject(event_type, CD_config, appUsageData)
{
	//CD_config masks
	const IMEI_mask               = 0x00000002;
	const IMSI_mask               = 0x00000004;
	const MSISDN_mask             = 0x00000008;
	const Model_mask              = 0x00000010;
	const SW_ver_mask             = 0x00000020;
	const PLMN_mask               = 0x00000040;
	const TAC_mask                = 0x00000080;
	const Cell_ID_mask            = 0x00000100;
	const PCI_mask                = 0x00000200;
	const Latitude_mask           = 0x00000400;
	const Longitude_mask          = 0x00000800;
	const Gps_Col_mask			  = 0x00001000;
	const Battery_Level_mask      = 0x00002000;  
	const CPU_mask                = 0x00004000;  
	const RAM_mask                = 0x00008000;  
	const Device_Temperature_mask = 0x00010000;
	const Battery_Temp_mask       = 0x00020000;								  	

	//AD_config masks
	const Apps_mask = 0x01;
	var data_name = "";
	var json = '';
	
	json += '"Name":"'+event_type+'",';
	
	if(event_type == 'AE4')
	{
	   data_name = '"AI3"';
	}
	else if (event_type == 'AE6')
	{
	   data_name = '"AI2"';
	}
	 	
	var time_data = getDateStamp();
	json+= '"DT":"'+time_data+'",';

	if((CD_config & IMEI_mask)!=0 ){
		json+= '"DI1":'+imei_global+',';
	}
	if((CD_config & IMSI_mask)!=0 ){
		json+= '"DI2":'+imsi_global+',';
	}
	if((CD_config & MSISDN_mask)!=0 ){
		json+= '"DI3":'+msisdn_global+',';
	}
	if((CD_config & Model_mask)!=0 ){
		json+= '"DI4":"'+model_global+'",';
	}
	if((CD_config & SW_ver_mask)!=0 ){
		json+= '"DI5":"'+soft_global+'",';
	}

	var dataState =  navigator.mozMobileConnections[0].data.state;
	//Add the data state to the coverage temporary object
	if (dataState  == 'registered' ) {
		if((CD_config & PLMN_mask)!=0){
			//Calculate PLMN using MCC and MNC
			var MNC_calc = navigator.mozMobileConnections[0].data.network.mnc;
			var MCC_calc = navigator.mozMobileConnections[0].data.network.mcc;
			//Append new data to the location temporary object
			let PLMN = MCC_calc + MNC_calc;
			json+= '"LI1":'+PLMN+',';
		}
		if((CD_config & TAC_mask)!=0){
			let TAC = navigator.mozMobileConnections[0].data.cell.gsmLocationAreaCode;
			json+= '"LI2":'+TAC+',';
		}
		if( CD_config & Cell_ID_mask){
			let Cell_Id = navigator.mozMobileConnections[0].data.cell.gsmCellId;
			json+= '"LI3":'+Cell_Id+',';
		}
	}
	if((CD_config & Battery_Level_mask)!=0){
		let Battery = Math.round(navigator.battery.level*100);
		json+= '"SI1":'+Battery+',';
	}
	//promises

	dummyPromise().then(function(){
		return new Promise((resolve, reject) => {
			var Lat_temp = (CD_config & Latitude_mask );
			var Long_temp = (CD_config & Longitude_mask);
			var GPS_available_temp = (CD_config & Gps_Col_mask);
			if( (Lat_temp | Long_temp)!=0){
				collectGeolocation().then(function(data){
					if((Lat_temp)!=0){
						json+= '"LI5":'+data.latitude+',';
					}
					if((Long_temp)!=0){
						json+= '"LI6":'+data.longitude+',';
					}
					if((GPS_available_temp)!=0){
						json+= '"LI7":'+data.gps_col+',';
					}
					resolve();
				}).catch(function(){
					console.log("this is catch for geo");     
					resolve();
				})
			}else{
				if((GPS_available_temp)!=0){
				json+= '"LI7":0,';
				}
				resolve();
			}
		});
	}).then(function(){
		return new Promise((resolve, reject) => {
			data_temp = JSON.stringify(appUsageData);
			json += data_name +":"+ data_temp;
			json="{"+json+"}";
			//console.log(json)
			writeEventBufferData(event_type, json).then(function(){
				
			})
		})
	});
}