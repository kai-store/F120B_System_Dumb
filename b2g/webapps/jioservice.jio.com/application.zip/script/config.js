//config.js
//paho MQTT client connection
/**
 * MQTT Server IP 
 * @global
 */
var MQTTServer_IP;

/**
 * MQTT Server Port Number 
 * @global
 */
var Port_No;


/**
 * MQTT Client User Identifier 
 * @global
 */
var clientID;

/**
 * MQTT Client User Name 
 * @global
 */
var user_name;

/**
 * MQTT Client User Password
 * @global
 */
var user_password;

/**
 * Size of Global Buffer to store event data for reporting
 * @global
 */
var global_buffer_size = 500;

/**
 * MQTT connect Exponential Timer Array.
 * <p>
 * Value = 10mins, 1hr, 4hr, 12hr
 * @global
 */
var exp_timer = [10, 60 , 240 , 720]; //24hr - [10mins, 1hr, 4hr, 12hr]
//var exp_timer = [1, 1, 1, 1];

var Network_Event_Topic;
var Device_Event_Topic;
var Application_Event_Topic;
var Network_Counter_Topic;
var Device_Counter_Topic;
var Application_Counter_Topic;

//LYF Privacy Key Global variable
var lyfPrivacyKey_global = true;

/**
 * Datastore Version Number
 * @global
 */
var Datastore_version_fromconfig = "1";



/**
 * Initial Configuration Settings
 * <p>
 * key value pair to enable or disable collection of data during event 
 * values:true/false
 * @global
 */
var init_config_settings = {
	"Login Parameters":
	{
		"URL":"www.example.com", 	    
		"Username":"test", 
		"Password":"test"   
	},			
	"Upload characteristics":
	{
		"Pseudo random time":[1, 4],
		"MQTTServer_IP":"jpdp.jpdc.jiophone.net",
		"MQTT_port":"9797",
		"Username":"jiophonedata",
		"Password":"jiophonedata@123",
		"Client ID":"testQoS1Consumer",
		"Network_Event_Topic":"jiophonedata/+/networkData",
		"Device_Event_Topic":"jiophonedata/+/deviceData",
		"Application_Event_Topic":"jiophonedata/+/appData",
		"Network_Counter_Topic":"jiophonedata/+/networkevtCounter",
		"Device_Counter_Topic":"jiophonedata/+/deviceevtCounter",
		"Application_Counter_Topic":"jiophonedata/+/appevtCounter"
	},
	"DC_enable": 0x00000001,
	"CD": 0x00003DFF,
	"ND": 0x03008081,
	"NE": 0x000003CC,
	"NC": 0x00000003,
	"DD": 0x000000F6,
	"DE": 0x00006F50,
	"DC": 0x00000001,
	"AD": 0x00000001,
	"AE": 0x00000006
};

/**
 * Global variable to check if first call after boot
 * @global
 */
var system_boot = 0;

/**
 * Global variable to store Configuration recieved from server
 * @global
 */
var config_from_server;

/**
 * Global flag to check reporting ongoing 
 * @global
 */
var reporting_ongoing_flag = 0;

/**
 * Data Store Indecies
 * @global
 */
const CONFIG_SETTING1_DSINDEX = 1;
const BUFFER_DATA_DSINDEX = 2;
const PRIVACY_KEY_INDEX = 4;
const IMEI_DSINDEX = 5;
const DEVICE_INFO_DSINDEX = 6;
const ICCID_DSINDEX = 7;
const ADID_DSINDEX = 8;
const IMSI_DSINDEX = 9;
const MSISDN_DSINDEX = 10;
const CONFIG_CRC1_DSINDEX = 11;
const NETWORK_COUNTER_DSINDEX = 12;
const DEVICE_COUNTER_DSINDEX = 13;
const CONFIG_SETTING2_DSINDEX = 14;
const APPLICATION_COUNTER_DSINDEX = 15;
const CONFIG_CRC2_DSINDEX = 17;
const WIFI_STATUS_DSINDEX = 18;
const DATASTORE_VERSION_DSINDEX = 19;
/**
 * Intial Buffer Data Indicies
 * <p>
 *structure to hold Datastore buffer status
 * <p>
 *start_add: from which index the buffer starts using the Datastore
 * <p>
 *end_add: last index usable by the buffer within the datastore
 * <p> 
 *current_add: points to the next write index of buffer
 * <p> 
 *buffer implementation is a round robin. after end_add is reached it revolves back to start_add.
 * @global
 */
var init_buffer_data_indicies = {start_add:20,end_add:520,current_add:20,read_add:20};
var init_Network_Count_Buffer = {"Name":"NC","DI1":0,"DI2":0,"DI3":0,"DI4":0,"DI5":0,"NC1":0,"NC2":0};
var init_Device_Count_Buffer = {"Name":"DC","DI1":0,"DI2":0,"DI3":0,"DI4":0,"DI5":0,"DC1":0};
var init_Application_Count_Buffer = {};

/**
 * MQTT Server Connection Status Flag 
 * @global
 */
var MQTT_disconnected = 0;

var jiodc_geo_enable = false;

var event_buffer_global_NE = [];
var event_buffer_NE_flag = 0;
var count_NE = 0;

var event_buffer_global_DE = [];
var event_buffer_DE_flag = 0;
var count_DE = 0;

var event_buffer_global_AE = [];
var event_buffer_AE_flag = 0;
var count_AE = 0;
var counter_buffer_global_NC = [];
var counter_buffer_NC_flag = 0;
var counter_buffer_NC_has_data = 0;
var count_NC = 0;

var counter_buffer_global_DC = [];
var counter_buffer_DC_flag = 0;
var counter_buffer_DC_has_data = 0;
var count_DC = 0;

var counter_buffer_global_AC = [];
var counter_buffer_AC_flag = 0;
var counter_buffer_AC_has_data = 0;
var count_AC = 0;

var DC_enable_config = 0x00000001;
var CD_config;
var ND_config;
var NE_config;
var NC_config;
var DD_config;
var DE_config;
var DC_config;
var AD_config;
var AE_config;

const NE1_mask  = 0x00000001
const NE2_mask  = 0x00000002
const NE3_mask  = 0x00000004
const NE4_mask  = 0x00000008
const NE5_mask  = 0x00000010
const NE6_mask  = 0x00000020
const NE7_mask  = 0x00000040
const NE8_mask  = 0x00000080
const NE9_mask  = 0x00000100
const NE10_mask = 0x00000200
const NE11_mask = 0x00000400
const NE12_mask = 0x00000800
const NE13_mask = 0x00001000
const NE14_mask = 0x00002000
const NE15_mask = 0x00004000
const NE16_mask = 0x00008000
const NE17_mask = 0x00010000
const NE18_mask = 0x00020000
const NE19_mask = 0x00040000
const NE20_mask = 0x00080000
const NE21_mask = 0x00100000
const NE22_mask = 0x00200000
const NE23_mask = 0x00400000
const NE24_mask = 0x00800000
const NE25_mask = 0x01000000
const NE26_mask = 0x02000000

const DE1_mask  = 0x00000001
const DE2_mask  = 0x00000002
const DE3_mask  = 0x00000004
const DE4_mask  = 0x00000008
const DE5_mask  = 0x00000010
const DE6_mask  = 0x00000020
const DE7_mask  = 0x00000040
const DE8_mask  = 0x00000080
const DE9_mask  = 0x00000100
const DE10_mask = 0x00000200
const DE11_mask = 0x00000400
const DE12_mask = 0x00000800
const DE13_mask = 0x00001000
const DE14_mask = 0x00002000
const DE15_mask = 0x00004000
const DE16_mask = 0x00008000
const DE17_mask = 0x00010000
const DE18_mask = 0x00020000
const DE19_mask = 0x00040000	

const AE1_mask  = 0x00000001
const AE2_mask  = 0x00000002
const AE3_mask  = 0x00000004
const AE4_mask  = 0x00000008
const AE5_mask  = 0x00000010
const AE6_mask  = 0x00000020
const AE7_mask  = 0x00000040

var disconnect_reasonarray = [  "BadNumber",
								"NoRouteToDestination",
								"ChannelUnacceptable",
								"OperatorDeterminedBarring",
								"NormalCallClearing",
								"Busy",
								"NoUserResponding",
								"UserAlertingNoAnswer",
								"CallRejected",
								"NumberChanged",
								"CallRejectedDestinationFeature",
								"PreEmption",
								"DestinationOutOfOrder",
								"InvalidNumberFormat",
								"FacilityRejected",
								"ResponseToStatusEnquiry",
								"Congestion",
								"NetworkOutOfOrder",
								"NetworkTempFailure",
								"SwitchingEquipCongestion",
								"AccessInfoDiscarded",
								"RequestedChannelNotAvailable",
								"ResourceUnavailable",
								"QosUnavailable",
								"RequestedFacilityNotSubscribed",
								"IncomingCallsBarredWithinCug",
								"BearerCapabilityNotAuthorized",
								"BearerCapabilityNotAvailable",
								"BearerNotImplemented",
								"ServiceNotAvailable",
								"IncomingCallExceeded",
								"RequestedFacilityNotImplemented",
								"UnrestrictedBearerNotAvailable",
								"ServiceNotImplemented",
								"InvalidTransactionId",
								"NotCugMember",
								"IncompatibleDestination",
								"InvalidTransitNetworkSelection",
								"SemanticallyIncorrectMessage",
								"InvalidMandatoryInfo",
								"MessageTypeNotImplemented",
								"MessageTypeIncompatibleProtocolState",
								"InfoElementNotImplemented",
								"ConditionalIe",
								"MessageIncompatibleProtocolState",
								"RecoveryOnTimerExpiry",
								"Protocol",
								"Interworking",
								"Barred",
								"FDNBlocked",
								"SubscriberUnknown",
								"DeviceNotAccepted",
								"ModifiedDial",
								"CdmaLockedUntilPowerCycle",
								"CdmaDrop",
								"CdmaIntercept",
								"CdmaReorder",
								"CdmaSoReject",
								"CdmaRetryOrder",
								"CdmaAcess",
								"CdmaPreempted",
								"CdmaNotEmergency",
								"CdmaAccessBlocked",
								"Unspecified"
							];
							
const reporting_threshold = 5;

var reporting_events_remaining = 0;
