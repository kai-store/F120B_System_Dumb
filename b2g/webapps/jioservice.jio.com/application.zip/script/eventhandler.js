//File Contains all the system event hanlding functions

//Global variable to store call count
var call_count = 0;
var incoming_count = 0;
var outgoing_count = 0;
var lockCount = 0;
var disconnect_reason = [];
var uninstalledApp_global;
var installedApp_global;
var incomingcall_sucess = 0;
var outgogincall_sucess = 0;


var server_socket = navigator.mozTCPSocket.listen(12345);

function Call_listen(){
	console.log("Call_listen to port 12345");
	
		server_socket.onconnect = (socket) => {
   		   console.log("Socket Connected");
		   //console.log(socket.socket);
		   socket.socket.ondata = (event) => {
		     // The received data is in event.data
			console.log("Data recieved");
			//console.log(event.data);
			var json_tmp = JSON.parse(event.data);
			var NE_name = json_tmp["Name"];
			delete json_tmp["Name"];
			delete json_tmp["DT"];
			delete json_tmp["LI2"];
			//console.log("Socket json_tmp:" + json_tmp);
			networkDataCollectorSocket(NE_name, CD_config,json_tmp);
   			}
		}
	
}

//Register for Outgoing CALL_END event
var telOutgoing = navigator.mozTelephony;
telOutgoing.addEventListener('callschanged', onCallsChanged);

function onCallsChanged() {
	var outgoingCall = telOutgoing.calls[telOutgoing.calls.length - 1];

	if (outgoingCall)	{
		outgoingCall.onconnected  = function (event) {
			outgogincall_sucess = 1;
			//console.log("outgoingCall on connect");
			if((DC_enable_config & 0x01) != 0)
			{
				call_count = call_count + 1;
				outgoing_count = outgoing_count + 1;
				writeCounterBufferData("NC","NC1",outgoing_count);
			}
			if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE3_mask) !=0) ){
				//console.log("NE3_mask enabled");
				//networkDataCollector("NE3", (CD_config & 0xFFFFF3FF) ,ND_config);
			}
			else
			{
				//console.log("NE3_mask disabled");
			}
		}
		outgoingCall.ondisconnected = function (event) {  
			//console.log("outgoingCall on disconnect");
			if (outgogincall_sucess == 1)
			{
				outgogincall_sucess = 0;
				//launchAdApp(); //TODO will be enabled in next version
			}

			if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE4_mask) !=0) ){
				//console.log("NE4_mask enabled");
				disconnect_reason = event.call.disconnectedReason;
				//networkDataCollector("NE4", CD_config ,ND_config);
			}
			else
			{
				//console.log("NE4_mask disabled");
			}
		}
	}
};

//Register for Incoming CALL_END event
var telIncoming = navigator.mozTelephony;

telIncoming.onincoming = function(event) {
	var incomingCall = event.call;

	incomingCall.onconnected  = function (event) {
		incomingcall_sucess = 1;
		//console.log("incomingCall on connect");
		if((DC_enable_config & 0x01) != 0)
		{
			call_count = call_count + 1;
			incoming_count = incoming_count + 1;
			writeCounterBufferData("NC","NC2",incoming_count);
		}
		if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE3_mask) !=0) ){
			//console.log("NE3_mask enabled");
			//networkDataCollector("NE3", (CD_config & 0xFFFFF3FF) ,ND_config);
		}
		else
		{
			//console.log("NE3_mask disabled");
		}
	}
	incomingCall.ondisconnected = function (event) {
		//console.log("incomingCall on disconnect");
		if (incomingcall_sucess == 1)
		{
			incomingcall_sucess = 0;
			//launchAdApp(); //TODO will be enabled in next version
		}
		if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE4_mask) !=0) ){
			//console.log("NE4_mask enabled");
			disconnect_reason = event.call.disconnectedReason;
			//networkDataCollector("NE4", CD_config ,ND_config);
		}
		else
		{
			//console.log("NE4_mask disabled");
		}
	}
};

//Register for SMS_RECEIVED event
navigator.mozSetMessageHandler('sms-received', function(message) {
	//message is the received object
	//console.log("SMS Received");
	//launchAdApp(); //TODO will be enabled in next version
	if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE8_mask) !=0) ){
		//console.log("NE8_mask enabled");
		networkDataCollector("NE8", (CD_config & 0xFFFFF3FF) ,ND_config);
	}
	else
	{
		//console.log("NE8_mask disabled");
	}
});

//Register for SMS_SENT event
navigator.mozSetMessageHandler('sms-sent', function(message) {
	//message is the sent object
	//console.log("SMS Sent");
	//launchAdApp(); //TODO will be enabled in next version
	if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE7_mask) !=0) ){
		//console.log("NE7_mask enabled");
		networkDataCollector("NE7", (CD_config & 0xFFFFF3FF) ,ND_config);
	}
	else
	{
		//console.log("NE7_mask disabled");
	}
});

/* Launches add application */
function launchAdApp() {
	store_name.then(function(stores) {
		stores[0].get(ADID_DSINDEX).then(function(tempAdid) {
			//console.log("add id is: " + tempAdid);

			if (tempAdid != undefined)
			{
				var url = 'app://jioads.jio.com';

				navigator.mozApps.mgmt.getAll().onsuccess = function(event) {
					var apps = event.target.result;
					apps.some((app) => app.origin === url && app.launch());
				}; 
			}
		});
	});
}

//Register Wifi Connected and Disconnected Event
navigator.mozWifiManager.onstatuschange = wifiStatusChange;
function wifiStatusChange(event) {
	if (event.status == "connected") {
		//DSIndex code
		store_name.then(function(stores) {
			stores[0].put(1, WIFI_STATUS_DSINDEX).then(function(wifi) {
			});
		});
		wifiEnabled = 1;
		//console.log("wifiEnabled");
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE11_mask) !=0) ){
			//console.log("DE11_mask enabled");
			DeviceDataCollector("DE11", CD_config, DD_config);
		}
		else
		{
			//console.log("DE11_mask disabled");
		}
	}
	else if (event.status == "disconnected") {
		wifiEnabled = 0;
		//DSIndex code
		store_name.then(function(stores) {
			stores[0].put(0, WIFI_STATUS_DSINDEX).then(function(wifi) {
			});
		});
		//console.log("wifidisabled");
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE12_mask) !=0) ){
			//console.log("DE12_mask enabled");
			DeviceDataCollector("DE12", CD_config, DD_config);
		}
		else
		{
			//console.log("DE12_mask disabled");
		}
	}

}

var previous_id = 0;
var previous_reporting = "";
var previous_mqtt = "";
//Register for alarm Event
navigator.mozSetMessageHandler("alarm", function (mozAlarm) {
                
	console.log("Alarm ID: "+mozAlarm.id+" Alarm calling " + mozAlarm.data["func"]);
	if (mozAlarm.id != previous_id) {
		previous_id = mozAlarm.id;
		if(mozAlarm.data["func"] == "reportingAlarm")
		{
			if(mozAlarm.date.toString().slice(4,21) != previous_reporting)
			{
				console.log("Call Reporting");
				previous_reporting = mozAlarm.date.toString().slice(4,21);
				reportingAlarm();
							
			}
			else
				console.log("False Reporting Alarm");

		}
		if(mozAlarm.data["func"] == "mqttConnect")
		{
			if(mozAlarm.date.toString().slice(4,21) != previous_mqtt)
			{
				console.log("Call MQTT");
				previous_mqtt = mozAlarm.date.toString().slice(4,21);
				mqttConnect();
			}
			else
				console.log("False MQTT alarm");
			
		}
	}
	else
		console.log("Duplicate Alarm ID");
});

var boot_flag = 0;

//outage code for LTE voice
var imsHandler = navigator.mozMobileConnections[0].imsHandler;
if (imsHandler) {
	imsHandler.oncapabilitychange = function capabilityChange() {
		// LTE voice status has been changed
		// To query latest status
		var capability = imsHandler.capability;
		if (capability) {
			// has LTE voice
			//console.log("oncapabilitychange has LTE voice", capability);
			if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE9_mask) !=0) ){
				//console.log("NE9_mask enabled");
				if (boot_flag == 1)
				{
					networkDataCollector("NE9", (CD_config & 0xFFFFF3FF) ,ND_config);
				}
				boot_flag = 1;				
			}
			else
			{
				//console.log("NE9_mask disabled");
			}
		} else {
			// has no LTE voice
			//console.log(" oncapabilitychange has no LTE voice", capability);
			if(((DC_enable_config & 0x01) != 0) && ((NE_config & NE10_mask) !=0) ){
				//console.log("NE10_mask enabled");
				if (boot_flag == 1)
				{
					networkDataCollector("NE10", CD_config ,ND_config);
				}				
			}
			else
			{
				//console.log("NE10_mask disabled");
			}
		}
	}
}

//Geolocation enable & disable event
function handleGeo(event) {
	
	if(jiodc_geo_enable != true)
	{
		if (event.settingValue === true) {
			//console.log("geo enabled");
			if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE14_mask) !=0) ){
				//console.log("DE14_mask enabled");
				DeviceDataCollector("DE14", (CD_config & 0xFFFFF3FF), DD_config);				
			}
			else
			{
				//console.log("DE14_mask disabled");
			}
		}
		else {
			//console.log("geo disabled");
			if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE15_mask) !=0) ){
				//console.log("DE15_mask enabled");
				DeviceDataCollector("DE15", (CD_config & 0xFFFFF3FF), DD_config);				
			}
			else
			{
				//console.log("DE15_mask disabled");
			}

		}
	}
	else
	{
		jiodc_geo_enable = false;
	}
}

navigator.mozSettings.addObserver('geolocation.enabled', handleGeo);
//navigator.mozSettings.addObserver('lockscreen.lock-message', handleScreenLock);
//navigator.mozSettings.addObserver('ril.data.enabled', handleDataConnected);

function handleScreenLock() {
	if (lockCount >= 2)
	{
		//console.log("handleScreenLock" + lockCount);
		lockCount = lockCount + 1;
		//launchAdApp();
	}
	else
	{
		//console.log("handleScreenLock" + lockCount);
		lockCount = lockCount + 1;
	}
}

function handleDataConnected(event) {
	if (event.settingValue === true) 
	{
		//console.log("handleDataConnected enabled");
		generateICCID();
	}
	else 
	{
		//console.log("handleDataConnected disabled");
	}
}


//Battery charging and discharging 
var bat = navigator.battery;
bat.addEventListener('chargingchange', batCharging);
//bat.addEventListener('levelchange', batLevel); 
function batCharging(){

var dataState =  navigator.mozMobileConnections[0].data.state;
	if( bat.charging )
	{
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE5_mask) !=0) ){
			//console.log("DE5_mask enabled");
			if (dataState  == 'registered' )
			{
				DeviceDataCollector("DE5", (CD_config & 0xFFFFF3FF), DD_config);
			}
		}
		else
		{
			//console.log("DE5_mask disabled");
		}
		//console.log("battery is connected for charging");
	}
	else
	{
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE7_mask) !=0) ){
			//console.log("DE7_mask enabled");
			if (dataState  == 'registered' )
			{
				DeviceDataCollector("DE7", (CD_config & 0xFFFFF3FF), DD_config);
			}
		}
		else
		{
			//console.log("DE7_mask disabled");
		}
		//console.log("battery is disconnected from charging");
	}
}

function batLevel(){
	//console.log("Battery level: "+ bat.level * 100 + "%");
	if( Math.round(bat.level * 100) == 100 ){
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE6_mask) !=0) ){
			//console.log("DE6_mask enabled");
			DeviceDataCollector("DE6", (CD_config & 0xFFFFF3FF), DD_config);
			
		}
		else
		{
			//console.log("DE6_mask disabled");
		}
		//console.log("battery completely charged");
	}else if( Math.round(bat.level * 100) == 5 ){
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE8_mask) !=0) ){
			//console.log("DE8_mask enabled");
			DeviceDataCollector("DE8", (CD_config & 0xFFFFF3FF), DD_config);
			
		}
		else
		{
			//console.log("DE8_mask disabled");
		}
		//console.log("battery discharged (below 5%) ");
	}
}
	//Airplane mode
navigator.mozSettings.addObserver('airplaneMode.enabled', handleAirplane_mode);
	
function handleAirplane_mode(event) {
  if (event.settingValue === true) {
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE9_mask) !=0) ){
			//console.log("DE9_mask enabled");
			DeviceDataCollector("DE9", (CD_config & 0xFFFFF3FF), DD_config);
			
		}
		else
		{
			//console.log("DE9_mask disabled");
		}
	  }
      else
	  {
		if(((DC_enable_config & 0x01) != 0) && ((DE_config & DE10_mask) !=0) ){
			//console.log("DE10_mask enabled");
			DeviceDataCollector("DE10", (CD_config & 0xFFFFF3FF), DD_config);
			
		}
		else
		{
			//console.log("DE10_mask disabled");
		}
	  }
}


//App install and uninstall

navigator.mozApps.mgmt.onuninstall = ApponUninstalled;
navigator.mozApps.mgmt.oninstall = ApponInstalled;
navigator.mozApps.mgmt.onupdate = ApponUpdate;

function ApponInstalled(data)
{
	 data.application.ondownloadsuccess = ApponDownloadSucess;         
}
function ApponUninstalled(data)
{
	// console.log(data.application.manifest.name);
	 uninstalledApp_global = data.application.manifest.name;
	 if(uninstalledApp_global == "JioDS"){
		config_from_server["DC_enable"] = 0x00000000;
		updateConfig(config_from_server,1);
		updateConfigToDS(config_from_server);
	}
	if(((DC_enable_config & 0x01) != 0) && ((AE_config & AE3_mask) !=0) ){
		//console.log("AE3_mask enabled");
		AppDataCollector("AE3", (CD_config & 0xFFFFF3FF), AD_config);
	}
	else
	{
		//console.log("AE3_mask disabled");
	}
                
}

function ApponDownloadSucess(data)
{
	installedApp_global = data.application.manifest.name; 
	if(((DC_enable_config & 0x01) != 0) && ((AE_config & AE2_mask) !=0) ){
		//console.log("AE2_mask enabled");
		AppDataCollector("AE2", (CD_config & 0xFFFFF3FF), AD_config);
	}
}

//App Upgrade event
function ApponUpdate(data)
{
	var updateApp_global = data.application.manifest.name; 
	if(updateApp_global == "JioDS"){
		console.log("JioDS App updated");
		var url = 'app://jiods.jio.com';
		
		setTimeout(function(){ JioDS_AppLaunch(url) }, 120000);
		setTimeout(function(){ jiods_store_update() }, 123000);
	}
}

//JioDS AppLaunch
function JioDS_AppLaunch(url) {
	navigator.mozApps.mgmt.getAll().onsuccess = function(event) {
		var apps = event.target.result;
		apps.some((app) => app.origin === url && app.launch());
	}; 
}

/*
//JioDS AppClose
function JioDS_AppClose(url) {
	console.log("inside appClose");
	
	navigator.mozApps.mgmt.getAll().onsuccess = function(event) {
		var apps = event.target.result;
		apps.some((app) => app.origin === url && app.close());
	}; 
}
*/

function jiods_store_update() {
	console.log("inside jiods_store_update");
	var store_jioDS = navigator.getDataStores('JioDSstore');
    if (store_jioDS)
	{
		store_jioDS.then(function(stores) {
		stores[0].get(1).then(function(app_config_settings) {
	
			/* Remove all pending alarms during the initialization */	
			var request = navigator.mozAlarms.getAll();

			request.onsuccess = function () {
				this.result.forEach(function(alarm) {
					navigator.mozAlarms.remove(alarm.id);
				});
			}
	
			updateConfig(app_config_settings,0);
			updateConfigToDS(app_config_settings);
			boot_flag = 1;
			console.log("datastore updated inside app download");
			});
		});
	}
	else
	{
		console.log("JioDSstore not defined in the app");
	}

}


//App usage event handler
window.navigator.mozSetMessageHandler('connection',appEvents);
function appEvents(request) {
  console.log("app usage event");
  if((DC_enable_config & 0x01) != 0) {
    if(request.keyword === 'amucomms'){
        var port = request.port;
        port.onmessage = function onReceivedMessage(evt) {
		 var evt_data_temp_appuse = JSON.parse(JSON.stringify(evt.data.data));
		 var evt_data_temp_crash = JSON.parse(JSON.stringify(evt.data.data));
		 for (i in evt_data_temp_appuse) {
			delete evt_data_temp_appuse[i].crashed;
			delete evt_data_temp_crash[i].invocations;
		}
		 AppDataCollectorObject("AE4", (CD_config & 0xFFFFF3FF),evt_data_temp_appuse);
		 AppDataCollectorObject("AE6", (CD_config & 0xFFFFF3FF),evt_data_temp_crash);
		 //console.log("app usage data"+JSON.stringify(evt.data));
       }
    }
  }
}
	   
function getPrivacyKey()
{	   
	  var req = navigator.mozSettings.createLock().get('jio.phone.monitor.enabled');
	  req.onsuccess = function () {
		var priv_key = req.result['jio.phone.monitor.enabled'];
		
		if (priv_key == undefined)
			priv_key = true;
			
			store_name.then(function(stores) {
		   stores[0].put(priv_key, PRIVACY_KEY_INDEX).then(function(config_settings) {
		      lyfPrivacyKey_global = priv_key;
			});
			});
		console.log("privacy key :"+priv_key);
	  }
	  req.onerror = function () {
		console.log("getPrivacyKey req error");
		store_name.then(function(stores) {
		   stores[0].put(lyfPrivacyKey_global, PRIVACY_KEY_INDEX).then(function(config_settings) {
			});
			});
	  }
}

navigator.mozSettings.addObserver('jio.phone.monitor.enabled', observerPrivacy);
function observerPrivacy(event) {
if (event.settingValue === true) 
	{
		console.log("LYF_PRIVACY_KEY enabled");
		store_name.then(function(stores) {
		   stores[0].put(true, PRIVACY_KEY_INDEX).then(function(config_settings) {
		   lyfPrivacyKey_global = true;
		   DC_enable_config = config_from_server["DC_enable"];
		   	/* Remove all pending alarms during the initialization */	
			var request = navigator.mozAlarms.getAll();

			request.onsuccess = function () {
				this.result.forEach(function(alarm) {
					navigator.mozAlarms.remove(alarm.id);
				});
			}
	        boot_flag = 1;
			updateConfig(config_from_server,0);
			});
			});
	}
	else 
	{
		console.log("LYF_PRIVACY_KEY disabled");
		 store_name.then(function(stores) {
		   stores[0].put(false, PRIVACY_KEY_INDEX).then(function(config_settings) {
		    lyfPrivacyKey_global = false;
			DC_enable_config = 0;
			});
			});
	}
  }

