'use strict';var CallsHandler=(function callsHandler(){var CALLS_LIMIT=8;var CDMA_CALLS_LIMIT=2;var MAX_NOTICE_COUNT=3;var MAX_NOTICE_TIMEOUT=30*60*1000;var handledCalls=[];var exitCallScreenTimeout=null;var oldBrightnessValue=0.2;var brightnessTimer=null;var isBrightnessDimMode=false;const BRIGHTNESS_TIMEOUT=5000;const DIM_VALUE=0.2;var toneInterval=null;var imsConferenceStartTime=0;var callHeldByUser=null;var noticeCount=0;var noticeTimeout=null;var imsHandler=null;var telephony=window.navigator.mozTelephony;var enableSpeaker=false;var isBTReceiverUsed=false;var operateState={answer:false,hangUp:false,merge:false};telephony.oncallschanged=onCallsChanged;telephony.addEventListener('ttymodereceived',ttyModeReceived);telephony.addEventListener('telephonycoveragelosing',onTelephonyCoverageLosing);window.addEventListener('keydown',handleKeyEvent,true);window.addEventListener('largetextenabledchanged',(event)=>{document.body.classList.toggle('large-text',navigator.largeTextEnabled);});document.body.classList.toggle('large-text',navigator.largeTextEnabled);navigator.getFlipManager().then((flipManager)=>{flipManager.addEventListener('flipchange',onFlipChange);});var conn=window.navigator.mozMobileConnections&&window.navigator.mozMobileConnections[0];if(conn&&conn.voice&&conn.voice.network&&conn.voice.network.mcc){SimplePhoneMatcher.mcc=conn.voice.network.mcc;}
if(conn&&conn.imsHandler){imsHandler=conn.imsHandler;imsHandler.addEventListener('capabilitychange',updateWifiCallState);}
var btHelper=new BluetoothHelper();var screenLock;var btConnectedState;var imsGroupRecords=[];function getImsRecord(){return imsGroupRecords;}
function insertImsRecord(number,name){var imsRecord={};imsRecord.number=number;imsRecord.name=name;imsGroupRecords.push(imsRecord);}
function setup(){if(telephony){telephony.muted=false;}
btHelper.getConnectedDevicesByProfile(btHelper.profiles.HFP,function(result){btConnectedState=!!(result&&result.length);isBTReceiverUsed=btConnectedState;CallScreen.setBTReceiverIcon(!!(result&&result.length));});btHelper.onhfpstatuschanged=function(evt){btConnectedState=evt.status;isBTReceiverUsed=btConnectedState;CallScreen.setBTReceiverIcon(evt.status);};var acm=navigator.mozAudioChannelManager;if(acm){acm.addEventListener('headphoneschange',function onheadphoneschange(){if(acm.headphones){CallScreen.switchToDefaultOut();}else{if(CallsHandler.enableSpeaker==true){CallScreen.switchToSpeaker();}}});}
btHelper.onscostatuschanged=function onscostatuschanged(evt){btConnectedState=evt.status;if(evt.status){CallScreen.switchToDefaultOut();}};navigator.mozSetMessageHandler('headset-button',handleHSCommand);navigator.mozSetMessageHandler('bluetooth-dialer-command',handleBTCommand);navigator.mozSetMessageHandler('cdma-info-rec-received',cdmaCallConnected);noticeCount=0;}
function onFlipChange(evt){var flipOpen=evt.currentTarget.flipOpened;var answerModeEnable=false;if(flipOpen){var lock=navigator.mozSettings.createLock();var answerModeSettings=lock.get('phone.answer.flipopen.enabled');answerModeSettings.onsuccess=function(){answerModeEnable=answerModeSettings.result['phone.answer.flipopen.enabled'];if(answerModeEnable){answer();}};answerModeSettings.onerror=function(){console.error("An error occure when get the answermode");};}else{if(btConnectedState){return;}
var acm=navigator.mozAudioChannelManager;if(acm&&acm.headphones){return;}
telephony.calls.forEach(function callIterator(call){call.hangUp();});if(telephony.conferenceGroup.calls.length){endConferenceCall();}}}
function cdmaCallConnected(message){if(message.lineControl){handledCalls[0].allowConnected();}}
var highPriorityWakeLock=null;function onCallsChanged(){CallScreen.showMainCallscreen();if(!highPriorityWakeLock&&telephony.calls.length>0){highPriorityWakeLock=navigator.requestWakeLock('high-priority');}
if(highPriorityWakeLock&&telephony.calls.length===0){highPriorityWakeLock.unlock();highPriorityWakeLock=null;}
var needMuteContinue=false;for(var i=0;i<telephony.calls.length;i++){if(telephony.calls[i].state==='incoming'||telephony.calls[i].state==='connected'){if(telephony.muted){needMuteContinue=true;}}}
if(telephony.conferenceGroup.state=='connected'){if(telephony.muted){needMuteContinue=true;}}
if(!needMuteContinue&&telephony.muted){unMute();}
if(telephony.active){telephony.active.addEventListener('error',handleBusyErrorAndPlayTone);}
telephony.calls.forEach(function callIterator(call){var alreadyAdded=handledCalls.some(function hcIterator(hc){return(hc.call==call);});if(!alreadyAdded){addCall(call);}});function hcIterator(call){return(call==hc.call);}
for(var index=(handledCalls.length-1);index>=0;index--){if(handledCalls[index].call.state==='disconnected'){removeCall(index);}}
if(telephony.calls.length===1&&telephony.conferenceGroup.calls.length===0){stopWaitingTone();}
if(cdmaCallWaiting()){CallScreenHelper.setState("connected_waiting");handleCallWaiting(telephony.calls[0]);}else{CallScreenHelper.setState();if(isCdma3WayCall()){CallScreen.hidePlaceNewCallButton();}else if(handledCalls.length!==0){CallScreen.showPlaceNewCallButton();}
else if(handledCalls.length===0&&telephony.conferenceGroup.calls.length===0){CallScreen.disableCallButton();}}
updateMergeAndOnHoldStatus();updateMuteAndSpeakerStatus();exitCallScreenIfNoCalls(CallScreen.callEndPromptTime);CallScreenHelper.render();}
function unMute(){CallsHandler.toggleMute();OptionHelper.swapParams('inCallParams','Unmute','Mute',true);CallScreen.updateCallsMuteState();}
function offSpeaker(){if(telephony.speakerEnabled){CallsHandler.toggleSpeaker();OptionHelper.swapParams('inCallParams','Speaker-off','Speaker',true);}}
function getOldBrightnessValue(){var lock=navigator.mozSettings.createLock();var brightnessSetting=lock.get('screen.brightness');brightnessSetting.onsuccess=function(){oldBrightnessValue=brightnessSetting.result['screen.brightness'];};}
function handleBrightnessTimer(isSetTimer){if(brightnessTimer){clearTimeout(brightnessTimer);}
if(isSetTimer){brightnessTimer=setTimeout(()=>{handleBrightnessDim();},BRIGHTNESS_TIMEOUT);}}
function handleBrightnessDim(){var settingObject={};settingObject['screen.brightness']=DIM_VALUE;navigator.mozSettings.createLock().set(settingObject);isBrightnessDimMode=true;}
function handleKeyEvent(event){if(isBrightnessDimMode){handleBrightnessRecover(true);}else{handleBrightnessTimer(true);}}
function handleBrightnessRecover(isSetTimer){var settingObject={};settingObject['screen.brightness']=oldBrightnessValue;navigator.mozSettings.createLock().set(settingObject);if(isSetTimer){handleBrightnessTimer(true);}else{handleBrightnessTimer(false);}
isBrightnessDimMode=false;}
function addCall(call){var cdmaTypes=['evdo0','evdoa','evdob','1xrtt','is95a','is95b'];var type=window.navigator.mozMobileConnections[call.serviceId].voice.type;var cdmaOutingCalls=(handledCalls.length==0&&cdmaTypes.indexOf(type)!==-1&&call.state==='dialing');if(handledCalls.length&&(call.state!='incoming')&&(call.state!='dialing')){return;}
if(telephony.calls.length>CALLS_LIMIT){HandledCall(call);call.hangUp();return;}
if(telephony.calls.length===1&&!telephony.conferenceGroup.calls.length){CallScreen.unmute();resetToDefault();CallScreen.switchToDefaultOut(true);getOldBrightnessValue();handleBrightnessRecover(true);}
var hc=new HandledCall(call);if(cdmaOutingCalls){hc.allowedConnected=false;}
handledCalls.push(hc);CallScreen.insertCall(hc.node);if(call.state==='incoming'){handleBrightnessRecover(true);turnScreenOn(call);}
if((handledCalls.length>1)||((telephony.calls.length>=1)&&(telephony.conferenceGroup.calls.length))){if(call.state==='incoming'){hc.hide();handleCallWaiting(call);}else{updatePlaceNewCall();hc.show();}}else{if(telephony.ownAudioChannel){telephony.ownAudioChannel();}
CallScreen.render(call.state);}
updateWifiCallState();}
function removeCall(index){var leftCallInfo=handledCalls[index].info;if(Array.isArray(leftCallInfo)){leftCallInfo=handledCalls[index].info[0];}else{leftCallInfo=handledCalls[index].info;}
handledCalls.splice(index,1);if(handledCalls.length===0){return;}
CallScreen.incomingInfo.classList.add('ended');CallScreen.incomingNumberAdditionalTelType.textContent='';LazyL10n.get(function localized(_){CallScreen.incomingNumberAdditionalTel.textContent=_('callEnded');self._cachedAdditionalTelType='';});CallScreen.hideIncoming();var remainingCall=null;handledCalls.forEach(function(handleCall){if(handleCall.call.state=='incoming'){remainingCall=handleCall;remainingCall.show();setTimeout(function nextTick(){if(remainingCall.call.state=='incoming'){CallScreen.render('incoming');}});return;}});if(openLines()===1){var groupCalls=document.getElementById('group-call-details');if(groupCalls&&groupCalls.classList.contains('display')){var toast={messageL10nId:'call-left-conference-toast',messageL10nArgs:{number:leftCallInfo},latency:2000,useTransition:true};Toaster.showToast(toast);}}}
function turnScreenOn(call){screenLock=navigator.requestWakeLock('screen');call.addEventListener('statechange',function callStateChange(){call.removeEventListener('statechange',callStateChange);if(screenLock){screenLock.unlock();screenLock=null;}});}
function handleBusyErrorAndPlayTone(evt){if(evt.call!==undefined&&evt.call.error.name==='BusyError'){var sequence=[[480,620,500],[0,0,500],[480,620,500],[0,0,500],[480,620,500],[0,0,500]];var sequenceDuration=sequence.reduce(function(prev,curr){return prev+curr[2];},0);TonePlayer.playSequence(sequence);exitCallScreenIfNoCalls(sequenceDuration);}}
function handleCallWaiting(call){LazyL10n.get(function localized(_){var number=call.secondId?call.secondId.number:call.id.number;if(!number){CallScreen.incomingNumber.textContent=_('withheld-number');CallScreen.incomingNumberAdditionalTel.textContent='';return;}
if(navigator.mozIccManager.iccIds.length>1){CallScreen.incomingSim.textContent=_('sim-number',{n:call.serviceId+1});}else{CallScreen.incomingSim.hidden=true;}
Contacts.findByNumber(number,function lookupContact(contact,matchingTel){if(CallsHandler.setCNAPText(call,CallScreen.incomingNumberAdditionalTel,CallScreen.incomingNumber)){if(contact&&contact.name){CallScreen.incomingNumber.textContent=contact.name;}}
else if(contact&&contact.name){CallScreen.incomingInfo.classList.add('additionalInfo');CallScreen.incomingNumber.textContent=contact.name;CallScreen.incomingNumberAdditionalTelType.textContent=Utils.getPhoneNumberAdditionalInfo(matchingTel);CallScreen.incomingNumberAdditionalTel.textContent=number;}else{CallScreen.incomingNumber.textContent=number;CallScreen.incomingNumberAdditionalTelType.textContent='';LazyL10n.get(function localized(_){CallScreen.incomingNumberAdditionalTel.textContent=_('unknown');self._cachedAdditionalTelType='';});}});});CallScreen.incomingHdIcon.classList.toggle('hide',call.voiceQuality==='Normal');if(cdmaCallWaiting()){CallScreen.holdAndAnswerOnly=true;}
CallScreen.incomingInfo.classList.remove('ended');CallScreen.showIncoming();playWaitingTone(call);}
function exitCallScreenIfNoCalls(timeout){if(handledCalls.length===0&&telephony.conferenceGroup.state!=='connected'){document.body.classList.toggle('no-handled-calls',true);CallScreenHelper.finalCallEndOption();noticeCount=0;if(exitCallScreenTimeout!==null){clearTimeout(exitCallScreenTimeout);exitCallScreenTimeout=null;}
exitCallScreenTimeout=setTimeout(function(evt){OptionHelper.softkeyPanel.hideMenu();exitCallScreenTimeout=null;if(handledCalls.length===0){handleBrightnessRecover(false);var imsGroupRecords=getImsRecord();imsGroupRecords.splice(0,imsGroupRecords.length);}else{document.body.classList.toggle('no-handled-calls',false);}},timeout);}}
function updateAllPhoneNumberDisplays(){handledCalls.forEach(function(call){if(!call._leftGroup){call.restorePhoneNumber();}});}
window.addEventListener('resize',updateAllPhoneNumberDisplays);function openLines(){return telephony.calls.length+
(telephony.conferenceGroup.calls.length?1:0);}
function handleBTCommand(message){var command=message.command;switch(command){case'CHUP':end();break;case'ATA':answer();break;case'CHLD=0':hangupWaitingCalls();break;case'CHLD=1':if((handledCalls.length===1)&&!cdmaCallWaiting()){end();}else{endAndAnswer();}
break;case'CHLD=2':if((handledCalls.length===1)&&!cdmaCallWaiting()){holdOrResumeCallByUser();}else{holdAndAnswer();}
break;case'CHLD=3':mergeCalls();break;default:var partialCommand=command.substring(0,3);if(partialCommand==='VTS'){KeypadManager.press(command.substring(4));}
break;}}
var lastHeadsetPress=0;function handleHSCommand(message){switch(message){case'headset-button-press':lastHeadsetPress=Date.now();return;case'headset-button-release':if((Date.now()-lastHeadsetPress)>1000){return;}
break;default:return;}
if(telephony.active){end();}else if((handledCalls.length>1)||cdmaCallWaiting()){holdAndAnswer();}else{answer();}}
function answer(){if(!handledCalls.length){return;}
if((handledCalls.length>1)||cdmaCallWaiting()||telephony.conferenceGroup.calls.length){holdAndAnswer();return;}
handleCall(handledCalls[0].call,'answer');CallScreen.render('connected');}
function holdAndAnswer(){if(((handledCalls.length<2)&&(telephony.calls.length<2)&&!telephony.conferenceGroup.calls.length)&&!cdmaCallWaiting()){return;}
if(telephony.calls.length===3||(telephony.calls.length>=2&&telephony.conferenceGroup.calls.length)){endAndAnswer();return;}
if(telephony.active){telephony.active.hold();if(cdmaCallWaiting()){btHelper.answerWaitingCall();}}else if(handledCalls.length>=2){var lastCall=handledCalls[handledCalls.length-1].call;handleCall(lastCall,'answer');}else{handledCalls[0].call.hold();}
CallScreen.hideIncoming();if(cdmaCallWaiting()){CallScreenHelper.setState('connected_hold');CallScreenHelper.render();handledCalls[0].updateCallNumber();CallScreen.cdmaCallWaiting=true;stopWaitingTone();}}
function endAndAnswer(){if((handledCalls.length<2)&&!cdmaCallWaiting()){return;}
if(telephony.active==telephony.conferenceGroup){endConferenceCall().then(function(){CallScreen.hideIncoming();},function(){});return;}
if(cdmaCallWaiting()){handledCalls[0].call.hold();stopWaitingTone();btHelper.answerWaitingCall();}else{var callToEnd=telephony.active||handledCalls[handledCalls.length-2].call;var callToAnswer;handledCalls.some(function(handledCall){if(handledCall.call.state=='incoming'){callToAnswer=handledCall.call;return true;}});if(callToEnd&&callToAnswer){callToEnd.addEventListener('disconnected',function ondisconnected(){callToEnd.removeEventListener('disconnected',ondisconnected);handleCall(callToAnswer,'answer');});handleCall(callToEnd,'hangUp');}else if(callToEnd){handleCall(callToEnd,'hangUp');}else if(callToAnswer){handleCall(callToAnswer,'answer');}}
CallScreen.hideIncoming();if(cdmaCallWaiting()){handledCalls[0].updateCallNumber();CallScreen.cdmaCallWaiting=true;}}
function toggleCalls(){if(CallScreen.incomingContainer.classList.contains('displayed')&&!cdmaCallWaiting()){return;}
if(openLines()<2&&!cdmaCallWaiting()){if(!telephony.active){holdOrResumeSingleCall();}
return;}
telephony.active.hold();btHelper.toggleCalls();callHeldByUser=null;}
function holdOrResumeCallByUser(){if(telephony.active){callHeldByUser=telephony.active;}
holdOrResumeSingleCall();}
function holdOrResumeSingleCall(){if(openLines()!==1||(telephony.calls.length&&(telephony.calls[0].state==='incoming'||!telephony.calls[0].switchable))){return;}
if(telephony.active){telephony.active.hold();CallScreen.render('connected-hold');}else{var line=telephony.calls.length?telephony.calls[0]:telephony.conferenceGroup;line.resume();callHeldByUser=null;CallScreen.render('connected');}}
function hangupWaitingCalls(){handledCalls.forEach(function(handledCall){var callState=handledCall.call.state;if(callState==='held'||(callState==='incoming'&&handledCalls.length>1)){handleCall(handledCall.call,'hangUp');}});}
function ignore(){if(cdmaCallWaiting()){CallScreenHelper.setState();stopWaitingTone();btHelper.ignoreWaitingCall();}else{var ignoreIndex=handledCalls.length-1;handleCall(handledCalls[ignoreIndex].call,'hangUp');}
CallScreen.incomingInfo.classList.add('ended');CallScreen.incomingNumberAdditionalTelType.textContent='';LazyL10n.get(function localized(_){CallScreen.incomingNumberAdditionalTel.textContent=_('callEnded');self._cachedAdditionalTelType='';});CallScreen.hideIncoming();}
function endConferenceCall(){return telephony.conferenceGroup.hangUp().then(function(){ConferenceGroupHandler.signalConferenceEnded();},function(){console.error('Failed to hangup Conference Call');});}
function end(){var callToEnd=null;handledCalls.forEach(function(handleCall){if(handleCall.call.state=='incoming'){callToEnd=handleCall.call;}});if(!callToEnd){if(telephony.active){callToEnd=telephony.active;}else if(openLines()===1){if(telephony.conferenceGroup.calls.length){callToEnd=telephony.conferenceGroup;}else{callToEnd=telephony.calls[0];}}else{if(!handledCalls.length){return;}
var lastCallIndex=handledCalls.length-1;callToEnd=handledCalls[lastCallIndex].call;}
if(callToEnd.calls){endConferenceCall();}else{handleCall(callToEnd,'hangUp');}}else{handleCall(callToEnd,'hangUp');}
callToEnd.addEventListener('statechange',function callStateChange(){var state=callToEnd.state;if((state==='disconnected'||state==='')&&!telephony.active){holdOrResumeSingleCall();}
callToEnd.removeEventListener('statechange',callStateChange);});}
function unmute(){telephony.muted=false;}
function switchToSpeaker(){btHelper.disconnectSco();if(!telephony.speakerEnabled){telephony.speakerEnabled=true;}}
function switchToDefaultOut(doNotConnect){if(telephony.speakerEnabled){telephony.speakerEnabled=false;}
if(!doNotConnect&&telephony.active&&!document.hidden){btHelper.connectSco();}}
function switchToReceiver(){btHelper.disconnectSco();if(telephony.speakerEnabled){telephony.speakerEnabled=false;}}
function toggleMute(){telephony.muted=!telephony.muted;}
function toggleSpeaker(){if(telephony.speakerEnabled){CallsHandler.switchToDefaultOut();}else{if(navigator.mozAudioChannelManager.headphones&&CallsHandler.enableSpeaker==true){telephony.speakerEnabled=false;}else{CallsHandler.switchToSpeaker();}}}
function playWaitingTone(call){var sequence=[[440,440,100],[0,0,100],[440,440,100]];toneInterval=window.setInterval(function playTone(){TonePlayer.playSequence(sequence);},10000);TonePlayer.playSequence(sequence);call.addEventListener('statechange',function callStateChange(){call.removeEventListener('statechange',callStateChange);window.clearInterval(toneInterval);});}
function stopWaitingTone(){window.clearInterval(toneInterval);}
function activeCall(){var telephonyActiveCall=telephony.active;var active=null;for(var i=0;i<handledCalls.length;i++){var handledCall=handledCalls[i];if(telephonyActiveCall===handledCall.call){active=handledCall;break;}}
return active;}
function activeCallForContactImage(){if(handledCalls.length===1){return handledCalls[0];}
return[activeCall()].concat(handledCalls).find(function(elem){return!elem||!elem.call.group;});}
function cdmaCallWaiting(){return((telephony.calls.length==1)&&(telephony.calls[0].state=='connected')&&(telephony.calls[0].secondId));}
function isFirstCallOnCdmaNetwork(){var cdmaTypes=['evdo0','evdoa','evdob','1xrtt','is95a','is95b'];if(handledCalls.length!==0){var ci=handledCalls[0].call.serviceId;var type=window.navigator.mozMobileConnections[ci].voice.type;return(cdmaTypes.indexOf(type)!==-1);}else{return false;}}
function isCdma3WayCall(){return isFirstCallOnCdmaNetwork()&&((telephony.calls.length===CDMA_CALLS_LIMIT)||(telephony.conferenceGroup.calls.length>0));}
function mergeCalls(){if(operateState.merge){return;}else{operateState.merge=true;}
if(ConferenceGroupUI.isImsconferenceGroup()){setImsConferenceStartTime();}
if(!telephony.conferenceGroup.calls.length&&telephony.calls.length===2){telephony.conferenceGroup.add(telephony.calls[0],telephony.calls[1]);}else if(telephony.conferenceGroup.state&&telephony.calls.length===1){telephony.conferenceGroup.add(telephony.calls[0]);}
callHeldByUser=null;}
function isEstablishingCall(){return telephony.calls.some(function(call){return call.state=='dialing'||call.state=='alerting';});}
function isAnyCallOnHold(){return telephony.calls.some(call=>call.state==='held')||(telephony.conferenceGroup&&telephony.conferenceGroup.state==='held');}
function isAnyCallSwitchable(){return telephony.calls.some(call=>call.switchable)||((telephony.conferenceGroup.calls.length>0)&&telephony.conferenceGroup.calls.every(call=>call.switchable));}
function isEveryCallMergeable(){return telephony.calls.every(call=>call.mergeable);}
function updatePlaceNewCall(){if(isEstablishingCall()){CallScreen.disablePlaceNewCallButton();}else{CallScreen.enablePlaceNewCallButton();}}
function updateMergeAndOnHoldStatus(){var isEstablishing=isEstablishingCall();if(openLines()>1&&!isEstablishing){CallScreen.hideOnHoldButton();if(isEveryCallMergeable()){CallScreen.showOnHoldAndMergeContainer();CallScreen.showMergeButton();}else{CallScreen.hideOnHoldAndMergeContainer();}}else{CallScreen.hideMergeButton();CallScreen.setShowIsHeld(!telephony.active&&isAnyCallOnHold());if(isEstablishing){CallScreen.disableOnHoldButton();}else{CallScreen.enableOnHoldButton();}
if(isAnyCallSwitchable()){CallScreen.showOnHoldAndMergeContainer();CallScreen.showOnHoldButton();}else{CallScreen.hideOnHoldAndMergeContainer();}}}
function updateMuteAndSpeakerStatus(){if(telephony.active){CallScreen.enableMuteButton();CallScreen.enableSpeakerButton();}else{CallScreen.disableMuteButton();CallScreen.disableSpeakerButton();}}
function ttyModeReceived(ttyModeEvent){var msgId='';console.log('Get ttyModeReceived, mode: '+ttyModeEvent.mode);switch(ttyModeEvent.mode){case'off':msgId='ttyModeOff';break;case'full':msgId='ttyModeFull';break;case'hco':msgId='ttyModeHco';break;case'vco':msgId='ttyModeVco';break;default:console.log('ttyModeReceived with unknown mode: '+ttyModeEvent.mode);break;}
if(!msgId){return;}
ConfirmDialog.show('',{id:msgId},{title:'cancel',callback:function(){ConfirmDialog.hide();}},{title:'settings',callback:function(){launchAccessibility();ConfirmDialog.hide();}});}
function launchAccessibility(){try{new MozActivity({name:'configure',data:{target:'device',section:'accessibility'}});}catch(e){console.error('Failed to create an activity: '+activityName);}}
function showCoverageLosingNotice(){var sequence=[[800,800,300],[0,0,100],[800,800,300]];TonePlayer.playSequence(sequence);ConfirmDialog.show('',{id:'losing-wifi-msg'},{title:'emergencyDialogBtnOk',callback:function(){ConfirmDialog.hide();}});}
function onTelephonyCoverageLosing(event){switch(event.type){case'ims-over-wifi':console.log('Telephony Coverage Losing from Wifi, msg: '+event.type);if(noticeCount>=MAX_NOTICE_COUNT){return;}
if(noticeTimeout!=null){window.clearTimeout(noticeTimeout);noticeTimeout=null;}
noticeTimeout=window.setTimeout(function(){noticeCount=0;},MAX_NOTICE_TIMEOUT);CallsHandler.showCoverageLosingNotice();noticeCount++;break;default:console.log('Telephony Coverage Losing, msg: '+event.type);break;}}
function updateWifiCallState(){var enabled=false;if(imsHandler&&((imsHandler.capability==='voice-over-wifi')||(imsHandler.capability==='video-over-wifi'))&&(!imsHandler.unregisteredReason)){enabled=true;}
var callListElement=document.getElementById('list-call');if(callListElement!==null){callListElement.classList.toggle('wificall',enabled);console.log('updateWifiCallState(): enabled = '+enabled);}}
function getGroupDetailsText(){var text='';handledCalls.forEach(function(handleCall){if(handleCall.call.group){text+=handleCall.info;text+=', ';}});text=text.substring(0,text.length-2);return text;}
function getImsGroupDetailsText(){var text='';var calls=telephony.conferenceGroup.calls;ConferenceGroupHandler.removeGroupDetails();var imsGroupRecords=getImsRecord();calls.forEach(function(call){var findMatchNumber=false;for(var i=0;i<imsGroupRecords.length;i++){var record=imsGroupRecords[i];if(record.number===call.id.number&&record.name!==''){text+=record.name;text+=', ';findMatchNumber=true;ConferenceGroupHandler.addToImsGroupDetails(call.id.number,record.name);break;}}
if(findMatchNumber===false){text+=call.id.number;text+=', ';ConferenceGroupHandler.addToImsGroupDetails(call.id.number,'');}});text=text.substring(0,text.length-2);return text;}
function getFirstStartTime(){var time=0;handledCalls.forEach(function(handleCall){if(handleCall.call.group){var startTime=handleCall.getStartTime();if(time===0||time>startTime){time=startTime;}}});return time;}
function setImsConferenceStartTime(){var groupDuration=document.querySelector('#group-call > .duration');if(groupDuration.dataset.startTime==undefined){imsConferenceStartTime=0;handledCalls.forEach(function(handleCall){var startTime=handleCall.getStartTime();if(imsConferenceStartTime===0||imsConferenceStartTime>startTime){imsConferenceStartTime=startTime;}});}else{imsConferenceStartTime=groupDuration.dataset.startTime;}}
function getImsConferenceStartTime(){return imsConferenceStartTime;}
function clearImsConferenceStartTime(){imsConferenceStartTime=0;}
function setCNAPText(call,numberItem,nameItem){var name=call.id.name;if(name===''){return false;}
var number=call.id.number;var numberPresentation=call.id.numberPresentation;nameItem.textContent=name;switch(numberPresentation){case('allowed'):numberItem.textContent=number;break;case('restricted'):case('unknown'):LazyL10n.get(function localized(_){numberItem.textContent=_('unknown');});break;case('payphone'):LazyL10n.get(function localized(_){numberItem.textContent=_('payphone');});break;}
return true;}
function resetToDefault(){offSpeaker();CallScreen.enableCallButton();CallScreen.hideDtmfNumber();btHelper.getConnectedDevicesByProfile(btHelper.profiles.HFP,function(result){btConnectedState=!!(result&&result.length);CallScreen.setBTReceiverIcon(btConnectedState);});}
function isInConferenceCall(number){var calls=telephony.conferenceGroup.calls;if(!calls.length){return false;}else{for(var i=0;i<calls.length;i++){if(calls[i].id.number===number){return true;}}
return false;}}
function handleCall(call,event){if(operateState[event]!==false){return;}
operateState[event]=true;call[event]();call.addEventListener('statechange',handleStateChangeOrError);call.addEventListener('error',handleStateChangeOrError);}
function handleStateChangeOrError(evt){operateState.answer=false;operateState.hangUp=false;evt.call.removeEventListener('statechange',handleStateChangeOrError);evt.call.removeEventListener('error',handleStateChangeOrError);}
return{setup:setup,answer:answer,holdAndAnswer:holdAndAnswer,endAndAnswer:endAndAnswer,toggleCalls:toggleCalls,ignore:ignore,end:end,toggleMute:toggleMute,toggleSpeaker:toggleSpeaker,unmute:unmute,switchToReceiver:switchToReceiver,switchToSpeaker:switchToSpeaker,switchToDefaultOut:switchToDefaultOut,holdOrResumeCallByUser:holdOrResumeCallByUser,checkCalls:onCallsChanged,mergeCalls:mergeCalls,updateAllPhoneNumberDisplays:updateAllPhoneNumberDisplays,updatePlaceNewCall:updatePlaceNewCall,exitCallScreenIfNoCalls:exitCallScreenIfNoCalls,updateMergeAndOnHoldStatus:updateMergeAndOnHoldStatus,updateMuteAndSpeakerStatus:updateMuteAndSpeakerStatus,ttyModeReceived:ttyModeReceived,onTelephonyCoverageLosing:onTelephonyCoverageLosing,updateWifiCallState:updateWifiCallState,showCoverageLosingNotice:showCoverageLosingNotice,getGroupDetailsText:getGroupDetailsText,getFirstStartTime:getFirstStartTime,setImsConferenceStartTime:setImsConferenceStartTime,getImsConferenceStartTime:getImsConferenceStartTime,clearImsConferenceStartTime:clearImsConferenceStartTime,setCNAPText:setCNAPText,getImsGroupDetailsText:getImsGroupDetailsText,insertImsRecord:insertImsRecord,getImsRecord:getImsRecord,isInConferenceCall:isInConferenceCall,get activeCall(){return activeCall();},get activeCallForContactImage(){return activeCallForContactImage();},get isAnyOpenCalls(){return handledCalls.length>0;},get imsRegState(){if(imsHandler)
return imsHandler.capability;else
return null;},get isBtConnected(){return btConnectedState;},get isMute(){return telephony.muted;},get isSpeakerEnabled(){return telephony.speakerEnabled;},get isBTReceiverUsed(){return isBTReceiverUsed;},set isMergeRequsted(value){operateState.merge=value;},isFirstCallOnCdmaNetwork:isFirstCallOnCdmaNetwork};})();