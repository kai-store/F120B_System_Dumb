// Bootstrapping happens after the GUI is shown in order to bring the UX as soon
// as possible.

window.addEventListener('load', function(event) {
  new google.assistant.MainController();
});
