app.component("softkeys", {
    bindings: {
        softkeylist: '<'
    },
    controller: function() {
        this.name = "Softkeys";

    },
     template: `<div id='softkey' ng-show="$ctrl.softkeylist.show">
                <span id="soft-key-left">{{$ctrl.softkeylist.leftkeytext}}</span>
                 <span id="soft-key-center">&#9633;</span>
                <span id="soft-key-right">{{$ctrl.softkeylist.rightkeytext}}</span>
              </div>`
})
