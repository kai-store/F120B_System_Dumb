var dbPromiseXpressNews;
// if  (!(navigator.appName  ==  'Microsoft Internet Explorer'  ||   !!(navigator.userAgent.match(/Trident/)  ||  navigator.userAgent.match(/rv:11/))  ||  (typeof  $.browser  !==  "undefined"  &&  $.browser.msie  ==  1))) {
dbPromiseXpressNews = idb.open('jioexpressnewsweb-db', 1, function(upgradeDB) {
    upgradeDB.createObjectStore('jioexpressnews');
});
// }

var idbKeyval = {
    get: function get(key) {
        return dbPromiseXpressNews.then(function(db) {
            return db.transaction('jioexpressnews').objectStore('jioexpressnews').get(key);
        });
    },
    set: function set(key, val) {
        return dbPromiseXpressNews.then(function(db) {
            var tx = db.transaction('jioexpressnews', 'readwrite');
            tx.objectStore('jioexpressnews').put(val, key);
            return tx.complete;
        });
    },
    'delete': function _delete(key) {
        return dbPromiseXpressNews.then(function(db) {
            var tx = db.transaction('jioexpressnews', 'readwrite');
            tx.objectStore('jioexpressnews')['delete'](key);
            return tx.complete;
        });
    },
    clear: function clear() {
        return dbPromiseXpressNews.then(function(db) {
            var tx = db.transaction('jioexpressnews', 'readwrite');
            tx.objectStore('jioexpressnews').clear();
            return tx.complete;
        });
    },
    keys: function keys() {
        return dbPromiseXpressNews.then(function(db) {
            var tx = db.transaction('jioexpressnews');
            var keys = [];
            var store = tx.objectStore('jioexpressnews');
            // This would be store.getAllKeys(), but it isn't supported by Edge or Safari.
            // openKeyCursor isn't supported by Safari, so we fall back
            (store.iterateKeyCursor || store.iterateCursor).call(store, function(cursor) {
                if (!cursor) return;
                keys.push(cursor.key);
                cursor['continue']();
            });
            return tx.complete.then(function() {
                return keys;
            });
        });
    }
};
