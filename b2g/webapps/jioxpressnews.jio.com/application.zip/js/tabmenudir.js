app.directive('tabMenu', function() {
    return {
        scope: {
            menus: '=',
            isbusy: '=?',
            focusIndex: '=?',
            callbackfnc: '&'
        }, // {} = isolate, true = child, false/undefined = no change
        controller: function($scope, $element, $attrs, $transclude) {},
        restrict: 'E', // E = Element, A = Attribute, C = Class, M = Comment
        template: `<div id="scrollmenuId" class="scrollmenu">
                  <a ng-repeat="item in menus track by item.id" ng-class="{'scrollmenu-ahover': $index == focusIndex}">{{item.name}}</a>
                  </div>`,
        replace: true,
        transclude: true,
        link: function($scope, iElm, iAttrs, controller, $timeout) {
            console.log("Inside link");
            $scope.name = "Tab Menu";
            var children,
                childrenOffsets = [],
                padding = 14,
                el,
                containerWidth,
                isChildDOMReady = false,
                focusId;
            $scope.focusIndex = $scope.focusIndex || 0;
            focusId = $scope.focusIndex;
            containerWidth = window.innerWidth;

            var setChildren = function() {
                if (!isChildDOMReady) {
                    try {
                        children = document.querySelectorAll('#newstopcontainer a'); //document.getElementById('newstopcontainer').find('a');
                        childrenOffsets = [];
                        for (var i = 0; i < children.length; i++) {
                            childrenOffsets.push({ 'left': children[i].offsetLeft, 'width': children[i].offsetWidth });
                        }

                        console.log("$element ", iElm);

                        if (children.length > 0) {
                            // alert("Children Ready")
                            el = document.getElementById("scrollmenuId");
                            padding = Number(window.getComputedStyle(children[0]).getPropertyValue("padding-right").substring(0, 2));
                            isChildDOMReady = true
                        }
                    } catch (e) {
                        console.log("Catch.... ", e);
                    }
                }
                // return isChildDOMReady;
            }
            var getPosition = function(index) {
                var left = 0;
                if (index !== 0) {
                    var child = childrenOffsets[index],
                        xpos = child.left,
                        w = child.width + padding,
                        h = xpos + w;

                    left = h - containerWidth;
                }

                (function(left) {
                    setTimeout(function() {
                        el.scrollLeft = left;
                    }, 100);
                })(left);
                $scope.callbackfnc({ arg: { index: index } });

            }

            /*to be done*/
            /*this.$onDestroy = function() {
                document.removeEventListener('keydown', onKeyEvent, false);
            };*/
            $scope.$on(
                "$destroy",
                function() {
                    document.removeEventListener('keydown', onKeyEvent, false);
                }
            );



            $scope.$watch('menus', function(newval, oldval) {
                if (newval && newval.length > 0) {
                    setChildren();
                }
            });

            $scope.$watch('focusIndex', function(newval, oldval) {
                if (newval != oldval && newval >= 0) {
                    $timeout(function() {
                        getPosition(newval);
                    }, 0);
                }
            });

            function onKeyEvent(event) {
                if (!$scope.isbusy) {
                    if (event.key == "ArrowLeft") {
                        if ($scope.focusIndex > 0) {
                            --$scope.focusIndex;
                        } else {
                            $scope.focusIndex = $scope.menus.length - 1;
                        }
                        focusId = $scope.focusIndex;
                        getPosition($scope.focusIndex);
                        event.preventDefault();
                        $scope.$apply();
                    }

                    if (event.key == "ArrowRight") {

                        if ($scope.focusIndex < $scope.menus.length - 1) {
                            ++$scope.focusIndex;
                        } else {
                            $scope.focusIndex = 0;
                        }
                        focusId = $scope.focusIndex;
                        getPosition($scope.focusIndex);
                        event.preventDefault();
                        $scope.$apply();
                    }

                }
            }
            setChildren();
            document.addEventListener('keydown', onKeyEvent, false);
        }
    };
});
