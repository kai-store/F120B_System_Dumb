/*
Analytics.js is dependent on Client.js
Load client.js before loading this.
Usage: Analaytics.js is use to send some events to server. Like begin, end, etc.
*/
(function(scope) {
    /**
     * AnalyticsJS is main class that exports in global scope.
     * @method AnalyticsJS
     * @return 
     */
    function AnalyticsJS() {
        var xForwardedFor = "NA",
            geoLocation = {},
            deviceTypeAbbr,
            platformAbbr,
            currentOS,
            userAgent,
            logNo = 1,
            evtNo = 1;

        platformAbbr = {
            "Windows": "WIN",
            "iOS": "I",
            "Andriod": "A",
            "Linux": "LIN",
            "Firefox OS": "K"
        };

        deviceTypeAbbr = {
            "mobile": "S",
            "tablet": "T"
        };


        /**
         * This Method is used to fetch user IP and store into xForwardedFor variable
         * @method getUserIP
         * @return 
         */
        function getUserIP() {
            try {
                var RTCPeerConnection = /*window.RTCPeerConnection ||*/ window.webkitRTCPeerConnection || window.mozRTCPeerConnection;
                if (RTCPeerConnection)(function() {
                    var rtc = new RTCPeerConnection({ iceServers: [] }),
                        addrs = Object.create(null);
                    if (1 || window.mozRTCPeerConnection) { // FF [and now Chrome!] needs a channel/stream to proceed
                        rtc.createDataChannel('', { reliable: false });
                    };

                    rtc.onicecandidate = function(evt) {
                        // convert the candidate to SDP so we can run it through our general parser
                        // see https://twitter.com/lancestout/status/525796175425720320 for details
                        if (evt.candidate) grepSDP("a=" + evt.candidate.candidate);
                    };
                    rtc.createOffer(function(offerDesc) {
                        grepSDP(offerDesc.sdp);
                        rtc.setLocalDescription(offerDesc);
                    }, function(e) { console.warn("offer failed", e); });

                    addrs["0.0.0.0"] = false;

                    function updateDisplay(newAddr) {
                        if (newAddr in addrs) return;
                        else addrs[newAddr] = true;
                        var displayAddrs = Object.keys(addrs).filter(function(k) {
                            return addrs[k];
                        });
                        //document.getElementById('list').textContent = displayAddrs.join(" or perhaps ") || "n/a";
                        xForwardedFor = displayAddrs.join();
                    }

                    function grepSDP(sdp) {
                        var hosts = [];
                        sdp.split('\r\n').forEach(function(line) { // c.f. http://tools.ietf.org/html/rfc4566#page-39
                            if (~line.indexOf("a=candidate")) { // http://tools.ietf.org/html/rfc4566#section-5.13
                                var parts = line.split(' '), // http://tools.ietf.org/html/rfc5245#section-15.1
                                    addr = parts[4],
                                    type = parts[7];
                                if (type === 'host') updateDisplay(addr);
                            } else if (~line.indexOf("c=")) { // http://tools.ietf.org/html/rfc4566#section-5.7
                                var parts = line.split(' '),
                                    addr = parts[2];
                                updateDisplay(addr);
                            }
                        });
                    }
                })();
            } catch (e) {}
        };

        /**
         * This method creates object of clientData. Uses Client.js methods to fetch data.
         * @method initClientData
         * @return 
         */
        function initClientData() {
            var deviceType = this.clientJS.getDeviceType(),
                pf = platformAbbr[currentOS],
                dtpe = deviceTypeAbbr[deviceType];

            if (!pf) pf = (userAgent.toUpperCase().indexOf('MAC') >= 0) ? "MAC" : currentOS;
            if (!dtpe) {
                if (!deviceType) {
                    if (currentOS === 'Firefox OS') {
                        dtpe = "F";
                    } else if ((currentOS === 'Windows' || currentOS === 'Linux' || userAgent.toUpperCase().indexOf('MAC') >= 0)) {
                        dtpe = "D";
                    }
                } else {
                    dtpe = deviceType;
                }
            }

            this.clientData = {
                'os': currentOS,
                'osv': this.clientJS.getOSVersion(),
                'mod': this.clientJS.getDevice(),
                'agent': this.clientJS.getBrowser(),
                'agentversion': this.clientJS.getBrowserVersion(),
                'sdv': '1.0.0.0',
                'pf': pf,
                'dtpe': dtpe,
                'res': this.clientJS.getCurrentResolution(),
                'mnu': this.clientJS.getDeviceVendor(),
                'ori': window.innerHeight > window.innerWidth ? 'portrait' : 'landscape',
                'did': "NA",
                'lat': geoLocation.lat,
                'lng': geoLocation.lng,
                "x-forwarded-for": xForwardedFor
            };
        };

        /**
         * This method is used internally by getPostData fnc in multiple cases to create object of common data.
         * @method addCommonData
         * @param {} postdata
         * @param {} clientData
         * @return 
         */
        function addCommonData(postData, clientData, addMnuOsv) {
            postData.dtpe = clientData.dtpe;
            postData.lng = clientData.lng;
            postData.lat = clientData.lat;
            postData.did = clientData.did;
            postData.pf = clientData.pf;
            postData.rtc = clientData.rtc;
            postData.logNo = clientData.logNo;
            postData.agent = clientData.agent;
            postData.agentversion = clientData.agentversion;
            postData["x-forwarded-for"] = clientData["x-forwarded-for"];
            if (addMnuOsv) {
                postData.osv = clientData.osv;
                postData.mnu = clientData.mnu;
                postData.evtNo = evtNo++;
            }
        };

        /**
         * This method returns an object which is used while sending an events to server.
         * @method getPostData
         * @param {} eventName
         * @param {} options
         * @return postdata
         */
        function getPostData(eventName, options) {
            var clientData = this.getClientData(eventName),
                postData = options;

            switch (eventName) {
                case "E":
                    addCommonData(postData, clientData);
                    postData.sty = clientData.sty;
                    break;
                case 'event':
                    switch (options.key) {
                        /*case 'search':
                        case 'media_end':
                        case 'snav':
                        case 'add_to_home_screen':
                        case 'video_share':
                        case 'utm_source':
                            postData.agent = clientData.agent;
                            postData.agentversion = clientData.agentversion;
                            break;*/
                        case 'api_failure':
                            postData.date = new Date();
                            break;
                    };
                    addCommonData(postData, clientData, true);
                    //delete postData.key; 
                    break;
                case "application_launched":
                    addCommonData(postData, clientData, true);
                    break;
                case "O":
                    if (options.key == 'login_failed') {
                        postData.date = new Date();
                        addCommonData(postData, clientData, true);
                        postData.sty = clientData.sty;
                        delete postData.key;
                    }
                    break;
                case "B":
                    for (var key in clientData) {
                        postData[key] = clientData[key];
                    }
                    postData.evtNo = evtNo++;
                    break;
            }

            return postData;
        };

        /**
         * This method returns geo locations of user.
         * @method getGeoLocation
         * @return 
         */
        this.getGeoLocation = function() {
            navigator.geolocation.getCurrentPosition(function(position) {
                geoLocation.lat = position ? position.coords.latitude : '';
                geoLocation.lng = position ? position.coords.longitude : '';

                if (window.AnalyticsJS && window.AnalyticsJS.clientData) {
                    window.AnalyticsJS.clientData.lat = geoLocation.lat;
                    window.AnalyticsJS.clientData.lng = geoLocation.lng;
                }
            });
        };

        /**
         * This returns client data
         * @method getClientData
         * @param {} param
         * @return MemberExpression
         */
        this.getClientData = function(param) {
            this.clientData.sty = param;
            this.clientData.logno = logNo++;
            this.clientData.rtc = new Date().getTime();

            return this.clientData;
        };

        /**
         * This method used to send event and data to server.
         * @method send
         * @param {} eventName
         * @param {} options
         * @param {} callbackSuccessFnc
         * @param {} callbackErrorFnc
         * @return 
         */
        this.send = function(eventName, options, callbackSuccessFnc, callbackErrorFnc) {
            /*var url = "http://collectpreprod.media.jio.com/postdata/" + eventName;*/
            var url = "https://collect.media.jio.com/postdata/" + eventName;

            if (navigator.onLine) {
                try {
                    var xhttp = new XMLHttpRequest({ mozSystem: true });
                    xhttp.open("POST", url, true);
                    xhttp.setRequestHeader("Content-type", "application/json");
                    xhttp.send(JSON.stringify(getPostData.call(this, eventName, options)));
                    /**
                     * Description
                     * @method onreadystatechange
                     * @return 
                     */
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState == 4) {
                            if (xhttp.status == 200) {
                                if (callbackSuccessFnc) callbackSuccessFnc(xhttp.responseText);
                            } else {
                                if (callbackErrorFnc) callbackErrorFnc(xhttp.status, xhttp.statusText);
                            }
                        }
                    };
                } catch (e) {
                    console.log(e);
                }
            } else {
                console.log('User is offline');
            }
        }

        /**
         * Initializes variables, objects and data.
         * @method init
         * @return 
         */
        this.init = function() {
            this.clientJS = new ClientJS();
            currentOS = this.clientJS.getOS();
            userAgent = this.clientJS.getUserAgent();
            this.getGeoLocation();
            getUserIP.call(this);
            initClientData.call(this);
        };

        this.init();
    }

    scope.AnalyticsJS = new AnalyticsJS();
})(window);
