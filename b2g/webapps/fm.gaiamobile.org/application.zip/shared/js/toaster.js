'use strict';
var Toaster = {
  showToast: function t_showToast(options) {
    navigator.mozApps.getSelf().onsuccess = function (evt) {
      var app = evt.target.result;
      app.connect('systoaster').then(function onConnAccepted(ports) {
        if (options.messageL10nId && !options.message) {
          options.message = navigator.mozL10n.get(options.messageL10nId, options.messageL10nArgs);
          options.messageL10nId = null;
          options.messageL10nArgs = null;
        }
        ports.forEach(function (port) {
          port.postMessage(options);
        });
      }, function onConnRejected(reason) {
        console.log('system-toaster is rejected:' + reason);
      });
    }
  }
};
