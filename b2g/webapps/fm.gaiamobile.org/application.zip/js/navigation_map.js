(function(exports) {
  /*the classes of option menu for navigation:
    'group-menu': softkey_panel.js, softkeybar's options
    'contact-prompt': thread_ui.js,the prompt options of phone number or email
  */
  const OPTION_MENU_CLASSES = ['group-menu', 'contact-prompt'];
  const OPTION_MENU = 'option-menu';

  var controls = {};
  var currentContainerID = null;

  var nav_id = 0;
  var _storeFocused = null;
  var _storeFocusId = 0;

  function listViewUpdate(elements) {
    var i=0;
    var id = nav_id;  /*to avoid 'data-nav-id' reproduced with grid*/

    for(i=0; i < elements.length; i++) {
        elements[i].setAttribute('data-nav-id', id);
        elements[i].style.setProperty('--nav-left', -1); //-1: invalid ID
        elements[i].style.setProperty('--nav-right', -1);
        elements[i].style.setProperty('--nav-down', id+1);
        elements[i].style.setProperty('--nav-up', id-1);
        elements[i].setAttribute('tabindex', 0);
        id++;
    }

    //top element
    elements[0].style.setProperty('--nav-up', id-1);
    //bottom element
    elements[elements.length-1].style.setProperty('--nav-down', nav_id);
    nav_id = id;
  };

  function getCurContainerId() {
    return currentContainerID;
  };

  function getCurControl() {
    var control = null;
    var containerId = getCurContainerId();

    if ( containerId ) {
      control = controls[containerId];
    }
    return control;
  };

  function getCurItem() {
    var item = null;
    var curControl = getCurControl();

    if ( curControl ) {
      if ( curControl.index >= 0 &&
        curControl.index < curControl.elements.length ) {
        item = curControl.elements[curControl.index];
      }
    }
    return item;
  };

  function sendIndexEvent(id, index, item, lastitem) {
    var evt = new CustomEvent("index-changed", {
      detail: {
        panel: id,
        index: index,
        focusedItem: item,
        lastItem:lastitem
      },
      bubbles: true,
      cancelable: false
    });

    window.dispatchEvent(evt);
  };

  function setCurIndex(index) {
    var curControl = getCurControl();

    if ( curControl ) {
      if ( index >= -1 && index < curControl.elements.length ){
        curControl.index = index;
        /*broadcoast change event*/
        var focusedItem = (index == -1) ? null : curControl.elements[index];
        var lastItem = _storeFocused;
        if(focusedItem) {
          _storeFocused = focusedItem;
          _storeFocusId = index;
        }

        sendIndexEvent(getCurContainerId(), index, focusedItem, lastItem);
      }
    }
  };

  var NavigationMap = {
    _customWeekFocus: {enable:false, type: ""},

    init: function _init() {
      console.log("NavigationMap init");

      document.addEventListener('focusChanged', function(e) {
        var focusedItem = e.detail.focusedElement;
        console.log("Received event focusChanged: id=" + (focusedItem ? focusedItem.id : null));

        var curControl = getCurControl();
        if ( curControl && curControl.elements ) {
          /*convert to an array*/
          var elements = Array.prototype.slice.call(curControl.elements);
          /*find the index of focused item in current control*/
          var index = elements.indexOf(focusedItem);
          if ( index >= 0 ) {
            /*update index*/
            setCurIndex(index);
          if(StatusManager.status === StatusManager.STATUS_FAV_RENAME)
            favEditor.onRenameFocusChange();

          var input = getCurItem().querySelector('input');
          if(input && !input.classList.contains('hidden'))
            input.focus();
            console.log("current index updated: " + index);
          }
        }
      });

      document.addEventListener('tcl-favlist-changed', function(e) {
        currentContainerID = 'fav-list-container';
        NavigationMap.reset('fav-list-container');
      });

      window.addEventListener('menuEvent', function(e) {
        console.log("menuEvent received: menuVisible = " + e.detail.menuVisible);
        if ( e.detail.menuVisible ) {
          e.detail.softkeyPanel.menu.form.id = OPTION_MENU;  //assign id to option menu for navSetup
          if ( _storeFocused ) {
            _storeFocused.classList.add('hasfocused');
            _storeFocused.classList.remove('focus');
          }
          NavigationMap.optionReset();
        } else {
          if(StatusManager.status === StatusManager.STATUS_FAV_RENAME)
            return;
          if(_storeFocused) {
            _storeFocused.classList.remove('hasfocused');
            _storeFocused.classList.add('focus');
            _storeFocused.focus();
            window.focus();
          }
        }
      });
    },

    setFocus: function _setFocus(id) {

      var curControl = getCurControl();
      if ( !curControl ) {
        console.log("setFocus failed!");
        return;
      }

      console.log("curIndex=" + curControl.index + ", length=" + curControl.elements.length);

      id = id || 0;
      id = (id == 'first') ? 0 :
          ((id == 'last') ? curControl.elements.length-1 : id);

      if (id >=0 && id < curControl.elements.length) {
        /*remove current focus, only one element has focus */
        var focused = document.querySelectorAll(".focus");
        for (var i=0; i < focused.length; i++) {
          focused[i].classList.remove('focus');
        }

        focused = document.querySelectorAll(".hasfocused");
        for (var i=0; i < focused.length; i++) {
          focused[i].classList.remove('hasfocused');
        }

        var toFocused = curControl.elements[id];
        toFocused.setAttribute('tabindex', 1);
        toFocused.classList.add('focus');

        toFocused.focus();
        window.focus();
      }

      //id may be -1
      setCurIndex(id);
    },

    /*setup navigation for the items that query from a container.
    @paramters:
        containerId: the id of the container element, undefined: coantainer = body
        query: the condition to query the items
    */
    navSetup: function _setup(containerId, query) {
      var elements = null;
      console.log("NavigationMap navSetup: containerId=" + containerId + ", qurey=" + query);

      var container = (containerId == undefined) ? document.body :
                   document.getElementById(containerId);

      if ( container ) {
        elements = container.querySelectorAll(query);
        if (elements.length > 0){
          switch(containerId) {
            case OPTION_MENU:
            case 'fav-list-container':
              listViewUpdate(elements);
              break;
            default:
              break;
          }

        }
      }

      if ( containerId && elements ) {
        if ( !controls[containerId] ) {
          controls[containerId] = {};
          controls[containerId].index = (elements.length > 0) ? 0 : -1;
        }
        controls[containerId].elements = elements;
      }
    },

    reset: function _reset(id) {
      console.log("NavigationMap reset: id=" + id);
      var index = 0;
      if(controls[id] && (controls[id].index > -1) ) {
          index = controls[id].index;
      }
      this.navSetup(id, ".focusable");
      index = (index > controls[id].elements.length - 1) ? controls[id].elements.length - 1 : index;
      NavigationMap.setFocus(index);
      this.scrollToElement(this.getCurItem(), {key: 'ArrowDown'});
    },

    /*option menu*/
    optionReset: function _reset() {
      console.log("optionReset");

      this.navSetup(OPTION_MENU, '.menu-button');

      /*remove current focus, only one element has focus */
      var focused = document.querySelectorAll(".focus");
      for (var i=0; i < focused.length; i++) {
        focused[i].classList.remove('focus');
      }

      var toFocused = controls[OPTION_MENU].elements[0];
      if ( toFocused ) {
        toFocused.setAttribute('tabindex', 1);
        toFocused.classList.add('focus');

        toFocused.focus();
        window.focus();
      }
    },

    scrollToElement: function _scroll(bestElementToFocus, evt) {
      console.log("NavigationMap scrollToElement");
      if(!bestElementToFocus) return;
      function isVisible(bestElementToFocus) {
        if (bestElementToFocus.offsetWidth === 0 ||
            bestElementToFocus.offsetHeight === 0) {
          return false;
        }
        var height = document.documentElement.clientHeight - 40;
        var rects = bestElementToFocus.getClientRects();
        for (var i = 0, l = rects.length; i < l; i++) {
          var r = rects[i];
          if (r.bottom > 0 && r.bottom <= height && r.top >= 120) {
            return true;
          }
        }
        return false;
      }
      if(!isVisible(bestElementToFocus)) {
        console.log(evt.key);
        switch (evt.key) {
          case 'ArrowDown':
            bestElementToFocus.scrollIntoView(false);
            break;
          case 'ArrowUp':
            bestElementToFocus.scrollIntoView(true);
            break;
        }
      }
    },

    getCurItem: function() {
      return getCurItem();
    },

    getCurIndex: function() {
      var curControl = getCurControl();
      if (curControl) {
        if (curControl.index >= 0 &&
        curControl.index < curControl.elements.length) {
          return curControl.index;
        }
      }
    }
  };

  exports.NavigationMap = NavigationMap;

})(window);
