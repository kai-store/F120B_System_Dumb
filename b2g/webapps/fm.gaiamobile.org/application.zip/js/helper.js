
(function(win){var timerID=null;var isLongPress=false;window.addEventListener('keyup',function(e){if(!($("antenna-warning").hidden&&$("airplane-mode-warning").hidden)){return;}
var isRtl='rtl'===document.documentElement.dir;var arrowKeys=isRtl?['ArrowRight','ArrowLeft']:['ArrowLeft','ArrowRight'];switch(e.key){case"ArrowRight":case"ArrowLeft":if(FMSoftkeyPanel.menuVisible())
return;if(StatusManager.status==StatusManager.STATUS_MAIN_PLAYING){clearTimeout(timerID);timerID=null;if(!isLongPress){var freq=mozFMRadio.frequency;freq=e.key===arrowKeys[0]?freq-0.1:freq+0.1;if(e.key===arrowKeys[0]&&freq<mozFMRadio.frequencyLowerBound){mozFMRadio.seekDown();}else if(e.key===arrowKeys[1]&&freq>mozFMRadio.frequencyUpperBound){mozFMRadio.seekUp();}else{mozFMRadio.setFrequency(freq);}}else{mozFMRadio.cancelSeek();}
isLongPress=false;}
break;case"Clear":if(StatusManager.status==StatusManager.STATUS_FAV_RENAME){var curItem=NavigationMap.getCurItem();var input=curItem.querySelector('input');var name=input.value;var selectionStart=input.selectionStart;input.value=name.substr(0,selectionStart-1)+name.substr(selectionStart);input.setSelectionRange(selectionStart-1,selectionStart-1);}
break;case"Enter":case"Accept":case"Shift":case"Call":if(StatusManager.status==StatusManager.STATUS_FAV_RENAME){favEditor.saveRename();}
break;}});function startStationScan(key){if(timerID){var request,isRtl='rtl'===document.documentElement.dir;if(isRtl&&key==='ArrowLeft'){request=mozFMRadio.seekUp();}else if(isRtl&&key==='ArrowRight'){request=mozFMRadio.seekDown();}else{request=(key==='ArrowLeft')?mozFMRadio.seekDown():mozFMRadio.seekUp();}
req.onsuccess=function(){setTimeout(function(){startStationScan(key);},1500);}}}
window.addEventListener('keydown',function(e){if(!($("antenna-warning").hidden&&$("airplane-mode-warning").hidden)){return;}
if(FMSoftkeyPanel.menuVisible())
return;switch(e.key){case"Backspace":case"BrowserBack":switch(StatusManager.status){case StatusManager.STATUS_FAV_RENAME:e.preventDefault();favEditor.undoRename();break;case StatusManager.STATUS_FAV_EDITING:e.preventDefault();favEditor.switchEditMode();break;case StatusManager.STATUS_MAIN_NO_PLAY:beforeLeaving();break;case StatusManager.STATUS_MAIN_PLAYING:beforeLeaving();break;}
break;case'EndCall':beforeLeaving();break;case"ArrowRight":case"ArrowLeft":if(StatusManager.status==StatusManager.STATUS_MAIN_PLAYING){if(!mozFMRadio.enabled){enableFMRadio(frequencyDialer.getFrequency());}
if(timerID===null){timerID=setTimeout(function(){isLongPress=true;startStationScan(e.key);},500);}}
break;case'ArrowUp':StatusManager.requestVolume('up');break;case'ArrowDown':StatusManager.requestVolume('down');break;}});function beforeLeaving(){var softkeyInit=true;if($("antenna-warning").hidden==false||$("airplane-mode-warning").hidden==false){softkeyInit=false;}
if(softkeyInit&&FMSoftkeyPanel.menuVisible()){window.dispatchEvent(new CustomEvent("menuChangeEvent",{detail:{action:'closeMenu'}}));}
NavigationMap.setFocus(0);if([StatusManager.STATUS_FAV_RENAME,StatusManager.STATUS_FAV_EDITING].contains(StatusManager.status)){if(StatusManager.status===StatusManager.STATUS_FAV_RENAME){favEditor.undoRename();}
favEditor.switchEditMode();}}})(window);