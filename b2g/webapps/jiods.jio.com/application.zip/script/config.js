var init_config_settings = {
	"Login Parameters":
	{
		"URL":"www.example.com", 	    
		"Username":"test", 
		"Password":"test"   
	},			
	"Upload characteristics":
	{
		"Pseudo random time":[1, 4],
		"MQTTServer_IP":"jpdp.jpdc.jiophone.net",
		"MQTT_port":"9797",
		"Username":"jiophonedata",
		"Password":"jiophonedata@123",
		"Client ID":"testQoS1Consumer",
		"Network_Event_Topic":"jiophonedata/+/networkData",
		"Device_Event_Topic":"jiophonedata/+/deviceData",
		"Application_Event_Topic":"jiophonedata/+/appData",
		"Network_Counter_Topic":"jiophonedata/+/networkevtCounter",
		"Device_Counter_Topic":"jiophonedata/+/deviceevtCounter",
		"Application_Counter_Topic":"jiophonedata/+/appevtCounter"
	},
	"DC_enable": 0x00000001,
	"CD": 0x00003DFF,
	"ND": 0x03008081,
	"NE": 0x000003CC,
	"NC": 0x00000003,
	"DD": 0x000000F6,
	"DE": 0x00006F50,
	"DC": 0x00000001,
	"AD": 0x00000001,
	"AE": 0x00000006
};
