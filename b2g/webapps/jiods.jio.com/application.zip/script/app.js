var lang = navigator.language;

if(lang!="en-US" && lang!="hi-IN"){
    lang="en-US";
}

readTextFile("data.json", function(text){
    var data = JSON.parse(text);
      document.getElementById("title").innerHTML=data[lang].title;
      document.getElementById("content1").innerHTML=data[lang].content1;
});

function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}

var store_name = navigator.getDataStores('JioDSstore');
store_name.then(function(stores) {
	stores[0].put(init_config_settings,1).then(function(id) {
		console.log("jioDS datastore updated");
	});	
    stores[0].get(1).then(function(app_config_settings) {
        		console.log(app_config_settings.DC_enable);
	});
});

setTimeout(function(){ App_close() }, 5000);
function App_close(){
    window.close();
}