function AppMode(){}

// AppType definitions
AppMode.APP_TYPE_JVC = "JVC";
AppMode.APP_TYPE_JC = "JC";
AppMode.APP_TYPE_JCL = "JCL";
AppMode.APP_TYPE_JMS = "JMS";
AppMode.APP_TYPE_JSDK = "JSDK";
AppMode.APP_TYPE_DESKTOP = "DESKTOP";
AppMode.APP_TYPE_MOBILE = "MOBILE";
AppMode.APP_TYPE_TIZEN = "TIZEN";

//App is in JMS Mode
 
AppMode.APP_VERSION_JMS = 'v1.1.37';

//AppModes = JVC | JC | JCL | JMS | JSDK | DESKTOP | MOBILE | TIZEN

AppMode.TYPE  = AppMode.APP_TYPE_JMS;
AppMode.FINAL_VERSION  = AppMode.APP_VERSION_JMS;

