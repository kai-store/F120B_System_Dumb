import history from './shared/my_history';
import JioChatSDK from './sdk/jio-sdk';
import ReactGA from 'react-ga';

import JioBaseComponent from './shared/jioBaseComponent';
import OnBoardingStore from './data/onboarding-store';
import ChatListStore from './data/chatlist-store';
import GroupListStore from './data/groupList-store';

export default class AppLifecycle extends JioBaseComponent {
    start() {
        console.log('[App Lifecycle] Lifecycle start.');

        this.sdkObj = JioChatSDK.getInstance();
        this.isDeviceMode = this.sdkObj.isDeviceMode();
        this.onboardingModel = OnboardingModel.getInstance();  
        this.onboardingStore = OnBoardingStore.getInstance();      
        this.chatListStore = ChatListStore.getInstance();

        if (AppMode.TYPE == AppMode.APP_TYPE_JVC) {
            this.config_app_name = 'RJIL_JioVideocall';
        } else if (AppMode.TYPE == AppMode.APP_TYPE_JMS) {
            this.config_app_name = 'RJIL_JioChat';
        } else if (AppMode.TYPE == AppMode.APP_TYPE_JCL) {
            this.config_app_name = 'RJIL_JioChannels';
        } else {
            this.config_app_name = 'RJIL_JioChat';
        }
    }

    setAppLifecycle() {
        console.log('[App Lifecycle] Lifecycle init.');
        
        var that = this;
        this.sdkObj.setSDKLifeCycle({
            onSIMChanged: function(callback){
                if (window.isReleaseBuild && JioChatSDK.getInstance().isDeviceMode()) {
                    if(window.silentPushCall){
                        callback.onSuccess(false);
                        return;
                    }

                    var config = new Config();
                    config.app_name = that.config_app_name;

                    initSsoConfig(config, function (onCallBack) {
                        console.log('[App Lifecycle] setSIMChanged onSuccess. user changed '+ onCallBack.USER_CHANGED);
                        callback.onSuccess(onCallBack.USER_CHANGED);
                        /**  Jio analytic device info and geolocation method related code */                        
                        window.onSimChanged = onCallBack.USER_CHANGED;
                        JioAnalytics.getInstance().geoFindMe(function(flag){
                        });
                        // debugger;
                        if (AppMode.TYPE !== AppMode.APP_TYPE_DESKTOP && AppMode.TYPE !== AppMode.APP_TYPE_MOBILE) {
                            JioAnalytics.getInstance().getDeviceInformation(function(flag){
                                if(flag){   
                                    window.deviceInfoLoaded = true;
                                    JioAnalytics.getInstance().processQueue();  
                                }
                            });
                        } 
                    }, function (onInitError) { 
                        console.log('[App Lifecycle] setSIMChanged onError. user changed.');
                        callback.onError(false);
                        /**  Jio analytic device info and geolocation method related code */
                        window.onSimChanged = false;
                        JioAnalytics.getInstance().geoFindMe(function(flag){
                        });
                        // debugger;
                        if (AppMode.TYPE !== AppMode.APP_TYPE_DESKTOP && AppMode.TYPE !== AppMode.APP_TYPE_MOBILE) {
                            JioAnalytics.getInstance().getDeviceInformation(function(flag){
                                if(flag){   
                                    window.deviceInfoLoaded = true;
                                    JioAnalytics.getInstance().processQueue();
                                }
                            });
                        } 
                    });
                } else {
                    callback.onSuccess(false);
                }
            },
			onReqPush: function (callback) {
                if (!that.isDeviceMode) {
                    callback.onError();
                    return;
                }

                var pushModel = new PushModel();
                pushModel.initilizeSW(function(data) { 
                    // subscription object is already available from the device       
                    if (data) { 
                        that.initPushObject(data, callback);
                        return;
                    } 
                    //Otherwise.
                    pushModel.registerDevice(function(pushObj) {
                        that.initPushObject(pushObj, callback);
                    });
                    
                });
                // this.onboardingStore.getDeviceInfoLDB(this.deviceId);
                // this.onboardingStore.on('GetDeviceInfoLDBCallback', (data) => {            
                //     if (!data) {
                //         this.registerDeviceForPush();
                //     } else {
                //         console.log('[View::Splash] Device already registered for Push notifications.');    
                //         this.initDeviceTokenModel(data);
                //         this.verifyUserLogin();
                //     }
                // });
			},
            onReqSSOToken: function (callback) {
                if (!that.isDeviceMode) {
                    callback.onError();
                    return;
                } 

                if ((!navigator.onLine) && (localStorage.getItem('ZLAVeryFirstTime') != 'false')) {
                    var msg = 'there-is-no-internet-connection-available-please-connect-to-internet';
                    that.showAlertMessageHeader('message', msg, function() {
                        // no action required.
                    });
                }

                // var successResponse = {"KEY_SSO_TOKEN":"AQIC5wM2LY4SfcxD6kQXTZeaqDkU6E11Cfl8hir7y_jOxCY.*AAJTSQACMDIAAlNLABQtODk2NjE2ODU2NDczMjIzMzMyMwACUzEAAjM5*","KEY_LB_COOKIE":"326","KEY_MSISDN":"918217634707","KEY_USER":{"commonName":"Narayan Rao Chavan","ssoLevel":"10","subscriberId":"5010605950"},"KEY_DEVICE_INFO":{"KEY_IMEI":"9115784000063701","KEY_IMSI":"405861061939249","KEY_MSISDN":"918217634707"},"USER_CHANGED":false}
                // ZLA SSO 
                var handleError = false,
                    forceSSo = false; 
                if (window.isReleaseBuild) {
                    var config= new Config();
                    config.app_name = that.config_app_name;
                    
                    console.log('[App Lifecycle] SSO call config. '+ JSON.stringify(config));
                    initSsoConfig(config, function (onCallBack) {
                        console.log('[App Lifecycle] SSO config. Is user changed '+ onCallBack.USER_CHANGED);
                        startSSOEngine(handleError, forceSSo, function(successResponse) {
                            console.log('[App Lifecycle] SSO first line '+ JSON.stringify(successResponse));
                            debugger;
                            if(AppMode.TYPE == AppMode.APP_TYPE_JVC || AppMode.TYPE == AppMode.APP_TYPE_JCL || AppMode.TYPE == AppMode.APP_TYPE_JMS){
                                ReactGA.event({
                                    category: 'Successful login',
                                    action: 'login',
                                    label: 'ZLA login success'
                                });
                                
                                /**** Jio analytics code */
                                var analyticDataObj = {
                                    "eventName" : "successful_login",
                                    "eventType" : "events",
                                    "dateTime" : new Date()
                                };
                                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
                                
                                var analyticDataObj1 = {
                                    "eventName" : "new_registration",
                                    "eventType" : "events",
                                    "dateTime" : new Date()
                                };
                                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj1);
                            }
                            // Clear local storage on Fresh Login
                            that.chatListStore.deleteLocalStorage();

                            var ssoObj = successResponse;
                            console.log('[App Lifecycle] SSO Success: '+ JSON.stringify(ssoObj));
        
                            that.phoneNumber = '+'+ ssoObj.KEY_MSISDN;     
                            that.userPhoneNo = that.phoneNumber;
                            window.deviceId = that.phoneNumber;
                            
                            // added this addPhonenumberLDB method in JCSSO
                            // that.addPhonenumberLDB();
                            
                            var ssoObject = JCSSO.getJCSSOObject(ssoObj);
        
                            console.log('[App Lifecycle] Lifecycle setting SSO.'+ JSON.stringify(ssoObject));
                            callback.onSuccess(ssoObject);
                        }, function(errorResponse) {
                            if(AppMode.TYPE == AppMode.APP_TYPE_JVC || AppMode.TYPE == AppMode.APP_TYPE_JMS || AppMode.TYPE == AppMode.APP_TYPE_JCL){
                                ReactGA.event({
                                    category: 'ZLA login',
                                    action: 'login',
                                    label: 'ZLA login failed'
                                });
                                /**** Jio analytics code */
                                var analyticDataObj = {
                                    "eventName" : "zla_loginerror",
                                    "eventType" : "events",
                                    "dateTime" : new Date()
                                };
                                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);

                                var analyticDataObj1 = {
                                    "eventName" : "failed_login",
                                    "eventType" : "events",
                                    "dateTime" : new Date()
                                };
                                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj1);
                            }
                            console.log('[View::Splash] SSO Error: '+ errorResponse.jioErrorCode + ' '+errorResponse.jioErrorMessage); 
        
                            // Not a Jio sim user  
                            console.log('[App Lifecycle] Lifecycle setting SSO Error.');
                            callback.onError();
                        }, false);   

                    }, function (onInitError) { 
                        if(AppMode.TYPE == AppMode.APP_TYPE_JVC || AppMode.TYPE == AppMode.APP_TYPE_JCL || AppMode.TYPE == AppMode.APP_TYPE_JMS){
                            ReactGA.event({
                                category: 'ZLA login',
                                action: 'login',
                                label: 'ZLA login failed'
                            });
                            /**** Jio analytics code */
                            var analyticDataObj = {
                                "eventName" : "zla_loginerror",
                                "eventType" : "events",
                                "dateTime" : new Date()
                            };
                            JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
                            
                            var analyticDataObj1 = {
                                "eventName" : "failed_login",
                                "eventType" : "events",
                                "dateTime" : new Date()
                            };
                            JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj1);
                        }
                        console.log('[App Lifecycle] SSO config error. '+ JSON.stringify(onInitError));
                        var msg = 'unable-to-load-datastore-please-reboot-device-and-try-again';
                        that.showAlertMessageHeader('message', msg, function() {
                            // no action required.
                        });
                        
                        callback.onError();
                    });
                } else {
                    var config= new Config();
                    config.app_name='RJIL_JioChat';
                    initSsoConfig(config);
    
                    startSSOEngine(handleError, forceSSo, function(successResponse) {
                        // Clear local storage on Fresh Login
                        that.chatListStore.deleteLocalStorage();
                        
                        var ssoObj = successResponse;
                        console.log('[View::Splash] SSO Success: '+ JSON.stringify(ssoObj));
    
                        that.phoneNumber = '+'+ ssoObj.KEY_MSISDN;     
                        that.userPhoneNo = that.phoneNumber;
                        window.deviceId = that.phoneNumber;
                        
                        // added this addPhonenumberLDB method in JCSSO
                        // that.addPhonenumberLDB();

                        var ssoObject = JCSSO.getJCSSOObject(ssoObj);
    
                        console.log('[App Lifecycle] Lifecycle setting SSO.'+ JSON.stringify(ssoObject));
                        callback.onSuccess(ssoObject);
                    },function(errorResponse) {
                        console.log('[View::Splash] SSO Error: '+ errorResponse.jioErrorCode + ' '+errorResponse.jioErrorMessage); 
    
                        // Not a Jio sim user  
                        console.log('[App Lifecycle] Lifecycle setting SSO Error.');
                        callback.onError();
                    }, false);   
                }
            },
            reqManualLogin: function() {
                console.log('[App Lifecycle] Lifecycle reqManualLogin called.');
                that.navToRegister();
            },
            onReqDeviceInfo: function (callback) {
                if (!that.userPhoneNo) {
                    that.userPhoneNo = that.onboardingModel.getUserPhoneNo();
                }
                
                var _deviceID = that.userPhoneNo;
                //For desktop.
                if (!that.isDeviceMode) {
                    var deviceId = localStorage.getItem(AppConstants.SKEY_DEVICE_ID);
                    if(deviceId){
                        _deviceID = deviceId;
                    }else{
                        _deviceID = UUID.randomUUIDHex();
                        localStorage.setItem(AppConstants.SKEY_DEVICE_ID, _deviceID);
                    }
                    window.deviceId = _deviceID;
                }

                if(!_deviceID || _deviceID == ""){
                    _deviceID = UserModel.getInstance().getPhoneNumber();
                    console.log("[onReqDeviceInfo] Reqing Device id frm usermodel: " + _deviceID);
                }

                var deviceInfo = new JCDeviceInfo();
                deviceInfo.setDeviceID(_deviceID); // keeping phone no. as a device id
                
                console.log('[App Lifecycle]  Lifecycle setting device info.'+ JSON.stringify(deviceInfo));
				callback.onSuccess(deviceInfo);
			},
            onProfile: function (profileObj) {
                that.addSSOProfiletoLDB(profileObj);
                console.log('[App Lifecycle] Lifecycle profile called.'+ JSON.stringify(profileObj));
            },
            onStart: function () {
                console.log('[App Lifecycle] Lifecycle onStart called.');
               
                if (localStorage.getItem('ZLAVeryFirstTime') != 'false') {
                    localStorage.setItem('ZLAVeryFirstTime', 'false');
                    that.navToWelcomeZLAUser();                
                } else {
                    if (window.location.href.indexOf('splash') > -1) { // redirect only if you are in splash
                        that.navToHome();                    
                    } else {
                        // keep the same page
                    }
                }       
            },
            onExit: function () {
                console.log('[App Lifecycle] Lifecycle onExit called.');
            },
            onError: function (errorResponse) {
                console.log('[App Lifecycle] Lifecycle onError called.');
                that.navToRegister();
            }
        });
    }

    initPushObject(pushSubscriptionObj, callback){
        var pushToken = PushToken.getInstance();
        if(pushSubscriptionObj.endpoint){
            pushToken.setEndPoint(pushSubscriptionObj.endpoint);
        }
        if(pushSubscriptionObj.keys){
            pushToken.setAuth(pushSubscriptionObj.keys.auth);
            pushToken.setPrivateString(pushSubscriptionObj.keys.p256dh);
        }
        // not required
        // pushToken.setDeviceID(that.userPhoneNo); // keeping phone no. as a device id

        console.log('[App Lifecycle] Lifecycle setting push object.'+ JSON.stringify(pushToken));
        callback.onSuccess(pushToken);
    }

    // add profile to LDB
    addSSOProfiletoLDB(profileObj) {
        var gender = profileObj.gender;
        if (gender === null || gender === undefined || gender === 'null') {
            gender = 2; // unknown
        }
        var profileData = {
            name: profileObj.name,
            phno: profileObj.mobileNo,
            selGender: gender
        };

        var that = this;
        this.onboardingStore.addProfileLDB(profileData, function(success){
            console.log('[App Lifecycle] User profile added in LDB.');
            // no action required
        });
    }

    /** all navigations */
    navToRegister() {
        if(AppMode.TYPE=="DESKTOP"){
            this.historyReplace('/desktopRegistrationView');
        }
        // else if(AppConstants.VAmessage != undefined && AppConstants.VAmessage != ""){
		//     this.historyReplace('/replyView/3/1,114,-55,-78,-117/127');
        // }
        // else if(AppConstants.voiceAssistant == true){
        //     this.historyReplace('/chatDetail/3/1,114,-55,-78,-117/PTYPE_CONTACTS_VIEW')
        // }
        else if( JioChatSDK.getInstance().getSDKMode() == JCSDKConstants.SDK_DEBUG_MODE){
            this.historyReplace('/register')
        }
        else{
            // this.historyReplace('/register');
            var msg = 'sorry-there-was-a-problem-please-close-and-re-launch-the-app';
            if (!navigator.onLine) {
                msg = 'there-is-no-internet-connection-available-please-connect-to-internet';
            }

            this.showAlertMessageHeader('message', msg, function() {
                // no action required.
            });
        }
    }

    navToWelcomeZLAUser() {

        // debugger;
        JioChatSDK.getInstance().setGlobalCallback();

        this.historyReplace('/welcomeZLAUser');
    }

    navToHome() {

        // debugger;
        JioChatSDK.getInstance().setGlobalCallback();

        var that = this;
        var hasPush = false, pushData;
        try{
            hasPush = ClientPushModel.getInstance().hasPush();
            pushData = ClientPushModel.getInstance().getPushData();
        }catch(ex){
            console.log("EXceptION: " + ex);
        }

        // if (!window.isFromPush && !this.pushData) {
        if(hasPush == true && pushData && AppMode.TYPE == AppMode.APP_TYPE_JVC){
            AppConstants.silentPushKey = true;
        }
        // else {
        if (AppMode.TYPE == AppMode.APP_TYPE_DESKTOP) {
            this.historyReplace('/desktopHomeView');
        }  else if(AppMode.TYPE == AppMode.APP_TYPE_MOBILE){
            this.historyReplace('/mobileHomeView');
        } else if (AppMode.TYPE == AppMode.APP_TYPE_JMS) {
            this.historyReplace('/chatList');
        } else if (AppMode.TYPE == AppMode.APP_TYPE_JCL) {
            this.historyReplace('/recentChannelsView/' + AppConstants.PTYPE_CONTACTS_VIEW);
        } else if(AppMode.TYPE == AppMode.APP_TYPE_JVC) {
            that.historyReplace('/home');           
        } else {
            this.historyReplace('/home');
        }

        // else if(AppConstants.VAmessage != undefined && AppConstants.VAmessage != ""){
        //     this.historyReplace('/replyView/3/1,114,-55,-78,-117/127');
        // } else if(AppConstants.voiceAssistant == true){
        //     this.historyReplace('/chatDetail/3/1,114,-55,-78,-117/PTYPE_CONTACTS_VIEW')
        // }

        // } 
        // else {
        //     var that = this;
        //     setTimeout(function() {
        //         that.navToPushPage();
        //     }, 10);
        // }
    }

    // navToPushPage() {
    //     if (AppMode.TYPE == "JVC") {
    //         AppConstants.silentPushKey = true;
    //         // console.log("video call push key:",AppConstants.silentPushKey);
    //         console.log("video call push key:", this.pushData.KEY);
    //         console.log("video call push DATA:", JSON.stringify(this.pushData));
    //         this.historyReplace('/home');
    //         return;
    //     }

    //     // var msgType = this.pushData.Message_Type;
    //     // var userId = this.pushData.UserId;
    //     var pushData = ClientPushModel.getInstance().getPushData();
    //     var msgType = pushData.Message_Type;
    //     var userId = pushData.UserId;

    //     if (msgType == 1) { // single chat
    //         msgType = 2;
    //     } else if (msgType == 2) { // group chat
    //         msgType = 1;
    //     }
        
    //     console.log("userId : "+userId+" >>>>>msgType : "+msgType);
    //     if (msgType && userId) {
    //         this.historyReplace('/chatDetail/'+ msgType +'/'+ userId + '/' + AppConstants.PTYPE_PUSH_NOTIFICATION);
    //     } else {
    //         this.historyReplace('/home');
    //     }
    // }

    // history stack
    historyReplace(page) {
        var that = this;
        setTimeout(function() {
            that.clearAllEmits();
            if(AppMode.TYPE=="JVC" || AppMode.TYPE == AppMode.APP_TYPE_JCL){
                ReactGA.pageview(page);
            }
            if(!window.silentPushCall){
                history.replace(page);
                if(!(AppMode.TYPE=="DESKTOP") && !(AppMode.TYPE=="MOBILE")){
                    var softkeyPanelElem = document.getElementById('softkeyPanel');
                    if (softkeyPanelElem) {
                        softkeyPanelElem.setAttribute('style', 'display: revert;');   
                        document.getElementById('splash_text').style.display = 'none';
                    }
                }
            }           
           
        }, 10);
    }

    clearAllEmits() {
        if (this.onboardingStore.listeners) {
            this.onboardingStore.listeners.clear();
        }
    }
}

AppLifecycle.getInstance = function () {
    if (!AppLifecycle.instance) {
        AppLifecycle.instance = new AppLifecycle();
        AppLifecycle.instance.start();
    }
    return AppLifecycle.instance;
}
// window.AppLifecycle = AppLifecycle;