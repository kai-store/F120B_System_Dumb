import React from 'react';
import ReactDOM from 'react-dom';
import EnhanceAnimation from './lib/enhance-animation'
import RegistrationView from './component/onboarding/registration-view';
import SplashView from './component/onboarding/splash-screen';

import CountryListView from './component/onboarding/countrylist-view';
import ChatListView from './component/chat/chatlist-view';
import ChatDetailView from './component/chat/chatdetail-view';

import BroadcastDetailView from './component/chat/broadcast-detail-view';
import MultiRichMedia from './component/chat/multi-richmedia-view';

import AddProfileView from './component/onboarding/addprofile-view';
import GenderList from './component/onboarding/select-gender';

import OtpVerifyView from './component/onboarding/otp-verify-view';
import CaptchaView from './component/onboarding/captcha-view';
import CameraView from './component/onboarding/camera-view';

import ContactsView from './component/contacts/contacts-view';
import BlockedContacts from './component/contacts/blocked-contacts';

import TermsView from './component/onboarding/terms-condition';
import WelcomeZLAUserView from './component/onboarding/welcomeZLAuser-view';
import MoreView from './component/more/more-list';

import SettingList from './component/settings/setting-list';
import ChatSettings from './component/settings/chat-settings';
import SecurityPolicySettings from './component/settings/security-policy-settings';
import Account from './component/settings/account';
import About from './component/settings/about';
import FAQ from './component/settings/faq';
import Feedback from './component/settings/feedback';
import Personalization from './component/settings/personalization';
import LanguageChange from './component/settings/language-change';
import DoNotDisturb from './component/settings/donot-disturb';
import DNDFromList from './component/settings/dnd-from';
import DNDToList from './component/settings/dnd-to';
import DelaySending from './component/settings/delay-sending';

import MyProfileView from './component/myprofile/myprofile-view';
import EditProfile from './component/myprofile/edit-profile';
import MoodView from './component/myprofile/mood-view';
import ProfilePreview from './component/myprofile/profile-preview';


import Invite from './component/contacts/invite-friend';
import FriendProfile from './component/contacts/friend-profile';

import CreateGroup from './component/group/create-group';
import GroupInformation from './component/group/group-information';
import GroupList from './component/group/group-list';

import ReplyView from './component/chat/reply-view';
import EmojiView from './component/emoji/emoji-view';
import ReadMoreView from './component/chat/readmore-view';
import ImagePreviewView from './component/chat/image-preview';
import AudioRecordView from './component/chat/audio-record-view';
import BroadcastReplyView from './component/chat/broadcast-reply-view';

import RecentListView from './component/chat/recentvideo-view';

//Phase 3
import LocationView from './component/location/location-view';
import StickersStoreView from './component/sticker/stickersstore-view';
import Stickers from './component/sticker/stickers';
import MyStickers from './component/sticker/my-stickers';
import StickerSendView from './component/sticker/stickers-send-view';
import RotateImageView from './component/chat/rotate-image-view';

import FilesList from './component/sharefiles/fileslist-view';
import BroadcastRecipientView from './component/chat/broadcast-recipients';

const routes = [
  {
    path: '/splash',
    action:() => {
      let Composed = EnhanceAnimation(SplashView, 'left-to-center', 'center-to-left');
      return <Composed ref={"splash"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/register',
    action:() => {
      let Composed = EnhanceAnimation(RegistrationView, 'left-to-center', 'center-to-left');
      return <Composed ref={"register"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/country',
     action:() => {
      let Composed = EnhanceAnimation(CountryListView, 'left-to-center', 'center-to-left');
      return <Composed ref="countrylist" exitOnClose={true} />
    }
  },
  {
    path: '/addprofile',
     action:() => {
      
      let Composed = EnhanceAnimation(AddProfileView, 'left-to-center', 'center-to-left');
      return <Composed ref={"addprofile"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
     }
  },
   {
    path: '/genderList',
     action:() => {
      let Composed = EnhanceAnimation(GenderList, 'left-to-center', 'center-to-left');
      return <Composed ref={"genderList"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
     }
  },  
  {
    path: '/verify',
     action:() => {
      let Composed = EnhanceAnimation(OtpVerifyView, 'left-to-center', 'center-to-left');
      return <Composed ref={"otpverify" + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/captchaView/:source',
     action:(params) => {
      let Composed = EnhanceAnimation(CaptchaView, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"captchaView/" + params.source + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
    {
    path: '/camera',
     action:() => {
      let Composed = EnhanceAnimation(CameraView, 'left-to-center', 'center-to-left');
      return <Composed ref="cameradummy" exitOnClose={true} />
    }
  },
   {
    path: '/contacts/:id/:groupId',
     action:(params) => {
      let Composed = EnhanceAnimation(ContactsView, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"contacts/"+ params.id + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/blockedContacts',
     action:() => {
      let Composed = EnhanceAnimation(BlockedContacts, 'left-to-center', 'center-to-left');
      return <Composed ref="blockedContacts" exitOnClose={true} />
    }
  },
  {
    path: '/friendProfile/:isJioUser',
     action:(params) => {
      let Composed = EnhanceAnimation(FriendProfile, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"friendProfile" + params.isJioUser + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
   {
    path: '/invite/:id',
     action:(params) => {
      let Composed = EnhanceAnimation(Invite, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"invite" + params.id} exitOnClose={true} />
    }
  },
  {
    path: '/createGroup/:id/:groupId/:groupName',
     action:(params) => {
      let Composed = EnhanceAnimation(CreateGroup, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"createGroup" + ( new Date().getTime() / 3000 ) } exitOnClose={true} />
    }
  },
  {
    path: '/groupInformation/:sessionType/:id',
     action:(params) => {
      let Composed = EnhanceAnimation(GroupInformation, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"groupInformation" + params.id + new Date().getTime()} exitOnClose={true} />
    }
  },
  {
    path: '/groupList/:id',
     action:(params) => {
      let Composed = EnhanceAnimation(GroupList, 'left-to-center', 'center-to-left');
      return <Composed {...params} ref={"groupList" + new Date().getTime()} exitOnClose={true} />
    }
  },
 {
    path: '/terms',
    action:() => {
      let Composed = EnhanceAnimation(TermsView, 'left-to-center', 'center-to-left');
      return <Composed ref='terms' exitOnClose={true} />
    }
  },
  {
    path: '/welcomeZLAUser',
    action:() => {
      let Composed = EnhanceAnimation(WelcomeZLAUserView, 'left-to-center', 'center-to-left');
      return <Composed ref='welcomeZLAUser' exitOnClose={true} />
    }
  },
  {
    path: '/chatList',
    action: (params) => {
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      let Composed = EnhanceAnimation(ChatListView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"chatlist_" + userId} exitOnClose={true} />
    }
  },
  {
    path: '/chatDetail/:id/:number/:pageType',
    action: (params) => {
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      if(!userId || userId == "") userId = "";
      let Composed = EnhanceAnimation(ChatDetailView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={ "chatdetail_" + userId + "_" + params.number } exitOnClose={true} />
    }
  },
  {
    path: '/broadcastDetailView',
    action: () => {
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      if(!userId || userId == "") userId = "";
      let Composed = EnhanceAnimation(BroadcastDetailView, 'right-to-center', 'center-to-right');
      return <Composed ref={"broadcastDetailView_" + userId} exitOnClose={true} />
    }
  },
  {
    path: '/more',
    action: () => {
      let Composed = EnhanceAnimation(MoreView, 'right-to-center', 'center-to-right');
      return <Composed ref="more" exitOnClose={true} />
    }
  },
  {
    path: '/settings',
    action: () => {
      let Composed = EnhanceAnimation(SettingList, 'right-to-center', 'center-to-right');
      return <Composed ref="setting" exitOnClose={true} />
    }
  },
  {
  path: '/chatSettings',
    action: () => {
      let Composed = EnhanceAnimation(ChatSettings, 'right-to-center', 'center-to-right');
      return <Composed ref="chatSettings" exitOnClose={true} />
    }
  },
  {
  path: '/securityPolicySettings',
    action: () => {
      let Composed = EnhanceAnimation(SecurityPolicySettings, 'right-to-center', 'center-to-right');
      return <Composed ref="securityPolicySettings" exitOnClose={true} />
    }
  },
   {
    path: '/languageChange',
    action: () => {
      let Composed = EnhanceAnimation(LanguageChange, 'right-to-center', 'center-to-right');
      return <Composed ref={"languageChange" + new Date()} exitOnClose={true} />
    }
  },
  {
  path: '/about',
    action: () => {
      let Composed = EnhanceAnimation(About, 'right-to-center', 'center-to-right');
      return <Composed ref="about" exitOnClose={true} />
    }
  },
  {
  path: '/faq',
    action: () => {
      let Composed = EnhanceAnimation(FAQ, 'right-to-center', 'center-to-right');
      return <Composed ref="faq" exitOnClose={true} />
    }
  },
  {
  path: '/feedback',
    action: () => {
      let Composed = EnhanceAnimation(Feedback, 'right-to-center', 'center-to-right');
      return <Composed ref="feedback" exitOnClose={true} />
    }
  },
  {
   path: '/account',
    action: () => {
      let Composed = EnhanceAnimation(Account, 'right-to-center', 'center-to-right');
      return <Composed ref="account" exitOnClose={true} />
    }
  },
  {
   path: '/doNotDisturb',
    action: () => {
      let Composed = EnhanceAnimation(DoNotDisturb, 'right-to-center', 'center-to-right');
      return <Composed ref="doNotDisturb" exitOnClose={true} />
    }
  },
  {
   path: '/dndFromList',
    action: () => {
      let Composed = EnhanceAnimation(DNDFromList, 'right-to-center', 'center-to-right');
      return <Composed ref="dndFromList" exitOnClose={true} />
    }
  },
  {
   path: '/dndToList',
    action: () => {
      let Composed = EnhanceAnimation(DNDToList, 'right-to-center', 'center-to-right');
      return <Composed ref="dndToList" exitOnClose={true} />
    }
  },
  {
   path: '/delaySending',
    action: () => {
      let Composed = EnhanceAnimation(DelaySending, 'right-to-center', 'center-to-right');
      return <Composed ref="delaySending" exitOnClose={true} />
    }
  },
  {
   path: '/personalization',
    action: () => {
      let Composed = EnhanceAnimation(Personalization, 'right-to-center', 'center-to-right');
      return <Composed ref="personalization" exitOnClose={true} />
    }
  },
  {
    path: '/profileView',
    action: () => {
      let Composed = EnhanceAnimation(MyProfileView, 'right-to-center', 'center-to-right');
      return <Composed ref={"profileView"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/editProfile',
    action: () => {
      let Composed = EnhanceAnimation(EditProfile, 'right-to-center', 'center-to-right');
      return <Composed ref={"editProfile" + ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/moodView',
    action: () => {
      let Composed = EnhanceAnimation(MoodView, 'right-to-center', 'center-to-right');
      return <Composed ref="moodView" exitOnClose={true} />
    }
  },
  {
    path: '/profilePreview/:name',
    action: (params) => {
      let Composed = EnhanceAnimation(ProfilePreview, 'right-to-center', 'center-to-right');
      return <Composed {...params} params={params} ref={"profilePreview/"+ ( new Date().getTime() / 3000 )} exitOnClose={true} />
    }
  },
  {
    path: '/replyView/:sessionType/:peerId/:msgType',
    action: (params) => {
      let Composed = EnhanceAnimation(ReplyView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"replyView" + params.sessionType + ' ' + params.peerId + ' ' + params.msgType} exitOnClose={true} />
    }
  },
  {
    path: '/broadcastReplyView/:peerId/:users',
    action: (params) => {
      let Composed = EnhanceAnimation(BroadcastReplyView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"broadcastReplyView" + ' ' + params.peerId + ' ' + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/emoji',
    action: (params) => {
      let Composed = EnhanceAnimation(EmojiView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"emojiView "} exitOnClose={true} />
    }
  },
  {
    path: '/readMore/:peerName/:msgType/:msgDirection',
    action: (params) => {
      let Composed = EnhanceAnimation(ReadMoreView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"readMoreView " + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/imagePreview/:sessionId/:thumbId',
    action: (params) => {
      let Composed = EnhanceAnimation(ImagePreviewView, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"imagePreviewView " + params.sessionId + ' ' + params.thumbId + ' ' + new Date()} exitOnClose={true} />
    }
  },
  {
    path: '/StickersStoreView',
      action: () => {
        let Composed = EnhanceAnimation(StickersStoreView, 'right-to-center', 'center-to-right');
        return <Composed ref="StickersStoreView" exitOnClose={true} />
      }
  },
  {
    path: '/MyStickers',
      action: () => {
        let Composed = EnhanceAnimation(MyStickers, 'right-to-center', 'center-to-right');
        return <Composed ref="MyStickers" exitOnClose={true} />
      }
  },
  {
    path: '/StickerSendView/:sessionType/:peerId',
      action: (params) => {
        let Composed = EnhanceAnimation(StickerSendView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"StickerSendView" + params.sessionType + ' ' + params.peerId }  exitOnClose={true} />
      }
  },
  {
    path: '/stickers/:id/:isDownloading',
      action: (params) => {
        let Composed = EnhanceAnimation(Stickers, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"stickers" + params.id + ' ' +params.isDownloading} exitOnClose={true} />
      }
   },
   {
    path: '/RotateImageView/:sessionType/:peerId',
      action: (params) => {
        let Composed = EnhanceAnimation(RotateImageView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"RotateImageView" + params.sessionType + ' ' + params.peerId  }  exitOnClose={true} />
      }
  },
  {
    path: '/fileManager',
    action: () => {
      let Composed = EnhanceAnimation(FileManager, 'right-to-center', 'center-to-right');
      return <Composed ref="fileManager" exitOnClose={true} />
    }
  },
  {
    path: '/locationView',
    action: () => {
      let Composed = EnhanceAnimation(LocationView, 'right-to-center', 'center-to-right');
      return <Composed ref="locationView" exitOnClose={true} />
    }
  },
  {
    path: '/filesList',
      action: () => {
        let Composed = EnhanceAnimation(FilesList, 'right-to-center', 'center-to-right');
        return <Composed ref="filesList" exitOnClose={true} />
      }
   },
   {
    path: '/audioRecordView/:sessionId/:msgId/:pageType/:sessionType/:users',
      action: (params) => {
        let Composed = EnhanceAnimation(AudioRecordView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"audioRecordView " + params.sessionId + ' ' +params.msgId + ' ' + params.pageType + ' ' + params.sessionType + ' ' + params.users + ' ' + new Date()} exitOnClose={true} />
      }
   },
  {
    path: '/multiRichMedia/:channelId/:msgId',
    action: (params) => {
      // var userId = userObj[0].userId;
      var userId = UserModel.getInstance().getUserID() ? String(UserModel.getInstance().getUserID()) : new Date();
      let Composed = EnhanceAnimation(MultiRichMedia, 'right-to-center', 'center-to-right');
      return <Composed {...params} ref={"multiRichMedia_" + userId + "_" + params.channelId + "_" + params.msgId}  exitOnClose={true} />
    }
  },
  {
    path: '/broadcastRecipientView/:msgId',
      action: (params) => {
        let Composed = EnhanceAnimation(BroadcastRecipientView, 'right-to-center', 'center-to-right');
        return <Composed {...params} ref={"broadcastRecipientView" + params.msgId + ' ' + new Date()} exitOnClose={true} />
    }
  },
];

export default routes;
