/**
 * @interface SendMessageCallback
 * @desc
 * SendMessageCallback is an anonymous interface will get invoked whenever success/failure response from the server after sending message to the server
 */
var SendMessageCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @function onSuccess
     * @callback SendMessageCallback~onSuccess
     * @param {JCMessage} message - contains the JCMessage object
     * @memberof SendMessageCallback
     */
    onSuccess:function(message){
        
    },

    /**
     * Method will be triggered when message gets failed.
     * @function onError
     * @callback SendMessageCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof SendMessageCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface SendTypingCallback
 * @desc
 * SendTypingCallback is an anonymous interface will get invoked whenever success/failure response from the server after sending typing event to the server
 */
var SendTypingCallback = {
    /**
     * Method will be triggered when success response from the server
     * @function onSuccess
     * @callback SendTypingCallback~onSuccess
     * @memberof SendTypingCallback
     */
    onSuccess:function(){
        
    },

    /**
     * Method will be triggered when typing event gets failed
     * @function onError
     * @callback SendTypingCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof SendTypingCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface SendReplyMessageCallback
 * @desc
 * SendReplyMessageCallback is an anonymous interface will get invoked whenever success/failure response from the server after sending reply to the server
 */
var SendReplyMessageCallback = {
    /**
     * Method will be triggered when success response from the server
     * @function onSuccess
     * @callback SendReplyMessageCallback~onSuccess
     * @param {Object} successResponse - contains the object
     * @memberof SendReplyMessageCallback
     */
    onSuccess:function(successResponse){
        
    },

    /**
     * Method will be triggered when reply to the message gets failed
     * @function onError
     * @callback SendReplyMessageCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof SendReplyMessageCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface SendReadReplyMessageCallback
 * @desc
 * SendReadReplyMessageCallback is an anonymous interface will get invoked whenever success/failure response from the server after sending readReply to the server
 */
var SendReadReplyMessageCallback = {
    /**
     * Method will be triggered when success response from the server.
     * @function onSuccess
     * @callback SendReadReplyMessageCallback~onSuccess
     * @param {Object} successResponse - contains the object
     * @memberof SendReadReplyMessageCallback
     */
    onSuccess:function(successResponse){
        
    },

    /**
     * Method will be triggered when readReply to the session gets failed
     * @function onError
     * @callback SendReadReplyMessageCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof SendReadReplyMessageCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface MessageInfoCallback
 * @desc
 * MessageInfoCallback is an anonymous interface will get invoked whenever success/failure response from the server
 */
var MessageInfoCallback = {
    /**
     * Method will be triggered when success repsonse from the server.
     * @function onSuccess
     * @callback MessageInfoCallback~onSuccess
     * @param {Array<OfflineMessageInfoModel>} offlineMsgInfoList - contains the OfflineMessageInfoModel object
     * @memberof MessageInfoCallback
     */
    onSuccess:function(offlineMsgInfoList){
        
    },

    /**
     * Method will be triggered when failure response from the server.
     * @function onError
     * @callback MessageInfoCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof MessageInfoCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface LoadMoreMessageCallback
 * @desc
 * LoadMoreMessageCallback is an anonymous interface will get invoked whenever success/failure response from the server
 */
var LoadMoreMessageCallback = {
    /**
     * Method will be triggered when success response from the server.
     * @function onSuccess
     * @callback LoadMoreMessageCallback~onSuccess
     * @param {Array<JCMessage>} messages - contains the JCMessage object
     * @memberof LoadMoreMessageCallback
     */
    onSuccess:function(messages){
        
    },

    /**
     * Method will be triggered when failure response from the server.
     * @function onError
     * @callback LoadMoreMessageCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof LoadMoreMessageCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface LastSeenCallback
 * @desc
 * LastSeenCallback is an anonymous interface will get invoked whenever success/failure response from the server
 */
var LastSeenCallback = {
    /**
     * Method will be triggered on Last Seen API success response from the server
     * @function onSuccess
     * @callback LastSeenCallback~onSuccess
     * @param {object} successResponse - contains the Last seen object ex:-{"to":{"0":-83,"1":-6,"2":92,"3":36,"4":2},"expire":300000,"isOnline":false,"lastSeen":"2017-08-24T12:14:06.954Z"}
     * if isOnline is true then user is online ex:- {"to":{"0":-23,"1":-8,"2":5,"3":42,"4":1},"expire":300000,"isOnline":true,"lastSeen":0}
     * @memberof LastSeenCallback
     */
    onSuccess:function(successResponse){
        
    },

    /**
     * Method will be triggered when failure response from the server
     * @function onError
     * @callback LastSeenCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof LastSeenCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface AllMessagesCallback
 * @desc
 * AllMessagesCallback is an anonymous interface will get invoked when we get messages from LDB
 */
var AllMessagesCallback = {
    /**
     * Method will triggered when retrieved all messages
     * @function onSuccess
     * @callback AllMessagesCallback~onSuccess
     * @param {Array<Array<JCMessage>>} messages - contains the Array of Array of JCMessage object if message exists else empty array will be returned.
     * @memberof AllMessagesCallback
     */
    onSuccess:function(messages){
        
    },

    /**
     * Method will be triggered when no messages.
     * @function onError
     * @callback AllMessagesCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof AllMessagesCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface DeleteMessageCallback
 * @desc
 * DeleteMessageCallback is an anonymous interface will get invoked whenever success/failure response from the server when deleting message
 */
var DeleteMessageCallback = {
    /**
     * Method will be triggered when message gets deleted
     * @function onSuccess
     * @callback DeleteMessageCallback~onSuccess
     * @param {Array<Int8Array>} messageIds - contains the array of Int8Array object
     * @memberof DeleteMessageCallback
     */
    onSuccess:function(messageIds){
        
    },

    /**
     * Method will be triggered when deleting message gets failed.
     * @function onError
     * @callback DeleteMessageCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof DeleteMessageCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface SMSQuotaCallback
 * @desc
 * SMSQuotaCallback is an anonymous interface will get invoked when we get success/failure response 
 */
var SMSQuotaCallback = {
    /**
     * Method will be triggered when message gets deleted
     * @function onSuccess
     * @callback SMSQuotaCallback~onSuccess
     * @param {object}  - contains the dayQuota & monthlyQuota.
     * @memberof SMSQuotaCallback
     */
    onSuccess:function(response){
        
    },

    /**
     * Method will be triggered when deleting message gets failed.
     * @function onError
     * @callback SMSQuotaCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof SMSQuotaCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface ClearChatCallback
 * @desc
 * ClearChatCallback is an anonymous interface will get invoked when we get success/failure response 
 */
var ClearChatCallback = {
    /**
     * Method will be triggered when chat history is cleared
     * @function onSuccess
     * @callback ClearChatCallback~onSuccess
     * @memberof ClearChatCallback
     */
    onSuccess:function(){
        
    },

    /**
     * Method will be triggered when failed to clear chat history
     * @function onError
     * @callback ClearChatCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof ClearChatCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface DeleteChatChatCallback
 * @desc
 * DeleteChatChatCallback is an anonymous interface will get invoked when we get success/failure response 
 */
var DeleteChatChatCallback = {
    /**
     * Method will be triggered when chat conversation deleted successfully
     * @function onSuccess
     * @callback DeleteChatChatCallback~onSuccess
     * @memberof DeleteChatChatCallback
     */
    onSuccess:function(){
        
    },

    /**
     * Method will be triggered when failed to delete chat conversation
     * @function onError
     * @callback DeleteChatChatCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof DeleteChatChatCallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface RecentChatCallback
 * @desc
 * RecentChatCallback is an anonymous interface will get invoked when we get messages from LDB
 * @ignore
 */
var RecentChatCallback = {
    /**
     * Method will triggered when retrieved all recent chat
     * @function onSuccess
     * @callback RecentChatCallback~onSuccess
     * @param {Map<string,JCChat>} messages - contains the Map object if chat exists else empty array will be returned.
     * @memberof RecentChatCallback
     * @ignore
     */
    onSuccess:function(messages){
        
    },

    /**
     * Method will be triggered when no recent chat.
     * @function onError
     * @callback RecentChatCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof RecentChatCallback
     * @ignore
     */
    onError: function(errorResponse){

    }
}
