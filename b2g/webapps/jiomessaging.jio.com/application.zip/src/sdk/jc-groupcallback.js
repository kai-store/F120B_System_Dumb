/**
 * @interface CreateGroupCallback
 * @desc
 * CreateGroupCallback is an anonymous interface will get invoked whenever success/failure response from the server after create group to the server
 */
var CreateGroupCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback CreateGroupCallback~onSuccess
     * @param {String} groupId - Id for the group
     * @memberof CreateGroupCallback
     */
    onSuccess:function(groupId){

     },

    /**
     * Method will be triggered when message gets failed.
     * @callback CreateGroupCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof CreateGroupCallback
     */
    onError:function(errorResponse){
        
     }
}

/**
 * @interface EditGroupNameCallback
 * @desc
 * EditGroupNameCallback is an anonymous interface will get invoked whenever success/failure response from the server after edit group to the server
 */
var EditGroupNameCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback EditGroupNameCallback~onSuccess
     * @param {String} groupId - Id for the group
     * @memberof EditGroupNameCallback
     */
    onSuccess:function(groupId){

     },

    /**
     * Method will be triggered when message gets failed.
     * @callback EditGroupNameCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof EditGroupNameCallback
     */
    onError:function(errorResponse){
        
     }
}

/**
 * @interface GetGroupListCallback
 * @desc
 * GetGroupListCallback is an anonymous interface will get all group details which are present in the user.
 */
var GetGroupListCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback GetGroupListCallback~onSuccess
     * @param {object} groupList - group list object for the user
     * @param groupList.heading - group name for the group 
     * @param groupList.id - group id for the group
     * @param groupList.img_url - group thumb image for the group
     * @param groupList.version - group version for the group               
     * @memberof GetGroupListCallback
     */

    onSuccess:function(groupList){

     }

}

/**
 * @interface GetGroupDetailCallback
 * @desc
 * GetGroupDetailCallback is an anonymous interface will get all group details which are present in the user.
 */
var GetGroupDetailCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback GetGroupDetailCallback~onSuccess
     * @param {object} groupdetail - group detail object for the group
     * @param groupdetail.groupName - group name for the group 
     * @param groupdetail.groupId - group id for the group
     * @param groupdetail.groupThumb - group thumb image for the group
     * @param groupdetail.groupCreatorId - group admin id for the group
     * @param groupdetail.users - users list for the group               
     * @param groupdetail.groupVersion - group version for the group               
     * @param {String} - user id for the user               
     * @memberof GetGroupDetailCallback
     */

    onSuccess:function(groupdetail, userId){

     }

}


/**
 * @interface QuitGroupCallback
 * @desc
 * QuitGroupCallback is an anonymous interface will quit the selected group which are present in the user.
 */
var QuitGroupCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback QuitGroupCallback~onSuccess
     * @param {String} success - contain the success response          
     * @memberof QuitGroupCallback
     */

    onSuccess:function(Success){

     },

     /**
     * Method will be triggered when message gets failed.
     * @callback QuitGroupCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof QuitGroupCallback
     */
    onError:function(errorResponse){
        
     }

}

/**
 * @interface RemoveUserFromGroupCallback
 * @desc
 * RemoveUserFromGroupCallback is an anonymous interface will get all group details which are present in the user.
 */
var RemoveUserFromGroupCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback RemoveUserFromGroupCallback~onSuccess
     * @param {object} groupdetail - group detail object for the group
     * @param groupdetail.groupName - group name for the group 
     * @param groupdetail.groupId - group id for the group
     * @param groupdetail.groupThumb - group thumb image for the group
     * @param groupdetail.groupCreatorId - group admin id for the group
     * @param groupdetail.users - users list for the group               
     * @param groupdetail.groupVersion - group version for the group               
     * @param {String} - user id for the user               
     * @memberof RemoveUserFromGroupCallback
     */

    onSuccess:function(groupdetail, userId){

     },

     /**
     * Method will be triggered when message gets failed.
     * @callback RemoveUserFromGroupCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof RemoveUserFromGroupCallback
     */
    onError:function(errorResponse){
        
     }

}


/**
 * @interface TransferAdminRightsCallback
 * @desc
 * TransferAdminRightsCallback is an anonymous interface will get all group details which are present in the user.
 */
var TransferAdminRightsCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback TransferAdminRightsCallback~onSuccess
     * @param {object} groupdetail - group detail object for the group
     * @param groupdetail.groupName - group name for the group 
     * @param groupdetail.groupId - group id for the group
     * @param groupdetail.groupThumb - group thumb image for the group
     * @param groupdetail.groupCreatorId - group admin id for the group
     * @param groupdetail.users - users list for the group               
     * @param groupdetail.groupVersion - group version for the group               
     * @param {String} - user id for the user               
     * @memberof TransferAdminRightsCallback
     */

    onSuccess:function(groupdetail, userId){

     },

     /**
     * Method will be triggered when message gets failed.
     * @callback TransferAdminRightsCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof TransferAdminRightsCallback
     */
    onError:function(errorResponse){
        
     }

}

/**
 * @interface AddMembersCallback
 * @desc
 * AddMembersCallback is an anonymous interface will get Success/failure response.
 */
var AddMembersCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback AddMembersCallback~onSuccess
     * @param success - success response                
     * @memberof AddMembersCallback
     */

    onSuccess:function(success){

     },

     /**
     * Method will be triggered when message gets failed.
     * @callback AddMembersCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof AddMembersCallback
     */
    onError:function(errorResponse){
        
     }

}
