import BaseModule from '../lib/base-module';
import JIOSDKUtils from './base-jc-user.js';
import ExploreStore from '../data/explore-store.js';

/**
 * @classdesc
 *  JCExploreClient is a singleton class which will do all explore operations, fetch explore channel list,explore channel info details etc..
 * 
 * @class JCExploreClient
 */
export default class JCExploreClient extends BaseModule {
    
    /**
    * Method for getting all explore channels
    * @param {ExploreChannelListAPICallback} callback - success/error callback once we get response
    * @memberof JCExploreClient#
    */
    getExploreList(callback){
        ExploreStore.getInstance().getDataFromLDB(callback);
    }
    
    /**
     * Method for getting all explore channels info
     * @param {ExploreChannelInfoAPICallback} callback - success/error callback once we get response
     * @memberof JCExploreClient#
     */
    getExploreChannelInfo(id,callback){
        ExploreStore.getInstance().getChannelDetailByIdFromLDB(id,callback);
    }
}

JCExploreClient.getInstance = function(){
    if( !JCExploreClient.instance) {
        JCExploreClient.instance = new JCExploreClient();
    }
    return JCExploreClient.instance;
}
