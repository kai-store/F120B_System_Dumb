/**
 * Class is for JCDeviceInfo information. 
 * @class
 */
function JCDeviceInfo(){
    this.endPoint = null;
    this.auth = null;
    this.privateString = null;
	this.deviceID =  window.deviceId; 
	this.OEM =  HTTPRequestConts.OEM;
	this.IMEI =  HTTPRequestConts.IMEI;
	this.BRAND =  HTTPRequestConts.BRAND;
	this.OS_VERSION =  HTTPRequestConts.OS_VERSION;
	this.NAV_C_VER = HTTPRequestConts.GET_NAV_C_VER_VAL;
}

JCDeviceInfo.prototype.setEndPoint = function(endPoint){
    this.endPoint = endPoint;

     // mushtaq added this code 
	// indexedDB
	var daoData = {
		deviceEndPoint: this.endPoint
	};
	this.updateLDB(daoData);
}

JCDeviceInfo.prototype.getEndPoint = function(){
    return this.endPoint;
}

JCDeviceInfo.prototype.setAuth = function(auth){
    this.auth = auth;

    // mushtaq added this code 
	// indexedDB
	var daoData = {
		deviceAuth: this.auth
	};
	this.updateLDB(daoData);
}

JCDeviceInfo.prototype.getAuth = function(){
    return this.auth;
}

JCDeviceInfo.prototype.setPrivateString = function(privateString){
    this.privateString = privateString;

    // mushtaq added this code 
	// indexedDB
	var daoData = {
		devicePrivateString: this.privateString
	};
	this.updateLDB(daoData);
}

JCDeviceInfo.prototype.getPrivateString = function(){
    return this.privateString;
}

/**
 * Method will set the deviceId.
 * @function setDeviceID
 * @param {String} deviceID - contains the deviceId
 * @memberof JCDeviceInfo#
 */
JCDeviceInfo.prototype.setDeviceID = function(deviceID){
    this.deviceID = deviceID;

    // mushtaq added this code 
	// indexedDB
	var daoData = {
		deviceId: this.deviceID
	};
	this.updateLDB(daoData);
}

/**
 * Method will get the deviceId.
 * @return {String}
 * @memberof JCDeviceInfo#
 */
JCDeviceInfo.prototype.getDeviceID = function(){
    return this.deviceID;
}

JCDeviceInfo.prototype.setOEM = function(oem){
	this.OEM = oem;
}

JCDeviceInfo.prototype.getOEM = function(){
	return this.OEM;
}

JCDeviceInfo.prototype.setIMEI = function(IMEI){
	this.IMEI = oem;
}

JCDeviceInfo.prototype.getIMEI = function(){
	return this.IMEI;
}
JCDeviceInfo.prototype.setBRAND = function(oem){
	this.BRAND = oem;
}

JCDeviceInfo.prototype.getBRAND = function(){
	return this.BRAND;
}

JCDeviceInfo.prototype.setOS_VERSION = function(osVer){
	this.OS_VERSION = osVer;
}
JCDeviceInfo.prototype.getOSVersion = function(){
	return this.OS_VERSION ;
}

JCDeviceInfo.prototype.setNAV_C_VER = function(navVer){
	this.NAV_C_VER = navVer;
}
JCDeviceInfo.prototype.getNAV_C_VER = function(){
	return this.NAV_C_VER ;
}

JCDeviceInfo.prototype.setOEM = function(oem){
	this.OEM = oem;
}

JCDeviceInfo.prototype.getOEM = function(){
	return this.OEM;
}

JCDeviceInfo.prototype.setIMEI = function(IMEI){
	this.IMEI = IMEI;
}

JCDeviceInfo.prototype.getIMEI = function(){
	return this.IMEI;
}
JCDeviceInfo.prototype.setBRAND = function(oem){
	this.BRAND = oem;
}

JCDeviceInfo.prototype.getBRAND = function(){
	return this.BRAND;
}

JCDeviceInfo.prototype.setOS_VERSION = function(osVer){
	this.OS_VERSION = osVer;
}
JCDeviceInfo.prototype.getOSVersion = function(){
	return this.OS_VERSION ;
}
JCDeviceInfo.prototype.setPush = function(jcPush){
	this.setAuth(jcPush.getAuth());
	this.setPrivateString(jcPush.getPrivateString());
	this.setEndPoint(jcPush.getEndPoint());
}
JCDeviceInfo.prototype.getPush = function(jcPush){
	var push = new JCPush();
	push.setAuth(this.getAuth());
	push.setPrivateString(this.getPrivateString());
	push.setEndPoint(this.getEndPoint());
	return push;
}
// mushtaq added this code
JCDeviceInfo.prototype.clearAll = function() {
	this.endPoint = null;
    this.auth = null;
    this.privateString = null;
    this.deviceID =  window.deviceId;
	this.OEM =  null;
	this.IMEI =  null;
	this.BRAND =  null;
	this.OS_VERSION =  null;
	this.NAV_C_VER = null;
}

JCDeviceInfo.prototype.updateLDB = function(data) {
	DevicesDAO.getInstance().updateByDataToLDB(data, function(success) {
		console.log('[Model:: JCDeviceInfo] Push token LDB updated:'+ success);	
	});
}

JCDeviceInfo.getInstance = function(){
    if(JCDeviceInfo.instance == null || JCDeviceInfo.instance == undefined){
        JCDeviceInfo.instance = new JCDeviceInfo();
    }
	
    return JCDeviceInfo.instance;
};

