import BaseModule from '../lib/base-module';
import CallStore from '../data/call-store';
import ContactStore from '../data/contacts-store';

/**
 * JCCall is a class which is used for making audio and video calls.
 * @class JCCall
 * @ignore
 */
export default class JCCall extends BaseModule {
    start(){
        this.callInstance = CallStore.getInstance();
    }

    /**
     * Method for requesting to make video call.
     * @function makeVideoCall
     * @param {CallP2PEligibilityCallback} callback - success or failure callbacks in return.
     * @memberof JCCall#
     * @ignore
     */
	makeVideoCall(userId, peerId, videoWidth, videoHeight, callback) {
      CallStore.getInstance().makeVideoCall(userId, peerId, videoWidth, videoHeight, callback);
    }

    /**
     * Method for requesting to make voice call.
     * @function makeVoiceCall
     * @param {CallP2PEligibilityCallback} callback - success or failure callbacks in return.
     * @memberof JCCall#
     * @ignore
     */
	  makeVoiceCall(userId, peerId, callback) {
      CallStore.getInstance().makeAudioCall(userId, peerId, callback);
    }
     /**
     * Method for adding unknown user call record to LDB.
     * @function updateCallRecordToContactLDB
     * @memberof JCCall#
     * @ignore
     */
    updateCallRecordToContactLDB(userId,portraits,data,callback){
      if(portraits === null){
        ContactStore.getInstance().updateContactProfileLDB(userId,data,callback);
      }else {
        ContactStore.getInstance().updateContactImageLDB(userId,portraits,data,callback);
      }      
    }

    /**
     * Method for adding call(video/audio) logs into local storage.
     * @function addCallLog
     * @param {function} callback - user defined callbacks in return.
     * @memberof JCCall#
     * @ignore
     */
    addCallLog(callLogData, callback) {
      CallStore.getInstance().addRecentCalltoLDB(callLogData, callback);
    }

    /**
     * Method for getting recent call(video/audio) logs.
     * @function getRecentCalls
     * @param {function} callback - user defined callbacks in return.
     * @memberof JCCall#
     * @ignore
     */
    getRecentCalls(callback) {
      CallStore.getInstance().fetchAllRecentCallDataFromLDB(callback);
    }
    
    /**
     * Method deleting particular call log.
     * @function deleteCallRecord
     * @param {function} callback - user defined callbacks in return.
     * @memberof JCCall#
     * @ignore
     */
    deleteCallRecord(callLogId, callback) {
      CallStore.getInstance().deleteRecentFromLDB(callLogId, callback);
    }

    /**
     * Method for deleting all call logs.
     * @function deleteAllCallRecords
     * @param {function} callback - user defined callbacks in return.
     * @memberof JCCall#
     * @ignore
     */
    deleteAllCallRecords(callback) {
      CallStore.getInstance().deleteAllRecentFromLDB(callback);
    }

    
    
}

JCCall.getInstance = function(){
    if( !JCCall.instance) {
        JCCall.instance = new JCCall();
        JCCall.instance.start();
    }
    return JCCall.instance;
}
