/**
 * @interface CallP2PEligibilityCallback
 * @desc
 * CallP2PEligibilityCallback is an anonymous interface will get invoked whenever success/failure response from the server after sending P2P eligibility request to the server.
 * @ignore
 */
var CallP2PEligibilityCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback CallP2PEligibilityCallback~onSuccess
     * @param {HDCall} hdCall - contains the HDCall object.
     * @memberof CallP2PEligibilityCallback
     */
     onSuccess:function(hdCall){

     },

    /**
     * Method will be triggered when message gets failed.
     * @callback CallP2PEligibilityCallback~onError
     * @param {HDCall} hdCall - contains the HDCall object.
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof CallP2PEligibilityCallback
     */
     onError:function(hdCall, errorResponse){
        
     }
}

