/**
 * Class is for JCMessage information. 
 * @class
 */
function JCMessage () {
    this.sessionId = "";
    this.sessionType = "";
	this.msgId = "";
    this.mobileNumbers = [];
	this.msgDirection = "";
	this.msgContent = "";
	this.msgType = "";
	this.msgFrom = "";
	this.msgTo = "";
	this.msgDateTime = "";
	this.msgLocalDateTime = "";
	this.msgThumbStatus = "";
	this.msgStatus = "";
	this.msgFileStatus = "";
	this.msgRead = "";
	this.msgSequence = 0;
	this.msgLocalSequence = 0;
    this.msgDelete = "";
    this.msgTOS = "";
    this.msgMultimedia = "";
    this.msgListen = "";
    this.msgPeerName = "";
    this.attachment = undefined;
    this.fileId = "";
    this.mThumbId = "";
    this.thumbLocalPath = "";
    this.fileLocalPath = "";
    this.broadcastUsers = [];
    // this.isAudioPlayed = false;
    this.isAudioPlayed = undefined;
    this.callMode = "";
    this.isThumbUploaded = "";
    this.isFileUploaded = "";
    this.bitRate = null;

    // Used when sending messages
    this.name = undefined;
    this.thumbObj = undefined;
    this.audioTime = 0;
    this.isBlack = false;
    this.broadcastPeerIds = [];
}

String.prototype.splice = function(idx, rem, str) {
    return this.slice(0, idx) + str + this.slice(idx + Math.abs(rem));
};

JCMessage.prototype = {

    init: function(chatMessageObj){
        var userId = UserModel.getInstance().getUserID();
        this.name = chatMessageObj.name;
        this.sessionType = chatMessageObj.sessionType;
        this.sessionId = String(chatMessageObj.from);
        if(this.sessionType == CINRequestConts.SESSIONGROUP){
            this.sessionId = String(chatMessageObj.to);
        }
        this.msgId = String(chatMessageObj.messageID);
        this.msgContent = chatMessageObj.messageBody;
        this.msgDateTime = moment(chatMessageObj.dateTime).valueOf();
        this.msgLocalDateTime = AppUtils.currentTime();
        this.msgFrom = String(chatMessageObj.from);
        this.msgTo = String(chatMessageObj.to);
        this.msgDelete = "0";
        this.attachment = chatMessageObj.attachment;

        this.msgSequence = 0;
        if(chatMessageObj.csequence){
            this.msgSequence = chatMessageObj.csequence;
        }

        var msgStatus = MessageConsts.STATUS_UNKNOWN;
        if(chatMessageObj.status){
            msgStatus = chatMessageObj.status;
        }
        this.msgStatus = msgStatus;
        this.attachment = chatMessageObj.attachment;
        this.msgType = chatMessageObj.msgType;

        if(this.msgFrom){
            var msgDirection = 0;
            if(String(userId) === String(this.msgFrom)){
                msgDirection = 0;
            }else{
                msgDirection = 1;
            }
            this.msgDirection = msgDirection;
        }

        // if(this.sessionType == CINRequestConts.SESSIONPUBLIC || this.sessionType == AppConstants.BROADCAST_MESSAGE){
        //     if(msgData.msgPeerName && msgData.msgPeerName != ""){
        //         instance.msgPeerName = msgData.msgPeerName;
        //     }
        // }

        this.msgLocalSequence = 0;
        this.msgTOS = "0";
        this.msgMultimedia = "0";
        this.msgListen = "0";

        if(this.msgType == MessageConsts.TYPE_IMAGE){
            var imageInfo = this.attachment;
            if(imageInfo){
                if(imageInfo.length > 0){
                    this.attachment = imageInfo[0];
                }
            }
        }

        if(this.msgType == MessageConsts.TYPE_IMAGE || 
        this.msgType == MessageConsts.TYPE_VIDEO ||
        this.msgType == MessageConsts.TYPE_FILE || 
        this.msgType == MessageConsts.TYPE_VOICE)
        {
            if(this.attachment){
                if(this.attachment.fileId){
                    this.fileId = this.attachment.fileId;

                    /*if(this.msgType == MessageConsts.TYPE_VOICE){
                        if(this.fileId){
                            if(!this.fileId.endsWith("_VOICE")){
                                this.fileId = this.fileId + "_VOICE";
                                this.attachment.fileId = this.fileId;
                            }
                        }
                    }*/
                }
                if(this.attachment.mThumbId){
                    this.mThumbId = this.attachment.mThumbId;
                }
            }
        }

        if(this.sessionType == CINRequestConts.SESSIONPUBLIC && this.msgType == MessageConsts.TYPE_PUBLIC_IMAGETEXT){
            if(this.attachment && this.attachment.length == 1){
                this.mThumbId = this.attachment[0].imageId;
                this.fileId = this.mThumbId;
            } else if(this.attachment && this.attachment.length > 1) {
                // For Multiple rich media
                this.attachment.forEach(function(attachmentObj, index){
                    if(attachmentObj.model == 2 || attachmentObj.model == "2"){
                        this.mThumbId = attachmentObj.imageId;
                        this.fileId = this.mThumbId;
                    }
                });
                //guddu added temp. remove after fixed at CIN side of single and multi rich media issue
                if(!this.mThumbId &&  !this.fileId ){
                    this.mThumbId = this.attachment[0].imageId;
                    this.fileId = this.mThumbId;
                }
                //guddu added end
            }
        }

    },

    downloadThumbnail: function(){
        if(this.getMsgType() == MessageConsts.TYPE_VIDEO || this.getMsgType() == MessageConsts.TYPE_IMAGE) {
            var attachment = this.getAttachment();
            if(attachment != undefined && attachment != null){
                var thumbnailObj = new Thumbnail();
                thumbnailObj.setFileId(attachment.mThumbId);
                thumbnailObj.setFileSize(attachment.mThumbSize);
                thumbnailObj.setFileName(attachment.mFileName);
                thumbnailObj.setMsgId(this.getMsgId());
                thumbnailObj.setMsgType(this.getMsgType());
                this.startDownload(thumbnailObj);
            }
        } else if(this.getMsgType() == MessageConsts.TYPE_PUBLIC_IMAGETEXT){
            var attachment = this.getAttachment();
            var index = -1;
            if(attachment && attachment.length == 1){
                index = 0;
            } else if(attachment && attachment.length > 1) {
                // For Multiple rich media
                attachment.forEach(function(attachmentObj, ind){
                    if(attachmentObj.model == 2 || attachmentObj.model == "2"){
                        index = ind;
                    }
                });
            //guddu added temp. remove after fixed at CIN side of single and multi rich media issue
                // if( index == -1){
                //     index = 0;
                // }
            //end guddu added
                if(index == -1){
                    index = 0;
                }
            }
            if(attachment && attachment != null && index != -1){
                var thumbnailObj = new Thumbnail();
                thumbnailObj.setFileId(attachment[index].imageId);
                thumbnailObj.setFileSize(attachment[index].imageSize);
                var mFileName = thumbnailObj.getFileId() +"_THUMB.jpg";
                thumbnailObj.setFileName(mFileName);
                thumbnailObj.setMsgId(this.getMsgId());
                thumbnailObj.setMsgType(this.getMsgType());
                this.startDownload(thumbnailObj);
            }
        }
    },

    reDownloadThumbnail: function(){
        var that = this;
        if(this.thumbLocalPath && this.thumbLocalPath != ""){
            // Check thumbnail exists in device if not then do start download else not required.
            DeviceModel.getFileFromDevice(this.thumbLocalPath, {
                onSuccess: function(fileObject){
                    if(fileObject == undefined || fileObject == null){
                        that.downloadThumbnail();
                    }
                },
                onError: function(){
                    that.downloadThumbnail();
                }
            })
        }else{
            this.downloadThumbnail();
        }
    },

    downloadRichMedia: function(){
        var attachment = this.getAttachment();
        if(attachment && attachment.length > 0){
            var thumbnailObj;
            var that = this;
            var msgId = this.getMsgId();
            var msgType = this.getMsgType();
            attachment.forEach(function(richMediaItem, index){
                thumbnailObj = new Thumbnail();
                if(!richMediaItem.thumbLocalPath || (richMediaItem.thumbLocalPath && richMediaItem.thumbLocalPath == "")){
                    thumbnailObj.setFileId(richMediaItem.imageId);
                    thumbnailObj.setFileSize(richMediaItem.imageSize);
                    var mFileName = thumbnailObj.getFileId() +"_THUMB.jpg";
                    thumbnailObj.setFileName(mFileName);
                    thumbnailObj.setMsgId(msgId);
                    thumbnailObj.setMsgType(msgType);
                    that.startDownload(thumbnailObj);
                }
            });
        }
    },

    downloadOriginalImage: function(){
        if(this.getMsgType() == MessageConsts.TYPE_IMAGE) {
            var attachment = this.getAttachment();
            if(attachment != undefined && attachment != null){
                var thumbnailObj = new Thumbnail();
                thumbnailObj.setFileId(attachment.fileId);
                thumbnailObj.setFileSize(attachment.mFileSize);
                thumbnailObj.setFileName(attachment.mFileName);
                thumbnailObj.setMsgId(this.getMsgId());
                thumbnailObj.setMsgType(this.getMsgType());
                this.startDownload(thumbnailObj);
            }
        }
    },

    downloadFullSizeImage: function(){
        if(this.getMsgType() == MessageConsts.TYPE_IMAGE) {
            var attachment = this.getAttachment();
            if(attachment != undefined && attachment != null){
                var thumbnailObj = new Thumbnail();
                thumbnailObj.setFileId(attachment.mOriginId);
                thumbnailObj.setFileSize(attachment.mOriginSize);
                var fileName = attachment.mFileName;
                if(fileName){
                    fileName = fileName.splice(fileName.indexOf("."), 0, "_HD");
                }
                thumbnailObj.setFileName(fileName);
                thumbnailObj.setMsgId(this.getMsgId());
                thumbnailObj.setMsgType(this.getMsgType());
                this.startDownload(thumbnailObj);
            }
        }
    },

    /**
     * Method will download the original attachment of message Ex. video, Image, Audio, etc.
     * @param {Object} attachment - attachment object for downlaoding respective file .
     * @param {String} attachment.fileId - FileID of file which you want to download.
     * @param {Number} attachment.mFileSize - File size of the file you want to download.
     * @param {String} attachment.mFileName - name of the file you want to download with extension(Ex. birthdayPicture.jpg ). 
     * @example
     * var jcMsgObj = new JCMessage();
     * var attachment = {
     *      fileId : "SOME_FILE_ID",
     *      mFileSize : 5173, // size of file in bytes
     *      mFileName : "FileName.ext" //filename with extension
     * };
     * //all Three parameters of object are mandatory.
     * jcMsgObj.downloadOriginalFile(attachment);
     * @memberof JCMessage#
     */
    downloadOriginalFile: function(attachment){
        // if(jcMsgObj.getMsgType() == MessageConsts.TYPE_IMAGE) {
            // var attachment = jcMsgObj.getAttachment();
            // if(attachment != undefined && attachment != null){
                var thumbnailObj = new Thumbnail();
                thumbnailObj.setFileId(attachment.fileId);
                thumbnailObj.setFileSize(attachment.mFileSize);
                thumbnailObj.setFileName(attachment.mFileName);
                this.startDownload(thumbnailObj);
            // }
        // }
    },

    reDownloadOriginalImage: function(){
        var that = this;
        if(this.fileLocalPath && this.fileLocalPath != ""){
            // Check thumbnail exists in device if not then do start download else not required.
            DeviceModel.getFileFromDevice(this.fileLocalPath, {
                onSuccess: function(fileObject){
                    if(fileObject == undefined || fileObject == null){
                        that.downloadOriginalImage();
                    }
                },
                onError: function(){
                    that.downloadOriginalImage();
                }
            })
        }else{
            this.downloadOriginalImage();
        }
    },

    startDownload: function(thumbnailObj){
        DataManager.getInstance().downloadStart(thumbnailObj, {
            onSuccess: function(imgResponse){
                console.log("[JCMessage:::Model] Success response response is " + thumbnailObj.fileId);
            },
            onError: function(imgErrResponse){
                console.log('[JCMessage:::Model] Error response on DownloadStart ' + thumbnailObj.fileId + ' ' + JSON.stringify(imgErrResponse));
                //below try-catch code added by shubham to give back error callback on download start error
                try {
                    var downloadCallback = JioChatSDK.getInstance().getDownloadCallback();
                    downloadCallback.onError(imgErrResponse);                    
                } catch (error) {
                    console.log("error while calling download callback for sdk");
                }
            }
        });
    },

    cancelDownload: function(thumbnailObj, callback){
        var that = this;
        DataManager.getInstance().cancelDownload(thumbnailObj);
        if(callback && callback.onSuccess){
            callback.onSuccess();
        }
    },

    cancelUpload: function(thumbnailObj, callback){
        var that = this;
		DataManager.getInstance().interrupt(thumbnailObj, {
			onSuccess: function(){
                if(callback && callback.onSuccess){
                    callback.onSuccess();
                }
			},
			onError: function(errResponse){
				if(callback && callback.onError){
                    callback.onError(errResponse);
                }
			}
		});
    },

    getCardInfo: function(){
        var cardInfoObj = new CardInfo();
        cardInfoObj.userId = this.attachment.userId;
        cardInfoObj.mobileNo = this.attachment.mobileNo;
        cardInfoObj.name = this.attachment.name;
        this.attachment = cardInfoObj;
        return this.attachment;
    },

    getThumbFromDevice: function(callback){
        if(!this.thumbLocalPath || this.thumbLocalPath == "") return;

        DeviceModel.getFileFromDevice(this.thumbLocalPath, {
            onSuccess: function(responseObj){
                if(callback && callback.onSuccess)
                    callback.onSuccess(responseObj);
            },
            onError: function(){
                if(callback && callback.onError)
                    callback.onError();
            }
        });
    },

    getFileFromDevice: function(callback){
        if(!this.fileLocalPath || this.fileLocalPath == "") return;

        DeviceModel.getFileFromDevice(this.fileLocalPath, {
            onSuccess: function(responseObj){
                if(callback && callback.onSuccess)
                    callback.onSuccess(responseObj);
            },
            onError: function(){
                if(callback && callback.onError)
                    callback.onError();
            }
        });
    },

    getFileObjFromDevice: function(callback){
        var that = this;
        this.getFileFromDevice({
            onSuccess: function(fileObj){
                var orgFileObj = fileObj;
                that.getFileFromDevice({
                    onSuccess: function(thumbObj){
                        if(callback && callback.onSuccess)
                            callback.onSuccess(fileObj, thumbObj);
                    },
                    onError: function(){
                        if(callback && callback.onError)
                            callback.onError();
                    }
                });
            },
            onError: function(){
                if(callback && callback.onError)
                    callback.onError();
            }
        });
    },

    composeAttachment: function(){
        var fileInfo, fileName;;
        var msgType = this.getMsgType();
        var attachment = this.getAttachment();
        var thumb = this.getThumbObj();
        if(msgType == MessageConsts.TYPE_VOICE){
            thumb = this.getAttachment();// for now keeping thumb as attachment for voice later need to change
        }
        var mThumbId, fileId, thumbLocalPath, fileLocalPath;
        // debugger;
        if( msgType == MessageConsts.TYPE_LOCATION){
            fileInfo = new LocationCard();
            fileInfo.setFleDesc(attachment.responseObj.results[0].formatted_address);
            fileInfo.setLatitude(attachment.latitude);
            fileInfo.setLongitude(attachment.longitude);
            this.setAttachment(fileInfo);
        }
        else if(msgType == MessageConsts.TYPE_EMOTICON){
            fileInfo = new DynamicEmoticonsInfo();
            fileInfo.setDynPictureId(attachment.emoticonFileId);
            fileInfo.setDynPictureSize(attachment.emoticonFileSize);
            fileInfo.setWidth(300);
            fileInfo.setHeight(300);
            fileInfo.setPackageId(attachment.emoticonPackageId);
            fileInfo.setStatPictureId(attachment.emoticonIconId);
            fileInfo.setStatPictureSize(attachment.emoticonIconSize);
            fileInfo.setPackageToken(attachment.emoticonPackageToken);
            // debugger;
            if(fileInfo){
                if(fileInfo.fileId){
                    fileId = fileInfo.fileId;
                }else if(fileInfo.dynPictureId){
                    fileId = fileInfo.dynPictureId;
                }

                if(fileInfo.mThumbId ){
                    mThumbId = fileInfo.mThumbId;
                }else if(fileInfo.statPictureId){
                    mThumbId = fileInfo.statPictureId;
                }
            }

            this.setAttachment(fileInfo);

        } else if(msgType == MessageConsts.TYPE_IMAGE || msgType == MessageConsts.TYPE_VIDEO ||            msgType == MessageConsts.TYPE_FILE || msgType == MessageConsts.TYPE_VOICE) {

            if(msgType == MessageConsts.TYPE_IMAGE){
                fileInfo = new ImageInfo();
            }
            else if(msgType == MessageConsts.TYPE_VIDEO){
                fileInfo = new VideoInfo();
            }
            else if(msgType == MessageConsts.TYPE_FILE){
                fileInfo = new FileInfo();
            } else if(msgType == MessageConsts.TYPE_VOICE){
                fileInfo = new VoiceInfo();
                var bitRate = this.getBitRate();
                if(!bitRate && bitRate != ''){
                    fileInfo.setBitRate("5");//for now hardcoding 12kbps
                }
                fileInfo.setTotalTime(this.getAudioTime());
            }

            if(attachment.size){
                fileInfo.setFileSize(attachment.size);
            }else if(attachment.mFileSize){
                fileInfo.setFileSize(attachment.mFileSize);
            }

            // debugger;
            if(msgType == MessageConsts.TYPE_IMAGE || msgType == MessageConsts.TYPE_VIDEO){
                if(thumb){
                    if(thumb.size && thumb.size != ""){
                        fileInfo.setThumbSize(thumb.size);//need to pass the thumb size
                    } else{
                        fileInfo.setThumbSize(attachment.size);//need to pass the thumb size
                    }
                } else{
                    // fileInfo.setThumbSize(this.getThumbSize());//need to pass the thumb size
                    fileInfo.setThumbId(this.getThumbId());
                }
            }


            if(this.getThumbId()){
                fileInfo.setThumbId(this.getThumbId());
            }
            if(this.getFileId()){
                fileInfo.setFileId(this.getFileId());
            }

            if(attachment._file){
                if(attachment.mFileName){
                    fileName = attachment.mFileName;
                }

                fileInfo._file = attachment._file;
                // fileInfo._thumb= thumb;
                if(this.getThumbLocalPath()){
                    thumbLocalPath = this.getThumbLocalPath();
                }
                if(this.getFileLocalPath()){
                    fileLocalPath = this.getFileLocalPath();
                }
            }else{
                if(attachment.name){
                    fileName = attachment.name.substring(attachment.name.lastIndexOf('/')+1);
                }else if(attachment.mFileName){
                    fileName = attachment.mFileName;
                }

                fileInfo._file = attachment;
                // fileInfo._thumb= thumb;
                if(attachment){
                    if(attachment.name && attachment.name != ""){
                        thumbLocalPath = attachment.name;
                        if(thumb){
                            if(thumb.name && thumb.name != ""){
                                thumbLocalPath = thumb.name;// thumb testing
                            }
                        }
                        fileLocalPath = attachment.name;
                    }
                }
            }

            if(msgType != MessageConsts.TYPE_VOICE){
                fileInfo.setFileName(fileName);
            }

            if(fileInfo.fileId){
                this.setFileId(fileInfo.fileId);
            }
            if(fileInfo.mThumbId){
                this.setThumbId(fileInfo.mThumbId);
            }

            if(attachment.fileId){
                this.setFileId(attachment.fileId);
                fileInfo.fileId = this.getFileId();
            }
            if(attachment.mThumbId){
                this.setThumbId(attachment.mThumbId);
                fileInfo.mThumbId = this.getThumbId();
            }

            if(thumbLocalPath && thumbLocalPath != ""){
                this.setThumbLocalPath(thumbLocalPath);
            }
            if(fileLocalPath && fileLocalPath != ""){
                this.setFileLocalPath(fileLocalPath);
            }

            this.setAttachment(fileInfo);
        }
    },

    toChatObject: function(){
        var chatMessage = new ChatMessage();
        var from, to;
        var msgType = this.getMsgType();
        var attachment = this.getAttachment();
        var sessionType = this.getSessionType();
        var thumb = this.getThumbObj();
        from = CommonUtilsModel.getInstance().StringToByteArray(this.getMsgFrom());
        if(sessionType == AppConstants.BROADCAST_MESSAGE){
            var peerId = JSON.parse(this.getBroadcastPeerIds());
            if(peerId && peerId.length > 0){
                var peerIdByteArray = [];
                peerId.forEach(function(item){
                    if(item && item != ""){
                        peerIdByteArray.push(CommonUtilsModel.getInstance().StringToByteArray(item));
                    }
                });
                chatMessage.setFrom(peerIdByteArray);
            }
            chatMessage.setTo(from);
            chatMessage.setBroadCast(true);
        } else{
            to = CommonUtilsModel.getInstance().StringToByteArray(this.getMsgTo());
            if(sessionType == CINRequestConts.SESSIONGROUP){
                chatMessage.setSessionType(CINRequestConts.SESSIONGROUP);
                chatMessage.setFrom(from);
                chatMessage.setTo(to);
            }else{
                chatMessage.setFrom(to);
                chatMessage.setTo(from);
            }
        }
        
        if(msgType == MessageConsts.TYPE_FREE_SMS){
            chatMessage.setMobileNumbers(this.getMobileNumbers());
        }
        var msgId = CommonUtilsModel.getInstance().StringToByteArray(String(this.getMsgId()));
        chatMessage.setMessageId(msgId);
        chatMessage.setMessageType(msgType);
        if(this.getMsgContent() && this.getMsgContent() != ""){
            chatMessage.setMessageBody(this.getMsgContent());
        }

        if(msgType == MessageConsts.TYPE_IMAGE || msgType == MessageConsts.TYPE_FILE || 
           msgType == MessageConsts.TYPE_VIDEO) {
               var lAttachment = this.getAttachment();
               var fileId = lAttachment.fileId;
               var mThumbId = lAttachment.mThumbId;
            //    var fileName = lAttachment.mFileName;
            if(thumb){
                if(thumb.size && thumb.size != ""){
                    lAttachment.setThumbSize(thumb.size);//need to pass the thumb size
                } else{
                    lAttachment.setThumbSize(attachment.size);//need to pass the thumb size
                }
                lAttachment.thumbnailObj._file = thumb; // thumb testing
            } else{
                lAttachment.setThumbSize(attachment.size);//need to pass the thumb size
                lAttachment.thumbnailObj._file = attachment;
            }

            if(mThumbId){
                lAttachment.setThumbId(mThumbId);
            }
            if(fileId){
                lAttachment.setFileId(fileId);
            }

            // if(fileName){
            //     lAttachment.setFileName(fileName);
            // } else if(!fileName){
            //     if(msgType == MessageConsts.TYPE_IMAGE){
            //         fileName = fileId + "_IMAGE";
            //     } else if(msgType == MessageConsts.TYPE_VIDEO){
            //         fileName = fileId + "_VIDEO";
            //     } else if(msgType == MessageConsts.TYPE_FILE){
            //         fileName = fileId + "_FILE";
            //     }
            //     lAttachment.setFileName(fileName);
            // }

            chatMessage.setAttachment(lAttachment);
        }
        else if(msgType == MessageConsts.TYPE_CARD || msgType == MessageConsts.TYPE_VOICE || msgType == MessageConsts.TYPE_EMOTICON || msgType == MessageConsts.TYPE_LOCATION){
            chatMessage.setAttachment(attachment);
        }
        return chatMessage;
    },

    sendMessage: function(isUploaded, callback){
        var that = this;
        var chatMessage = this.toChatObject();
        var msgType = this.getMsgType();
        // debugger;
        if(!isUploaded && (msgType == MessageConsts.TYPE_IMAGE || msgType == MessageConsts.TYPE_VOICE || msgType == MessageConsts.TYPE_VIDEO || msgType == MessageConsts.TYPE_GRAFFI || msgType == MessageConsts.TYPE_FILE)){// || msgType == MessageConsts.TYPE_LOCATION
            var to = chatMessage.getTo();
            var peerIds = new Array();
            peerIds.push(to);
            var mainAttachment = chatMessage.getAttachment();
            mainAttachment.peerIds = peerIds;
            mainAttachment.msgId = this.getMsgId();
            mainAttachment.msgType = this.getMsgType();
            if(msgType == MessageConsts.TYPE_LOCATION){
                if(mainAttachment.thumbnailObj){
                    mainAttachment.thumbnailObj.msgId = mainAttachment.msgId;
                    mainAttachment.thumbnailObj.peerIds = peerIds;
                    DataManager.getInstance().addAttachmet(mainAttachment.thumbnailObj);
                }
            } else{
                if(mainAttachment.thumbnailObj){
                    mainAttachment.thumbnailObj.msgId = mainAttachment.msgId;
                }
                DataManager.getInstance().addAttachmet(mainAttachment);
            }
        } else {
            if(this.getSessionType() == CINRequestConts.SESSIONPUBLIC){
                RMCManager.getInstance().sendMessage(chatMessage, {
                    onSuccess: function(response){
                        if(callback && callback.onSuccess){
                            callback.onSuccess(response);
                        }

                        if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
                            // JioAnalytics - Message Sent
                            var analyticDataObj = {
                                "eventName" : "Message_sent",
                                "eventType" : "events",
                                "dateTime" : new Date()
                            };
                            JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
                        }

                    },
                    onError: function(errResponse){
                        if(callback && callback.onError){
                            callback.onError(errResponse);
                        }
                    }
                });
            } else{
                JIOClient.getInstance().sendMessage(chatMessage, {
                    onSuccess: function(response) {
                        if(callback && callback.onSuccess){
                            callback.onSuccess(response);
                        }
                        that.captureAnalytics(response);
                    },
                    onError: function(errResponse) {
                        if(callback && callback.onError){
                            callback.onError(errResponse);
                        }
                    }
                });
            }
        }
    },

    getNotificationMsg: function(){
        if(JioChatSDK.getInstance().isSDKMode() == JCSDKConstants.SDK_ENABLED_MODE){
            var notification = {
                showMsgNotification: false,
                messageBody: ""
            };
            return notification;
        }
        if(!TimeUtils){
            return;
        }
        var showMsgNotification = true;
        if(window.dndFrom != "" && window.dndTo != ""){
          var fromHour = TimeUtils.getDndHours(window.dndFrom);
          var toHour = TimeUtils.getDndHours(window.dndTo);
          var date = new Date();

          fromHour = parseInt(fromHour);
          toHour = parseInt(toHour);

          if(isNaN(fromHour)){
              fromHour = -1;
          }
          if(isNaN(toHour)){
              toHour = -1;
          }

          console.log('Date get hours; ' + currentHour);
          var currentHour = date.getHours();
        //   var currentHour = moment(date).format("A hh:mm");
          if(fromHour != -1 && toHour != -1 && currentHour >= fromHour && currentHour <= toHour){
            showMsgNotification = false;
          }
        }
        var notification = {
            showMsgNotification: showMsgNotification,
            messageBody: ""
        };
        var msgType = this.getMsgType();
        if(msgType == MessageConsts.TYPE_TEXT || msgType == MessageConsts.TYPE_FREE_SMS){
            notification.messageBody = this.getMsgContent();
        } else if (msgType == MessageConsts.TYPE_IMAGE){
            notification.messageBody = "[Image]";
        } else if (msgType == MessageConsts.TYPE_VIDEO){
            notification.messageBody = "[Video]";
        } else if (msgType == MessageConsts.TYPE_CARD){
            notification.messageBody = "[Business Card]";
        } else if (msgType == MessageConsts.TYPE_VOICE){
            // messageBody = "[Voice Message]";
            notification.messageBody = "";
        } else if (msgType == MessageConsts.TYPE_FILE){
            // messageBody = "[File]";
            notification.messageBody = "";
        } else if (msgType == MessageConsts.TYPE_EMOTICON){
            // messageBody = "[Sticker]";
            notification.messageBody = "";
        } else if(msgType == MessageConsts.TYPE_PUBLIC_IMAGETEXT){
            // if(attachment && attachment){
            //     notification.messageBody = "";
            // }
        }
        return notification;
    },

    captureAnalytics: function(responseObj){
        if(responseObj && AppMode.TYPE == AppMode.APP_TYPE_JMS){
            var eventName, label;
            if(responseObj.sessionType){
                eventName = 'message_P2P';
                label = 'Sent P2P Message'
            } else if(responseObj.sessionType == CINRequestConts.SESSIONGROUP){
                eventName = 'message_group';
                label = 'Sent Group Message'
            }

            var msgType = '';
            if(responseObj.msgType == MessageConsts.TYPE_TEXT){
                msgType = 'text';
            } else if(responseObj.msgType == MessageConsts.TYPE_IMAGE){
                msgType = 'image';
            } else if(responseObj.msgType == MessageConsts.TYPE_VIDEO){
                msgType = 'video';
            } else if(responseObj.msgType == MessageConsts.TYPE_CARD){
                msgType = 'contact';
            } else if(responseObj.msgType == MessageConsts.TYPE_VOICE){
                msgType = 'audionote';
            }
            if(msgType == ''){
                return;
            }

            // Jio analytics code
            var analyticDataObj = {
                eventName : eventName,
                eventType : "events",
                dateTime : new Date(),
                exceptionType : msgType,
            };
            JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
        }
    },

    /**
     * Method will set the sessionId. Here the sessionId can be peerId/groupId/channelId.
     * @param {String} sessionId - contains the sessionId of partyB
     * @memberof JCMessage#
     */
    setSessionId: function(sessionId){
        this.sessionId = String(sessionId);
    },

    /**
     * Method will get the sessionId(partyB). Here the sessionId can be peerId/groupId/channelId.
     * @return {String}
     * @memberof JCMessage#
     */
    getSessionId: function(){
        return this.sessionId;
    },

    /**
     * Method will set the sessionType.
     * @param {CINRequestConts} sessionType - sessionType will any one of these based on the conversation.
     * @example
     * var jcMsgObj = new JCMessage();
     * jcMsgObj.setSessionType(CINRequestConts.SESSIONSINGLE);
     * @memberof JCMessage#
     */
    setSessionType: function(sessionType){
        this.sessionType = sessionType;
    },

    /**
     * Method will get the sessionType.
     * @return {CINRequestConts}
     * @memberof JCMessage#
     */
    getSessionType: function(){
        return this.sessionType;
    },

    /**
     * Method will set the messageId. If msgId is undefined/null will set the random messageId. The msgId should set only for resending the message else msgId will be undefined.
     * @param {String} msgId - contains the messageId of the message
     * @memberof JCMessage#
     */
    setMsgId: function(msgId){
        if(!msgId || msgId == ""){
            msgId = UUID.randomUUID();
        }
        this.msgId = msgId;
    },

    /**
     * Method will get the messageId.
     * @return {String}
     * @memberof JCMessage#
     */
    getMsgId: function(){
        return this.msgId;
    },

    /**
     * Method will set the mobile number as an array of String. This will be set only for sending free SMS.
     * @param {Array<String>} mobileNumbers - contains the array of mobile number as string
     * @memberof JCMessage#
     */
    setMobileNumbers: function(mobileNumbers){
        if(mobileNumbers && mobileNumbers.length > 0){
            this.mobileNumbers = mobileNumbers;
        }
    },

    /**
     * Method will get the mobile numbers.
     * @return {Array<String>}
     * @memberof JCMessage#
     */
    getMobileNumbers: function(){
        return this.mobileNumbers;
    },

    /**
     * Method will set the msgDirection. If msgDirection is 0 message flows on the sender(right) side which means you sent the message else message flows on the receipient(left) side
     * @param {Number} msgDirection - msgDirection will be 0/1
     * @memberof JCMessage#
     */
    setMsgDirection: function(msgDirection){
        this.msgDirection = msgDirection;
    },

    /**
     * Method will get the msgDirection.
     * @return {Number}
     * @memberof JCMessage#
     */
    getMsgDirection: function(){
        return this.msgDirection;
    },

    /**
     * Method will set the msgContent. Will be set only if msgType is TEXT OR FREE_SMS else optional
     * @param {String} msgContent - contains the message body
     * @memberof JCMessage#
     */
    setMsgContent: function(msgContent){
        this.msgContent = msgContent;
    },

    /**
     * Method will get the message body.
     * @return {String}
     * @memberof JCMessage#
     */
    getMsgContent: function(){
        return this.msgContent;
    },

    /**
     * Method will set the msgType. Which tells us the what kind of message it is. Usually this can be set using MessageConsts
     * @param {MessageConsts} msgType - contains the message type
     * @example
     * var jcMsgObj = new JCMessage();
     * jcMsgObj.setMsgType(MessageConsts.TYPE_TEXT);
     * @memberof JCMessage#
     */
    setMsgType: function(msgType){
        this.msgType = msgType;
    },

    /**
     * Method will get the msgType.
     * @return {MessageConsts}
     * @memberof JCMessage#
     */
    getMsgType: function(){
        return this.msgType;
    },

    /**
     * Method will set the userId of whom we're sending.
     * @param {String} msgFrom - contains the userId of the peer who is sending the message in case of group messages. For P2P messages this will be the peerId(receipient userId).
     * @memberof JCMessage#
     */
    setMsgFrom: function(msgFrom){
        this.msgFrom = msgFrom;
    },

    /**
     * Method will get the msgFrom
     * @return {String}
     * @memberof JCMessage#
     */
    getMsgFrom: function(){
        return this.msgFrom;
    },

    /**
     * Method will set the sender userId. Which is basically our userId
     * @param {String} msgTo - contains the peerId/receipient ID to whom we're going to send message in case of group messages. For P2P messages this will be the userId of sender.
     * @memberof JCMessage#
     */
    setMsgTo: function(msgTo){
        this.msgTo = msgTo;
    },

    /**
     * Method will get the msgTo.
     * @return {String}
     * @memberof JCMessage#
     */
    getMsgTo: function(){
        return this.msgTo;
    },

    /**
     * Method will set the server dateTime in utc milliseconds
     * @param {long} msgDateTime - contains the server message date time in UTCMilliseconds
     * @memberof JCMessage#
     */
    setMsgDateTime: function(msgDateTime){
        this.msgDateTime = msgDateTime;
    },
    
    /**
     * Method will get the server dateTime in utc milliseconds
     * @return {long}
     * @memberof JCMessage#
     */
    getMsgDateTime: function(){
        return this.msgDateTime;
    },

    /**
     * Method will set the local dateTime in utc milliseconds
     * @param {long} msgDateTime - contains the local date time in UTCMilliseconds
     * @memberof JCMessage#
     */
    setMsgLocalDateTime: function(msgLocalDateTime){
        this.msgLocalDateTime = msgLocalDateTime;
    },

    /**
     * Method will get the local dateTime in utc milliseconds
     * @return {long}
     * @memberof JCMessage#
     */
    getMsgLocalDateTime: function(){
        return this.msgLocalDateTime;
    },

    setThumbStatus: function(msgThumbStatus){
        this.msgThumbStatus = msgThumbStatus;
    },

    getThumbStatus: function(){
        return this.msgThumbStatus;
    },

    /**
     * Method will set the message status. Whether the message is sent/delivered/read. The value will be MessageConsts.
     * @param {Number} msgStatus - contains the message status
     * @memberof JCMessage#
     */
    setMsgStatus: function(msgStatus){
        this.msgStatus = msgStatus;
    },

    /**
     * Method will get the message status.
     * @return {Number}
     * @memberof JCMessage#
     */
    getMsgStatus: function(){
        return this.msgStatus;
    },

    setMsgFileStatus: function(msgFileStatus){
        this.msgFileStatus = msgFileStatus;
    },

    getMsgFileStatus: function(){
        return this.msgFileStatus;
    },

    setMsgRead: function(msgRead){
        this.msgRead = msgRead;
    },

    getMsgRead: function(){
        return this.msgRead;
    },

    /**
     * Method will the set the message sequence from the server.
     * @param {long} msgSequence - contains the server message sequence
     * @memberof JCMessage#
     */
    setMsgSequence: function(msgSequence){
        this.msgSequence = msgSequence;
    },

    /**
     * Method will get the server msg sequence
     * @return {long}
     * @memberof JCMessage#
     */
    getMsgSequence: function(){
        return this.msgSequence;
    },

    setMsgLocalSequence: function(msgLocalSequence){
        this.msgLocalSequence = msgLocalSequence;
    },

    getMsgLocalSequence: function(){
        return this.msgLocalSequence;
    },

    /**
     * Method will set the message deleted status. Whenever sending messages msgDelete status will be "0"
     * @param {String} msgDelete - contains the msgDelete. The value will be "0" or "1". 0 - msg not deleted, 1 - msg deleted
     * @memberof JCMessage#
     */
    setMsgDelete: function(msgDelete){
        this.msgDelete = msgDelete;
    },

    /**
     * Method will get the message deleted status.
     * @return {String}
     * @memberof JCMessage#
     */
    getMsgDelete: function(){
        return this.msgDelete;
    },

    /**
     * Method used set the audio bitrate.
     * @param {String} bitRate - contains the audio bitRate.
     * @memberof JCMessage#
     */
    setBitRate: function(bitRate){
        this.bitRate = bitRate;
    },

    /**
     * Method will get the bitRate.
     * @return {String}
     * @memberof JCMessage#
     * @ignore
     */
    getBitRate: function(){
        return this.bitRate;
    },

    setMsgTOS: function(msgTOS){
        this.msgTOS = msgTOS;
    },

    getMsgTOS: function(){
        return this.msgTOS;
    },

    setMsgMultimedia: function(msgMultimedia){
        this.msgMultimedia = msgMultimedia;
    },

    getMsgMultimedia: function(){
        return this.msgMultimedia;
    },

    setMsgListen: function(msgListen){
        this.msgListen = msgListen;
    },

    getMsgListen: function(){
        return this.msgListen;
    },
    
    setMsgPeerName: function(msgPeerName){
        this.msgPeerName = msgPeerName;
    },

    getMsgPeerName: function(){
        return this.msgPeerName;
    },

    setName: function(name){
        this.name = name;
    },

    getName: function(){
        return this.name;
    },

    /**
     * Method used set the attachment object
     * @param {object} attachment - contains the blob object
     * @memberof JCMessage#
     */
    setAttachment: function(attachment){
        this.attachment = attachment;
    },

    /**
     * Method will get the attachment object.
     * @return {object}
     * @memberof JCMessage#
     * @ignore
     */
    getAttachment: function(){
        return this.attachment;
    },

    /**
     * Method used set the file id
     * @param {String} fileId - contains the file id
     * @memberof JCMessage#
     */
    setFileId: function(fileId){
        this.fileId = fileId;
    },

    /**
     * Method used get the file id.
     * @return {String}
     * @memberof JCMessage#
     */
    getFileId: function(){
        return this.fileId;
    },

    /**
     * Method used set the thumb id
     * @param {String} mThumbId - contains the thumb id
     * @memberof JCMessage#
     */
    setThumbId: function(mThumbId){
        this.mThumbId = mThumbId;
    },

    /**
     * Method used get the thumb id.
     * @return {String}
     * @memberof JCMessage#
     */
    getThumbId: function(){
        return this.mThumbId;
    },

    setFileLocalPath: function(fileLocalPath){
        this.fileLocalPath = fileLocalPath;
    },

    /**
     * Method used get the file local path.
     * @return {String}
     * @memberof JCMessage#
     */
    getFileLocalPath: function(){
        return this.fileLocalPath;
    },

    setThumbLocalPath: function(thumbLocalPath){
        this.thumbLocalPath = thumbLocalPath;
    },

    /**
     * Method used get the thumb local path.
     * @return {String}
     * @memberof JCMessage#
     */
    getThumbLocalPath: function(){
        return this.thumbLocalPath;
    },

    setBroadcastUsers: function(broadcastUsers){
        this.broadcastUsers = broadcastUsers;
    },

    getBroadcastUsers: function(){
        return this.broadcastUsers;
    },

    setAudioPlayed: function(isAudioPlayed){
        this.isAudioPlayed = isAudioPlayed;
    },

    isAudioPlayed: function(){
        return this.isAudioPlayed;
    },

    setCallMode: function(callMode){
        this.callMode = callMode;
    },

    getCallMode: function(){
        return this.callMode;
    },

    /**
     * Method used set the thumbnail object
     * @param {object} thumbObj - contains the thumbnail blob
     * @memberof JCMessage#
     */
    setThumbObj: function(thumbObj){
        this.thumbObj = thumbObj;
    },

    /**
     * Method used get the thumbnail object
     * @return {object} - contains the thumbnail object
     * @memberof JCMessage#
     * @ignore
     */
    getThumbObj: function(){
        return this.thumbObj;
    },

    /**
     * Method used set the audio time
     * @param {String} audioTime - contains the audio recorded time
     * @memberof JCMessage#
     */
    setAudioTime: function(audioTime){
        this.audioTime = audioTime;
    },

    /**
     * Method used get the audio time
     * @return {String} - contains the audio recorded time
     * @memberof JCMessage#
     * @ignore
     */
    getAudioTime: function(){
        return this.audioTime;
    },

    setBlack: function(isBlack){
        this.isBlack = isBlack;
    },

    isBlack: function(){
        return this.isBlack;
    },

    setBroadcastPeerIds: function(broadcastPeerIds){
        this.broadcastPeerIds = broadcastPeerIds;
    },

    getBroadcastPeerIds: function(){
        return this.broadcastPeerIds;
    }

}
