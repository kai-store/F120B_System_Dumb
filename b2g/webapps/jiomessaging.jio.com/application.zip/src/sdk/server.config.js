function ServerConfig() {}

ServerConfig.setIOT = function () {
    HTTPRequestConts.BASE_URL = 'https://iotnav.rsocial.net:8011/';
    HTTPRequestConts.BASE_URL_ACP = 'https://iotacp.rsocial.net:8091/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://iotacp.rsocial.net:8091/';
    console.log("HTTP links are pointing to IOT");
}

ServerConfig.setProduction = function () {
    HTTPRequestConts.BASE_URL = 'https://nav.jiobuzz.com/';
    HTTPRequestConts.BASE_URL_ACP = 'https://acp.jiobuzz.com/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://acp.jiobuzz.com/';
    console.log("HTTP links are pointing to Production");
    HTTPRequestConts.isProd = true;
}

ServerConfig.setPreProduction = function () {
    HTTPRequestConts.BASE_URL = 'https://preprod.rsocial.net:9000/';
    HTTPRequestConts.BASE_URL_ACP = 'https://preprod.rsocial.net:9001/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://preprod.rsocial.net:9001/';
    console.log("HTTP links are pointing to pre-Production");
    HTTPRequestConts.isProd = false;

}

ServerConfig.setReplica = function () {
    HTTPRequestConts.BASE_URL = 'https://navreplica.rsocial.net:8010/';
    HTTPRequestConts.BASE_URL_ACP = 'https://acpreplica.rsocial.net:8020/';
    HTTPRequestConts.BASE_URL_ACP_LOGIN = 'https://acpreplica.rsocial.net:8020/';
    console.log("HTTP links are pointing to Replica");
}