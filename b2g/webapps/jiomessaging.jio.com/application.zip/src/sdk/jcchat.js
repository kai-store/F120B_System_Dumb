/**
 * Class is for JCChat information.
 * @class
 */
function JCChat() {
    this.sessionId = "";
	this.peerId = "";
	this.mobileNumbers = "";
	this.sessionType = "";
	this.name = "";
	this.userIds = "";
	this.top = "";
	this.show = "";
	this.delete = "";
	this.maxVersion = "";
	this.lastMessage = "";
	this.draftMessage = "";
    this.msgDateTime = "";
    this.msgLocalDateTime = "";
    this.sessionImageData = "";
    this.msgType = "";
    this.lastReadSeq = "0";
    this.unreadCount = 0;
    this.msgStatus = "";
    this.msgDirection = "";
    this.followType = -1;
    this.pinToTop = -1;
    this.showThis = true;
    this.callMode = "";
}

JCChat.prototype = {

    init: function(chatObj){
        if(chatObj && typeof chatObj == "object"){
            this.setSessionId(chatObj.sessionId);
            this.setMobileNumbers(chatObj.mobileNumber);
            this.setPeerId(chatObj.peerId);
            this.setSessionType(chatObj.sessionType);
            this.setName(chatObj.name);
            this.setUserIds(chatObj.userIds);
            this.setTop(chatObj.isTop);
            this.setDelete(chatObj.isDelete);
            this.setLastMessage(chatObj.lastMessage);
            this.setDraftMessage(chatObj.draftMessage);
            this.setMsgLocalDateTime(chatObj.msgLocalDateTime);
            this.setMsgDateTime(chatObj.msgDateTime);
            this.setImage(chatObj.sessionImageData);
            this.setMsgType(chatObj.msgType);
            this.setUnreadCount(chatObj.unreadCount);
            this.setMsgStatus(chatObj.msgStatus);
            this.setMsgDirection(chatObj.msgDirection);
            this.setPinToTop(chatObj.pinToTop);
            this.setCallMode(chatObj.callMode);
        }
    },

    /**
     * Method will set the sessionId. Here the sessionId can be peerId/groupId/channelId.
     * @param {String} sessionId - contains the sessionId of partyB
     * @memberof JCChat#
     * @ignore
     */
    setSessionId: function(sessionId){
        this.sessionId = String(sessionId);
    },
    /**
     * Method will get the sessionId(partyB). Here the sessionId can be peerId/groupId/channelId.
     * @return {String}
     * @memberof JCChat#
     */
    getSessionId: function(){
        return this.sessionId;
    },

    /**
     * Method will set the peerId. Here the peerId can be peerId/groupId/channelId.
     * @param {String} peerId - contains the peerId of partyB
     * @memberof JCChat#
     * @ignore
     */
    setPeerId: function(peerId){
        this.peerId = String(peerId);
    },
    /**
     * Method will get the peerId(partyB). Here the peerId can be peerId/groupId/channelId.
     * @return {String}
     * @memberof JCChat#
     */
    getPeerId: function(){
        return this.peerId;
    },

    /**
     * Method will set the mobile number as an array of String. This will be set only for sending free SMS.
     * @param {Array<String>} mobileNumbers - contains the array of mobile number as string
     * @memberof JCChat#
     * @ignore
     */
    setMobileNumbers: function(mobileNumbers){
        if(mobileNumbers && mobileNumbers.length > 0){
            this.mobileNumbers = mobileNumbers;
        }
    },
    /**
     * Method will get the mobile numbers.
     * @return {Array<String>}
     * @memberof JCChat#
     */
    getMobileNumbers: function(){
        return this.mobileNumbers;
    },

    /**
     * Method will set the sessionType.
     * @param {CINRequestConts} sessionType - sessionType will be any one among these based on the conversation.
     * @example
     * var jcChatObj = new JCChat();
     * jcChatObj.setSessionType(CINRequestConts.SESSIONSINGLE);
     * @memberof JCChat#
     * @ignore
     */
    setSessionType: function(sessionType){
        this.sessionType = sessionType;
    },
    /**
     * Method will get the sessionType.
     * @return {CINRequestConts}
     * @memberof JCChat#
     */
    getSessionType: function(){
        return this.sessionType;
    },

    /**
     * Method will set the conversation name.
     * @param {String} name - contains the name of the conversation.
     * @memberof JCChat#
     * @ignore
     */
    setName: function(name){
        if(name && name != ""){
            this.name = name;
        }
    },
    /**
     * Method will get the chat name.
     * @return {String}
     * @memberof JCChat#
     */
    getName: function(){
        return this.name;
    },

    /**
     * Method will set the userIds.
     * @param {Array<String>} userIds - contains the userIds.
     * @memberof JCChat#
     * @ignore
     */
    setUserIds: function(userIds){
        if(userIds && userIds.length > 0){
            this.userIds = userIds;
        }
    },
    /**
     * Method will get the userIds.
     * @return {Array<String>}
     * @memberof JCChat#
     * @ignore
     */
    getUserIds: function(){
        return this.userIds;
    },

    /**
     * Method will set the pin to top.
     * @param {String} top - contains the pin to top.
     * @memberof JCChat#
     * @ignore
     */
    setTop: function(top){
        this.top = top;
    },
    /**
     * Method will get the pin to top.
     * @return {String}
     * @memberof JCChat#
     * @ignore
     */
    isTop: function(){
        return this.top;
    },

    /**
     * Method will set the delete.
     * @param {String} deleted - contains the deleted. The value will 0 - session not deleted, 1 - deleted.
     * @memberof JCChat#
     */
    setDelete: function(deleted){
        this.delete = deleted;
    },
    /**
     * Method will get the pin to top.
     * @return {String}
     * @memberof JCChat#
     */
    isDelete: function(){
        return this.delete;
    },

    /**
     * Method will set the max version.
     * @param {String} maxVersion - contains the max version.
     * @memberof JCChat#
     * @ignore
     */
    setMaxVersion: function(maxVersion){
        this.maxVersion = maxVersion;
    },
    /**
     * Method will get the max version.
     * @return {String}
     * @memberof JCChat#
     * @ignore
     */
    getMaxVersion: function(){
        return this.maxVersion;
    },

    /**
     * Method will set the last message.
     * @param {String} lastMessage - contains the last message.
     * @memberof JCChat#
     * @ignore
     */
    setLastMessage: function(lastMessage){
        this.lastMessage = lastMessage;
    },
    /**
     * Method will get the last message.
     * @return {String}
     * @memberof JCChat#
     */
    getLastMessage: function(){
        return this.lastMessage;
    },

    /**
     * Method will set the draft message.
     * @param {String} draftMessage - contains the draft message.
     * @memberof JCChat#
     * @ignore
     */
    setDraftMessage: function(draftMessage){
        this.draftMessage = draftMessage;
    },
    /**
     * Method will get the draft message.
     * @return {String}
     * @memberof JCChat#
     */
    getDraftMessage: function(){
        return this.draftMessage;
    },

    /**
     * Method will set the server dateTime in utc milliseconds
     * @param {long} msgDateTime - contains the server message date time in UTCMilliseconds
     * @memberof JCChat#
     * @ignore
     */
    setMsgDateTime: function(msgDateTime){
        this.msgDateTime = msgDateTime;
    },
    /**
     * Method will get the server dateTime in utc milliseconds
     * @return {long}
     * @memberof JCChat#
     */
    getMsgDateTime: function(){
        return this.msgDateTime;
    },

    /**
     * Method will set the local dateTime in utc milliseconds
     * @param {long} msgDateTime - contains the local date time in UTCMilliseconds
     * @memberof JCChat#
     * @ignore
     */
    setMsgLocalDateTime: function(msgLocalDateTime){
        this.msgLocalDateTime = msgLocalDateTime;
    },
    /**
     * Method will get the local dateTime in utc milliseconds
     * @return {long}
     * @memberof JCChat#
     */
    getMsgLocalDateTime: function(){
        return this.msgLocalDateTime;
    },

    /**
     * Method will set the msgType. Which tells us the what kind of message it is. Usually this can be set using MessageConsts
     * @param {MessageConsts} msgType - contains the message type
     * @example
     * var jcChatObj = new JCChat();
     * jcChatObj.setMsgType(MessageConsts.TYPE_TEXT);
     * @memberof JCChat#
     * @ignore
     */
    setMsgType: function(msgType){
        this.msgType = msgType;
    },

    /**
     * Method will get the msgType.
     * @return {MessageConsts}
     * @memberof JCChat#
     */
    getMsgType: function(){
        return this.msgType;
    },

    /**
     * Method will set the msgDirection. If msgDirection is 0 message flows on the sender(right) side which means you sent the message else message flows on the receipient(left) side
     * @param {Number} msgDirection - msgDirection will be 0/1
     * @memberof JCChat#
     * @ignore
     */
    setMsgDirection: function(msgDirection){
        this.msgDirection = msgDirection;
    },

    /**
     * Method will get the msgDirection.
     * @return {Number}
     * @memberof JCChat#
     * @ignore
     */
    getMsgDirection: function(){
        return this.msgDirection;
    },

    /**
     * Method will set the unread count.
     * @param {Number} unreadCount - contains the total number of unread messages in a conversation.
     * @memberof JCChat#
     * @ignore
     */
    setUnreadCount: function(unreadCount){
        this.unreadCount = unreadCount;
    },
    /**
     * Method will get the total number of unread messages in a conversation.
     * @return {Number}
     * @memberof JCChat#
     * @ignore
     */
    getUnreadCount: function(){
        return this.unreadCount;
    },

    /**
     * Method will set the message status.
     * @param {String} msgStatus - contains the last message status.
     * @memberof JCChat#
     * @ignore
     */
    setMsgStatus: function(msgStatus){
        this.msgStatus = msgStatus;
    },
    /**
     * Method will get the last message status.
     * @return {String}
     * @memberof JCChat#
     */
    getMsgStatus: function(){
        return this.msgStatus;
    },

    /**
     * Method will set the chat image.
     * @param {Base64String} imageData - contains the chat image data in base64.
     * @memberof JCChat#
     * @ignore
     */
    setImage: function(imageData){
        this.sessionImageData = imageData;
    },

    /**
     * Method will get the chat image.
     * @return {Base64String}
     * @memberof JCChat#
     */
    getImage: function(){
        return this.sessionImageData;
    },

    /**
     * Method will set the follow type.
     * @param {Number} followType - contains the follow type.
     * @memberof JCChat#
     * @ignore
     */
    setFolowType: function(followType){
        this.followType = followType;
    },

    /**
     * Method will get the follow type.
     * @return {Number}
     * @memberof JCChat#
     * @ignore
     */
    getFollowType: function(){
        return this.followType;
    },

    /**
     * Method will set the pinToTop.
     * @param {Number} pinToTop - pinToTop will be -1 OR 1
     * @memberof JCChat#
     * @ignore
     */
    setPinToTop: function(pinToTop){
        this.pinToTop = pinToTop;
    },

    /**
     * Method will return the pinToTop.
     * @return {Number}
     * @memberof JCChat#
     * @ignore
     */
    getPinToTop: function(){
        return this.pinToTop;
    },

    /**
     * Method will set the call mode.
     * @param {String} callMode - callMode will be voice/video
     * @memberof JCChat#
     * @ignore
     */
    setCallMode: function(callMode){
        this.callMode = callMode;
    },

    /**
     * Method will return the callMode.
     * @return {String}
     * @memberof JCChat#
     * @ignore
     */
    getCallMode: function(){
        return this.callMode;
    },
}
