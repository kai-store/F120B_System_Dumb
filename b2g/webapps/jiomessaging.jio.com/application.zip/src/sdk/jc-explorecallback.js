/**
 * @interface ExploreChannelListAPICallback
 * @desc
 * ExploreChannelListAPICallback is an anonymous interface will get invoked whenever success/failure response from the server after getting explorelist to the server
 */
var ExploreChannelListAPICallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @function onSuccess
     * @callback ExploreChannelListAPICallback~onSuccess
     * @param {Array<JCExplore>} explore - contains the JCExplore object
     * @memberof ExploreChannelListAPICallback
     */
    onSuccess:function(explore){
        
    },

    /**
     * Method will be triggered when explore gets failed.
     * @function onError
     * @callback ExploreChannelListAPICallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof ExploreChannelListAPICallback
     */
    onError: function(errorResponse){

    }
}

/**
 * @interface ExploreChannelInfoAPICallback
 * @desc
 * ExploreChannelInfoAPICallback is an anonymous interface will get invoked whenever success/failure response from the server after getting exploreChannelInfo to the server
 */
var ExploreChannelInfoAPICallback = {
    /**
     * Method will be triggered when success response from the server.
     * @function onSuccess
     * @callback ExploreChannelInfoAPICallback~onSuccess
     * @param {JCExploreContent} successResponse - contains the JCExploreContent
     * @memberof ExploreChannelInfoAPICallback
     */
    onSuccess:function(successResponse){
        
    },

    /**
     * Method will be triggered when exploreChannelInfo  gets failed
     * @function onError
     * @callback ExploreChannelInfoAPICallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof ExploreChannelInfoAPICallback
     */
    onError: function(errorResponse){

    }
}
