/**
 * Class will represents error information.
 * @class Error
 */
function Error(){
    /**
     * Error code will hold error id.
     * @member {number} errCode
     * @memberof Error#
     * @name errorCode
     */

    /**
     * Error message will hold error message as a string. You can directly display this string to user.
     * @member {string} errMsg
     * @memberof Error#
     * @name errMsg
     */
}
