/**
* Class holds information related to Push Token.
* @class JCPush
*/
function JCPush(){
    this.endPoint = null;
    this.auth = null;
    this.privateString = null;
}

JCPush.prototype = {
    /**
     * Method will set endPoint for push token.
     * @param {String} endPoint - end point from push object
     * @memberof JCPush#
     * 
     */
    setEndPoint :function(endPoint){
        this.endPoint = endPoint;
    },
    /**
     * Method will return endPoint for push token
     * @return {String} endPoint
     * @memberof JCPush#
     */
    getEndPoint: function(){
        return this.endPoint;
    },
    /**
     * Method will set auth for push token.
     * @param  {String} auth - authorization from push object
     * @memberof JCPush#
     */
    setAuth : function(auth){
        this.auth = auth;
    },
    /**
     * Method will return auth for push token.
     * @return {String} auth
     * @memberof JCPush#
     */
    getAuth : function(){
        return this.auth;
    },
    /**
     * Method will set PrivateString for push token.
     * @param {String} privateString - private string of push object
     * @memberof JCPush#
     */
    setPrivateString : function(privateString){
        this.privateString = privateString;
    },
    /**
     * Method will return privateString for push token.
     * @return {String} privateString
     * @memberof JCPush#
     */
    getPrivateString : function(){
        return this.privateString;
    }
}

// JCPush.prototype.setEndPoint = 


// JCPush.prototype.getEndPoint = function(){
//     return this.endPoint;
// }


// JCPush.prototype.setAuth = function(auth){
//     this.auth = auth;
// }


// JCPush.prototype.getAuth = function(){
//     return this.auth;
// }


// JCPush.prototype.setPrivateString = function(privateString){
//     this.privateString = privateString;
// }

// JCPush.prototype.getPrivateString = function(){
//     return this.privateString;
// }
