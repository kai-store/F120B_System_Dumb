/**
 * @interface ContactsBlacklistCallback
 * @desc
 * ContactsBlacklistCallback is an anonymous interface will get invoked whenever success/failure response from the server after sending block/unblock contact to the server
 */
var ContactsBlacklistCallback = {
    /**
     * Method will be triggered when success response from the server. 
     * @callback ContactsBlacklistCallback~onSuccess
     * @param {Map<string,object>} contact - contains the contact list
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof ContactsBlacklistCallback
     */
    onSuccess:function(version,userId,successResponse){

     },

    /**
     * Method will be triggered when message gets failed.
     * @callback ContactsBlacklistCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof ContactsBlacklistCallback
     */
    onError:function(errorResponse){
        
     }
}

/**
 * @interface ContactsInfoCallback
 * @desc
 * ContactsInfoCallback is an anonymous interface will get invoked when we retrieve contactInfo from LDB
 */
var ContactsInfoCallback = {
    /**
     * Method will be triggered when we retrieve contactInfo from LDB by contactId
     * @callback ContactsInfoCallback~onSuccess
     * @param {Object} contact - contains the contact object if exists else empty object
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof ContactsInfoCallback
     */
    onSuccess:function(Contact){

     }
}


/**
 * @interface SyncContactWithProfileCallback
 * @desc
 * SyncWithNumberCallback is an anonymous interface will get invoked when we retrieve contactInfo with profile
 */
var SyncContactWithProfileCallback = {
    /**
     * Method will be triggered when we retrieve contactInfo from LDB by contactId
     * @callback SyncContactWithProfileCallback~onSuccess
     * @param {Object} contact - contains the contact object if exists else empty object
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.gender - Gender of the user
     * @param contact.portraitId - portraitId of the user obtained from profile 
     * @param contact.mood - Mood for the contact
     * @memberof SyncContactWithProfileCallback
     */
    onSuccess:function(Contact){

     },
    
     /**
     * Method will be triggered when profile pictures of the contacts will be updated
     * if not provided then success callback will be triggered when profile pictures are updated
     * @callback SyncContactWithProfileCallback~onProfilePictureUpdate
     * @param {Object} contact - contains the contact object if exists else empty object
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.gender - Gender of the user
     * @param contact.portraitId - portraitId of the user obtained from profile 
     * @param contact.mood - Mood for the contact
     * @memberof SyncContactWithProfileCallback
     */
    onProfilePictureUpdate: function(contact){

    }
}

/**
 * @interface AllContactsCallback
 * @desc
 * AllContactsCallback is an anonymous interface will get invoked when we retrieve allContacts Info from LDB
 */
var AllContactsCallback = {
    /**
     * Method will be triggered when we retrieve all contacts from LDB 
     * @callback AllContactsCallback~onSuccess
     * @param {Map<string,object>} contact - contains the array contact object if exists else empty array
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof AllContactsCallback
     */
    onSuccess:function(Contact){

     }
}

/**
 * @interface ContactsSyncCallback
 * @desc
 * ContactsSyncCallback is an anonymous interface will get invoked whenever success/failure response from the server after contacts syncing
 */
var ContactsSyncCallback = {
    /**
     * Method will be triggered when contacts syncing is success
     * @callback ContactsSyncCallback~onSuccess
     * @param {Map<string,object>} contacts - contains the array of contact object
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof ContactsSyncCallback
     */
    onSuccess:function(Contact){

     },

    /**
     * Method will be triggered when contact syncing fails
     * @callback ContactsSyncCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof ContactsSyncCallback
     */
    onError:function(errorResponse){
        
     }
}

/**
 * @interface DeviceContactsCallback
 * @desc
 * DeviceContactsCallback is an anonymous interface will get invoked when we retrieve allContacts Info from device
 */
var DeviceContactsCallback = {
    /**
     * Method will be triggered when we retrieve all contacts from LDB 
     * @callback DeviceContactsCallback~onSuccess
     * @param {Map<string,object>} contact - contains the array contact object if exists else empty array
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof DeviceContactsCallback
     */
    onSuccess:function(Contact){

     },
    /**
     * Method will be triggered when contact status will be changed Ex:- status changed from nonJioUser to jioUser
     * @callback DeviceContactsCallback~onUpdate
     * @param {Map<string,object>} contact - contains the array contact object if exists else empty array
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof DeviceContactsCallback
     */
    onUpdate: function(Contact){

    },

    /**
     * Method will be triggered when profile pictures of the contacts will be updated
     * if not provided then success callback will be triggered when profile pictures are updated
     * @callback DeviceContactsCallback~onProfilePictureUpdate
     * @param {Map<String,object>} contact - contains the array contact object if exists else empty array
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof DeviceContactsCallback
     */
    onProfilePictureUpdate: function(contact){

    }
}

/**
 * @interface ContactsFavouriteCallback
 * @desc
 * ContactsFavouriteCallback is an anonymous interface will get invoked when we want to favourite or unfavourite particular contact
 */
var ContactsFavouriteCallback = {
    /**
     * @param {Object} response - Response from Favourite API Ex:- { mobileNumber: "+919343512211", favorite: true }
     * @param {String} response.mobileNumber - mobile number on which favourite API action used  
     * @param {Boolean} response.favorite - status of mobile number true or false 
     */
    onSuccess : function(response){

    },
    /**
     * @param {Object} error - error from favourite API 
     */
    onError : function(error){

    }
}


/**
 * @interface ProfileWithUserIdCallback
 * @desc
 * ProfileWithUserIdCallback is an anonymous interface will get invoked when we retrieve profile of contact from server with userId
 */
var ProfileWithUserIdCallback = {
    /**
     * Method will be triggered when we retrieve all contacts from LDB 
     * @callback ProfileWithUserIdCallback~onSuccess
     * @param {Object} contact - contains the contact object
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof ProfileWithUserIdCallback
     */
    onSuccess:function(Contact){

     },
    /**
     * Method will be triggered when profile picture of the contact will be updated
     * @callback ProfileWithUserIdCallback~onProfilePictureUpdate
     * @param {Object} contact - contains the contact object
     * @param contact.contactId - Id for the contact
	 * @param contact.mobileNumber - Mobile number for the contact
	 * @param contact.phoneBookName - Phonebook name for the contact
	 * @param contact.userId - User id for the contact
     * @param contact.rcsName - JioContact name for the contact
     * @param contact.rcsAvatar - User image for the contact
     * @param contact.activeStatus - Check JioContact or not
     * @param contact.isBlack - Check contact is blocked or not
     * @param contact.cardVersion - Version for the contact
     * @param contact.gender - Gender of the user
     * @param contact.mood - Mood for the contact
     * @param contact.favorite - Check contact is favorite or not
     * @memberof ProfileWithUserIdCallback
     */
    onProfilePictureUpdate: function(contact){

    },
    /**
     * Method will be triggered if any error occured during flow
     * @callback ProfileWithUserIdCallback~onError
     * @param {String} error - caused error will be received here
     * @memberof ProfileWithUserIdCallback
     */
    onError : function(error){

    }
};