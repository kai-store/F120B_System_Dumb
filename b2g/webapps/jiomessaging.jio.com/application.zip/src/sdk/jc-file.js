/**
 * Class is for JCMessage information. 
 * @class
 */
function JCFile () {

}
