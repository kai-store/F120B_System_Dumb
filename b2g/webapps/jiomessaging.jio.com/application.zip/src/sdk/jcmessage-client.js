import BaseModule from '../lib/base-module';
import JIOSDKUtils from './base-jc-user';
import ChatListStore from '../data/chatlist-store';
import MessageStore from '../data/message-store';
import GroupListStore from '../data/groupList-store';
import SettingsStore from '../data/setting-store';
import JCDeviceUtility from './jc-device-utility';

/**
 * @classdesc
 * JCMessageClient is a singleton class which will do all message operations, like sending message, typing event..,
 * 
 * @class JCMessageClient
 */
export default class JCMessageClient extends BaseModule {

	start(){
		this.chatInstance = ChatListStore.getInstance();
		this.msgInstance = MessageStore.getInstance();
		this.deviceUtility = JCDeviceUtility.getInstance();
		this.groupListInstance = GroupListStore.getInstance();
		this.settingInstance = SettingsStore.getInstance();
	}

	/**
	 * Method for sending message to server
	 * @param {JCMessage} messageObj - contains the information about the message object
	 * @param {SendMessageCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
    sendMessage(messageObj, callback){
        if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		// debugger;
		// var msgType = messageObj.getMsgType();
		// if(AppMode.TYPE == AppMode.APP_TYPE_JSDK && (msgType == MessageConsts.TYPE_IMAGE || MessageConsts.TYPE_VIDEO)){
		// 	var that = this;
		// 	var attachment = messageObj.getAttachment();
		// 	if(!attachment){
		// 		JIOUtils.sendError(-1, "Please send a proper request", callback);
		// 		return;
		// 	}

		// 	this.msgInstance.createThumbnailInDevice(attachment, function(fileName){
		// 		that.deviceUtility.getBlob(fileName, {
		// 			onSuccess: function(fileBlob){
		// 				messageObj.setThumbObj(fileBlob);
		// 				console.log("Thumbnail created" + JSON.stringify(messageObj));
		// 				that.msgInstance.sendMessageAPIClient(messageObj, callback);
		// 			},
		// 			onError: function(){

		// 			}
		// 		});
		// 	});
		// } else {
			this.msgInstance.sendMessageAPIClient(messageObj, callback);
		// }
    }

	/**
	 * Method for sending typing event to server
	 * @param {String} peerId - peerId of the receipient
	 * @param {SendTypingCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	sendTyping(peerId, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		this.msgInstance.sendTypingAPIClient(peerId, callback);
	}

	/**
	 * Method for sending reply to the server saying message got received/delivered
	 * @param {String} peerId - peerId of the receipient
	 * @param {String} messageId - messageId of the received message
	 * @param {long} msgSequence - msgSequence of the received message
	 * @param {SendReplyMessageCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	sendReply(peerId, messageId, msgSequence, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		this.msgInstance.replyAPIClient(peerId, messageId, msgSequence, callback);
	}

	/**
	 * Method for sending read reply to the server saying message has been read by the user
	 * @param {String} peerId - peerId of the receipient
	 * @param {Long} lastSeq - lastSeq of the received receipient message
	 * @param {Number} unreadCount - unreadCount of the received receipient message
	 * @param {SendReadReplyMessageCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	sendReadReply(peerId, lastSeq, unreadCount, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		var type = 0;//Always 0, not required
		var sessionType = CINRequestConts.SESSIONSINGLE;//Static
		var isJioUser = true;//Static
		this.msgInstance.readReplyAPIClient(peerId, lastSeq, unreadCount, type, sessionType, isJioUser, callback);
	}

	/**
	 * Method for deleting message
	 * @param {String} peerId - peerId of the receipient
	 * @param {Array<Int8Array>} messageIds - array of messageIds
	 * @param {Array<Int8Array>} albumMessageIds - Always this will be undefined or empty string
	 * @param {String} sessionId - sessionId of the receipient
	 * @param {AppConstants} pageType - pageType is used to delete the appropriate message.
	 * @param {DeleteMessageCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	deleteMessage(peerId, messageIds, albumMessageIds, sessionId, pageType, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		this.msgInstance.deleteMessageAPIClient(peerId, messageIds, albumMessageIds, sessionId, pageType, callback);
	}

	/**
	 * Method for getting last seen from the server for the session
	 * @param {String} peerId - peerId of the receipient
	 * @param {LastSeenCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	getLastSeen(peerId, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		this.msgInstance.lastSeenAPIClient(peerId, callback);
	}

	/**
	 * Method for getting message info from server
	 * @param {String} sessionId - contains the sessionId
	 * @param {MessageInfoCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	getMsgInfo(sessionId, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		var that = this;
		this.msgInstance.getTotalMsgCountForSessionIdFromLDB(sessionId, function(totalMsgCount){
			that.msgInstance.callMsgsInfoAPIClient(totalMsgCount, sessionId, callback);
		});
	}

	/**
	 * Method for getting message info from server
	//  * @param {Number} totalMsgCount - contains the totalMsgCount taken from the LDB
	 * @param {OfflineMessageInfoModel} msgModel - contains the OfflineMessageInfoModel object
	 * @param {String} sessionId - contains the sessionId
	 * @param {LoadMoreMessageCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCMessageClient#
	 */
	// getPreviousMessageHistory(totalMsgCount, msgModel, sessionId, callback){
	getPreviousMessageHistory(msgModel, sessionId, callback){
		if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		var that = this;
		this.msgInstance.getTotalMsgCountForSessionIdFromLDB(sessionId, function(totalMsgCount){
			that.msgInstance.callRecentMessagesAPIClient(totalMsgCount, msgModel, sessionId, callback);
		});
	}

	/**
	 * Method for getting all the messages.
	 * @param {String} sessionId - sessionId of the messages to be retrieved
	 * @param {AllMessagesCallback} callback - success callback when we get response
	 * @memberof JCMessageClient#
	 */
	getAllMessages(sessionId, callback){
		this.msgInstance.getAllMessagesLDB(String(sessionId), callback);
	}

	/**
	 * Method for getting SMS Quota.
	 * @param {SMSQuotaCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked whenever gets the response
	 * @memberof JCMessageClient#
	 */
	getFreeSMSQuota(callback){
		var that = this;
		this.msgInstance.getFreeSMSCountFromLDB({
			onSuccess: function(response){
				var isDataAvailable = false;
				if(response){
					if(response.dayQuota && String(response.dayQuota).length > 0){
						if(callback){
							if(callback.onSuccess){
								isDataAvailable = true;
								callback.onSuccess(response);
							}
						}
					}
				}
				if(!isDataAvailable){
					that.chatInstance.callGetFreeSMSQuota(callback);
				}
			}
		});
	}

	/**
	 * Method for clearing chat history.
	 * @param {String} sessionId - sessionId of the conversation when clearing chat. In case of the clear all chat history, pass logged in userId.
	 * @param {ClearChatCallback} callback - contains the onSuccess/onError callback, appropriate method will be invoked once we get the response
	 * @memberof JCMessageClient#
	 */
	clearChat(sessionId, callback){
		if(!sessionId || sessionId == ""){
			JIOUtils.sendError(-1, "SessionId cannot be empty", callback)
			return;
		}
		
		this.groupListInstance.clearChat(sessionId, callback);
	}
	
	/**
	 * Method for getting all recent chat. This will return only non-deleted chat conversation.
	 * @param {String} sessionId - sessionId of the messages to be retrieved
	 * @param {RecentChatCallback} callback - success/error callback once we get response
	 * @memberof JCMessageClient#
	 */
	getRecentChat(callback){
		this.chatInstance.getRecentChat(callback);
	}

	/**
	 * Method for deleting chat conversation. This will return only non-deleted chat conversation.
	 * @param {String} sessionId - sessionId of the chat conversation.
	 * @param {AppConstants} deleteType - deleteType to define the type of chat to be deleted. The value will be RECENT_CHANNELS for deleting only recent channels else pass as empty string.
	 * @param {DeleteChatChatCallback} callback - success/error callback once we get response.
	 * @memberof JCMessageClient#
	 */
    deleteChat(sessionId, deleteType, callback){
        if(!sessionId || sessionId == ""){
            JIOUtils.sendError(-1, "SessionId cannot be empty", callback);
            return;
        }

        this.chatInstance.deleteChat(sessionId, deleteType, callback);
    }

	/**
	 * Method for getting all the messages.
	 * @param {AllMessagesCallback} callback - success/error callback when we get response
	 * @memberof JCMessageClient#
	 */
	getAllBroadcastMessages(callback){
		this.msgInstance.getAllBroadcastMessagesFromLDB(callback);
	}

	/**
	 * Method for getting all the offline messages.
	 * @param {OfflineMessagesCallback} callback - Offline Message Callback
	 * @memberof JCMessageClient#
	 */
	getAllOfflineMessages(){
		JIOClient.getInstance().getAllOfflineMessages();
	}

	/**
	 * Method for sending all the offline messages.
	 * @param {OfflineMessagesCallback} callback - Offline Message Callback
	 * @memberof JCMessageClient#
	 */
	sendAllOfflineMessages(){
		if(!this.msgInstance) return;

		this.msgInstance.startUploadOfflineMessages();
	}

	/**
	 * Method for setting read receipt for messages.
	 * @param {Boolean} isVisible - true to show readReceipt, false to hide read receipt
	 * @param {CommonResponseCallback} callback - Offline Message Callback
	 * @memberof JCMessageClient#
	 */
	readReceipt(isVisible, callback){
		this.settingInstance.readReplyAPICallFromSDK(isVisible, callback);
	}
}


/**
 * Method will retutn an instance of JCMessageClient class. You should not create class object directly.
 * @return JCMessageClient class ref.
 * @example
 * var messageClient = JCMessageClient.getInstance();
 * * var jcMsgObj = new JCMessage()
 * For sending Audio mandatory fields are:
 *    jcMsgObj.setAttachment(audioBlob);//audio blob from device, similar to file Object
 *    jcMsgObj.setMsgType(MessageConsts.TYPE_VOICE);
 *    jcMsgObj.setAudioTime(time);// time in seconds
 * NOTE: only the format in which audio can be recorded from feature phone can be listened on receiver end of feature phone.
 * 
 * For sending Image mandatory fields are:
 *    jcMsgObj.setAttachment(imageBlob);//image blob from device, similar to file Object
 *    jcMsgObj.setMsgType(MessageConsts.TYPE_IMAGE);
 * 
 * For sending Video mandatory fields are:
 *    jcMsgObj.setAttachment(videoBlob);//image blob from device, similar to file Object
 *    jcMsgObj.setMsgType(MessageConsts.TYPE_VIDEO);
 * 
 * For sending File mandatory fields are:
 *    jcMsgObj.setAttachment(fileBlob);//file blob from device, similar to file Object
 *    jcMsgObj.setMsgType(MessageConsts.TYPE_FILE);
 * 
 * messageClient.sendMessage(jcMsgObj,callback);
 */
JCMessageClient.getInstance = function(){
    if( !JCMessageClient.instance) {
        JCMessageClient.instance = new JCMessageClient();
		JCMessageClient.instance.start();
    }
    return JCMessageClient.instance;
}
