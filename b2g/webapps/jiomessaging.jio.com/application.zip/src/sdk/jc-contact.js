import BaseModule from '../lib/base-module';

export default class JCContacts extends BaseModule {
  
}

JCContacts.getInstance = function() {
    if(!JCContacts.instance) {
        JCContacts.instance = new JCContacts();
    }
    return JCContacts.instance;
}
