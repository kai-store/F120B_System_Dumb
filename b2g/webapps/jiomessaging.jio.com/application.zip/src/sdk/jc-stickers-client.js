import BaseModule from '../lib/base-module';
import JIOSDKUtils from './base-jc-user.js';
import StickerStore from '../data/sticker-store-store';


/**
 * @classdesc
 * JCStickersClient is a singleton class which will do all Stickers related operations, like getting sticker-list, delete stickrs, etc.
 * 
 * @class JCStickersClient
 * @ignore
 */
export default class JCStickersClient extends BaseModule {

	start(){

        this.stickerInstance = StickerStore.getInstance();
	}

	/**
	 * Method to get Sticker list from API
	 * @param {Integer} version - version of Sticker List
	 * @param {object} callback - contains the {onSuccess:()=>{}, onError : () => {}, onVersion : ()=>{}} callback, appropriate method will be invoked whenever gets the response from the server
	 * @memberof JCStickersClient#
	 */
	getStickerListFromAPI(version, callback){

		StickerStore.getInstance().callEmoticonListAPIClient(version , callback);
	
    }

    /**
     * Method to set callback once thumblist is downloaded
     * @param {function} callback 
     * @memberof JCStickersClient#
     */
    // setEmoticonDownloadCallback(callback){
    //     this.stickerInstance.setEmoticonThumbDownloadCallback(callback);//onEmoticonThumbDownload
    // }

    /**
     * Method to set callback for getting updated sticker list from DB
     * @param {function} callback 
     * @memberof JCStickersClient#
     */
    // setStickerListUpdateCallback(callback){
    //     this.stickerInstance.setStickerListUpdateCallback(callback);
    // }

    /**
     * Method to set callback once thumblist is downloaded
     * @param {function(fileObj)} callback 
     * @memberof JCStickersClient#
     */
    setPackageDownloadProgressListener(callback){
        this.stickerInstance.setPackageDownloadProgressListener(callback);
    }

    /**
     * Method to download emoticon package
     * @param {Emoticon} emoticon object of Emoticon
     * @param {object} callback contains the {onSuccess:()=>{}, onError : () => {}} callback, appropriate method will be invoked whenever gets the response from the server
     * @memberof JCStickersClient#
     */

    downloadEmoticonPackage(emoticon , callback){

        this.stickerInstance.getEmoticonOrder(emoticon, callback);
        
    }

    /**
     * Method to set callback for updating sticker for sending
     * @param {function} callback
     * @memberof JCStickersClient#
     */
    // setUpdateStickerSendViewCallback(callback){
    //     this.stickerInstance.setUpdateStickerSendViewCallback(callback);
    // }


    /**
     * Method to download emoticon package
     * @param {function} callback
     * @memberof JCStickersClient#
     */
    setStickerDescImageDownloadCallback(callback){
        this.stickerInstance.setStickerDescImageDownloadCallback(callback);//onEmoticonDescImageDownloadListener
    }


    /**
     * Method to fetch sticker list from DB.
     * This Method will invoke callback stickerListUpdateCallback
     * @memberof JCStickersClient#     
     */
    // getStickerListFromDB(){
    //     this.stickerInstance.fetchEmoticonsFromLDB();
    // }

    /**
     * This method will return stickerList as Map 
     * @memberof JCStickersClient# 
     */
    // getStickerListMap(){
    //     return this.stickerInstance.getAllStickerStore();
    // }
    /**
     *Method to get sticker detail for particular emoticonId 
     * @param {integer} emoticonId 
     * @param {object} callback contains { onSuccess : ()=>{}, onError : ()=>{}}
     * @memberof JCStickersClient# 
     */
    getStickerDetail(emoticonId, callback ){
        this.stickerInstance.getStickerDetail(emoticonId ,callback);
    }

    /**
     * Method to get base64 of sticker image, 
     * pass saved sticker file path to get base64.
     * @param {String} filePath 
     * @param {function(base64)} callback 
     * @memberof JCStickersClient# 
     */
    getStickerBase64(filePath, callback){
        this.stickerInstance.getStickerThumbListBase64(filePath, callback);
    }

    /**
     * Method to get base64 from map using emoticonId, 
     * only for sticker list of sticker store.
     * @param {integer} emoticonId 
     * @param {function(base64)} callback 
	 * @memberof JCStickersClient#
     */
    getStickerThumbBase64(emoticonId, callback){
        this.stickerInstance.getStickerThumbBase64(emoticonId, callback)
    }

    /**
     * Method to update sticker to LDB by data
     * @param {Emoticon} emoticonInfo 
     * @param {object} callback contains { onSuccess : ()=>{}, onError : ()=>{}}
	 * @memberof JCStickersClient#
     */
    // updateStickerByDataToLDB(emoticonInfo , callback){
    //     this.stickerInstance.updateStickerByDataToLDB(emoticonInfo, callback);
    // }

    /**
     * method to set callback for updating my sticker list 
     * @param {function} callback 
	 * @memberof JCStickersClient# 

     */
    setUpdateMyStickerCallback(callback){
        this.stickerInstance.setUpdateMyStickerCallback(callback);
    }

    /**
     *Method to get mySticker list Map
     *@return Map 
     * @memberof JCStickersClient#
     */
    // getMyStickerList(){
    //    return this.stickerInstance.getAllDownloadedStickers();
    // }

    /**
     * Method to get map of Sticker-list thumb's base64 
	 * @memberof JCStickersClient#     
     */
    getEmoticonListThumbsBase64(){
        return this.stickerInstance.getEmoticonListThumbsBase64();
    }

    /**
     * Method to get list of thumb's paths map
	 * @memberof JCStickersClient#     
     */
    getEmoticonListThumbs(){
        return this.stickerInstance.getEmoticonListThumbs();
    }

    /**
     * Method to delete my sticker
     * @param {number} emoticonId id of Sticker package
     * @param {object} callback contains { onSuccess : ()=>{}, onError : ()=>{}} 
	 * @memberof JCStickersClient#     
     */
    deleteMySticker(emoticonId ,callback){
        this.stickerInstance.deleteMySticker(emoticonId, callback);
    }

    /**
     * Get sticker from Db
     * This method will invoke updateStickerSendViewCallback
     * @param {number} eomticonId
     * @param {function} callback
     * @memberof JCStickersClient#
     */
    getStikcersFromDB(emoticonId, callback){
        this.stickerInstance.getStikcersFromDB(emoticonId, callback);
    }

    /**
     * Method to get sticker by fileId from Db
     * @param {String} fileId 
     * @param {function} callback 
     * @memberof JCStickersClient#     
     */
    getStickerByFileId(fileId , callback){
        this.stickerInstance.getStickerByFileId(fileId , callback);
    }

    /**
     * Method to get all emoticon map from a package
	 * @memberof JCStickersClient#     
     */
    getAllEmoticonsFromDao(){
     return   this.stickerInstance.getAllEmoticonsFromDao();
    }

    getStickersFromPackage(emoticonId , callback){
        this.stickerInstance.getStickersFromPackage(emoticonId,callback);
    }

    createJCMessageForSticker(emoticonFileId, sessionType, peerId, callback){
        this.stickerInstance.createJCMessageForSticker(emoticonFileId, sessionType, peerId, callback);
    }

    /**
     * Method to fetch mySticker from LDB
     * this method will invoke updateMyStickerCallback
     * @memberof JCStickersClient#     
     */
    fetchMyStickerFromLDB(){
        this.stickerInstance.fetchMyStickerFromLDB();
    }

    getMyStickerList(callback){
        this.stickerInstance.getMyStickerList(callback);
    }

    /**
     * Method to set callback for emoticon download error
     * @param {function} callback
     * @memberof JCStickersClient#
     */
     setEmoticonDownloadErrorCallback(callback){
        this.stickerInstance.setEmoticonDownloadErrorCallback(callback);
     }


     stickerStoreListener(callback){

         if(callback.onStickerDetailDownloadProgress !== undefined){
            this.stickerInstance.setStickerDetailProgressListener(callback.onStickerDetailDownloadProgress);
         }else{
            this.stickerInstance.setEmoticonThumbDownloadCallback(callback.onEmoticonThumbDownload);
            this.stickerInstance.setPackageDownloadProgressListener(callback.onPackageDownloadProgress);
            this.stickerInstance.setEmoticonDownloadErrorCallback(callback.onEmoticonPackageDownloadError);
         }

     }

     downloadSingleEmoticon(emoticon, callback){
         this.stickerInstance.downloadSingleEmoticon(emoticon, callback);
     }

}


    /**
     * Method will retutn an instance of JCStickersClient class. You should not create class object directly.
     * @return JCStickersClient class instance.
     * @example
     * var stickersClient = JCStickersClient.getInstance();
     * stickersClient.anyMethodFromThisClass(args, callback);
     */
JCStickersClient.getInstance = function(){
    if( !JCStickersClient.instance) {
        JCStickersClient.instance = new JCStickersClient();
		JCStickersClient.instance.start();
    }
    return JCStickersClient.instance;
}
