import BaseModule from '../lib/base-module';
import GroupStore from '../data/groupList-store';
/**
 * Class is for JC-Group information. 
 * @class JioGroupClient
 *  
 */

export default class JioGroupClient extends BaseModule {
    /**
     * Method will create a group in server and save it to database. 
     * @param {Object} data - This parameter has the data like GroupMembers, GroupName.
     * @param {Array<member>} data.members - The members of the group.
     * @param {string} member.userId - The user id for the member who is going to join in a group.
     * @param {string} data.name - The name of the group.
     * @param {CreateGroupCallback} callback - get success or failure.
     * @memberof JioGroupClient#
     * @example
     * var groupClient = JioChatSDK.getInstance().getGroupClient();
     * var data = {
     *  name:"groupName"
     *  members: [{userId: "<userId>"}]
     * };
     * groupClient.createGroup(data, {
     *  onSuccess: function(data){
     *      
     *  },
     *  onError: function(error){
     *  
     *  }
     * });
     */
    createGroup(data,callback){
        GroupStore.getInstance().callCreateGroupAPIClient(data,callback);
    }

    /**
     * Method will edit the group name in server and save it to database. 
     * @param {String} GroupId - The id of the group.
     * @param {String} GroupName - The name of the group.
     * @param {String} UserName - The registered username.
     * @param {EditGroupNameCallback} callback - get success or failure.
     * @memberof JioGroupClient#
     */
    editGroupName(GroupId, GroupName, UserName, callback){
        GroupStore.getInstance().callUpdateGroupAPI(GroupId, GroupName, UserName, callback);
    }

    /**
     * Method will get the group list for the user. 
     * @param {GetGroupListCallback} callback - get all groups list.
     * @memberof JioGroupClient#
     */
    getGroupList(callback){
        GroupStore.getInstance().fetchGroupsfromLDB(callback);
    }

    /**
     * Method will get the group detail for the group.
     * @param {String} GroupID - The id for the group. 
     * @param {GetGroupDetailCallback} callback - get group detail.
     * @memberof JioGroupClient#
     */
    getGroupDetail(GroupID, callback){
        GroupStore.getInstance().getGroupInformationFromLBD(GroupID, callback);
    }

    /**
     * Method will quit the group from the user.
     * @param {String} GroupID - The id for the group. 
     * @param {String} SelfName - The user name. 
     * @param {QuitGroupCallback} callback - get success/failure response.
     * @memberof JioGroupClient#
     */
    quitGroup(GroupID, SelfName, callback){
        GroupStore.getInstance().callQuitGroupAPIClient(GroupID, SelfName, callback);
    }

    /**
     * Method will remove the user from the group.
     * @param {String} GroupID - The id for the group. 
     * @param {String} GroupName - The name for the group.
     * @param {String} UserName - The user name which need to remove. 
     * @param {RemoveUserFromGroupCallback} callback - get all groups list.
     * @memberof JioGroupClient#
     */
    removeUserFromGroup(GroupID, GroupName, UserName, callback){
        GroupStore.getInstance().callKickFromGroupAPIClient(GroupID, GroupName, UserName, callback);
    }


    /**
     * Method will transfer admin right from the group.
     * @param {String} GroupID - The id for the group. 
     * @param {String} UserId - The user id for the new admin. 
     * @param {TransferAdminRightsCallback} callback - get all groups list.
     * @memberof JioGroupClient#
     */
    transferAdminRightFromGroup(GroupID, UserId, callback){
        GroupStore.getInstance().callTransferGroupAdminAPIClient(GroupID, UserId, callback);
    }

    /**
     * Method will add new members to the group.
     * @param {String} GroupID - The id for the group. 
     * @param {Array.<Object>} SelectedContact - The list of contacts. 
     * @param {String} SelectedContact.name - The name of the contact.
     * @param {String} SelectedContact.userId - The userId of the contact.
     * @param {AddMembersCallback} callback - get all groups list.
     * @memberof JioGroupClient#
     */
    addNewMembersToGroup(SelectedContact, GroupID, callback){
        GroupStore.getInstance().callAddNewUserAPI(SelectedContact, GroupID, callback);
    }

}

/**
 * Method will retutn an instance of JioGroupClient class. You should not create class object directly.
 * @return JioGroupClient class ref.
 * @example
 * var groupClient = JioGroupClient.getInstance();
 * groupClient.createGroup(callback);
 */
JioGroupClient.getInstance = function(){
    if( !JioGroupClient.instance) {
        JioGroupClient.instance = new JioGroupClient();
    }
    return JioGroupClient.instance;
}
