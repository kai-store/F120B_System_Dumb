// import BaseModule from './lib/base-module';
import JIOSDKUtils from './base-jc-user.js';
import ChatListStore from '../data/chatlist-store';
import MessageStore from '../data/message-store';

/**
 * @classdesc
 * JCDeviceUtility is a singleton class which will do all message operations, like sending message, typing event..,
 * 
 * @class JCDeviceUtility
 */
export default class JCDeviceUtility {

	start(){
		this.chatInstance = ChatListStore.getInstance();
		this.msgInstance = MessageStore.getInstance();
		// this.groupListInstance = GroupListStore.getInstance();
		// this.settingInstance = SettingsStore.getInstance();
	}

	/**
	 * @memberof JCDeviceUtility#
     * @ignore
	 */
    insertContent(callback){
        if(!JIOSDKUtils.isLoggedOrThrowError(callback)){
			return;
		}

		this.chatInstance.callGetContentFromDevice({
            onSuccess: function(fileBlob){
                console.log("File Blob received in device Utility ::: ");
                // if(callback && callback.onSuccess){
                    var fileType;
                //     if(fileBlob.type.includes("image")){
                //         fileType = MessageConsts.TYPE_IMAGE;
                //     } else if(fileBlob.type.includes("video")){
                //         fileType = MessageConsts.TYPE_VIDEO;
                //     }
                //     if(fileType){
                        callback.onSuccess(fileType, fileBlob);
                //     }
                // }
            },
            onError: function(errResponse){
                if(callback && callback.onError){
                    callback.onError(errResponse);
                }
            }
        });
    }

    /**
	 * @memberof JCDeviceUtility#
     * @ignore
	 */
    getBlob(fileName, callback){
        if(!fileName || fileName == ""){
            JIOUtils.sendError(-1, "File name cannot be empty", callback);
            return;
        }

        DeviceModel.getFileFromDevice(fileName, callback);
    }

    /**
	 * @memberof JCDeviceUtility#
     * @ignore
	 */
    getBase64(fileName, callback){
        if(!fileName || fileName == ""){
            JIOUtils.sendError(-1, "File name cannot be empty", callback);
            return;
        }

        DeviceModel.getBase64(false, fileName, callback);
    }

    


}


/**
 * Method will retutn an instance of JCDeviceUtility class. You should not create class object directly.
 * @return JCDeviceUtility class ref.
 * @example
 * var deviceUtility = JCDeviceUtility.getInstance();
 */
JCDeviceUtility.getInstance = function(){
    if( !JCDeviceUtility.instance) {
        JCDeviceUtility.instance = new JCDeviceUtility();
		JCDeviceUtility.instance.start();
    }
    return JCDeviceUtility.instance;
}
