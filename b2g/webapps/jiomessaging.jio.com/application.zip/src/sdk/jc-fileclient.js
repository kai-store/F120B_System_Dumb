import BaseModule from '../lib/base-module';

/**
 * @classdesc
 * JCFileClient is a singleton class. This class will do file related operations like download and upload files.
 * @version 0.5
 * @class JCFileClient
 */
export default class JCFileClient extends BaseModule {

	start(){
		this.downloadCallback = null;
        this.uploadCallback = null;
	}

    /**
     * Method will download given file in to device sd card.
     * @param {JCFile} jcFileInfo
     * @memberof JCFileClient#
     */
    downloadFile(jcFile){

    }
    /**
     * Method will upload given sdcard file to server.
     * @param {JCFile} jcFileInfo
     * @memberof JCFileClient#
     */
    uploadFile(jcFile){

    }

    /**
    * Method will set callback for file download. 
	* @param {DownloadCallback} callback - Callback 
	* @memberof JCFileClient#
    */
	setDownloadCallback(callback){
		this.downloadCallback = callback;
	}
	
	/**
	 * Method will return DownloadCallback, if its set otherwise it will return null
	 * @returns {DownloadCallback} Download callback, if its set
	 * @memberof JCFileClient#
	 * @ignore
	 */
	getDownloadCallback(){
		return this.downloadCallback;
	}
	/**
	 * Method will set callback for file upload
	 * @param {UploadCallback} callback - callback
	 * @memberof JCFileClient# 
	 */
	setUploadCallback(callback){
		this.uploadCallback = callback;
	}

	/**
	 * Method will return UploadCallback, if its set otherwise it will return null
	 * @returns {UploadCallback} Upload callback, if its set
	 * @memberof JCFileClient#
	 * @ignore
	 */
	getUploadCallback(){
		return this.uploadCallback;
	}
}
/**
 * Method will retutn an instance of FileClient class. You should not create class object directly.
 * @return JCFileClient class ref.
 * @example
 * var jcFileClient = JCFileClient.getInstance();
 * @ignore
 */
JCFileClient.getInstance = function(){
    if( !JCFileClient.instance) {
        JCFileClient.instance = new JCFileClient();
		JCFileClient.instance.start();
    }
    return JCFileClient.instance;
}
