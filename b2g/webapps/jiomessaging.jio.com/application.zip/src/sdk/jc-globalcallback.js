/**
 * @interface MessageCallback
 * @desc
 * MessageCallback is an interface will get invoked when incoming message or any event get fired from the server.
 * Needs to implement below methods, and needs to set to JioChatSDK. 
 */
var MessageCallback = {

    /**
     * Method will triggered when message added to LDB. 
     * @callback MessageCallback~onMessageAdded
     * @param {JCMessage} chatMessage - Chat message
     * @memberof MessageCallback
     */

    /**
     * Method will triggered when any incoming message (PPM, Group, Text Message, Message with an attachment) coming from server. 
     * @callback MessageCallback~onTextMessage
     * @param {JCMessage} chatMessage - Chat message
     * @memberof MessageCallback
     */

    /**
     * Method will triggered when any incoming message coming from server.
     * @function onTyping
     * @callback MessageCallback~onTyping
     * @param {Int8Array} peerId - Userid
     * @memberof MessageCallback
     */

    /**
     * Method will triggered when partyB typing.
     * @function onReply
     * @callback MessageCallback~onReply
     * @param {Int8Array} peerId - peerid
     * @param {Int8Array} msgId - message id
     * @param {JCMessage} chatMessage - Chat message 
     * @memberof MessageCallback
     */
     /**
      * Method will triggered when partyB read sent message.
      * @function onReadReply
      * @callback MessageCallback~onReadReply
      * @param {Int8Array} peerId - peerId
      * @param {boolean} isReadOtherOne - peerId read your message then its true, otherwise false
      * @param {number} lastReadSeq - last read seq, peerId.
      * @param {JCMessage} chatMessage - Chat Message for more info
      * @memberof MessageCallback
      * 
      */

    /* Offline Message Callback */
    /**
     * Method will be triggered when any incoming offline message (PPM, Group, Text Message, Message with an attachment) coming from server. 
     * @callback MessageCallback~onOfflineMessagesReceived
     * @param {Array<JCMessage>} chatMessage - Chat message
     * @memberof MessageCallback
     */

    /**
     * Method will be triggered when offline message sent (PPM, Group, Text Message, Message with an attachment) to server. 
     * @callback MessageCallback~onOfflineMessageSent
     * @param {JCMessage} chatMessage - Chat message
     * @memberof MessageCallback
     */

    /**
     * Method will be triggered when sending offline message gets failed.
     * @callback MessageCallback~onOfflineMessageSentError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof MessageCallback
     */

     /**
     * Method will be triggered when contact profile received.
     * @callback MessageCallback~onContactReceived
     * @param {JCContactProfile} profileObj - contains the profile information of contact
     * @memberof MessageCallback
     */

     /**
     * Method will be triggered when error occured while receiving contact.
     * @callback MessageCallback~onContactError
     * @param {Error} errorResponse - contains error occured while receiving contact
     * @memberof MessageCallback
     */

    /**
     * Method will be triggered when contact portraits are received.
     * @callback MessageCallback~onContactPortraitReceived
     * @param {Array<JCContactProfile>} profileObjArray - contains the array of received portraits
     * @memberof MessageCallback
     */

    /**
     * Method will be triggered when contact portraits are received .
     * @callback MessageCallback~onContactPortraitError
     * @param {Error} errorResponse - contains error occured while receiving contact portrait
     * @memberof MessageCallback
     */


};

/**
 * @interface GroupNotificationCallback
 * @desc 
 * GroupNotificationCallback is an interface will get invoked when incoming any group related events get fired from the server.
 * Needs to implement below methods. 
 * @ignore
 */
var GroupNotificationCallback = {
    /**
     * Method will triggered when any group members are joined group. 
     * @callback GroupNotificationCallback~onGroupJoined
     * @param {object} group - Group
     * @memberof GroupNotificationCallback
     */

    /**
     * Method will triggered when group admin changed group name or group desc or any other details changed.
     * @function onGroupInfoChanged
     * @callback GroupNotificationCallback~onGroupInfoChanged
     * @param {object} group - Updated Group Info
     * @memberof GroupNotificationCallback
     */

    /**
     * Method will triggered when admin added any group member is added to group.
     * @function onGroupBuddyUpdate
     * @callback GroupNotificationCallback~onGroupBuddyUpdate
     * @param {object} group - Updated group info with all group members.
     * @memberof GroupNotificationCallback
     */
    
     /**
      * Method will triggered when some one self leave group or admin force removed group member. 
      * New Group object will contains all the members who left group.
      * @function onGroupBuddyLeave
      * @callback GroupNotificationCallback~onGroupBuddyLeave
      * @param {object} group - Updated group info
      * @memberof GroupNotificationCallback
      * 
      */

    /**
      * Method will triggered when group changed.
      * @function onGroupSetChanged
      * @callback GroupNotificationCallback~onGroupSetChanged
      * @param {ChatMessage} chat - Chat Message for more info
      * @memberof GroupNotificationCallback
      * 
      */

    /**
      * Method will triggered when partyB read sent message.
      * @function onGroupJoinedSyncNotify
      * @callback GroupNotificationCallback~onGroupJoinedSyncNotify
      * @param {object} group - Updated group info
      * @memberof GroupNotificationCallback
      * 
      */

    /**
      * Method will triggered when group portrait is changed.
      * @function onGroupPortraitChanged
      * @callback GroupNotificationCallback~onGroupPortraitChanged
      * @param {Int8Array} thumb - portrait data
      * @param {object} group - Updated group info
      * @memberof GroupNotificationCallback
      * 
      */

     /**
      * Method will triggered when admin name is updated.
      * @function onGroupAdminUpdated
      * @callback GroupNotificationCallback~onGroupAdminUpdated
      * @param {object} group - Updated group info
      * @memberof GroupNotificationCallback
      * 
      */

    /**
      * Method will triggered when Admin updated a new Admin.
      * @function onGroupAdminUpdatedForNewAdmin
      * @callback GroupNotificationCallback~onGroupAdminUpdatedForNewAdmin
      * @param {object} group - Updated group info
      * @memberof GroupNotificationCallback
      * 
      */ 
};

/**
 * @interface IncomingNotificationCallback
 * @desc IncomingNotificationCallback
 * IncomingNotificationCallback is an interface will get invoked when incoming any user contact related events get fired from the server.
 * Needs to implement below methods. 
 * @ignore
 * 
 */
var IncomingNotificationCallback = {
    /**
     * Method will triggered when contact version is changed.
     * @function reverseContactChanged
     * @callback IncomingNotificationCallback~reverseContactChanged
     * @param {object} profile - Updated Group Info
     * @memberof IncomingNotificationCallback
     */

    /**
     * Method will triggered when contact portrait is changed.
     * @function selfAvatarChanged
     * @callback IncomingNotificationCallback~selfAvatarChanged
     * @param {Int8Array} avatarId - portrait id
     * @param {Int8Array} data - image data
     * @memberof IncomingNotificationCallback
     */ 

    /**
     * Method will triggered when contact portrait is changed.
     * @function onSetLastSeenChanged
     * @callback IncomingNotificationCallback~onSetLastSeenChanged
     * @param {Int8Array} lastseen - either 'online' or last seen time
     * @memberof IncomingNotificationCallback
     */ 

    /**
     * Method will triggered when contact portrait is changed.
     * @function onFreeSmsQuotaChange
     * @callback IncomingNotificationCallback~onFreeSmsQuotaChange
     * @param {number} dayQuota - day Quota
     * @param {number} monthQuota - month Quota
     * @memberof IncomingNotificationCallback
     */
};

/**
 * @interface HDCallNotificationCallback
 * @desc 
 * HDCallNotificationCallback is an interface will get invoked when any call related events get fired from the server.
 * Needs to implement below methods. 
 * @ignore
 */
var InComingHDCallNotificationCallback = {
    /**
     * Method will triggered when a partyA receive call.
     * @function onRinging
     * @callback InComingHDCallNotificationCallback~onRinging
     * @param {object} hdcall - Updated HD call Info
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onInvitedUsers
     * @callback InComingHDCallNotificationCallback~onInvitedUsers
     * @param {Int8Array} invitorId - inviter id
     * @param {Int8Array} invitedIds - inviter id's
     * @param {object} hdcall - Updated HD call Info
     * @memberof InComingHDCallNotificationCallback
     */ 

    /**
     * Method will triggered when .
     * @function onKickMember
     * @callback HDCallNotificationCallback~onKickMember
     * @param {Int8Array} userId - user id
     * @param {number} type - 
     * @memberof InComingHDCallNotificationCallback
     */ 

    /**
     * Method will triggered when .
     * @function onSwitchNegotiation
     * @callback HDCallNotificationCallback~onSwitchNegotiation
     * @param {object} hdcall - Updated HD call Info
     * @memberof InComingHDCallNotificationCallback
     */

     /**
     * Method will triggered when .
     * @function onSwitchNegotiationResp
     * @callback HDCallNotificationCallback~onSwitchNegotiationResp
     * @param {object} hdcall - Updated HD call Info
     * @param {Int8Array} userId - user id
     * @param {number} isAgree - 
     * @param {number} isToAudio - 
     * @param {String} sdpOffer - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onAnsCall
     * @callback HDCallNotificationCallback~onAnsCall
     * @param {object} hdcall - Updated HD call Info
     * @param {Int8Array} userId - user id
     * @param {number} version - version
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onUserOnShow
     * @callback HDCallNotificationCallback~onUserOnShow
     * @param {object} hdcall - Updated HD call Info
     * @param {Int8Array} userId - user id
     * @param {number} isOnShow - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onKeepOrReturnSession
     * @callback HDCallNotificationCallback~onKeepOrReturnSession
     * @param {object} hdcall - Updated HD call Info
     * @param {Int8Array} userId - user id
     * @param {number} isKeepSession - 
     * @memberof InComingHDCallNotificationCallback
     */

     /**
     * Method will triggered when .
     * @function onSwitchDevice
     * @callback HDCallNotificationCallback~onSwitchDevice
     * @param {object} hdcall - Updated HD call Info
     * @param {Int8Array} userId - user id
     * @param {number} isApply - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function endSession
     * @callback HDCallNotificationCallback~endSession
     * @param {} key - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onPacketRecevied
     * @callback HDCallNotificationCallback~onPacketRecevied
     * @param {object} hdcall - Updated HD call Info
     * @param {Int8Array} userId - user id
     * @param {number} count - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onRemoteRinging
     * @callback HDCallNotificationCallback~onRemoteRinging
     * @param {object} hdcall - Updated HD call Info
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onSDPRecevied
     * @callback HDCallNotificationCallback~onSDPRecevied
     * @param {object} hdcall - Updated HD call Info
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onCallBusy
     * @callback HDCallNotificationCallback~onCallBusy
     * @param {object} hdcall - Updated HD call Info
     * @param {number} state - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onWaitedSession
     * @callback HDCallNotificationCallback~onWaitedSession
     * @param {} key - 
     * @param {Int8Array} fromUserId - from user id
     * @param {String} fromUserName - user name
     * @param {String} mobileNo - 
     * @param {Int8Array} toUserId - to user id
     * @param {String} tokenAddress - 
     * @param {number} createrId - 
     * @param {number} type - 
     * @param {number} status -
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onICERecevied
     * @callback HDCallNotificationCallback~onICERecevied
     * @param {object} hdcall - Updated HD call Info
     * @param {Array} iceCandidates - 
     * @memberof InComingHDCallNotificationCallback
     */

    /**
     * Method will triggered when .
     * @function onTURNRecived
     * @callback HDCallNotificationCallback~onTURNRecived
     * @param {object} hdcall - Updated HD call Info
     * @memberof InComingHDCallNotificationCallback
     */

};

// /**
//  * @interface OfflineMessagesCallback
//  * @desc
//  * OfflineMessagesCallback is an interface will get invoked when sending offline message & receiving offline message or any event get fired from the server.
//  * Needs to implement below methods, and needs to set to JioChatSDK. 
//  */
// var OfflineMessagesCallback = {
//     /**
//      * Method will be triggered when any incoming offline message (PPM, Group, Text Message, Message with an attachment) coming from server. 
//      * @callback OfflineMessagesCallback~onMessagesReceived
//      * @param {Array<JCMessage>} chatMessage - Chat message
//      * @memberof OfflineMessagesCallback
//      */

//     /**
//      * Method will be triggered when offline message sent (PPM, Group, Text Message, Message with an attachment) to server. 
//      * @callback OfflineMessagesCallback~onMessageSent
//      * @param {JCMessage} chatMessage - Chat message
//      * @memberof OfflineMessagesCallback
//      */

//     /**
//      * Method will be triggered when sending offline message gets failed.
//      * @callback OfflineMessagesCallback~onMessageSentError
//      * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
//      * @memberof OfflineMessagesCallback
//      */
// }

/**
 * @interface UploadCallback
 * @desc
 * UploadCallback is an interface will get invoked when uploading files like image/video/emoticons, etc.,
 * Needs to implement below methods, and needs to set to JioChatSDK. 
 */
var UploadCallback = {

  /**
     * Method will be triggered when file upload progress changed
     * @callback UploadCallback~onProgressChanged
     * @param {Object} attachment - contains the attachment object.
     * @param {String} attachment.fileId - fileId of the attachment
	   * @param {Number} attachment.progress - upload progress of the attachment
     * @memberof UploadCallback
     */

  /**
     * Method will be triggered when file gets uploaded successfully.
     * @callback UploadCallback~onSuccess
     * @param {Object} attachment - contains the attachment object.
     * @param {String} attachment.fileId - fileId of the attachment
	   * @param {Number} attachment.progress - download progress of the attachment
     * @memberof UploadCallback
     */

    /**
     * Method will be triggered when file upload failed.
     * @callback UploadCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof UploadCallback
     */
};

/**
 * @interface DownloadCallback
 * @desc
 * DownloadCallback is an interface will get invoked when downloading files like image/video/emoticons, etc.,
 * Needs to implement below methods, and needs to set to JioChatSDK. 
 */
var DownloadCallback = {
    /**
     * Method will be triggered when file download progress changed
     * @callback DownloadCallback~onProgressChanged
     * @param {Object} attachment - contains the attachment object.
     * @param {String} attachment.fileId - fileId of the attachment
	   * @param {String} attachment.fileName - file name of the attachment
     * @param {Number} attachment.progress - download progress of the attachment
     * @memberof DownloadCallback
     */

    /**
     * Method will be triggered when file gets downloaded successfully.
     * @callback DownloadCallback~onSuccess
     * @param {Object} attachment - contains the attachment object.
     * @param {String} attachment.fileId - fileId of the attachment
	   * @param {String} attachment.fileName - file name of the attachment
	   * @param {String} attachment.filePath - filePath of downloaded the attachment
	   * @param {Number} attachment.progress - download progress of the attachment
     * @memberof DownloadCallback
     */

    /**
     * Method will be triggered when file download failed.
     * @callback DownloadCallback~onError
     * @param {Error} errorResponse - contains the error information like errorMsg, errorCode
     * @memberof DownloadCallback
     */
};
