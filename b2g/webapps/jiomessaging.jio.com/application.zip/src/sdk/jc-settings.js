function JCSettings() {
	this.enableMessages = true;
	this.enableGroup = true;
	this.enableNotifications = true;
	this.enableChannels = true;
	this.enableCall = true;
}

JCSettings.prototype.init = function(mode) {
	if(mode == undefined || mode == null || mode == AppMode.APP_TYPE_JSDK || mode == AppMode.APP_TYPE_JC){
		return;
	}
	this.enableMessages = !( mode==AppMode.APP_TYPE_JVC); //mode==AppMode.APP_TYPE_JCL ||mode==AppMode.APP_VERSION_JVC
	this.enableGroup = this.enableMessages;
	this.enableNotifications = true;
	this.enableChannels = (mode==AppMode.APP_TYPE_JCL || (mode!=AppMode.APP_TYPE_JMS && mode!=AppMode.APP_VERSION_JVC)); //mode!=AppMode.APP_VERSION_JVC
	this.enableCall = (mode==AppMode.APP_VERSION_JVC || (mode!=AppMode.APP_TYPE_JCL && mode!=AppMode.APP_TYPE_JMS));
};

JCSettings.prototype.setEnableMessages = function(enableMessages) {
	this.enableMessages = enableMessages;
};

JCSettings.prototype.isMessagesEnabled = function() {
	return this.enableMessages;
};

JCSettings.prototype.setEnableGroup = function(enableGroup) {
	this.enableGroup = enableGroup;
};

JCSettings.prototype.isGroupEnabled = function() {
	return this.enableGroup;
};

JCSettings.prototype.setEnableNotifications = function(enableNotifications) {
	this.enableNotifications = enableNotifications;
};

JCSettings.prototype.isNotificationEnabled = function() {
	return this.enableNotifications;
};

JCSettings.prototype.setEnableChannels = function(enableChannels) {
	this.enableChannels = enableChannels;
};

JCSettings.prototype.isChannelsEnabled = function() {
	return this.enableChannels;
};

JCSettings.prototype.setEnableCall = function(enableCall) {
	this.enableCall = enableCall;
};
JCSettings.prototype.isCallEnabled = function() {
	return this.enableCall;
};
