function BroadcastMessage() {
	this.userId = "";
	this.userName = "";
    this.phoneBookName = "";
    this.colorCode = "";
}

BroadcastMessage.prototype = {
	constructor: BroadcastMessage,
  
    addToLDB:function(userId, callback){
        //Arranging Contact Data to be inserted
	    var data = {
            userId : this.userId,
            userName : this.userName,
            phoneBookName : this.phoneBookName,
            colorCode : this.colorCode     
        } 

        var that = this;
          UserDB.getInstance().create(userId, function(success){
            console.log("Insert Group : "+UserDB.getInstance().database);
                //Making INSERT group request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    console.log("BROADCAST GROUP CREATED SUCCESSFULLY");
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    bulkAddToLDB:function(userId, contacts, callback){
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE);
            putNext(0);

            function putNext(i) {
                if (i<contacts.length) {
                    var request = objectStore.put(contacts[i])
                    request.onsuccess = function(event) {
                        putNext(i+1)
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    addNewMembersToLDB:function(userId, usersData, callback){
        BroadcastMessage.getInstance().getByGroupIdFromLDB(userId, 'broadcastID', function(users){
            console.log(users);
            var newMembers = [];
            var groupMembers = usersData;
            groupMembers.forEach(function(groupMember,userIndex){
                var isAlreadyThere = false;
                users.forEach(function(user,index){
                     if(user.userId == groupMember.userId){
                        // newMembers.push(groupMember);
                        isAlreadyThere = true;
                     }
                 });

                if (!isAlreadyThere) {
                    newMembers.push(groupMember);
                };
            });

             var data = {
                    groupId : groupData.groupId,
                    users : newMembers   
                } 

            BroadcastMessage.getInstance().addByGroupDataToLDB(userId, data, function(success){
                callback(success)
            });
          
                
        });  
	},
    getAllFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE);
            var items = [];
        
            trans.oncomplete = function(evt) {  
                callback(items);
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching broadcast contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
	},
    deleteMemberByGroupIdFromLDB:function(userId, memberId, callback){
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                   callback(true);
                };
            
                var cursorRequest = index.openCursor('broadcastID');
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching broadcast contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        if(cursor.value.userId == memberId){
                            var request = cursor.delete();
                            request.onsuccess = function() {
                                console.log('Deleted Broadcast Member');
                            };
                            request.onerror = function(error) {
                                console.log('Delete Broadcast Memeber Failed');
                                callback(false);
                            };
                        }
                       
                        cursor.continue();
                    }
                };
        });
	},
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){

            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
	}
	
};

BroadcastMessage.getInstance= function(){
    if(!BroadcastMessage.instance){
        BroadcastMessage.instance = new BroadcastMessage();
    }
    return BroadcastMessage.instance;
};
