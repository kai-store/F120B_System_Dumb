function ActiveUser () {
	this.userId = "";
	this.mobileNumber = "";
	this.pwd = "";
	this.token = "";
	this.userName = "";
	this.status = "";
    this.domain = "";
	this.cmpAddress = "";
	this.serverNumber = "";
	this.navResponse = "";
	this.serverKey = "";
	this.credential = "";
	this.dateTime = "";
	this.tokenExpiry = "";
    this.language = "";
    this.deviceModel = "";
    this.userImage = "";
    this.userGender = "";
    this.userMood = "";
    this.userQRCode = "";
    this.termsConditions = "";
    this.faq = "";
    this.portraitId = "";
}

ActiveUser.prototype = {
	constructor:ActiveUser,
  
    addToLDB:function(callback){
        //Arranging User Data to be inserted
	    var data = {
            userId : this.userId,
            pwd : this.pwd,
            mobileNumber : this.mobileNumber,
            token : this.token,
            userName : this.userName,
            status : this.status,
            domain : this.domain,
            cmpAddress : this.cmpAddress,
            serverNumber : this.serverNumber,
            navResponse : this.navResponse,
            serverKey : this.serverKey,
            credential : this.credential,
            dateTime : this.dateTime,
            tokenExpiry : this.tokenExpiry,
            language : this.language,
            deviceModel : this.deviceModel,
            userImage : this.userImage,
            userGender : this.userGender,
            userMood : this.userMood,
            userQRCode : this.userQRCode,
            termsConditions : this.termsConditions,
            faq : this.faq
            

        } 
        
         CommonDB.getInstance().create(function(success){
            console.log("Insert Active User : "+CommonDB.getInstance().database);
                
            //Making INSERT contact request to Local DB
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_ACTIVE_USER], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    addByDataToLDB:function(data, callback){
         CommonDB.getInstance().create(function(success){
            console.log("Insert Active User : "+CommonDB.getInstance().database);
                
            //Making INSERT contact request to Local DB
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_ACTIVE_USER], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(data, callback){
         CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER);
                //var request = index.get(data.mobileNumber);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.mobileNumber);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.pwd != undefined && data.pwd != null){
                             updateData.pwd = data.pwd;
                         }
                         if(data.mobileNumber != undefined && data.mobileNumber != null){
                             updateData.mobileNumber = data.mobileNumber;
                         }
                         if(data.token != undefined && data.token != null){
                             updateData.token = data.token;
                         }
                         if(data.userName != undefined && data.userName != null){
                             updateData.userName = data.userName;
                         }
                          if(data.userId != undefined && data.userId != null){
                             updateData.userId = data.userId;
                         }
                         if(data.status != undefined && data.status != null){
                             updateData.status = data.status;
                         }
                         if(data.domain != undefined && data.domain != null){
                             updateData.domain = data.domain;
                         }
                         if(data.cmpAddress != undefined && data.cmpAddress != null){
                             updateData.cmpAddress = data.cmpAddress;
                         }
                         if(data.serverNumber != undefined && data.serverNumber != null){
                             updateData.serverNumber = data.serverNumber;
                         }
                         if(data.navResponse != undefined && data.navResponse != null){
                             updateData.navResponse = data.navResponse;
                         }
                         if(data.serverKey != undefined && data.serverKey != null){
                             updateData.serverKey = data.serverKey;
                         }
                         if(data.credential != undefined && data.credential != null){
                             updateData.credential = data.credential;
                         }
                         if(data.dateTime != undefined && data.dateTime != null){
                             updateData.dateTime = data.dateTime;
                         }
                         if(data.tokenExpiry != undefined && data.tokenExpiry != null){
                             updateData.tokenExpiry = data.tokenExpiry;
                         }
                         if(data.language != undefined && data.language != null){
                             updateData.language = data.language;
                         }
                         if(data.deviceModel != undefined && data.deviceModel != null){
                             updateData.deviceModel = data.deviceModel;
                         }
                         if(data.userImage != undefined && data.userImage != null){
                             updateData.userImage = data.userImage;
                         }
                         if(data.userGender != undefined && data.userGender != null){
                             updateData.userGender = data.userGender;
                         }
                         if(data.userMood != undefined && data.userMood != null){
                             updateData.userMood = data.userMood;
                         }
                         if(data.userQRCode != undefined && data.userQRCode != null){
                             updateData.userQRCode = data.userQRCode;
                         }
                          if(data.termsConditions != undefined && data.termsConditions != null){
                             updateData.termsConditions = data.termsConditions;
                         }
                         if(data.faq != undefined && data.faq != null){
                             updateData.faq = data.faq;
                         }
                         if(data.portraitId != undefined && data.portraitId != null){
                             updateData.portraitId = data.portraitId;
                         }
                         if(data.thumbData != undefined && data.thumbData != null){
                             updateData.thumbData = data.thumbData;
                         }
                       
         

                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(callback){
         CommonDB.getInstance().create(function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_ACTIVE_USER], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    //  getByUserIdFromLDB:function(userId, callback){	
    //     CommonDB.getInstance().create(function(success){
    //             var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, IDBTransaction.READ_ONLY);
    //             var request = trans
    //                         .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER)
    //                         .get(userId);
                
    //             //Handler for success operation
    //             request.onsuccess = function(event) {
    //                 callback(event.target.result);            
    //             };

    //             //Handler for success operation
    //             request.onerror = function(event) {
    //                 callback([]);
    //             }
    //     }); 
    // },
    getByUserIdFromLDB:function(userId, callback){  
         CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER);
                var index = objectStore.index("userId");
                var request = index.get(userId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
    getByMobileNumberFromLDB:function(mobileNumber, callback){          
         CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER);
                var index = objectStore.index("mobileNumber");
                var request = index.get(mobileNumber);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
    getUserIdForMobileNumber:function(mobileNumber ,callback){
        CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER);
                var index = objectStore.index("mobileNumber");
                var request = index.get(mobileNumber);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result.userId);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
     },
     getUserDetailForMobileNumber:function(mobileNumber ,callback){
        CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER);
                var index = objectStore.index("mobileNumber");
                var request = index.get(mobileNumber);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
     },
     getMobileNumberForUserId:function(userId, callback){
        CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_ACTIVE_USER, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER);
                var index = objectStore.index("userId");
                var request = index.get(userId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    if(event.target.result != undefined){
                        callback(event.target.result.mobileNumber); 
                    }else{
                        callback({});
                    }
                               
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback({});
                }
        }); 
     },
	deleteAllFromLDB:function(callback){
        CommonDB.getInstance().create(function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_ACTIVE_USER], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_ACTIVE_USER)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	}
   
	
};

ActiveUser.getInstance= function(){
    if(!ActiveUser.instance){
        ActiveUser.instance = new ActiveUser();
    }
    return ActiveUser.instance;
};
