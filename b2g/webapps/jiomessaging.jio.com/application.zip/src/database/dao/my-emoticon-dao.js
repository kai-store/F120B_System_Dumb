function MyEmoticonDAO () {
	this.emoticonId = "";
	this.emoticonSequence = "";
	this.emoticonVersion = "";
	this.emoticonProgress = "";
	this.emoticonStatus = "";
	this.emoticonPayType = "";
    this.emoticonIsNew = "";
	this.emoticonPackageId = "";
	this.emoticonSize = "";
	this.emoticonPrice = "";
	this.emoticonDescProgress = "";
	this.emoticonHasUpload = "";
	this.emoticonPanelNorthPath = "";
    this.emoticonPanelSelectPath = "";
    this.emoticonPanelThumbPath = "";
    this.emoticonDescImagePath = "";
    this.emoticonLocalSequence = "";
    this.emoticonIsOrdered = "";
    this.emoticonPath = "";
    this.emoticonDownloadIndex = "";
    this.emoticonBlockSize = "";
    this.emoticonName = "";
    this.emoticonToken = "";
    this.emoticonDescription = "";
    this.emoticonDevelopers = "";
    this.emoticonThumbPath = "";
    this.emoticonThumbId = "";
    this.emoticonThumbSize = "";
    this.emoticonDescImageId = "";
    this.emoticonDescImageSize = "";
    this.isSelected = '';
}

MyEmoticonDAO.prototype = {
	constructor:MyEmoticonDAO,
  
    addToLDB:function(userId,callback){
        //Arranging Emoticon Data to be inserted
	    var data = {
            emoticonId : this.emoticonId,
            emoticonSequence : this.emoticonSequence,
            emoticonVersion : this.emoticonVersion,
            emoticonProgress : this.emoticonProgress,
            emoticonStatus : this.emoticonStatus,
            emoticonPayType : this.emoticonPayType,
            emoticonIsNew : this.emoticonIsNew,
            emoticonPackageId : this.emoticonPackageId,
            emoticonSize : this.emoticonSize,
            emoticonPrice : this.emoticonPrice,
            emoticonDescProgress : this.emoticonDescProgress,
            emoticonHasUpload : this.emoticonHasUpload,
            emoticonPanelNorthPath : this.emoticonPanelNorthPath,
            emoticonPanelSelectPath : this.emoticonPanelSelectPath,
            emoticonPanelThumbPath : this.emoticonPanelThumbPath,
            emoticonDescImagePath : this.emoticonDescImagePath,
            emoticonLocalSequence : this.emoticonLocalSequence,
            emoticonIsOrdered : this.emoticonIsOrdered,
            emoticonPath : this.emoticonPath,
            emoticonDownloadIndex : this.emoticonDownloadIndex,
            emoticonBlockSize : this.emoticonBlockSize,
            emoticonName : this.emoticonName,
            emoticonToken : this.emoticonToken,
            emoticonDescription : this.emoticonDescription,
            emoticonDevelopers : this.emoticonDevelopers,
            emoticonThumbPath : this.emoticonThumbPath,
            emoticonThumbId : this.emoticonThumbId,
            emoticonThumbSize : this.emoticonThumbSize,
            emoticonDescImageId : this.emoticonDescImageId,
            emoticonDescImageSize : this.emoticonDescImageSize,
            isSelected : this.isSelected

        } 
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MY_EMOTICONS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
	},
    addByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                 
            //Making INSERT contact request to Local DB
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MY_EMOTICONS], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(userId, data, callback){
        
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_THUMB_ID);
               
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.emoticonThumbId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.emoticonSequence != undefined && data.emoticonSequence != null){
                             updateData.emoticonSequence = data.emoticonSequence;
                         }
                         if(data.emoticonVersion != undefined && data.emoticonVersion != null){
                             updateData.emoticonVersion = data.emoticonVersion;
                         }
                         if(data.emoticonProgress != undefined && data.emoticonProgress != null){
                             updateData.emoticonProgress = data.emoticonProgress;
                         }
                         if(data.emoticonStatus != undefined && data.emoticonStatus != null){
                             updateData.emoticonStatus = data.emoticonStatus;
                         }
                         if(data.emoticonPayType != undefined && data.emoticonPayType != null){
                             updateData.emoticonPayType = data.emoticonPayType;
                         }
                         if(data.emoticonIsNew != undefined && data.emoticonIsNew != null){
                             updateData.emoticonIsNew = data.emoticonIsNew;
                         }
                         if(data.emoticonPackageId != undefined && data.emoticonPackageId != null){
                             updateData.emoticonPackageId = data.emoticonPackageId;
                         }
                         if(data.emoticonSize != undefined && data.emoticonSize != null){
                             updateData.emoticonSize = data.emoticonSize;
                         }
                         if(data.emoticonPrice != undefined && data.emoticonPrice != null){
                             updateData.emoticonPrice = data.emoticonPrice;
                         }
                         if(data.emoticonDescProgress != undefined && data.emoticonDescProgress != null){
                             updateData.emoticonDescProgress = data.emoticonDescProgress;
                         }
                         if(data.emoticonHasUpload != undefined && data.emoticonHasUpload != null){
                             updateData.emoticonHasUpload = data.emoticonHasUpload;
                         }
                         if(data.emoticonPanelNorthPath != undefined && data.emoticonPanelNorthPath != null){
                             updateData.emoticonPanelNorthPath = data.emoticonPanelNorthPath;
                         }
                         if(data.emoticonPanelSelectPath != undefined && data.emoticonPanelSelectPath != null){
                             updateData.emoticonPanelSelectPath = data.emoticonPanelSelectPath;
                         }
                         if(data.emoticonPanelThumbPath != undefined && data.emoticonPanelThumbPath != null){
                             updateData.emoticonPanelThumbPath = data.emoticonPanelThumbPath;
                         }
                         if(data.emoticonDescImagePath != undefined && data.emoticonDescImagePath != null){
                             updateData.emoticonDescImagePath = data.emoticonDescImagePath;
                         }
                         if(data.emoticonLocalSequence != undefined && data.emoticonLocalSequence != null){
                             updateData.emoticonLocalSequence = data.emoticonLocalSequence;
                         }
                         if(data.emoticonIsOrdered != undefined && data.emoticonIsOrdered != null){
                             updateData.emoticonIsOrdered = data.emoticonIsOrdered;
                         }
                         if(data.emoticonPath != undefined && data.emoticonPath != null){
                             updateData.emoticonPath = data.emoticonPath;
                         }
                         if(data.emoticonDownloadIndex != undefined && data.emoticonDownloadIndex != null){
                             updateData.emoticonDownloadIndex = data.emoticonDownloadIndex;
                         }
                         if(data.emoticonBlockSize != undefined && data.emoticonBlockSize != null){
                             updateData.emoticonBlockSize = data.emoticonBlockSize;
                         }
                         if(data.emoticonName != undefined && data.emoticonName != null){
                             updateData.emoticonName = data.emoticonName;
                         }
                         if(data.emoticonToken != undefined && data.emoticonToken != null){
                             updateData.emoticonToken = data.emoticonToken;
                         }
                         if(data.emoticonDescription != undefined && data.emoticonDescription != null){
                             updateData.emoticonDescription = data.emoticonDescription;
                         }
                         if(data.emoticonDevelopers != undefined && data.emoticonDevelopers != null){
                             updateData.emoticonDevelopers = data.emoticonDevelopers;
                         }
                         if(data.emoticonThumbPath != undefined && data.emoticonThumbPath != null){
                             updateData.emoticonThumbPath = data.emoticonThumbPath;
                         }
                         if(data.emoticonThumbId != undefined && data.emoticonThumbId != null){
                             updateData.emoticonThumbId = data.emoticonThumbId;
                         }
                         if(data.emoticonThumbSize != undefined && data.emoticonThumbSize != null){
                             updateData.emoticonThumbSize = data.emoticonThumbSize;
                         }
                         if(data.emoticonDescImageId != undefined && data.emoticonDescImageId != null){
                             updateData.emoticonDescImageId = data.emoticonDescImageId;
                         }
                         if(data.emoticonDescImageSize != undefined && data.emoticonDescImageSize != null){
                             updateData.emoticonDescImageSize = data.emoticonDescImageSize;
                         }
                         if(data.isSelected != undefined && data.isSelected != null){
                             updateData.isSelected = data.isSelected;
                         }
         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MY_EMOTICONS], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    
    //--------testing get by emoticonID ---------------
    getByEmoticonIdFromLDB:function(userId, emoticonId, callback){  
         UserDB.getInstance().create(userId,function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_PACKAGE_ID);
                var request = index.get(emoticonId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
    //--------testing get by emoticonID end------------
    getByThumbIdIdFromLDB:function(userId, thumbId, callback){  
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_THUMB_ID);
                var request = index.get(thumbId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
   
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MY_EMOTICONS], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	},

    deleteByEmoticonIdFromLDB:function(userId, emoticonId, callback){ 
        // debugger; 
         UserDB.getInstance().create(userId,function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_PACKAGE_ID);
                // var request = index.delete(emoticonId);

                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(emoticonId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
                
        }); 
    }
   
	
};

MyEmoticonDAO.getInstance= function(){
    if(!MyEmoticonDAO.instance){
        MyEmoticonDAO.instance = new MyEmoticonDAO();
    }
    return MyEmoticonDAO.instance;
};
