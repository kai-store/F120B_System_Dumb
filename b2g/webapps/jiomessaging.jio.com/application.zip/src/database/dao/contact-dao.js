function Contact() {
	this.contactId = "";
	this.mobileNumber = "";
	this.phoneBookName = "";
	this.phoneBookPinyin = "";
	this.userId = "";
	this.rcsName = "";
	this.rcsPinyin = "";
	this.rcsData = "";
	this.rcsAvatar = "";
	this.phoneBookData = "";
	this.activeStatus = "";
	this.isBlack = "";
	this.isHide = "";
	this.cardVersion = "";
    this.gender = "";
    this.mood = "";
    this.company = "";
    this.favorite = false;
    this.expression = "";
    this.colorCode = "";
    this.isPhoneBookContact = 0;
    this.portraitId = "";
  
}

Contact.prototype = {
	constructor: Contact,
    listenMessages:function(){
        console.log("Listen Contacts Started");    
        self.importScripts('../../utils/underscore.js');
        // self.importScripts('../user-cipher-db.js');
        self.importScripts('../user-db.js');
        self.importScripts('../db-utils.js');
        self.importScripts('../database.js');
        self.importScripts('../db.consts.js');
        self.importScripts('../../app-const.js');
        self.importScripts('../../app-mode.js');
        self.importScripts('../dao/group-mapping-dao.js');
        self.importScripts('../dao/group-dao.js');
        // self.importScripts('../dao/contact-dao.js');
        self.importScripts('../dao/session-dao.js');
        // self.importScripts('../dao/channels-list-dao.js');
        // self.importScripts('../dao/channels-focus-list-dao.js');
        self.importScripts('../../cin/CinBase64.js');
        self.importScripts('../../cin/cin.request.conts.js');
        self.importScripts('../../cin/message/message.const.js');

        self.onmessage = function(event) {
            if(event.data.length == 0) return;
           
           
           var funcName = event.data.functionName;
           var userId = event.data.userId;
        //    console.log("param1: "+funcName+">>>>>>>> param2: "+userId);   
           switch(funcName) {
                case "addToLDB":
                    var contactData = event.data.data;
                    var data = {
                        contactId : contactData.contactId,
                        mobileNumber : contactData.mobileNumber,
                        phoneBookName : contactData.phoneBookName,
                        phoneBookPinyin : contactData.phoneBookPinyin,
                        userId : contactData.userId,
                        rcsName : contactData.rcsName,
                        rcsPinyin : contactData.rcsPinyin,
                        rcsData : contactData.rcsData,
                        rcsAvatar : contactData.rcsAvatar,
                        phoneBookData : contactData.phoneBookData,
                        activeStatus : contactData.activeStatus,
                        isBlack : contactData.isBlack,
                        isHide : contactData.isHide,
                        cardVersion : contactData.cardVersion,
                        gender : contactData.gender,
                        mood : contactData.mood,
                        company : contactData.company,
                        favorite : contactData.favorite,
                        expression : contactData.expression,
                        colorCode : contactData.colorCode,
                        isPhoneBookContact : contactData.isPhoneBookContact,
                        portraitId : contactData.portraitId
                    } 
                    Contact.getInstance().addByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "addByDataToLDB":
                    var data = event.data.data;
                    Contact.getInstance().addByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                break;
                case "updateByDataToLDB":
                     var data = event.data.data;
                    Contact.getInstance().updateByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    
                break;
                case "updateByUserIdToLDB":
                    var data = event.data.data;
                    Contact.getInstance().updateByUserIdToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                   
                break;
                case "bulkUpdateToLDB":
                    var contacts = event.data.contacts;
                    Contact.getInstance().bulkUpdateToLDB(userId, contacts, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                
                break;
                case "bulkAddToLDB":
                    var contacts = event.data.contacts;
                    Contact.getInstance().bulkAddToLDB(userId, contacts, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                   
                break;
                case "getAllFromLDB":
                    Contact.getInstance().getAllFromLDB(userId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    }); 
                    
                break;
                case "getByContactUserIdFromLDB":
                    var contactUserId = event.data.contactUserId;
                    Contact.getInstance().getByContactUserIdFromLDB(userId, contactUserId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                   
                break;
                case "getByMobileNumberFromLDB":
                     var mobileNumber = event.data.mobileNumber;
                     Contact.getInstance().getByMobileNumberFromLDB(userId, mobileNumber, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                   
                break;
                case "deleteAllFromLDB":
                    Contact.getInstance().deleteAllFromLDB(userId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
             
                break;
                default:
                    console.log("Nothing to do with contacts dao for :"+funcName);
           }
        };
    },
    addToLDB:function(userId, callback){
        //Arranging Contact Data to be inserted
	    var data = {
            contactId : this.contactId,
            mobileNumber : this.mobileNumber,
            phoneBookName : this.phoneBookName,
            phoneBookPinyin : this.phoneBookPinyin,
            userId : this.userId,
            rcsName : this.rcsName,
            rcsPinyin : this.rcsPinyin,
            rcsData : this.rcsData,
            rcsAvatar : this.rcsAvatar,
            phoneBookData : this.phoneBookData,
            activeStatus : this.activeStatus,
            isBlack : this.isBlack,
            isHide : this.isHide,
            cardVersion : this.cardVersion,
            gender : this.gender,
            mood : this.mood,
            company : this.company,
            favorite : this.favorite,
            expression : this.expression,
            colorCode : this.colorCode,
            isPhoneBookContact : this.isPhoneBookContact,
            portraitId: this.portraitId

        } 

          UserDB.getInstance().create(userId, function(success){
           
                //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CONTACTS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    addByDataToLDB:function(userId, data, callback){
          UserDB.getInstance().create(userId, function(success){
          
                //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CONTACTS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    updateByDataToLDB:function(userId, data, callback){
        // debugger;
        console.log("[contact:store] Image Updating to DAO :",data);
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CONTACTS, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER);
                // var request = index.get(data.mobileNumber);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.mobileNumber);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor && cursor != null) {
                         var updateData = cursor.value;
                         if(data.contactId != undefined && data.contactId != null){
                             updateData.contactId = data.contactId;
                         }
                         if(data.mobileNumber != undefined && data.mobileNumber != null){
                             updateData.mobileNumber = data.mobileNumber;
                         }
                         if(data.phoneBookName != undefined && data.phoneBookName != null){
                             updateData.phoneBookName = data.phoneBookName;
                         }
                         if(data.phoneBookPinyin != undefined && data.phoneBookPinyin != null){
                             updateData.phoneBookPinyin = data.phoneBookPinyin;
                         }
                         if(data.userId != undefined && data.userId != null && data.userId != ""){
                             updateData.userId = data.userId;
                         }
                         if(data.rcsName != undefined && data.rcsName != null){
                             updateData.rcsName = data.rcsName;
                         }
                         if(data.rcsPinyin != undefined && data.rcsPinyin != null){
                             updateData.rcsPinyin = data.rcsPinyin;
                         }
                         if(data.rcsData != undefined && data.rcsData != null){
                             updateData.rcsData = data.rcsData;
                         }
                         if(data.rcsAvatar != undefined && data.rcsAvatar != null){
                             updateData.rcsAvatar = data.rcsAvatar;
                         }
                         if(data.phoneBookData != undefined && data.phoneBookData != null){
                             updateData.phoneBookData = data.phoneBookData;
                         }
                         if(data.activeStatus != undefined && data.activeStatus != null){
                             updateData.activeStatus = data.activeStatus;
                         }
                         if(data.isBlack != undefined && data.isBlack != null){
                             updateData.isBlack = data.isBlack;
                         }
                         if(data.isHide != undefined && data.isHide != null){
                             updateData.isHide = data.isHide;
                         }
                         if(data.cardVersion != undefined && data.cardVersion != null){
                             updateData.cardVersion = data.cardVersion;
                         }
                         if(data.gender != undefined && data.gender != null){
                             updateData.gender = data.gender;
                         }
                         if(data.mood != undefined && data.mood != null){
                             updateData.mood = data.mood;
                         }
                         if(data.expression != undefined && data.expression != null){
                             updateData.expression = data.expression;
                         }
                         if(data.company != undefined && data.company != null){
                             updateData.company = data.company;
                         }
                         if(data.favorite != undefined && data.favorite != null){
                             updateData.favorite = data.favorite;
                         }
                          if(data.isPhoneBookContact != undefined && data.isPhoneBookContact != null){
                             updateData.isPhoneBookContact = data.isPhoneBookContact;
                         }
                         if(data.colorCode != undefined && data.colorCode != null){
                             updateData.colorCode = data.colorCode;
                         }
                            if(data.portraitId && data.portraitId != ""){
                                updateData.portraitId = data.portraitId;
                            }                    
                       
                       

                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    } 
                };
        });	 
    },
    
    updateByUserIdToLDB:function(userId, data, callback){
        // debugger;
        console.log("updTES DATA:",data);
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CONTACTS, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);            
              
                // trans.oncomplete = function(evt) {  
                //     callback(true);
                // };
            
                var cursorRequest = index.openCursor(data.userId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    // debugger;
                    if (cursor) {
                         var updateData = cursor.value;
                        //  if(data.contactId != undefined && data.contactId != null){
                        //      updateData.contactId = data.contactId;
                        //  }
                         if(data.mobileNumber != undefined && data.mobileNumber != null){
                             updateData.mobileNumber = data.mobileNumber;
                         }
                         if(data.phoneBookName != undefined && data.phoneBookName != null){
                             updateData.phoneBookName = data.phoneBookName;
                         }
                         if(data.phoneBookPinyin != undefined && data.phoneBookPinyin != null){
                             updateData.phoneBookPinyin = data.phoneBookPinyin;
                         }
                         if(data.userId != undefined && data.userId != null && data.userId != ""){
                             updateData.userId = data.userId;
                         }
                         if(data.rcsName != undefined && data.rcsName != null){
                             updateData.rcsName = data.rcsName;
                         }
                         if(data.rcsPinyin != undefined && data.rcsPinyin != null){
                             updateData.rcsPinyin = data.rcsPinyin;
                         }
                         if(data.rcsData != undefined && data.rcsData != null){
                             updateData.rcsData = data.rcsData;
                         }
                         if(data.rcsAvatar != undefined && data.rcsAvatar != null){
                             updateData.rcsAvatar = data.rcsAvatar;
                         }
                         if(data.phoneBookData != undefined && data.phoneBookData != null){
                             updateData.phoneBookData = data.phoneBookData;
                         }
                         if(data.activeStatus != undefined && data.activeStatus != null){
                             updateData.activeStatus = data.activeStatus;
                         }
                         if(data.isBlack != undefined && data.isBlack != null){
                             updateData.isBlack = data.isBlack;
                         }
                         if(data.isHide != undefined && data.isHide != null){
                             updateData.isHide = data.isHide;
                         }
                         if(data.cardVersion != undefined && data.cardVersion != null){
                             updateData.cardVersion = data.cardVersion;
                         }
                         if(data.gender != undefined && data.gender != null){
                             updateData.gender = data.gender;
                         }
                         if(data.mood != undefined && data.mood != null){
                             updateData.mood = data.mood;
                         }
                         if(data.expression != undefined && data.expression != null){
                             updateData.expression = data.expression;
                         }
                         if(data.company != undefined && data.company != null){
                             updateData.company = data.company;
                         }
                         if(data.favorite != undefined && data.favorite != null){
                             updateData.favorite = data.favorite;
                         }
                          if(data.isPhoneBookContact != undefined && data.isPhoneBookContact != null){
                             updateData.isPhoneBookContact = data.isPhoneBookContact;
                         }
                         if(data.colorCode != undefined && data.colorCode != null){
                             updateData.colorCode = data.colorCode;
                         }
                            if(data.portraitId && data.portraitId != ""){
                                updateData.portraitId = data.portraitId;
                            }
                       
                       
                       

                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("contact list callback update success!!");
                                callback(true);
                            }
                            res.onerror = function(e){
                                console.log("contact list callback update failed!!");
                                callback(false);
                            }
                        
                        // cursor.continue();
                    }
                };
        });	 
	},

    bulkUpdateToLDB:function(userId, contacts, callback){
        UserDB.getInstance().create(userId, function(success){
            // var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CONTACTS], "readwrite")
                            // .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
            putNext(0);

            function putNext(i) {
                if (i<contacts.length) {
                    Contact.getInstance().updateByDataToLDB(userId, contacts[i], function(sucess){
                        putNext(i+1)
                    });
                    // var request = objectStore.put(contacts[i])
                    // request.onsuccess = function(event) {
                    //     putNext(i+1)
                    // };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    bulkAddToLDB:function(userId, contacts, callback){
        console.log("In bulk add to lDB userID is "+userId+" contacts "+contacts+"callback"+JSON.stringify(callback));
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CONTACTS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
            putNext(0);

            function putNext(i) {
                if (i<contacts.length) {
                    var request = objectStore.put(contacts[i]);
                    request.onsuccess = function(event) {
                        putNext(i+1);
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    getAllFromLDB:function(userId, callback){
        // debugger;	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CONTACTS, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
            var items = [];
        
            trans.oncomplete = function(evt) {  
                // callback(items);
                // callback(_.sortBy(items,"phoneBookName"));

                callback(_.sortBy(items, function (i) { return i.phoneBookName.toLowerCase(); }));
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
	},
     getByContactUserIdFromLDB:function(userId, contactUserId, callback){	
        //  debugger;
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CONTACTS, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);
                var request = index.get(contactUserId);
                console.log('CONTACT USER ID :' +contactUserId);
                //Handler for success operation
                request.onsuccess = function(event) {
                    if(event.target.result !== undefined && event.target.result !== null){
                         callback(event.target.result); 

                    }  else{
                        callback({});
                    }             

                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback({});
                }
        });
    },
     getByMobileNumberFromLDB:function(userId, mobileNumber, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CONTACTS, IDBTransaction.READ_ONLY);
            var request = trans
                        .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS)
                        .get(mobileNumber);
            
            //Handler for success operation
            request.onsuccess = function(event) {
                if(event.target.result !== undefined && event.target.result !== null){
                    callback(event.target.result); 
                } else{
                    callback({});
                }          
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback({});
            } 
        });
    },
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
              //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CONTACTS], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
	}
	
};

Contact.getInstance= function(){
    if(!Contact.instance){
        Contact.instance = new Contact();
        Contact.instance.listenMessages();
    }
    return Contact.instance;
};

Contact.getInstance();