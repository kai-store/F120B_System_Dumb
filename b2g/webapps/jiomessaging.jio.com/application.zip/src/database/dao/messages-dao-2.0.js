function Messages() {
	this.msgId = "";
	this.msgDirection = "";
	this.msgContent = "";
	this.msgType = "";
	this.msgFrom = "";
	this.msgTo = "";
	this.msgDateTime = "";
	this.msgLocalDateTime = "";
	this.msgThumbStatus = "";
	this.msgStatus = "";
	this.msgFileStatus = "";
	this.msgRead = "";
	this.msgSequence = 0;
	this.msgLocalSequence = 0;
    this.msgDelete = "";
    this.msgTOS = "";
    this.msgMultimedia = "";
    this.msgListen = "";
    this.sessionId = "";
    this.sessionType = "";
    this.msgPeerName = "";
    this.attachment = undefined;
    this.fileId = "";
    this.mThumbId = "";
    this.thumbLocalPath = "";
    this.fileLocalPath = "";
    this.broadcastUsers = [];
    this.isAudioPlayed = false;
    this.callMode = "";
    this.mobileNumbers = [];
    this.isThumbUploaded = "";
    this.isFileUploaded = "";
    this.fullImagePath = "";
}

Messages.prototype = {
	constructor: Messages,
    listenMessages:function(){
        console.log("Listen Message Started");
          
// if( 'function' === typeof importScripts) {
                // self.importScripts('../../utils/underscore.js');
                // self.importScripts('../user-cipher-db.js');
                // self.importScripts('../user-db.js');
                // self.importScripts('../db-utils.js');
                // self.importScripts('../database.js');
                // self.importScripts('../db.consts.js');
                // self.importScripts('../../app-const.js');
                // self.importScripts('../../app-mode.js');
                // self.importScripts('../dao/group-mapping-dao.js');
                // self.importScripts('../dao/group-dao.js');
                // self.importScripts('../dao/contact-dao.js');
                // self.importScripts('../dao/session-dao.js');
                // // self.importScripts('../dao/channels-list-dao.js');
                // // self.importScripts('../dao/channels-focus-list-dao.js');
                // self.importScripts('../../cin/CinBase64.js');
                // self.importScripts('../../cin/cin.request.conts.js');
                // self.importScripts('../../cin/message/message.const.js');
        //    }
        self.onmessage = function(event) {
           if(event.data.length == 0) return;
           
           
           var funcName = event.data.functionName;
           var userId = event.data.userId;
           console.log("[Messages:::DAO] param1: " + funcName + ">>>>>>>> param2: " + userId);
           switch(funcName) {
                case "addToLDB":
                var userData = event.data.data;
                var data = {
                    msgId : userData.msgId,
                    msgDirection : userData.msgDirection,
                    msgContent : userData.msgContent,
                    msgType : userData.msgType,
                    msgFrom : userData.msgFrom,
                    msgTo : userData.msgTo,
                    msgDateTime : userData.msgDateTime,
                    msgLocalDateTime : userData.msgLocalDateTime,
                    msgThumbStatus : userData.msgThumbStatus,
                    msgStatus : userData.msgStatus,
                    msgRead : userData.msgRead,
                    msgSequence : userData.msgSequence,
                    msgLocalSequence : userData.msgLocalSequence,
                    msgDelete : userData.msgDelete,
                    msgTOS : userData.msgTOS,
                    msgMultimedia : userData.msgMultimedia,
                    msgListen : userData.msgListen,
                    sessionId : userData.sessionId,
                    sessionType : userData.sessionType,
                    msgPeerName : userData.msgPeerName,
                    attachment : userData.attachment,
                    fileId : userData.fileId,
                    mThumbId : userData.mThumbId,
                    thumbLocalPath: userData.thumbLocalPath,
                    fileLocalPath: userData.fileLocalPath,
                    broadcastUsers: userData.broadcastUsers,
                    isAudioPlayed: userData.isAudioPlayed,
                    callMode:userData.callMode
                } 
                    Messages.getInstance().addByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "addByDataToLDB":
                    var data = event.data.data;
                    Messages.getInstance().addByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateByDataToLDB":
                    var data = event.data.data;
                    Messages.getInstance().updateByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateByDataForSessionToLDB":
                    var data = event.data.data;
                    Messages.getInstance().updateByDataForSessionToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateDataForSessionToLDB":
                    var data = event.data.data;
                    Messages.getInstance().updateDataForSessionToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateMessageStatusByDataForSessionToLDB":
                    var data = event.data.data;
                    Messages.getInstance().updateMessageStatusByDataForSessionToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateMessageStatusForPeerId":
                    var peerId = event.data.peerId;
                    var messageStatus = event.data.messageStatus;
                    Messages.getInstance().updateMessageStatusForPeerId(userId, peerId, messageStatus, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateMsgStatusBySequence":
                    var peerId = event.data.peerId;
                    var lastReadSequence = event.data.lastReadSequence;
                    var messageStatus = event.data.messageStatus;
                    Messages.getInstance().updateMsgStatusBySequence(userId, peerId, lastReadSequence, messageStatus, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "bulkAddToLDB":
                    var messages = event.data.messages;
                    Messages.getInstance().bulkAddToLDB(userId, messages, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getAllBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getAllBySessionIdFromLDB(userId, sessionId, function(items){
                        var responseData = {
                            result:items,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getAllBroadcastBySessionTypeFromLDB":

                    Messages.getInstance().getAllBroadcastBySessionTypeFromLDB(userId, function(items){
                        var responseData = {
                            result:items,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getDeleteStatusBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getDeleteStatusBySessionIdFromLDB(userId, sessionId, function(status){
                        var responseData = {
                            result:status,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getAllDeletedBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getAllDeletedBySessionIdFromLDB(userId, sessionId, function(items){
                        var responseData = {
                            result:items,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getUnreadMessageCountBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getUnreadMessageCountBySessionIdFromLDB(userId, sessionId, function(unReadMessageCount){
                        var responseData = {
                            result:unReadMessageCount,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;

                case "getTotalMessageCountBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getTotalMessageCountBySessionIdFromLDB(userId, sessionId, function(totalMsgCount){
                        var responseData = {
                            result:totalMsgCount,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getAllNonUploadMessagesFromLDB":
                    Messages.getInstance().getAllNonUploadMessagesFromLDB(userId, function(items){
                        var responseData = {
                            result:items,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getByMsgIdFromLDB":
                    var messageId = event.data.messageId;
                    Messages.getInstance().getByMsgIdFromLDB(userId, messageId, function(msg){
                        var responseData = {
                            result:msg,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getRecentMessageForSessionId":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getRecentMessageForSessionId(userId, sessionId, function(msg){
                        var responseData = {
                            result:msg,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getBroadcastRecentMessageForSessionId":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getBroadcastRecentMessageForSessionId(userId, sessionId, function(msg){
                        var responseData = {
                            result:msg,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getLastSequenceMessageForSessionId":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getLastSequenceMessageForSessionId(userId, sessionId, function(msg){
                        var responseData = {
                            result:msg,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getMessageByFileId":
                    var fileId = event.data.fileId;
                    Messages.getInstance().getMessageByFileId(userId, fileId, function(msg){
                        var responseData = {
                            result:msg,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;

                case "getAllMessagesByMsgTypeForSessionId":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getAllMessagesByMsgTypeForSessionId(userId, sessionId, function(messages){
                        var responseData = {
                            result:messages,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getAllMediaMessageForSessionId":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().getAllMediaMessageForSessionId(userId, sessionId, function(messages){
                        var responseData = {
                            result:messages,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "deleteAllBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().deleteAllBySessionIdFromLDB(userId, sessionId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "deleteAllChannelMsgBySessionIdFromLDB":
                    var sessionId = event.data.sessionId;
                    Messages.getInstance().deleteAllChannelMsgBySessionIdFromLDB(userId, sessionId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData);
                    });
                    break;
                case "deleteByMessageIdFromLDB":
                    var messageId = event.data.messageId;
                    Messages.getInstance().deleteByMessageIdFromLDB(userId, messageId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "deleteByMessageIdForSessionIdFromLDB":
                    var messageId = event.data.messageId;
                    var sessionId = event.data.sessionId;
                    var deleteType = event.data.deleteType;
                    Messages.getInstance().deleteByMessageIdForSessionIdFromLDB(userId, messageId, sessionId, deleteType, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "deleteAllFromLDB":
                    Messages.getInstance().deleteAllFromLDB(userId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                   
                default:
                    console.log("Nothing to do with messages dao for :"+funcName);
            }
           
        };
    },
    isNewSession:function(userId, sessionId, callback){
           Session.getInstance().getSessionForSessionIdFromLDB(userId, sessionId, function(session){
                console.log("isNewSession: "+session);	
                if(session == null){
                     callback(true);
                }else{
                     callback(false);
                }
            });
       
    },
    addToLDB:function(userId, data, callback){
        //Arranging Message Data to be inserted
	    // var data = {
        //     msgId : this.msgId,
        //     msgDirection : this.msgDirection,
        //     msgContent : this.msgContent,
        //     msgType : this.msgType,
        //     msgFrom : this.msgFrom,
        //     msgTo : this.msgTo,
        //     msgDateTime : this.msgDateTime,
        //     msgLocalDateTime : this.msgLocalDateTime,
        //     msgThumbStatus : this.msgThumbStatus,
        //     msgStatus : this.msgStatus,
        //     msgRead : this.msgRead,
        //     msgSequence : this.msgSequence,
        //     msgLocalSequence : this.msgLocalSequence,
        //     msgDelete : this.msgDelete,
        //     msgTOS : this.msgTOS,
        //     msgMultimedia : this.msgMultimedia,
        //     msgListen : this.msgListen,
        //     sessionId : this.sessionId,
        //     sessionType : this.sessionType,
        //     msgPeerName : this.msgPeerName,
        //     attachment : this.attachment,
        //     fileId : this.fileId,
        //     mThumbId : this.mThumbId,
        //     thumbLocalPath: this.thumbLocalPath,
        //     fileLocalPath: this.fileLocalPath,
        //     broadcastUsers: this.broadcastUsers,
        //     isAudioPlayed: this.isAudioPlayed,
        //     callMode: this.callMode
        // }
         UserCipherDB.getInstance().create(userId, function(success){
            console.log("Insert MEssages : "+data);
                //Making INSERT contact request to Local DB 
                var request = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    // Session.getInstance().addByMessageToLDB(userId, data, function(success){
                    //     callback(true)
                    // });
                     Session.getInstance().updateRecentMessageBySessionId("", "", userId, data.sessionId, function(success){
                        callback(true);
                    }); 
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
       
   
	},
    addByDataToLDB:function(userId, data, callback){
        //Arranging Message Data to be inserted
         UserCipherDB.getInstance().create(userId, function(success){
            console.log("Insert MEssages : "+data);
                //Making INSERT contact request to Local DB 
                var request = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    if(data.sessionType == CINRequestConts.SESSIONPUBLIC){
                        callback(true);
                    }else{
                        // Session.getInstance().updateRecentMessageBySessionId(userId, data.sessionId, function(success){
                        //     callback(true);
                        // });
                        callback(true);
                    }
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
       
   
	},
    updateByDataToLDB:function(userId, data, callback){
         UserCipherDB.getInstance().create(userId, function(success){
              var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_ID);
                var request = index.get(data.msgId);
            
             
                // trans.oncomplete = function(evt) {  
                //     callback(true);
                // };
            
                var cursorRequest = index.openCursor(data.msgId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                        //  if(data.sessionId != undefined && data.sessionId != null && data.sessionId != ""){
                        //      updateData.sessionId = data.sessionId;
                        //  }
                         if(data.msgId != undefined && data.msgId != null && data.msgId != ""){
                             updateData.msgId = data.msgId;
                         }
                         if(data.msgFrom != undefined && data.msgFrom != null && data.msgFrom != ""){
                             updateData.msgFrom = data.msgFrom;
                         }
                         if(data.msgTo != undefined && data.msgTo != null && data.msgTo != ""){
                             updateData.msgTo = data.msgTo;
                         }
                         if(data.sessionType != undefined && data.sessionType != null && data.sessionType != ""){
                             updateData.sessionType = data.sessionType;
                         }
                         if(data.msgType != undefined && data.msgType != null && data.msgType != ""){
                             updateData.msgType = data.msgType;
                         }
                         if(data.msgStatus != undefined && data.msgStatus != null && data.msgType != ""){
                             updateData.msgStatus = data.msgStatus;
                         }
                         if(data.msgContent != undefined && data.msgContent != null && data.msgContent != ""){
                             updateData.msgContent = data.msgContent;
                         }
                         if(data.msgRead != undefined && data.msgRead != null && data.msgRead != ""){
                             updateData.msgRead = data.msgRead;
                         }
                         if(data.msgDateTime != undefined && data.msgDateTime != null && data.msgDateTime != ""){
                             updateData.msgDateTime = data.msgDateTime;
                         }
                        //  Updated by Kaal
                         if(data.msgLocalDateTime != undefined && data.msgLocalDateTime != null && data.msgLocalDateTime != ""){
                            updateData.msgLocalDateTime = data.msgLocalDateTime;
                         }

                         if(data.msgSequence != undefined && data.msgSequence != null && data.msgSequence != ""){
                             updateData.msgSequence = data.msgSequence;
                         }
                         
                         if(data.msgLocalSequence != undefined && data.msgLocalSequence != null && data.msgLocalDateTime != ""){
                             updateData.msgLocalSequence = data.msgLocalSequence;
                         }
                         if(data.msgDelete != undefined && data.msgDelete != null && data.msgDelete != ""){
                             updateData.msgDelete = data.msgDelete;
                         }
                         if(data.attachment != undefined && data.attachment != null && data.attachment != ""){
                             updateData.attachment = data.attachment;
                         }

                         if(data.fileId != undefined && data.fileId != null && data.fileId != ""){
                             updateData.fileId = data.fileId;
                         }

                         if(data.mThumbId != undefined && data.mThumbId != null && data.mThumbId != ""){
                             updateData.mThumbId = data.mThumbId;
                         }

                        if(data.thumbLocalPath != undefined && data.thumbLocalPath != null &&   data.thumbLocalPath != ""){
                             updateData.thumbLocalPath = data.thumbLocalPath;
                         }

                         if(data.fileLocalPath != undefined && data.fileLocalPath != null && data.fileLocalPath != ""){
                             updateData.fileLocalPath = data.fileLocalPath;
                         }

                         if(data.fullImagePath != undefined && data.fullImagePath != ""){
                            updateData.fullImagePath = data.fullImagePath;
                        }

                         if(data.broadcastUsers != undefined && data.broadcastUsers != null && data.broadcastUsers != ""){
                             updateData.broadcastUsers = data.broadcastUsers;
                         }

                         if(data.isAudioPlayed != undefined && data.isAudioPlayed != null && data.isAudioPlayed == ""){
                             updateData.isAudioPlayed = data.isAudioPlayed;
                         }

                         if(data.callMode && data.callMode != ""){
                             updateData.callMode = data.callMode;
                         }

                         if(data.mobileNumbers && data.mobileNumbers != "" && data.mobileNumbers.length > 0){
                             updateData.mobileNumbers = data.mobileNumbers;
                         }

                         if(data.msgType == MessageConsts.TYPE_PUBLIC_IMAGETEXT && data.ppFileId && data.ppFileId != ""){
                             var path;
                             if(data.thumbLocalPath && data.thumbLocalPath != ""){
                                path = data.thumbLocalPath;
                             } else if(data.fileLocalPath && data.fileLocalPath != ""){
                                path = data.fileLocalPath;
                             }
                            if(path && path != ""){
                                var attachment = updateData.attachment;
                                if(attachment && attachment.length > 0){
                                    attachment.forEach(function(aitem, ind){
                                        if(aitem.imageId == data.ppFileId){
                                            aitem.thumbLocalPath = path;
                                        }
                                    });
                                }
                            }
                         }

                         if(data.isThumbUploaded && data.isThumbUploaded != ""){
                             updateData.isThumbUploaded = data.isThumbUploaded;
                         }

                         if(data.isFileUploaded && data.isFileUploaded != ""){
                             updateData.isFileUploaded = data.isFileUploaded;
                         }
                         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                // console.log("update success!!");
                                if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
                                    callback(true);
                                } else {
                                    if(data.sessionType == AppConstants.BROADCAST_MESSAGE){
                                        data.sessionId = AppConstants.BROADCAST;
                                        Session.getInstance().updateByMessage(userId, data, function(sessioUpdateSuccess){
                                            // console.log("session updated success!!");
                                            callback(true);
                                        });
                                    }else{
                                        Session.getInstance().updateByMessage(userId, data, function(sessioUpdateSuccess){
                                            // console.log("session updated success!!");
                                            callback(true);
                                        });
                                    }
                                }
                            }
                            res.onerror = function(e){
                                // console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    updateByDataForSessionToLDB:function(userId, data, callback){
         UserCipherDB.getInstance().create(userId, function(success){
              var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(data.sessionId);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                        //  if(data.sessionId != undefined && data.sessionId != null){
                        //      updateData.sessionId = data.sessionId;
                        //  }
                         if(data.msgId != undefined && data.msgId != null){
                             updateData.msgId = data.msgId;
                         }
                         if(data.msgFrom != undefined && data.msgFrom != null){
                             updateData.msgFrom = data.msgFrom;
                         }
                         if(data.msgTo != undefined && data.msgTo != null){
                             updateData.msgTo = data.msgTo;
                         }
                         if(data.sessionType != undefined && data.sessionType != null){
                             updateData.sessionType = data.sessionType;
                         }
                         if(data.msgType != undefined && data.msgType != null){
                             updateData.msgType = data.msgType;
                         }
                        //  Kaal added STATUS_SENT & STATUS_ARRIVED
                         if(data.msgStatus != undefined && data.msgStatus != null && (updateData.msgStatus == MessageConsts.STATUS_SENT || updateData.msgStatus == MessageConsts.STATUS_ARRIVED)){
                             if((String(updateData.msgFrom)) != String(userId)){
                                updateData.msgStatus = data.msgStatus;
                             }
                         }
                         
                         if(data.msgContent != undefined && data.msgContent != null){
                             updateData.msgContent = data.msgContent;
                         }
                         if(data.msgRead != undefined && data.msgRead != null){
                             updateData.msgRead = data.msgRead;
                         }
                          if(data.msgDateTime != undefined && data.msgDateTime != null){
                             updateData.msgDateTime = data.msgDateTime;
                         }
                         if(data.msgLocalDateTime != undefined && data.msgLocalDateTime != null){
                             updateData.msgLocalDateTime = data.msgLocalDateTime;
                         }

                         if(data.msgSequence != undefined && data.msgSequence != null){
                             updateData.msgSequence = data.msgSequence;
                         }
                         if(data.msgLocalSequence != undefined && data.msgLocalSequence != null){
                             updateData.msgLocalSequence = data.msgLocalSequence;
                         }
                         if(data.msgDelete != undefined && data.msgDelete != null){
                            //  if(updateData.msgDelete != "1"){
                                updateData.msgDelete = data.msgDelete;
                            //  }
                         }
                         if(data.attachment != undefined && data.attachment != null && data.attachment != ""){
                             updateData.attachment = data.attachment;
                         }

                         if(data.fileId != undefined && data.fileId != null && data.fileId != ""){
                             updateData.fileId = data.fileId;
                         }

                         if(data.mThumbId != undefined && data.mThumbId != null && data.mThumbId != ""){
                             updateData.mThumbId = data.mThumbId;
                         }

                         if(data.thumbLocalPath != undefined && data.thumbLocalPath != null &&   data.thumbLocalPath != ""){
                             updateData.thumbLocalPath = data.thumbLocalPath;
                         }

                         if(data.fileLocalPath != undefined && data.fileLocalPath != null && data.fileLocalPath != ""){
                             updateData.fileLocalPath = data.fileLocalPath;
                         }

                         if(data.broadcastUsers != undefined && data.broadcastUsers != null && data.broadcastUsers != ""){
                             updateData.broadcastUsers = data.broadcastUsers;
                         }

                        if(data.isAudioPlayed != undefined && data.isAudioPlayed != null){
                             updateData.isAudioPlayed = data.isAudioPlayed;
                        }
                         if(data.callMode && data.callMode != ""){
                             updateData.callMode = data.callMode;
                         }

                         if(data.mobileNumbers && data.mobileNumbers != "" && data.mobileNumbers.length > 0){
                             updateData.mobileNumbers = data.mobileNumbers;
                         }
                         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                // console.log("update success!!");
                               Session.getInstance().updateByMessage(userId, data, function(sessioUpdateSuccess){
                                    // console.log("session updated success!!");
                               });
                                // callback(true);
                            }
                            res.onerror = function(e){
                                // console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    updateMessageStatusByDataForSessionToLDB:function(userId, data, callback){
         UserCipherDB.getInstance().create(userId, function(success){
              var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.get(data.sessionId);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         //  Kaal have to removed this
                         if(!(updateData.msgStatus == MessageConsts.STATUS_UNKNOWN ||
                         updateData.msgStatus == MessageConsts.STATUS_FAILED ||
                         updateData.msgStatus == MessageConsts.STATUS_DRAFT||
                         updateData.msgStatus == MessageConsts.STATUS_SENDING)){
                             if(data.msgStatus != undefined && data.msgStatus != null){
                                updateData.msgStatus = data.msgStatus;
                             }
                         }
                         // Remove up to this End
               
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                // console.log("update success!!");
                               Session.getInstance().updateByMessage(userId, data, function(sessioUpdateSuccess){
                                    // console.log("session updated success!!");
                               });
                                // callback(true);
                            }
                            res.onerror = function(e){
                                // console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    updateMessageStatusForPeerId:function(userId, peerId, messageStatus, callback){
         UserCipherDB.getInstance().create(userId, function(success){
              var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(peerId);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(peerId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if((updateData.msgFrom == userId) && (messageStatus != undefined && messageStatus != null)){
                             updateData.msgStatus = messageStatus;
                         }
                         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                // console.log("update success!!");
                                // callback(true);
                            }
                            res.onerror = function(e){
                                // console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
    },
    updateMsgStatusBySequence:function(userId, peerId, lastReadSequence, messageStatus, callback){
         UserCipherDB.getInstance().create(userId, function(success){
              var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.get(peerId);
            
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(peerId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         
                         if(updateData.sessionType == CINRequestConts.SESSIONSINGLE 
                            && updateData.msgDirection == "0" && updateData.msgType != MessageConsts.TYPE_FREE_SMS && updateData.msgType != MessageConsts.TYPE_UPDATE_STATUS){

                            if(parseInt(updateData.msgSequence) <= parseInt(lastReadSequence)){
                                if(messageStatus != undefined && messageStatus != null){
                                    if(updateData.msgStatus == MessageConsts.STATUS_ARRIVED){
                                        updateData.msgStatus = messageStatus;
                                        var res = cursor.update(updateData);
                                        res.onsuccess = function(e){
                                            // console.log("update success!!");
                                            // callback(true);
                                        }
                                        res.onerror = function(e){
                                            // console.log("update failed!!");
                                            callback(false);
                                        }
                                    }
                                }
                            }
                            
                         }
                        
                        cursor.continue();
                    }
                };
        });	 
    },
    updateDataForSessionToLDB:function(userId, data, callback){
         UserCipherDB.getInstance().create(userId, function(success){
              var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(data.sessionId);

                trans.oncomplete = function(evt) {  
                    callback(true);
                    Session.getInstance().updateByMessage(userId, data, function(sessioUpdateSuccess){
                        // console.log("session updated success!!");
                    });
                };
            
                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         
                         //  Kaal added STATUS_SENT & STATUS_ARRIVED
                        if(data.msgStatus != undefined && data.msgStatus != null && (updateData.msgStatus == MessageConsts.STATUS_SENT || updateData.msgStatus == MessageConsts.STATUS_ARRIVED) && updateData.msgDirection == 1){
                            if((String(updateData.msgFrom)) != String(userId)){
                                updateData.msgStatus = data.msgStatus;
                                var res = cursor.update(updateData);
                                res.onsuccess = function(e){
                                    // console.log("update success!!");
                                    // callback(true);
                                }
                                res.onerror = function(e){
                                    // console.log("update failed!!");
                                    callback(false);
                                }
                            }
                        }
                        
                        cursor.continue();
                    }
                };
        });	 
    },
    updatePeerNameForSessionToLDB:function(userId, data, callback){
        UserCipherDB.getInstance().create(userId, function(success){
            var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, 'readwrite');
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
            
            var request = index.get(data.sessionId);
            trans.oncomplete = function(evt) {  
                callback(true);
            };
            
            var cursorRequest = index.openCursor(data.sessionId);
            
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
                callback(false);
            };
            
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var updateData = cursor.value;
                    if(String(data.msgFrom) == String(updateData.msgFrom) && data.msgPeerName && data.msgPeerName != ""){
                        updateData.msgPeerName = data.msgPeerName;
                    }

                    if(data.name && data.name != ""){
                        updateData.name = data.name;
                    }
                    
                    var res = cursor.update(updateData);
                    res.onsuccess = function(e){
                        // console.log("update success!!");
                    }
                    res.onerror = function(e){
                        // console.log("update failed!!");
                        callback(false);
                    }
                    cursor.continue();
                }
            };
       });	 
   },
   bulkAddToLDB:function(userId, messages, callback){
        UserCipherDB.getInstance().create(userId, function(success){
            putNext(0);

            function putNext(i) {
                if (i<messages.length) {
                    var msgItem = messages[i];
                    // This msg check updated by kaal on 31stAug 2017
                    Messages.getInstance().getByMsgIdFromLDB(userId, msgItem.msgId, function(msg){
                        if(msg && msg.msgId && msg.msgId != ""){
                            putNext(i + 1);
                        } else {
                            Messages.getInstance().addByDataToLDB(userId, msgItem, function(dbResponse){
                                putNext(i + 1);
                            });
                        }
                    });
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }
        });
    },
    // bulkAddToLDB:function(userId, messages, callback){
    //     UserCipherDB.getInstance().create(userId, function(success){
    //         var objectStore = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], "readwrite")
    //                         .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
    //         putNext(0);

    //         function putNext(i) {
    //             if (i<messages.length) {
    //                 var request = objectStore.put(messages[i])
    //                 request.onsuccess = function(event) {
    //                     putNext(i+1)
    //                 };
    //             } else {   // complete
    //                 console.log('populate complete');
    //                 // Kaal commented
    //                 callback(true);
    //                 // Kaal updated
    //                 // if(messages && messages.length > 0){
    //                 //     var data = messages[0];
    //                 //     if(data && data.sessionId){
    //                 //         if(data.sessionType == CINRequestConts.SESSIONPUBLIC){
    //                 //             callback(true);
    //                 //         } else{
    //                 //             Session.getInstance().updateRecentMessageBySessionId(userId, data.sessionId, function(success){
    //                 //                 callback(true);
    //                 //             });
    //                 //         }
    //                 //     }
    //                 // }
    //             }
    //         }
    //     });
    // },
    getAllBySessionIdFromLDB:function(userId, sessionId, callback){	
        var that = this;
         UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(sessionId);
            
                var items = [];
                trans.oncomplete = function(evt) {
                    // console.log("SORTED ITEM : "+_.sortBy(items,"msgDateTime")); 
                    callback(_.sortBy(items,"msgDateTime"));
                    // callback(_.sortBy(items,"msgLocalDateTime"));
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var cvalue = cursor.value;
                        if(cvalue){
                            if(cvalue.sessionType != AppConstants.BROADCAST_MESSAGE){
                                items.push(cursor.value);
                            }
                        }
                        cursor.continue();
                    }
                };

        });	 
	},
    getAllBroadcastBySessionTypeFromLDB:function(userId, callback){	
        var that = this;
         UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_TYPE);
            
                var items = [];
                trans.oncomplete = function(evt) {
                    var sortedItems = _.sortBy(items,"msgLocalDateTime");
                    callback(sortedItems.reverse())
                };
            
                var cursorRequest = index.openCursor(AppConstants.BROADCAST_MESSAGE);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        items.push(cursor.value);
                        cursor.continue();
                    }
                };

        });	 
	},
    getDeleteStatusBySessionIdFromLDB:function(userId, sessionId, callback){	
        var that = this;
         UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(sessionId);
            
                var msgDeleteStatus = "";
                trans.oncomplete = function(evt) {
                    callback(msgDeleteStatus);
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        msgDeleteStatus = cursor.value.msgDelete;
                        cursor.continue();
                    }
                };

        });	 
	},
    getAllDeletedBySessionIdFromLDB:function(userId, sessionId, callback){	
        var that = this;
         UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(sessionId);
            
                var items = [];
                trans.oncomplete = function(evt) {
                    // console.log("SORTED ITEM : "+_.sortBy(items,"msgDateTime")); 
                    callback(_.sortBy(items,"msgDateTime"));
                    // callback(_.sortBy(items,"msgLocalDateTime"));
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        if(cursor.value.msgDelete == "1"){
                            items.push(cursor.value);
                        }
                        
                        cursor.continue();
                    }
                };

        });	 
	},
    getUnreadMessageCountBySessionIdFromLDB:function(userId, sessionId, callback){	
        var that = this;
        UserCipherDB.getInstance().create(userId, function(success){
            var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
            var objectStore = trans
                        .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GET_UNREAD_COUNT);

            var unReadMessageCount = 0;
            trans.oncomplete = function(evt) {
                callback(unReadMessageCount);
            };
            
            var cursorRequest = index.openCursor(IDBKeyRange.only([sessionId, MessageConsts.STATUS_ARRIVED, 1]));
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
                callback(0);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var msgItem = cursor.value;
                    if(msgItem.msgType != MessageConsts.TYPE_UNREAD_MESSAGE){
                        unReadMessageCount = unReadMessageCount + 1;
                    }
                    cursor.continue();
                }
            };
        });	 
    },
    getTotalMessageCountBySessionIdFromLDB:function(userId, sessionId, callback){	
        var that = this;
         UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.get(sessionId);
            
                var totalMsgCount = 0;
                trans.oncomplete = function(evt) {
                    callback(totalMsgCount);
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(0);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {

                        // Updated by Kaal
                        var msgItem = cursor.value;
                        if(msgItem.sessionId != undefined && msgItem.sessionId != null){
                            totalMsgCount = totalMsgCount + 1;
                        }
                        
                        cursor.continue();
                    }
                };

        });	 
	},
    getAllNonUploadMessagesFromLDB:function(userId, callback){	
         UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                // var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_STATUS);
                // var request = index.get(sessionId);
       
                var items = [];
                trans.oncomplete = function(evt) {  
                    callback(items);
                };
            
                var cursorRequest = objectStore.openCursor();
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback([]);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        // console.log("Un upoad messgae Id : "+cursor.value.msgId);
                        if(cursor.value.msgStatus == MessageConsts.STATUS_UNKNOWN 
                        || cursor.value.msgStatus == MessageConsts.STATUS_FAILED
                        || cursor.value.msgStatus == MessageConsts.STATUS_DRAFT
                        || cursor.value.msgStatus == MessageConsts.STATUS_SENDING){
                             items.push(cursor.value);
                        }
                        cursor.continue();
                    }
                };
            
        });	 
	},
    getByMsgIdFromLDB:function(userId, messageId, callback){	
        UserCipherDB.getInstance().create(userId, function(success){
               var trans = UserCipherDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_MESSAGES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_ID);
                var request = index.get(messageId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback({});
                }
        });	 
      
    },
    getRecentMessageForSessionId:function(userId, sessionId, callback){
     
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.get(sessionId);
            
          
                var maxDateTimeMessage = {};
                var maxDateTime = 0;
                trans.oncomplete = function(evt) {  
                   
                    callback(maxDateTimeMessage);
                  
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                 
                    callback({});
                    
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                 
                    if (cursor) {
                        if(parseInt(cursor.value.msgDateTime)>=maxDateTime){
                            maxDateTime = parseInt(cursor.value.msgDateTime);
                            maxDateTimeMessage = evt.target.result.value;
                        }
                        /*if(parseInt(cursor.value.msgLocalDateTime)>=maxDateTime){
                            maxDateTime = parseInt(cursor.value.msgLocalDateTime);
                            maxDateTimeMessage = evt.target.result.value;
                        }*/
                        
                        cursor.continue();
                    }
                };
            
         });
    },
    getBroadcastRecentMessageForSessionId:function(userId, sessionId, callback){
     
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                
                var maxDateTimeMessage = {};
                var maxDateTime = 0;
                trans.oncomplete = function(evt) {  
                   
                    callback(maxDateTimeMessage);
                  
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                 
                    callback({});
                    
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                 
                    if (cursor) {
                        var cvalue = cursor.value;
                        if(cvalue){
                            if(cvalue.sessionType == AppConstants.BROADCAST_MESSAGE){
                                if(parseInt(cursor.value.msgDateTime)>=maxDateTime){
                                    maxDateTime = parseInt(cursor.value.msgDateTime);
                                    maxDateTimeMessage = evt.target.result.value;
                                }
                                /*if(parseInt(cursor.value.msgLocalDateTime)>=maxDateTime){
                                    maxDateTime = parseInt(cursor.value.msgLocalDateTime);
                                    maxDateTimeMessage = evt.target.result.value;
                                }*/
                            }
                        }
                        
                        cursor.continue();
                    }
                };
            
         });
    },
    getChannelsRecentMessageForSessionId:function(userId, sessionId, callback){
     
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                
                var maxDateTimeMessage = {};
                var maxDateTime = 0;
                trans.oncomplete = function(evt) {  
                    callback(maxDateTimeMessage);
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                 
                    callback({});
                    
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                 
                    if (cursor) {
                        var cvalue = cursor.value;
                        if(cvalue){
                            if(cvalue.sessionType == CINRequestConts.SESSIONPUBLIC){
                                if(parseInt(cursor.value.msgDateTime)>=maxDateTime){
                                    maxDateTime = parseInt(cursor.value.msgDateTime);
                                    maxDateTimeMessage = evt.target.result.value;
                                }
                                /*if(parseInt(cursor.value.msgLocalDateTime)>=maxDateTime){
                                    maxDateTime = parseInt(cursor.value.msgLocalDateTime);
                                    maxDateTimeMessage = evt.target.result.value;
                                }*/
                            }
                        }
                        
                        cursor.continue();
                    }
                };
            
         });
    },
    getLastSequenceMessageForSessionId:function(userId, sessionId, callback){
     
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.get(sessionId);
            
          
                var lastSequenceMessage = {};
                var maxSequence = 0;
                var maxDateTime = 0;
                trans.oncomplete = function(evt) {  
                    callback(lastSequenceMessage);
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                    callback({});
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                 
                    if (cursor) {
                        var data = cursor.value;
                        // if(String(data.msgFrom) == String(sessionId)){
                        // if(data.msgDirection == 0 || data.msgDirection == "0"){
                        if(data.msgDirection == 1 || data.msgDirection == "1"){
                            /*if(parseInt(data.msgSequence) >= maxSequence){
                                maxSequence = parseInt(data.msgSequence);
                                lastSequenceMessage = data;
                            }*/
                            if(parseInt(data.msgDateTime) >= maxDateTime){
                                maxDateTime = parseInt(data.msgDateTime);
                                lastSequenceMessage = data;
                            }
                            /*if(parseInt(data.msgLocalDateTime) >= maxDateTime){
                                maxDateTime = parseInt(data.msgLocalDateTime);
                                lastSequenceMessage = data;
                            }*/
                        }
                        
                        cursor.continue();
                    }
                };
            
         });
    },
    getMessageByFileId:function(userId, fileId, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID);
                var isThumb = false;
                if(fileId.endsWith("_THUMB") == true){
                    isThumb = true;
                    index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_THUMB_ID);
                }
          
                var message = {};
                trans.oncomplete = function(evt) {  
                    // callback(message);
                };
            
                var cursorRequest = index.openCursor(fileId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                    callback({});
                    
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var value = cursor.value;
                        if(value.attachment != undefined && value.attachment != null && value.attachment != ""){
                            if(isThumb == false){
                                if(value.attachment.fileId != undefined && value.attachment.fileId != null && value.attachment.fileId != ""){
                                    if(value.attachment.fileId === fileId){
                                        message = value;
                                        callback(message);
                                    }
                                }
                            }else{
                                if(value.attachment.mThumbId != undefined && value.attachment.mThumbId != null && value.attachment.mThumbId != ""){
                                    if(value.attachment.mThumbId === fileId){
                                        message = value;
                                        callback(message);
                                    }
                                }
                            }
                        }
                        
                        // cursor.continue();
                    }
                };
            
         });
    },
    getAllMessagesByMsgTypeForSessionId:function(userId, sessionId, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
          
                var messages = [];
                trans.oncomplete = function(evt) {  
                    // callback(messages);
                    callback(_.sortBy(messages,"msgLocalDateTime"));
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                    callback({});
                    
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                 
                    if (cursor) {
                        var value = cursor.value;
                        if(value.msgType == MessageConsts.TYPE_IMAGE){
                            messages.push(value);
                        }
                        
                        cursor.continue();
                    }
                };
            
         });
    },
    getAllMediaMessageForSessionId:function(userId, sessionId, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
          
                var messages = [];
                trans.oncomplete = function(evt) {  
                    // callback(messages);
                    callback(_.sortBy(messages,"msgLocalDateTime"));
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching messages : "+error);
                    callback({});
                    
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                 
                    if (cursor) {
                        var value = cursor.value;
                        if(value.msgType == MessageConsts.TYPE_IMAGE || value.msgType == MessageConsts.TYPE_VIDEO){
                            messages.push(value);
                        } else if(value.msgType == MessageConsts.TYPE_PUBLIC_IMAGETEXT || AppMode.TYPE == AppMode.APP_TYPE_JCL){
                            messages.push(value);
                        }
                        
                        cursor.continue();
                    }
                };
            
         });
    },
    deleteAllBySessionIdFromLDB:function(userId, sessionId, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                    Session.getInstance().updateRecentMessageBySessionId("", "", userId, sessionId, function(success){
                        callback(true);
                    }); 
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
    deleteAllChannelMsgBySessionIdFromLDB:function(userId, sessionId, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                    callback(true); 
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
    deleteByMessageIdFromLDB:function(userId, messageId, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(messageId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
    deleteByMessageIdForSessionIdFromLDB:function(userId, messageId, sessionId, deleteType, callback){
        UserCipherDB.getInstance().create(userId, function(success){
                var trans = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) {  
                    console.log('Delete TYPE : ' + deleteType);
                    if (deleteType == AppConstants.BROADCAST) {
                        // || deleteType == AppConstants.CHANNELS
                        Session.getInstance().updateRecentMsgForOtherMsgBySessionId(userId, sessionId, deleteType, function(success){
                            callback(true);
                        }); 
                    } else if (deleteType == AppConstants.CHANNELS) {
                        callback(true);
                    } else {
                        Session.getInstance().updateRecentMessageBySessionId("", "", userId, sessionId, function(success){
                            callback(true);
                        }); 
                    }
                   
                };
            
                var cursorRequest = index.openCursor(messageId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
	deleteAllFromLDB:function(userId, callback){
        UserCipherDB.getInstance().create(userId, function(success){    
             //Making DELETE ALL messages request to Local DB 
            var request = UserCipherDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_MESSAGES], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_MESSAGES)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                Session.getInstance().deleteAllFromLDB(userId, function(success){
                    callback(true);
                });
                // callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
       
	},
    dynamicSort:function(property) {
        var sortOrder = 1;
        if(property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a,b) {
            var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
            return result * sortOrder;
        }
    }
	
};

Messages.getInstance = function(){
    if(!Messages.instance){
        Messages.instance = new Messages();
        // Messages.instance.listenMessages();  
    }
    
    return Messages.instance;
};


