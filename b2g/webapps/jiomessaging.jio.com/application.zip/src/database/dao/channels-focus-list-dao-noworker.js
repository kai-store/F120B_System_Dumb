function ChannelFocusListDAO () {
	this.channelId = "";
	this.serverChannelId = "";
	this.channelProfileVersion = "";
	this.channelContentVersion = "";
	this.channelGlobalId = "";
	this.serverChannelStatus = "";
    this.serverChannelCheck = "";
	this.serverChannelNeedPlayIntroVideo = "";
	this.channelGetOkResponse = "";
	this.channelUpdateLogoURL = "";
    this.channelDescription = "";
    this.channelFollowType = -1;
    this.channelIsFollowing = false;
    this.channelName = "";
    this.channelSerialNumber = "";
    this.channelCardVersion = "";
    this.channelIsReceivingMessage = "";
    this.PinToChat = "";
    this.channelPortraitId = "";
    this.channelPublicId = "";
    this.channelAttentive = "";
    this.channelOfficial = "";
    this.channelImagePath="";
    this.channelSubmenuJSON="";

    // Works for "JCL"(JioChannels)
    this.msgType = "";
    this.lastMessage = "";
    this.msgDirection = "";
    this.unreadCount = 0;
    this.msgStatus = "";
    this.msgId = "";
    this.msgDateTime = "";
    this.msgLocalDateTime = "";
    this.msgDelete = "0";
    this.sessionId = "";
    this.msgPeerName = "";
    this.sessionType = "";
}

ChannelFocusListDAO.prototype = {
	constructor:ChannelFocusListDAO,
    listenMessages:function(){
        console.log("Listen channels Started");
          
        // if( 'function' === typeof importScripts) {
          //      self.importScripts('../../utils/underscore.js');
          //      self.importScripts('../user-db.js');
          //      self.importScripts('../db-utils.js');
          //      self.importScripts('../database.js');
          //      self.importScripts('../db.consts.js');
          //      self.importScripts('../../app-const.js');
          //      self.importScripts('../../app-mode.js');
                // self.importScripts('../dao/group-mapping-dao.js');
                // self.importScripts('../dao/group-dao.js');
                // self.importScripts('../dao/contact-dao.js');
          //      self.importScripts('../dao/session-dao.js');
                // self.importScripts('../dao/channels-list-dao.js');
          //      self.importScripts('../../cin/CinBase64.js');
          //      self.importScripts('../../cin/cin.request.conts.js');
          //      self.importScripts('../../cin/message/message.const.js');
          //      self.importScripts('../dao/messages-dao-2.0.js');
          //      self.importScripts('../user-cipher-db.js');
        //    }

        self.onmessage = function(event) {
           if(event.data.length == 0) return;
           
           
           var funcName = event.data.functionName;
           var userId = event.data.userId;
        //    console.log("param1: "+funcName+">>>>>>>> param2: "+userId);   
           switch(funcName) {
                case "bulkAddOfFocusChannelToLDB":
                    var data = event.data.data;
                    ChannelFocusListDAO.getInstance().bulkAddOfFocusChannelToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData);
                    });
                    break;
                case "updateFocusChannelByDataToLDB":
                    var data = event.data.data;
                    ChannelFocusListDAO.getInstance().updateFocusChannelByDataToLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateSessionDataByChannelIdToLDB":
                    var data = event.data.data;
                    var unreadCount = event.data.unreadCount;
                    ChannelFocusListDAO.getInstance().updateSessionDataByChannelIdToLDB(userId, unreadCount, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "updateRecentMessageBySessionId":
                    var data = event.data.data;
                    var sessionId = event.data.sessionId;
                    ChannelFocusListDAO.getInstance().updateRecentMessageBySessionId(userId, sessionId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getAllFocusChannelsFromLDB":
                    ChannelFocusListDAO.getInstance().getAllFocusChannelsFromLDB(userId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "getByFocusIdFromLDB":
                    var channelId = event.data.channelId;
                    ChannelFocusListDAO.getInstance().getByFocusIdFromLDB(userId, channelId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                case "bulkUpdateToFocusLDB":
                    var data = event.data.data;
                    ChannelFocusListDAO.getInstance().bulkUpdateToFocusLDB(userId, data, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                     case "deleteFocusChannelById":
                    var channelId = event.data.channelId;
                    ChannelFocusListDAO.getInstance().deleteFocusChannelById(userId, channelId, function(success){
                        var responseData = {
                            result:success,
                            callId:event.data.callId
                        }
                        self.postMessage(responseData)
                    });
                    break;
                default:
                    console.log("Nothing to do with messages dao for :"+funcName);
            }
           
        };
    },
    
    bulkAddOfFocusChannelToLDB:function(userId, channels, callback){
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
            putNext(0);

            function putNext(i) {
                if (i<channels.length) {
                    var request = objectStore.put(channels[i]);
                    request.onsuccess = function(event) {
                        putNext(i+1)
                    };
                    request.onerror=function(err){
                        console.log("Error while bulkadd focus channel");
                        callback(false);
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    updateFocusChannelByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                // if(!success){
                //     callback(true);
                //     return;
                // }
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
            
                // trans.oncomplete = function(evt) {  
                //     callback(true);
                // };
            
                var cursorRequest = index.openCursor(data.channelId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.serverChannelId != undefined && data.serverChannelId != null){
                             updateData.serverChannelId = data.serverChannelId;
                         }
                         if(data.channelProfileVersion != undefined && data.channelProfileVersion != null){
                             updateData.channelProfileVersion = data.channelProfileVersion;
                         }
                         if(data.channelContentVersion != undefined && data.channelContentVersion != null){
                             updateData.channelContentVersion = data.channelContentVersion;
                         }
                         if(data.channelGlobalId != undefined && data.channelGlobalId != null){
                             updateData.channelGlobalId = data.channelGlobalId;
                         }
                         if(data.serverChannelStatus != undefined && data.serverChannelStatus != null){
                             updateData.serverChannelStatus = data.serverChannelStatus;
                         }
                         if(data.serverChannelCheck != undefined && data.serverChannelCheck != null){
                             updateData.serverChannelCheck = data.serverChannelCheck;
                         }
                         if(data.serverChannelNeedPlayIntroVideo != undefined && data.serverChannelNeedPlayIntroVideo != null){
                             updateData.serverChannelNeedPlayIntroVideo = data.serverChannelNeedPlayIntroVideo;
                         }
                         if(data.channelGetOkResponse != undefined && data.channelGetOkResponse != null){
                             updateData.channelGetOkResponse = data.channelGetOkResponse;
                         }
                         if(data.channelUpdateLogoURL != undefined && data.channelUpdateLogoURL != null){
                             updateData.channelUpdateLogoURL = data.channelUpdateLogoURL;
                         }
                         if(data.channelFollowType != undefined && data.channelFollowType != null){
                             updateData.channelFollowType = data.channelFollowType;
                         } 
                         if(data.channelIsFollowing != undefined && data.channelIsFollowing != null){
                             updateData.channelIsFollowing = data.channelIsFollowing;
                         }
                         if(data.channelName && data.channelName != ""){
                             updateData.channelName = data.channelName;
                         }
                         if(data.channelSerialNumber != undefined && data.channelSerialNumber != null){
                             updateData.channelSerialNumber = data.channelSerialNumber;
                         }
                         if(data.channelCardVersion != undefined && data.channelCardVersion != null){
                             updateData.channelCardVersion = data.channelCardVersion;
                         }
                         if(data.channelIsReceivingMessage != undefined && data.channelIsReceivingMessage != null){
                             updateData.channelIsReceivingMessage = data.channelIsReceivingMessage;
                         }
                         if(data.PinToChat != undefined && data.PinToChat != null && data.PinToChat != -1){
                             updateData.PinToChat = data.PinToChat;
                         }
                         if(data.channelPortraitId != undefined && data.channelPortraitId != null){
                             updateData.channelPortraitId = data.channelPortraitId;
                         }
                         if(data.channelPublicId != undefined && data.channelPublicId != null){
                             updateData.channelPublicId = data.channelPublicId;
                         }
                         if(data.channelAttentive != undefined && data.channelAttentive != null){
                             updateData.channelAttentive = data.channelAttentive;
                         }
                         if(data.channelOfficial != undefined && data.channelOfficial != null){
                             updateData.channelOfficial = data.channelOfficial;
                         }
                         if(data.channelImagePath != undefined && data.channelImagePath != null){
                             updateData.channelImagePath = data.channelImagePath;
                         }
                          if(data.channelDescription != undefined && data.channelDescription != null){
                             updateData.channelDescription = data.channelDescription;
                         }

                         if(data.channelSubmenuJSON != undefined && data.channelSubmenuJSON != null){
                             updateData.channelSubmenuJSON = data.channelSubmenuJSON;
                         }

                         if(data.unreadCount !=="" && data.unreadCount >= 0 ){
                             updateData.unreadCount = data.unreadCount;
                         }               
                         
         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                                callback(true);
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        // cursor.continue();
                    }
                };
        });	 
    },
    
    updateSessionDataByChannelIdToLDB:function(userId, unreadCount, data, callback){
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);

                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if(!cursor){
                        var sdata = {
                            sessionId : data.sessionId,
                            sessionType : CINRequestConts.SESSIONPUBLIC,
                            channelName : data.msgPeerName,
                            isDelete : "0",
                            lastMessage : data.lastMessage,
                            msgDateTime : data.msgDateTime,
                            msgLocalDateTime: data.msgLocalDateTime,
                            // sessionImageData : data.thumbObj,
                            msgType : data.msgType,
                            unreadCount: 0,
                            msgStatus: data.msgStatus,
                            msgDirection: data.msgDirection,
                        }

                        if(data.msgDirection == 1 && data.msgStatus == MessageConsts.STATUS_ARRIVED){
                            sdata.unreadCount = unreadCount;
                        }
                        
                    }
                    else if (cursor) {
                        var updateData = cursor.value;

                        // Works for JCL
                        if(data.sessionId && data.sessionId != ""){
                            updateData.sessionId = data.sessionId;
                        }

                        if(data.sessionType && data.sessionType != ""){
                            updateData.sessionType = data.sessionType;
                        }
                        
                        if((data.msgType && data.msgType != "") || data.msgType === 0 ){
                            updateData.msgType = data.msgType;
                        }

                        // Kaal updated - Updating the last message based on the msgDateTime
                        if(updateData.msgDateTime < data.msgDateTime){
                            if(data.msgContent && data.msgContent != ""){
                                updateData.lastMessage = data.msgContent;
                            }

                            if(data.msgType == MessageConsts.TYPE_PUBLIC_IMAGETEXT){
                                if(data.attachment && data.attachment[0].title && data.attachment[0].title != ""){
                                    updateData.lastMessage = data.attachment[0].title;
                                }
                            }
                        } else {
                            if(data.msgContent && data.msgContent != "" && updateData.msgContent && updateData.msgContent == ""){
                                updateData.lastMessage = data.msgContent;
                            }
                        }

                        if(data.msgContent == ""){
                            updateData.lastMessage = updateData.channelDescription;
                        }

                        if(data.msgDirection && data.msgDirection != ""){
                            updateData.msgDirection = data.msgDirection;
                        }

                        // var count = updateData.unreadCount;
                        //  if(!count || count == ""){
                        //     count = 0;  
                        //  }
                        //  if(data.msgDirection == 1 && data.msgStatus == MessageConsts.STATUS_ARRIVED){
                        //     count = parseInt(count) + unreadCount;
                        //  }

                        // if(count >= 0){
                        //      updateData.unreadCount = count;
                        //  }

                        if(data.msgStatus && data.msgStatus != ""){
                            updateData.msgStatus = data.msgStatus;
                        }

                        if(data.msgId && data.msgId != ""){
                            updateData.msgId = data.msgId;
                        }

                        if(data.msgDateTime && data.msgDateTime != ""){
                            updateData.msgDateTime = data.msgDateTime;
                        }

                        if(data.msgLocalDateTime && data.msgLocalDateTime != ""){
                            updateData.msgLocalDateTime = data.msgLocalDateTime;
                        }

                        // if(data.msgDelete && data.msgDelete != ""){
                        //     updateData.msgDelete = data.msgDelete;
                        // }

                        if(data.msgPeerName && data.msgPeerName != ""){
                            updateData.channelName = data.msgPeerName;
                        }
         
                        var res = cursor.update(updateData);
                        res.onsuccess = function(e){
                            console.log("update success!!");
                            callback(true);
                        }
                        res.onerror = function(e){
                            console.log("update failed!!");
                            callback(false);
                        }
                    }
                };
        });	 
	},
   
    getAllFocusChannelsFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
            // if(!success){
            //     callback([]);
            //     return;
            // }
            console.log("instance "+ UserDB.getInstance());
            console.log("database "+ UserDB.getInstance().database);
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST, "readwrite");
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
            console.log("store"+store);
            console.log("transaction"+trans);
            var items = [];

            trans.oncomplete = function(evt) {  
                if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
                    var sortedData = _.sortBy(items,"msgDateTime").reverse();
                    callback(sortedData);
                }else{
                    callback(items);
                }
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching channels : "+error);
                 callback([]);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor && cursor.value) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
	},
    
    getByFocusIdFromLDB:function(userId, channelId, callback){  
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST , IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
                var request = index.get(channelId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
    bulkUpdateToFocusLDB:function(userId, portraitData, callback){
        UserDB.getInstance().create(userId, function(success){
            putNext(0);

            function putNext(i) {
                if (i<portraitData.length) {
                    var pData = portraitData[i];
                    if(pData && pData.channelId){
                        ChannelFocusListDAO.getInstance().updateFocusChannelByDataToLDB(userId, pData, function(sucess){
                            putNext(i+1)
                        });
                    }
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    deleteFocusChannelById:function(userId, channelId, callback){
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
               
                trans.oncomplete = function(evt) {  
                    // callback(true);
                };
            
                var cursorRequest = index.openCursor(channelId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching focus channel: "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        if(cursor.value.channelId == channelId){
                            var request = cursor.delete();
                            request.onsuccess = function() {
                                console.log('Deleted focus channel');
                                callback(true);
                            };
                            request.onerror = function(error) {
                                console.log('Delete focus channel Failed');
                                callback(false);
                            };
                        }
                       
                        cursor.continue();
                    }
                };
        });
	},
   
	deleteAllFocusFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_LIST], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
    },

    updateRecentMessageBySessionId:function(userId, sessionId, callback){
        Messages.getInstance().getRecentMessageForSessionId(userId, sessionId, function(msg){
            console.log("Received MEssages : "+msg.msgId);
            if(msg.msgId == undefined || msg.msgId == null){
                // console.log("DELETE SESSION : "+msg.msgId);
                msg.channelId = String(sessionId);
                msg.sessionId = String(sessionId);
                msg.msgType=-1;
                msg.msgContent = "";
                ChannelFocusListDAO.getInstance().updateSessionDataByChannelIdToLDB(userId, 0, msg, function(success){
                    callback(true)
                });
            }else{
                msg.channelId = msg.sessionId;
                msg.sessionId = String(msg.sessionId);
                ChannelFocusListDAO.getInstance().updateSessionDataByChannelIdToLDB(userId, 0, msg, function(success){
                    callback(true)
                });
            }
        });
    },

    updateRecentMsgBySessionId:function(userId, sessionId, msg, callback){
        console.log("Received MEssages : "+msg.msgId);
        if(msg.msgId == undefined || msg.msgId == null){
            // console.log("DELETE SESSION : "+msg.msgId);
            msg.channelId = String(sessionId);
            msg.sessionId = String(sessionId);
            msg.msgType=-1;
            msg.msgContent = "";
            ChannelFocusListDAO.getInstance().updateSessionDataByChannelIdToLDB(userId, 0, msg, function(success){
                callback(true);
            });
        }else{
            msg.channelId = msg.sessionId;
            msg.sessionId = String(msg.sessionId);
            ChannelFocusListDAO.getInstance().updateSessionDataByChannelIdToLDB(userId, 0, msg, function(success){
                callback(true);
            });
        }
    },
   
	
};

ChannelFocusListDAO.getInstance= function(){
    if(!ChannelFocusListDAO.instance){
        ChannelFocusListDAO.instance = new ChannelFocusListDAO();
        ChannelFocusListDAO.instance.listenMessages(); 
    }
    return ChannelFocusListDAO.instance;
};
ChannelFocusListDAO.getInstance();
