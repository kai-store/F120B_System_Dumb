function DevicesDAO () {
	this.deviceId = "";
	this.deviceAuth = "";
	this.devicePrivateString = "";
	this.deviceEndPoint = "";
}

DevicesDAO.prototype = {
	constructor:DevicesDAO,
  
    addToLDB:function(callback){
        //Arranging Device Data to be inserted
	    var data = {
            deviceId : this.deviceId,
            deviceAuth : this.deviceAuth,
            devicePrivateString : this.devicePrivateString,
            deviceEndPoint : deviceEndPoint

        } 
        
         CommonDB.getInstance().create(function(success){       
            //Making INSERT device request to Local DB
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_DEVICES], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    addByDataToLDB:function(data, callback){
         CommonDB.getInstance().create(function(success){
                 
            //Making INSERT device request to Local DB
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_DEVICES], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(data, callback){
        
         CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_DEVICES, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_DEVICE_ID);
             
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.deviceId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.devicePrivateString != undefined && data.devicePrivateString != null){
                             updateData.devicePrivateString = data.devicePrivateString;
                         }
                         if(data.deviceAuth != undefined && data.deviceAuth != null){
                             updateData.deviceAuth = data.deviceAuth;
                         }
                         if(data.deviceEndPoint != undefined && data.deviceEndPoint != null){
                             updateData.deviceEndPoint = data.deviceEndPoint;
                         }
    
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(callback){
         CommonDB.getInstance().create(function(success){
                //Making SELECT ALL devices request to Local DB 
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_DEVICES], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
   
    // getByDeviceIdFromLDB:function(userId, callback){  
    //      CommonDB.getInstance().create(function(success){
    //             var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_DEVICES, IDBTransaction.READ_ONLY);
    //             var objectStore = trans
    //                         .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES);
    //             var index = objectStore.index("userId");
    //             var request = index.get(userId);
                
    //             //Handler for success operation
    //             request.onsuccess = function(event) {
    //                 callback(event.target.result);            
    //             };

    //             //Handler for success operation
    //             request.onerror = function(event) {
    //                 callback([]);
    //             }
    //     }); 
    // },
    getByDeviceIdFromLDB:function(deviceId, callback){  
         CommonDB.getInstance().create(function(success){
                var trans = CommonDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_DEVICES, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_DEVICE_ID);
                var request = index.get(deviceId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
    
	deleteAllFromLDB:function(callback){
        CommonDB.getInstance().create(function(success){
            //Making DELETE ALL devices request to Local DB 
            var request = CommonDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_DEVICES], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_DEVICES)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	}
   
	
};

DevicesDAO.getInstance= function(){
    if(!DevicesDAO.instance){
        DevicesDAO.instance = new DevicesDAO();
    }
    return DevicesDAO.instance;
};
