function ChannelContentPageDAO () {
    this.channelId = "";
	this.channelPageId = "";
	this.channelPageLocalIndex = "";
	this.channelContentInfoId = "";
	this.channelContentColumnIndex = "";
	this.channelContentType = "";
	this.channelVideoId = "";
    this.channelResourceURI = "";
    this.channelMediaHTML = "";
	this.channelMediaVideo = "";
    this.channelMediaStream = "";
    this.channelContentColumnTitle = "";
}


ChannelContentPageDAO.prototype = {
	constructor:ChannelContentPageDAO,
  
    addToLDB:function(userId, callback){
        //Arranging Emoticon Data to be inserted
	    var data = {
            channelId : this.channelId,
            channelPageId : this.channelPageId,
            channelPageLocalIndex : this.channelPageLocalIndex,
            channelContentInfoId : this.channelContentInfoId,
            channelContentColumnIndex : this.channelContentColumnIndex,
            channelContentType : this.channelContentType,
            channelVideoId : this.channelVideoId,
            channelResourceURI : this.channelResourceURI,
            channelMediaHTML : this.channelMediaHTML,
            channelMediaVideo : this.channelMediaVideo,
            channelMediaStream : this.channelMediaStream,
            channelContentColumnTitle :this.channelContentColumnTitle
        } 
        
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
	},
    addByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                 
            //Making INSERT contact request to Local DB
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    bulkAddToLDB:function(userId, contents, callback){
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE);
            putNext(0);

            function putNext(i) {
                if (i<contents.length) {
                    var request = objectStore.put(contents[i])
                    request.onsuccess = function(event) {
                        putNext(i+1)
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    updateByDataToLDB:function(userId, data, callback){
        
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE);
                var index = objectStore.index(DatabaseConstants.CHANNEL_PAGE_ID);
               
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.channelPageId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.channelPageId != undefined && data.channelPageId != null){
                             updateData.channelPageId = data.channelPageId;
                         }
                         if(data.channelPageLocalIndex != undefined && data.channelPageLocalIndex != null){
                             updateData.channelPageLocalIndex = data.channelPageLocalIndex;
                         }
                         if(data.channelContentInfoId != undefined && data.channelContentInfoId != null){
                             updateData.channelContentInfoId = data.channelContentInfoId;
                         }
                         if(data.channelContentColumnIndex != undefined && data.channelContentColumnIndex != null){
                             updateData.channelContentColumnIndex = data.channelContentColumnIndex;
                         }
                         if(data.channelContentType != undefined && data.channelContentType != null){
                             updateData.channelContentType = data.channelContentType;
                         }
                         if(data.channelVideoId != undefined && data.channelVideoId != null){
                             updateData.channelVideoId = data.channelVideoId;
                         }
                         if(data.channelResourceURI != undefined && data.channelResourceURI != null){
                             updateData.channelResourceURI = data.channelResourceURI;
                         }
         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    
    getByChannelPageIdFromLDB:function(userId, channelId, callback){ 
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE);
                var index = objectStore.index(DatabaseConstants.CHANNEL_ID);
               var items = [];
                trans.oncomplete = function(evt) {  
                    callback(items);
                };
            
                var cursorRequest = index.openCursor(channelId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback([]);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        items.push(cursor.value)
                        cursor.continue();
                    }
                };
        });	  
     
    },
   
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	}
   
	
};

ChannelContentPageDAO.getInstance= function(){
    if(!ChannelContentPageDAO.instance){
        ChannelContentPageDAO.instance = new ChannelContentPageDAO();
    }
    return ChannelContentPageDAO.instance;
};
