function RecentCallDAO () {
	this.callerId = "";
	this.userName = "";
	this.userImage = "";
	this.callTime = "";
    this.dateTime = 0;
    this.callType = "";
    this.colorCode = "";
    this.callLogId = "";
    this.peerNumber = "";
}

RecentCallDAO.prototype = {
	constructor:RecentCallDAO,
  
    addToLDB:function(userId, callback){
        // debugger;
        //Arranging Emoticon Data to be inserted
      
	    var data = {
            callerId : this.callerId,
            userName : this.userName,
            userImage : this.userImage,
            callTime : this.callTime,
            dateTime : this.dateTime,
            callType : this.callType,
            colorCode : this.colorCode,
            callLogId : this.callLogId,
            peerNumber : this.peerNumber
        } 

        RecentCallDAO.getInstance().removeLastRecord(userId,function(success){
            UserDB.getInstance().create(userId, function(success){
                //Making INSERT contact request to Local DB 
                    var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL], "readwrite")
                                .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL)
                                .put(data);

                    //Handler for success operation            
                    request.onsuccess = function(event) {
                        callback(true)
                    };

                    //Handler for failure operation                   
                    request.onerror = function(event) {
                        callback(false)
                    }   
            });
        });
	},
    removeLastRecord:function(userId,callback){
        var callLogId;
        RecentCallDAO.getInstance().getAllFromLDB(userId,function(data){
            if(data.length === 30){
                callLogId = data[29].callLogId;
                RecentCallDAO.getInstance().deleteByLogIdFromLDB(userId,callLogId,function(flagData){
                    if(flagData){
                         callback(true);
                    }

                })
            }else {
                callback(true);
            }
        });
    },
    getRecentLogByIdFromLDB:function(userId, callerId, callback){	
        //  debugger;
        UserDB.getInstance().create(userId, function(success){
             var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL);
                var index = objectStore.index(DatabaseConstants.RECENT_CALL_ID);
                var request = index.get(callerId);
                console.log('CONTACT USER ID :' +callerId);
                //Handler for success operation
                request.onsuccess = function(event) {
                    if(event.target.result !== undefined && event.target.result !== null){
                         callback(event.target.result); 

                    }  else{
                        callback({});
                    }             

                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback({});
                }
        });
    },
    addByDataLDB:function(userId, data, callback){
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL)
                            .add(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
    },
    updateByDataToLDB:function(userId, data, callback){

         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL);
                var index = objectStore.index(DatabaseConstants.RECENT_CALL_ID);
                // var request = index.get(data.mobileNumber);
            
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.callerId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching call records : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor && cursor != null) {
                         var updateData = cursor.value;
                         if(data.userName != undefined && data.userName != null){
                             updateData.userName = data.userName;
                         }
                         if(data.userImage != undefined && data.userImage != null){
                             updateData.userImage = data.userImage;
                         }
                         if(data.callTime != undefined && data.callTime != null){
                             updateData.callTime = data.callTime;
                         }
                         if(data.callType != undefined && data.callType != null){
                             updateData.callType = data.callType;
                         }
                         if(data.dateTime != undefined && data.dateTime != null){
                             updateData.dateTime = data.dateTime;
                         }
                         if(data.peerNumber != undefined && data.peerNumber != null){
                             updateData.peerNumber = data.peerNumber;
                         }
                        
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    } 
                };
        });	 
    },
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                var sortedItems = _.sortBy(event.target.result,DatabaseConstants.RECENT_CALL_DATE_TIME);
                callback(sortedItems.reverse());            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    deleteByLogIdFromLDB:function(userId, callLogId, callback){
        // debugger;
        UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL);
                var index = objectStore.index(DatabaseConstants.RECENT_CALL_LOG_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(callLogId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
    deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){    
             //Making DELETE ALL messages request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
        
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            }  
        });
       
	}
	
};

RecentCallDAO.getInstance= function(){
    if(!RecentCallDAO.instance){
        RecentCallDAO.instance = new RecentCallDAO();
    }
    return RecentCallDAO.instance;
};
