function GroupMember() {
	this.userId = "";
	this.userName = "";
	this.phoneBookName = "";
	this.mobileNumber = "";
}

GroupMember.getInstance= function(){
    return new GroupMember();
};
