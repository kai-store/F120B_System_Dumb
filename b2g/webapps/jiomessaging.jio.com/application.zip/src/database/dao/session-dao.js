function Session() {
	this.sessionId = "";
	this.peerId = "";
	this.mobileNumber = "";
	this.sessionType = "";
	this.name = "";
	this.userIds = "";
	this.isTop = "";
	this.isShow = "";
	this.isDelete = "";
	this.maxVersion = "";
	this.lastMessage = "";
	this.draftMessage = "";
    this.msgDateTime = "";
    this.msgLocalDateTime = "";
    this.sessionImageData = "";
    this.msgType = "";
    this.lastReadSeq = "0";
    this.unreadCount = 0;
    this.msgStatus = "";
    this.msgDirection = "";
    this.followType = -1;
    this.pinToChat = "";
    this.pinToTop = -1;
    this.callMode = "";
    this.channelIsFollowing=false;
}

Session.prototype = {
	constructor: Session,
  
    addToLDB:function(userId, data, callback){
        //Arranging Session Data to be inserted
	    // var data = {
        //     sessionId : this.sessionId,
        //     peerId : this.peerId,
        //     mobileNumber : this.mobileNumber,
        //     sessionType : this.sessionType,
        //     name : this.name,
        //     userIds : this.userIds,
        //     isTop : this.isTop,
        //     isShow : this.isShow,
        //     isDelete : this.isDelete,
        //     maxVersion : this.maxVersion,
        //     lastMessage : this.lastMessage,
        //     draftMessage : this.draftMessage,
        //     msgDateTime : this.msgDateTime,
        //     msgLocalDateTime: this.msgLocalDateTime,
        //     sessionImageData : imageData,
        //     isRead : this.isRead,
        //     msgType : this.msgType,
        //     lastReadSeq: this.lastReadSeq,
        //     unreadCount: this.unreadCount,
        //     msgStatus: this.msgStatus,
        //     msgDirection: this.msgDirection,
        //     pinToTop: this.pinToTop
        // }

        UserDB.getInstance().create(userId, function(success){
            console.log("Insert Active User : "+UserDB.getInstance().database);
                //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SESSION], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    addByMessageToLDB:function(name, thumbObj, userId, message, callback){
      var peerId = message.msgFrom;
      if(peerId == userId){
          peerId = message.msgTo;
      }
      if(message.sessionType == CINRequestConts.SESSIONGROUP){
          peerId = message.msgTo;
      }
       if (message.sessionType == CINRequestConts.SESSIONSINGLE || message.sessionType == AppConstants.BROADCAST_MESSAGE) {
                Contact.getInstance().getByContactUserIdFromLDB(userId, peerId ,function(contact){
                    var contactName = message.mobileNumber;
                    var contactImageData = ""; 
                    if(contact != undefined && contact != null){
                        if(contact.phoneBookName && contact.phoneBookName != ""){
                            contactName = contact.phoneBookName;
                        }else if(contact.rcsName && contact.rcsName != ""){
                            contactName = contact.rcsName;
                        }

                        if(contact.rcsAvatar && contact.rcsAvatar != ""){
                            contactImageData = contact.rcsAvatar;
                        }else{
                            contactImageData = contact.phoneBookData;
                        }
                    }
                    // if(message.name && message.name != ""){
                    //     contactName = message.name;
                    // }
                    if(message.sessionType == AppConstants.BROADCAST_MESSAGE){
                        message.sessionId = AppConstants.BROADCAST;
                        peerId = message.sessionId;
                    }

                    Session.getInstance().getSessionBySessionIdFromLDB(userId, peerId, function(sessionData){
                        if(sessionData){
                            if(sessionData.sessionId != undefined && sessionData.sessionId != null){
                                // Update to LDB

                                var constructedData = {
                                    sessionId : message.sessionId,
                                    peerId : message.sessionId,
                                    sessionType : message.sessionType,
                                    // isDelete : message.msgDelete,
                                    isDelete : "0",
                                    msgContent : message.msgContent,
                                    // draftMessage : message.msgContent,
                                    msgDateTime : message.msgDateTime,
                                    msgLocalDateTime : message.msgLocalDateTime,
                                    isRead : 0,
                                    msgType : message.msgType,
                                    unreadCount: sessionData.unreadCount,
                                    msgStatus: message.msgStatus,
                                    msgDirection: message.msgDirection,
                                    callMode: message.callMode
                                }
                                
                                if(contactName && contactName != ""){
                                    constructedData.name = contactName;
                                }
                                if(contactImageData && contactImageData != ""){
                                    constructedData.sessionImageData = contactImageData;
                                }
                                Session.getInstance().updateByMessage(userId, constructedData, callback);
                            }else{
                                Session.getInstance().addByMessageAndName(userId, message, contactName, contactImageData, callback);
                            }
                        }
                        else{
                            Session.getInstance().addByMessageAndName(userId, message, contactName, contactImageData, callback);
                        }
                    });

            });
        }else if (message.sessionType == CINRequestConts.SESSIONGROUP){
            Group.getInstance().getByGroupIdFromLDB(userId, peerId ,function(group){
                    var groupName = "";
                    var groupImageData = ""; 
                    if(group != undefined && group != null){
                        if(group.groupName && group.groupName != ""){
                            groupName = group.groupName;
                        }
                        if(group.groupImageData && group.groupImageData != ""){
                            groupImageData = group.groupImageData;
                        }
                        if(group.groupThumb && group.groupThumb != ""){
                            groupImageData = group.groupThumb;
                        }
                    }

                    if(name && name != "" && (!groupName || groupName == "")){
                        groupName = name;
                    }

                    // if(message.name && message.name != ""){
                    //     groupName = message.name;
                    // }

                    Session.getInstance().getSessionBySessionIdFromLDB(userId, peerId, function(sessionData){
                        if(sessionData){
                            if(sessionData.sessionId != undefined && sessionData.sessionId != null){
                                // Update to LDB

                                var constructedData = {
                                    sessionId : message.sessionId,
                                    peerId : message.sessionId,
                                    sessionType : message.sessionType,
                                    isDelete : "0",
                                    msgContent : message.msgContent,
                                    msgDateTime : message.msgDateTime,
                                    msgLocalDateTime : message.msgLocalDateTime,
                                    isRead : 0,
                                    msgType : message.msgType,
                                    unreadCount: sessionData.unreadCount,
                                    msgStatus: message.msgStatus,
                                    msgDirection: message.msgDirection,
                                    callMode: message.callMode
                                }
                                if(groupName && groupName != ""){
                                    constructedData.name = groupName;
                                }
                                if(groupImageData && groupImageData != ""){
                                    constructedData.sessionImageData = groupImageData;
                                }

                                Session.getInstance().updateByMessage(userId, constructedData, callback);
                            }else{
                                Session.getInstance().addByMessageAndName(userId, message, groupName, groupImageData, callback)
                            }
                        }
                        else{
                            Session.getInstance().addByMessageAndName(userId, message, groupName, groupImageData, callback)
                        }
                    });

                /*Session.getInstance().addByMessageAndName(userId, message, groupName, groupImageData, callback);*/

            });
            // Group.getInstance().getByGroupIdFromLDB(userId, peerId, function(response){
			// 	if(response.groupName !== undefined && response.groupName != null){
			// 		phoneBookName = response.groupName;
			// 	}
			// 	that.setState({title: phoneBookName});
			// });
            //  Session.getInstance().addByMessageAndName(userId, message, "", callback);
            
        } else if(message.sessionType == CINRequestConts.SESSIONPUBLIC){
            // CHANNELS
            // ChannelListDAOWorker.getInstance().getByChannelIdFromLDB(userId, peerId ,function(channelData){
                //ChannelFocusListDAO ChannelsFocusDAOWorker
            ChannelsFocusDAOWorker.getInstance().getByFocusIdFromLDB(userId, peerId ,function(channelData){
                    var channelName = "";
                    var pinToChat;
                    var followType;
                    var channelIsFollowing;
                    if(channelData){
                        channelName = channelData.channelName;
                        if(!channelName && channelName == ""){
                            channelName = message.msgPeerName;
                        }
                        pinToChat = channelData.PinToChat;
                        followType = channelData.channelFollowType;
                        channelIsFollowing = channelData.channelIsFollowing;
                    }
                    // if(message.name && message.name != ""){
                    //     channelName = message.name;
                    // }

                    if(name && name != "" && (!channelName || channelName == "")){
                        channelName = name;
                    }

                    var channelImageData = "";
                    
                    // message.sessionId = "channels";

                    Session.getInstance().getSessionBySessionIdFromLDB(userId, peerId, function(sessionData){
                        if(sessionData){
                            if(sessionData.sessionId != undefined && sessionData.sessionId != null){
                                // Update to LDB

                                var constructedData = {
                                    sessionId : message.sessionId,
                                    peerId : message.sessionId,
                                    sessionType : CINRequestConts.SESSIONPUBLIC,
                                    isDelete : "0",
                                    msgContent : message.msgContent,
                                    msgDateTime : message.msgDateTime,
                                    msgLocalDateTime : message.msgLocalDateTime,
                                    isRead : 0,
                                    msgType : message.msgType,
                                    unreadCount: sessionData.unreadCount,
                                    msgStatus: message.msgStatus,
                                    msgDirection: message.msgDirection,
                                    pinToChat: pinToChat,
                                    followType: followType,
                                    channelIsFollowing: channelIsFollowing
                                }
                                
                                if(channelName && channelName != ""){
                                    constructedData.name = channelName;
                                }
                                if(channelImageData && channelImageData != ""){
                                    constructedData.sessionImageData = channelImageData;
                                }
                                Session.getInstance().updateByMessage(userId, constructedData, callback);

                                // Make other entry with session id is channels
                                var cData = {
                                    sessionId : AppConstants.CHANNELS,
                                    peerId : AppConstants.CHANNELS,
                                    sessionType : CINRequestConts.SESSIONPUBLIC,
                                    isDelete : "0",
                                    msgContent : message.msgContent,
                                    msgDateTime : message.msgDateTime,
                                    msgLocalDateTime : message.msgLocalDateTime,
                                    isRead : 0,
                                    msgType : message.msgType,
                                    unreadCount: sessionData.unreadCount,
                                    msgStatus: message.msgStatus,
                                    msgDirection: message.msgDirection
                                }
                                
                                cData.name = "Channels";
                                if(channelImageData && channelImageData != ""){
                                    cData.sessionImageData = channelImageData;
                                }
                                Session.getInstance().updateByMessage(userId, cData, callback);




                            }else{
                                Session.getInstance().addByMessageAndName(userId, message, channelName, channelImageData, callback);

                                // Make other entry with session id is channels
                                var newMessage = {
                                    sessionId : AppConstants.CHANNELS,
                                    peerId : AppConstants.CHANNELS,
                                    sessionType : CINRequestConts.SESSIONPUBLIC,
                                    msgDelete : message.msgDelete,
                                    msgContent : message.msgContent,
                                    msgContent : message.msgContent,
                                    msgDateTime : message.msgDateTime,
                                    msgLocalDateTime : message.msgLocalDateTime,
                                    msgType : message.msgType,
                                    msgStatus: message.msgStatus,
                                    msgDirection: message.msgDirection,
                                    pinToChat: pinToChat,
                                    followType: followType,
                                    channelIsFollowing:channelIsFollowing
                                }


                                Session.getInstance().addByMessageAndName(userId, newMessage, "Channels", channelImageData, callback);
                            }
                        }
                        else{
                            Session.getInstance().addByMessageAndName(userId, message, channelName, channelImageData, callback);

                            // Make other entry with session id is channels
                            var newMessage = {
                                sessionId : AppConstants.CHANNELS,
                                peerId : AppConstants.CHANNELS,
                                sessionType : CINRequestConts.SESSIONPUBLIC,
                                msgDelete : message.msgDelete,
                                msgContent : message.msgContent,
                                msgContent : message.msgContent,
                                msgDateTime : message.msgDateTime,
                                msgLocalDateTime : message.msgLocalDateTime,
                                msgType : message.msgType,
                                msgStatus: message.msgStatus,
                                msgDirection: message.msgDirection,
                                pinToChat: pinToChat,
                                followType: followType,
                                channelIsFollowing: channelIsFollowing
                            }
                            Session.getInstance().addByMessageAndName(userId, newMessage, "Channels", channelImageData, callback);
                        }
                    });

            });

        }
  
	},
    addByMessageAndName: function(userId, message, name, imageData, callback){
         //Arranging Session Data to be inserted
	    var data = {
            sessionId : message.sessionId,
            peerId : message.sessionId,
            mobileNumber : "",
            sessionType : message.sessionType,
            name : name,
            userIds : "",
            isTop : "",
            isShow : "",
            isDelete : message.msgDelete,
            maxVersion : "",
            lastMessage : message.msgContent,
            // draftMessage : message.msgContent,
            draftMessage : "",
            msgDateTime : message.msgDateTime,
            msgLocalDateTime : message.msgLocalDateTime,
            sessionImageData : imageData,
            isRead : 0,
            msgType : message.msgType,
            msgStatus : message.msgStatus,
            msgDirection: message.msgDirection,
            pinToChat: message.pinToChat,
            pinToTop: -1,
            callMode: message.callMode
        }

        UserDB.getInstance().create(userId, function(success){
            console.log("Insert Active User : "+UserDB.getInstance().database);
                //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SESSION], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
    },
    updateByMessage: function(userId, data, callback){

        UserDB.getInstance().create(userId, function(success){
              var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);

                var isSuccess = false;
                // trans.oncomplete = function(evt) {  
                //     callback(isSuccess);
                // };
            
                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.sessionId != undefined && data.sessionId != null){
                             updateData.sessionId = data.sessionId;
                             updateData.peerId =  data.sessionId;
                         }
                         if(data.mobileNumber && data.mobileNumber != ""){
                             updateData.mobileNumber = data.mobileNumber;
                         }
                         if(data.name && data.name != ""){
                             updateData.name = data.name;
                         }
                         if(data.sessionType != undefined && data.sessionType != null){
                             updateData.sessionType = data.sessionType;
                         }
                         if(data.msgContent != undefined && data.msgContent != null){
                             updateData.lastMessage = data.msgContent;
                         }
                         if(data.draftMessage && data.draftMessage != ""){
                             updateData.draftMessage = data.draftMessage;
                         }

                         if(data.msgDateTime != undefined && data.msgDateTime != null){
                            updateData.msgDateTime = data.msgDateTime;
                         }
                         if(data.msgLocalDateTime != undefined && data.msgLocalDateTime != null){
                            updateData.msgLocalDateTime = data.msgLocalDateTime;
                         }
                         if(data.msgRead != undefined && data.msgRead != null){
                            updateData.isRead = data.msgRead;
                         }
                         if(data.msgDelete != undefined && data.msgDelete != null){
                            // if(updateData.isDelete != "1"){
                                updateData.isDelete = data.msgDelete;
                            //  }
                         }
                         if(data.isDelete != undefined && data.isDelete != ""){
                             updateData.isDelete = data.isDelete;
                         }

                        //  Kaal updated on DAO
                         if(data.lastReadSeq != undefined && data.lastReadSeq != null){
                            updateData.lastReadSeq = data.lastReadSeq;
                         }

                         if(data.msgType != undefined && data.msgType != null){
                            updateData.msgType = data.msgType;
                         }

                        //  if(data.msgStatus == MessageConsts.STATUS_READBYFRIEND){
                        //     if(data.msgStatus && data.msgStatus != "" && updateData.msgStatus == MessageConsts.STATUS_SENT || updateData.msgStatus == MessageConsts.STATUS_ARRIVED){
                        //         updateData.msgStatus = data.msgStatus;
                        //     }
                        //  }else{
                        //     if(data.msgStatus != undefined && data.msgStatus != null){
                        //         updateData.msgStatus = data.msgStatus;
                        //     }
                        //  }
                        var msgStatus = data.msgStatus;
                        if(msgStatus && msgStatus != ""){
                            msgStatus = parseInt(msgStatus);
                            if(!isNaN(msgStatus)){
                                if(!updateData.msgStatus || updateData.msgStatus == "" || updateData.msgStatus == "0" || updateData.msgStatus == 0){
                                    updateData.msgStatus = data.msgStatus;
                                } else{
                                    if(updateData.msgStatus && updateData.msgStatus != ""){
                                        // if(updateData.msgStatus == MessageConsts.STATUS_UNKNOWN || updateData.msgStatus == MessageConsts.STATUS_FAILED || updateData.msgStatus == MessageConsts.STATUS_DRAFT){
                                        //     // No need to update
                                        // }else{
                                            updateData.msgStatus = data.msgStatus;
                                        // }
                                    }
                                }
                            }
                        }

                         if(data.sessionImageData && data.sessionImageData != ""){
                             updateData.sessionImageData = data.sessionImageData;
                         }

                         if(data.unreadCount >= 0){
                             updateData.unreadCount = data.unreadCount;
                         }

                         if(data.followType != undefined && data.followType != null){
                             updateData.followType = data.followType;
                         }

                         if(data.channelIsFollowing != undefined && data.channelIsFollowing != null){
                             updateData.channelIsFollowing = data.channelIsFollowing;
                         }

                         if(data.pinToChat != undefined && data.pinToChat != null){
                             updateData.pinToChat = data.pinToChat;
                         }

                         if(data.pinToTop == -1 || data.pinToTop > 0){
                             updateData.pinToTop = data.pinToTop;
                         }

                         if(data.callMode && data.callMode != ""){
                             updateData.callMode = data.callMode;
                         }
                        
                         if(data.msgDirection == 0 || data.msgDirection == 1 || data.msgDirection == "0" || data.msgDirection == "1"){
                             updateData.msgDirection = data.msgDirection;
                         }

                         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                isSuccess = true;
                                callback(true);
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        // cursor.continue();
                    }
                };
        });	 
    },
    updateUnReadCountBySessionId: function(userId, data, callback){

        UserDB.getInstance().create(userId, function(success){
              var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
            
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.sessionId != undefined && data.sessionId != null){
                             updateData.sessionId = data.sessionId;
                             updateData.peerId =  data.sessionId;
                         }
                         if(data.mobileNumber && data.mobileNumber != ""){
                             updateData.mobileNumber = data.mobileNumber;
                         }
                         if(data.name && data.name != ""){
                             updateData.name = data.name;
                         }
                         if(data.sessionType != undefined && data.sessionType != null){
                             updateData.sessionType = data.sessionType;
                         }
                         if(data.msgContent != undefined && data.msgContent != null){
                             updateData.lastMessage = data.msgContent;
                         }
                         if(data.draftMessage && data.draftMessage != ""){
                             updateData.draftMessage = data.draftMessage;
                         }
                         if(data.msgDateTime != undefined && data.msgDateTime != null){
                            updateData.msgDateTime = data.msgDateTime;
                         }
                         if(data.msgLocalDateTime != undefined && data.msgLocalDateTime != null){
                            updateData.msgLocalDateTime = data.msgLocalDateTime;
                         }
                         if(data.msgRead != undefined && data.msgRead != null){
                            updateData.isRead = data.msgRead;
                         }
                         if(data.msgDelete != undefined && data.msgDelete != null){
                            // if(updateData.isDelete != "1"){
                                updateData.isDelete = data.msgDelete;
                            //  }
                         }

                        //  Kaal updated on DAO
                         if(data.lastReadSeq != undefined && data.lastReadSeq != null){
                            updateData.lastReadSeq = data.lastReadSeq;
                         }

                         if(data.msgType != undefined && data.msgType != null){
                            updateData.msgType = data.msgType;
                         }
                         
                        //  if(data.msgStatus != undefined && data.msgStatus != null){
                        //      updateData.msgStatus = data.msgStatus;
                        //  }
                        var msgStatus = data.msgStatus;
                        // if(msgStatus && msgStatus != ""){
                        //     msgStatus = parseInt(msgStatus);
                        //     if(!isNaN(msgStatus)){
                        //         if(!updateData.msgStatus || updateData.msgStatus == "" || updateData.msgStatus == "0" || updateData.msgStatus == 0){
                        //             updateData.msgStatus = data.msgStatus;
                        //         } else{
                        //             if(updateData.msgStatus && updateData.msgStatus != ""){
                        //                 if(updateData.msgStatus == MessageConsts.STATUS_UNKNOWN || updateData.msgStatus == MessageConsts.STATUS_FAILED || updateData.msgStatus == MessageConsts.STATUS_DRAFT){
                        //                     // No need to update
                        //                 }else{
                        //                     updateData.msgStatus = data.msgStatus;
                        //                 }
                        //             }
                        //         }
                        //     }
                        // }

                         if(data.unreadCount){
                            //  var unreadCount = parseInt(updateData.unreadCount);
                            //  if(!isNaN(unreadCount)){
                            //      unreadCount = unreadCount + data.unreadCount;
                            //  }else{
                            //      unreadCount = data.unreadCount;
                            //  }
                             updateData.unreadCount = data.unreadCount;
                         }

                         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                // console.log("update success!!");
                                
                                // callback(true);
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
    },
    getAllFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
            var items = [];
            var pinToTopArr = [];
            trans.oncomplete = function(evt) {
                if(pinToTopArr && pinToTopArr.length > 0){
                    pinToTopArr = _.sortBy(pinToTopArr,"pinToTop").reverse();
                }
                var sortedItems = _.sortBy(items,"msgDateTime").reverse();
                if(sortedItems && sortedItems.length > 0){
                    sortedItems.forEach(function(sItem){
                        pinToTopArr.push(sItem);
                    });
                }
                callback(pinToTopArr);
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var cvalue = cursor.value;
                    if(cvalue){
                        if(cvalue.pinToTop > 0 && cvalue.sessionId != AppConstants.CHANNELS){
                            pinToTopArr.push(cvalue);
                        }else{
                            if(cvalue.sessionType == CINRequestConts.SESSIONPUBLIC && cvalue.pinToChat == 1){
                                items.push(cvalue);
                            } else if(cvalue.sessionType != CINRequestConts.SESSIONPUBLIC && cvalue.sessionId != AppConstants.CHANNELS){
                                items.push(cvalue);
                            }else if(cvalue.sessionId == AppConstants.CHANNELS){
                                items.push(cvalue);
                            }
                        }
                    }
                    cursor.continue();
                }
            };
        });
	},
    getAllChannelsFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
            var items = [];
        
            trans.oncomplete = function(evt) { 
                var sortedItems = _.sortBy(items,"msgDateTime");
                // var sortedItems = _.sortBy(items,"msgLocalDateTime");
                callback(sortedItems.reverse()) 
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var cvalue = cursor.value;
                    if(cvalue){
                        var isDelete = false;
                        if(cvalue.isDelete == "1" || cvalue.isDelete == 1){
                            isDelete = true;
                        }
                        if(cvalue.sessionType == CINRequestConts.SESSIONPUBLIC &&  cvalue.sessionId != AppConstants.CHANNELS && !isDelete){
                            items.push(cvalue);
                        }
                    }
                    cursor.continue();
                }
            };
        });
	},
    getAllRecentChannelsFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
            var items = [];
        
            trans.oncomplete = function(evt) { 
                var sortedItems = _.sortBy(items,"msgDateTime");
                // var sortedItems = _.sortBy(items,"msgLocalDateTime");
                callback(sortedItems.reverse()) 
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var cvalue = cursor.value;
                    if(cvalue){
                        if(cvalue.sessionType == CINRequestConts.SESSIONPUBLIC &&  cvalue.sessionId != AppConstants.CHANNELS){
                            items.push(cvalue);
                        }
                    }
                    cursor.continue();
                }
            };
        });
	},
    getRecentChannelsFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
            
            var maxDateTimeMessage = {};
            var maxDateTime = 0;
            trans.oncomplete = function(evt) { 
                callback(maxDateTimeMessage);
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var cvalue = cursor.value;
                    if(cvalue){
                        var isDelete = false;
                        if(cvalue.isDelete == "1" || cvalue.isDelete == 1){
                            isDelete = true;
                        }

                        if(cvalue.sessionType == CINRequestConts.SESSIONPUBLIC &&  cvalue.sessionId != AppConstants.CHANNELS && !isDelete){
                            if(parseInt(cvalue.msgDateTime)>=maxDateTime){
                                maxDateTime = parseInt(cvalue.msgDateTime);
                                maxDateTimeMessage = cvalue;
                            }
                        }
                    }
                    cursor.continue();
                }
            };
        });
	},
    updateRecentMessageBySessionId:function(name, thumbObj, userId, sessionId, callback){
        Messages.getInstance().getRecentMessageForSessionId(userId, sessionId, function(msg){
            console.log("Received MEssages : "+msg.msgId);
            if(msg.msgId == undefined || msg.msgId == null){
                console.log("DELETE SESSION : "+msg.msgId);
                // Session.getInstance().deleteAllBySessioIdFromLDB(userId, sessionId, function(success){
                //     callback(true);
                // });
                var data = {
                    sessionId: String(sessionId),
                    isDelete: "1"
                };
                Session.getInstance().updateByMessage(userId, data, function(dbResponse){
                    callback(dbResponse);
                })
            }else{
                Session.getInstance().addByMessageToLDB(name, thumbObj, userId, msg, function(success){
                    callback(true);
                });
            }
        });
    },
    updateRecentMsgForOtherMsgBySessionId:function(userId, sessionId, deleteType, callback){
        Messages.getInstance().getBroadcastRecentMessageForSessionId(userId, sessionId, function(msg){
            console.log("Received MEssages : "+msg.msgId);
            if(msg.msgId == undefined || msg.msgId == null){
                console.log("DELETE SESSION : "+msg.msgId);
                if(deleteType == AppConstants.BROADCAST){
                    sessionId = AppConstants.BROADCAST;
                } else if (deleteType == AppConstants.CHANNELS) {
                    sessionId = AppConstants.CHANNELS;
                }
                Session.getInstance().deleteAllBySessioIdFromLDB(userId, sessionId, function(success){
                    callback(true)
                });
            }else{
                 Session.getInstance().addByMessageToLDB("", "", userId, msg, function(success){
                    callback(true)
                });
            }
           
        });
       
    },
    updateRecentMsgForChannelsBySessionId:function(userId, sessionId, deleteType, callback){
        Messages.getInstance().getChannelsRecentMessageForSessionId(userId, sessionId, function(msg){
            console.log("Received MEssages : "+msg.msgId);
            if(msg.msgId == undefined || msg.msgId == null){
                console.log("DELETE SESSION : "+msg.msgId);

                // Get All recent channels
                Session.getInstance().getAllChannelsFromLDB(userId, function(channelsList){
                    var channelCount = 0;
                    if(channelsList){
                        channelCount = channelsList.length;
                    }
                    if(channelCount == 1){
                        Session.getInstance().deleteAllBySessioIdFromLDB(userId, sessionId, function(success){
                            callback(true)
                        });
                        if (deleteType == AppConstants.CHANNELS) {
                            sessionId = AppConstants.CHANNELS;
                        }

                        Session.getInstance().deleteAllBySessioIdFromLDB(userId, sessionId, function(success){
                            // callback(true)
                        });

                    }else{
                        // Update by last message

                        Session.getInstance().deleteAllBySessioIdFromLDB(userId, sessionId, function(success){
                            if(channelCount > 0){
                                var lastMsgItem;;
                                var item;
                                for(var i = 0; i < channelCount; i++){
                                    item = channelsList[i];
                                    if(sessionId && sessionId != "" &&item.sessionId && item.sessionId != ""){
                                        if(String(sessionId) != item.sessionId){
                                            lastMsgItem = channelsList[i];
                                            break;
                                        }
                                    }
                                }
                                if(lastMsgItem){
                                    var data = {
                                        sessionId : AppConstants.CHANNELS,
                                        peerId : AppConstants.CHANNELS,
                                        sessionType : lastMsgItem.sessionType,
                                        name : lastMsgItem.name,
                                        isDelete : lastMsgItem.msgDelete,
                                        msgContent : lastMsgItem.lastMessage,
                                        draftMessage : lastMsgItem.msgContent,
                                        msgDateTime : lastMsgItem.msgDateTime,
                                        msgLocalDateTime : lastMsgItem.msgLocalDateTime,
                                        sessionImageData : lastMsgItem.sessionImageData,
                                        msgType : lastMsgItem.msgType,
                                        msgStatus : lastMsgItem.msgStatus,
                                        msgDirection: lastMsgItem.msgDirection
                                    }

                                    Session.getInstance().updateByMessage(userId, data, function(success){
                                        callback(true);
                                    });
                                }else{
                                    callback(true);
                                }
                            }else{
                                callback(true);
                            }

                        });
                    }

                    /*Session.getInstance().deleteAllBySessioIdFromLDB(userId, sessionId, function(success){
                        callback(true)
                    });*/

                });

            }else{
                 Session.getInstance().addByMessageToLDB("", "", userId, msg, function(success){
                    callback(true)
                });
            }
           
        });
    },
    deleteAllBySessioIdFromLDB:function(userId, sessionId, callback){
        UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SESSION], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in deleting session : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
    deleteByMessageIdForSessionIdFromLDB:function(userId, messageId, sessionId, callback){
        UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SESSION], 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_MSG_ID);
                // var request = index.delete(sessionId);
                
                trans.oncomplete = function(evt) { 
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(messageId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in deleting session : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
              
          });
	},
	deleteAllFromLDB:function(userId, callback){
        // UserDB.getInstance().create(userId, function(success){
        //       //Making DELETE ALL contacts request to Local DB 
        //     var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SESSION], "readwrite")
        //                 .objectStore(DatabaseConstants.OBJECT_STORE_SESSION)
        //                 .clear();
            
        //     //Handler for success operation
        //     request.onsuccess = function(event) {
        //         callback(true);            
        //     };

        //     //Handler for success operation
        //     request.onerror = function(event) {
        //         callback(false);
        //     }  
        // });

    //Making DELETE ALL Session request to Local DB 
    // Kaal updated for the bug no: 2037 on 3rd Oct'2017
    Session.getInstance().getAllFromLDB(userId, function(response){
        if(response && response.length > 0){
            putNext(0);

            function putNext(i) {
                if (i < response.length) {
                    var data = {
                        sessionId: String(response[i].sessionId),
                        isDelete: "1"
                    };
    
                    Session.getInstance().updateByMessage(userId, data, function(dbResponse){
                        putNext(i + 1);
                    });
                } else {
                    callback(true);
                }
            }
        }
    });

	},
    // Kaal added getSessionBySessionIdFromLDB()
    getSessionBySessionIdFromLDB:function(userId, sessionId, callback){	
        UserDB.getInstance().create(userId, function(success){
               var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);
                var request = index.get(sessionId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback({});
                }
        });	 
      
    },

    getLastPinToTop:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
            
            var pinToTop = -1;
            trans.oncomplete = function(evt) { 
                callback(pinToTop) 
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    var cvalue = cursor.value;
                    if(cvalue){
                        if(cvalue.pinToTop > 0){
                            pinToTop = cvalue.pinToTop;
                        }
                    }
                    cursor.continue();
                }
            };
        });
	},

    updateTop: function(userId, sessionId, callback){
        Session.getInstance().getLastPinToTop(userId, function(lastPinVal){
            if(lastPinVal == -1){
                var data = {
                    sessionId : sessionId,
                    peerId : sessionId,
                    lastMessage : "",
                    isDelete: "1",
                    pinToTop: 1
                }
                Session.getInstance().addToLDB(userId, data, function(dbResponse){
                    callback(dbResponse);
                });
            } else {
                var data = {
                    sessionId: sessionId,
                    pinToTop: 1
                };
                if(lastPinVal > 0){
                    data.pinToTop = lastPinVal + 1;
                }
                Session.getInstance().updateByMessage(userId, data, function(dbResponse){
                    callback(dbResponse);
                });
            }
        });
    },

    removeTop: function(userId, sessionId, callback){
        var data = {
            sessionId: sessionId,
            pinToTop: -1
        };
        Session.getInstance().updateByMessage(userId, data, function(dbResponse){
            callback(dbResponse);
        })
    },
    updateMessageBySessionId: function(userId, data, unreadCount, callback){

        UserDB.getInstance().create(userId, function(success){
              var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SESSION, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_SESSION);
                var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_SESSION_ID);

                var isSuccess = false;
                // trans.oncomplete = function(evt) {  
                //     callback(isSuccess);
                // };
            
                var cursorRequest = index.openCursor(data.sessionId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if(!cursor){
                        var sdata = {
                            sessionId : data.sessionId,
                            peerId : data.sessionId,
                            mobileNumber : data.mobileNumbers,
                            sessionType : data.sessionType,
                            name : data.name,
                            isDelete : "0",
                            lastMessage : data.msgContent,
                            msgDateTime : data.msgDateTime,
                            msgLocalDateTime: data.msgLocalDateTime,
                            sessionImageData : data.thumbObj,
                            msgType : data.msgType,
                            lastReadSeq: data.msgSequence,
                            unreadCount: 0,
                            msgStatus: data.msgStatus,
                            msgDirection: data.msgDirection,
                        }
                        if(data.msgDirection == 1 && data.msgStatus == MessageConsts.STATUS_ARRIVED){
                            sdata.unreadCount = unreadCount;
                        }

                        Session.getInstance().addToLDB(userId, sdata, function(dbResponse){
                            callback(dbResponse);
                        });
                    }
                    else if (cursor) {
                         var updateData = cursor.value;
                         var isUpdate = false;
                         if(data.name && data.name != ""){
                             updateData.name = data.name;
                         }
                         if(data.msgDirection == 1 && data.msgDateTime > updateData.msgDateTime){
                            isUpdate = true;
                         }else if(data.msgDirection == 0){
                            isUpdate = true;
                         } else if(data.msgDirection == 1 && (data.msgType == MessageConsts.TYPE_UPDATE_STATUS || updateData.msgType == MessageConsts.TYPE_UPDATE_STATUS)){
                             isUpdate = true;
                         }
                            
                         if(data.sessionType != undefined && data.sessionType != null){
                             updateData.sessionType = data.sessionType;
                         }
                         if(data.msgContent != undefined && data.msgContent != null){
                             updateData.lastMessage = data.msgContent;
                         }

                         if(data.msgDateTime != undefined && data.msgDateTime != null){
                            updateData.msgDateTime = data.msgDateTime;
                         }

                         if(data.msgLocalDateTime != undefined && data.msgLocalDateTime != null){
                            updateData.msgLocalDateTime = data.msgLocalDateTime;
                         }

                         updateData.isDelete = "0";

                        //  Kaal updated on DAO
                         if(data.msgSequence != undefined && data.msgSequence != null){
                            updateData.msgSequence = data.msgSequence;
                         }

                         if(data.msgType != undefined && data.msgType != null){
                            updateData.msgType = data.msgType;
                         }

                        //  if(data.msgStatus == MessageConsts.STATUS_READBYFRIEND){
                        //     if(data.msgStatus && data.msgStatus != "" && updateData.msgStatus == MessageConsts.STATUS_SENT || updateData.msgStatus == MessageConsts.STATUS_ARRIVED){
                        //         updateData.msgStatus = data.msgStatus;
                        //     }
                        //  }else{
                        //     if(data.msgStatus != undefined && data.msgStatus != null){
                        //         updateData.msgStatus = data.msgStatus;
                        //     }
                        //  }
                        var msgStatus = data.msgStatus;
                        if(msgStatus && msgStatus != ""){
                            msgStatus = parseInt(msgStatus);
                            if(!isNaN(msgStatus)){
                                if(!updateData.msgStatus || updateData.msgStatus == "" || updateData.msgStatus == "0" || updateData.msgStatus == 0){
                                    updateData.msgStatus = data.msgStatus;
                                } else{
                                    if(updateData.msgStatus && updateData.msgStatus != ""){
                                        // if(updateData.msgStatus == MessageConsts.STATUS_UNKNOWN || updateData.msgStatus == MessageConsts.STATUS_FAILED || updateData.msgStatus == MessageConsts.STATUS_DRAFT){
                                        //     // No need to update
                                        // }else{
                                            updateData.msgStatus = data.msgStatus;
                                        // }
                                    }
                                }
                            }
                        }

                         if(data.thumbObj && data.thumbObj != ""){
                             updateData.sessionImageData = data.thumbObj;
                         }
                         
                         var count = updateData.unreadCount;
                         if(!count || count == ""){
                            count = 0;  
                         }
                         if(data.msgDirection == 1 && data.msgStatus == MessageConsts.STATUS_ARRIVED){
                            count = parseInt(count) + unreadCount;
                         }

                         if(count >= 0){
                            //  updateData.unreadCount = count;
                         }

                         if(isUpdate){
                            var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                // isSuccess = true;
                                callback(true);
                            }
                            
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                         } else{
                             callback(false);
                         }
                    }
                };
        });	 
    },

	
};

Session.getInstance= function(){
    if(!Session.instance){
        Session.instance = new Session();
    }
    return Session.instance;
};
