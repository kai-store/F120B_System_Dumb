function Settings() {}

Settings.prototype = {
	constructor: Settings,
  
    addToLDB:function(userId, setting, callback){
        //Arranging Settings Data to be inserted

          UserDB.getInstance().create(userId, function(success){
            console.log("Insert Active User : "+UserDB.getInstance().database);
                //Making INSERT Settings request to Local DB 

                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SETTINGS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_SETTINGS)
                            .put(setting);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
          
	},
    bulkAddToLDB:function(userId, settings, callback){
        UserDB.getInstance().create(userId, function(success){
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_SETTINGS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_SETTINGS);
            putNext(0);

            function putNext(i) {
                if (i<settings.length) {
                    var request = objectStore.put(settings[i])
                    request.onsuccess = function(event) {
                        putNext(i+1)
                    };
                } else {   // complete
                    console.log('populate complete');
                    callback(true);
                }
            }  
        });
    },
    getAllFromLDB:function(userId, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SETTINGS, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_SETTINGS);
            var items = [];
        
            trans.oncomplete = function(evt) {  
                callback(items);
            };
        
            var cursorRequest = store.openCursor();
        
            cursorRequest.onerror = function(error) {
                console.log("Error in fetching contacts : "+error);
            };
        
            cursorRequest.onsuccess = function(evt) {                 
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
	},
     getBySettingsKeyFromLDB:function(userId, settingsKey, callback){	
        UserDB.getInstance().create(userId, function(success){
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_SETTINGS, IDBTransaction.READ_ONLY);
            var request = trans
                        .objectStore(DatabaseConstants.OBJECT_STORE_SETTINGS)
                        .get(settingsKey);
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback({});
            } 
        });
    }
	
};

Settings.getInstance= function(){
    if(!Settings.instance){
        Settings.instance = new Settings();
    }
    return Settings.instance;
};
