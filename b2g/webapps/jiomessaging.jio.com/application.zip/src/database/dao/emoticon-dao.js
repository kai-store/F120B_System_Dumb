function EmoticonDAO () {
	this.emoticonId = "";
	this.emoticonWidth = "";
	this.emoticonHeight = "";
	this.emoticonLocal = "";
	this.emoticonStatus = "";
	this.emoticonPackageId = "";
    this.emoticonPackageToken = "";
	this.emoticonFileSize = "";
	this.emoticonIconSize = "";
	this.emoticonPath = "";
	this.emoticonIconPath = "";
	this.emoticonFileId = "";
	this.emoticonIconId = "";
}

EmoticonDAO.prototype = {
	constructor:EmoticonDAO,
  
    addToLDB:function(userId, callback){
        //Arranging Emoticon Data to be inserted
	    var data = {
            emoticonId : this.emoticonId,
            emoticonWidth : this.emoticonWidth,
            emoticonHeight : this.emoticonHeight,
            emoticonLocal : this.emoticonLocal,
            emoticonStatus : this.emoticonStatus,
            emoticonPackageId : this.emoticonPackageId,
            emoticonPackageToken : this.emoticonPackageToken,
            emoticonFileSize : this.emoticonFileSize,
            emoticonIconSize : this.emoticonIconSize,
            emoticonPath : this.emoticonPath,
            emoticonIconPath : this.emoticonIconPath,
            emoticonFileId : this.emoticonFileId,
            emoticonIconId : this.emoticonIconId

        } 
       
        console.log("data sent to emoticonDao is"+ JSON.stringify(data));
        UserDB.getInstance().create(userId, function(success){
               //Making INSERT contact request to Local DB 
                var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_EMOTICONS], "readwrite")
                            .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS)
                            .put(data);

                //Handler for success operation            
                request.onsuccess = function(event) {
                    callback(true)
                };

                //Handler for failure operation                   
                request.onerror = function(event) {
                    callback(false)
                }   
          });
        
	},
    addByDataToLDB:function(userId, data, callback){
         UserDB.getInstance().create(userId, function(success){
                 
            //Making INSERT contact request to Local DB
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_EMOTICONS], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS)
                        .put(data);

            //Handler for success operation            
            request.onsuccess = function(event) {
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function(event) {
                callback(false)
            }      
         });
        
	},
    updateByDataToLDB:function(userId, data, callback){
        
         UserDB.getInstance().create(userId, function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_EMOTICONS, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_FILE_ID);
               
                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(data.emoticonFileId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                         var updateData = cursor.value;
                         if(data.emoticonWidth != undefined && data.emoticonWidth != null){
                             updateData.emoticonWidth = data.emoticonWidth;
                         }
                         if(data.emoticonHeight != undefined && data.emoticonHeight != null){
                             updateData.emoticonHeight = data.emoticonHeight;
                         }
                         if(data.emoticonLocal != undefined && data.emoticonLocal != null){
                             updateData.emoticonLocal = data.emoticonLocal;
                         }
                         if(data.emoticonStatus != undefined && data.emoticonStatus != null){
                             updateData.emoticonStatus = data.emoticonStatus;
                         }
                         if(data.emoticonPackageId != undefined && data.emoticonPackageId != null){
                             updateData.emoticonPackageId = data.emoticonPackageId;
                         }
                         if(data.emoticonPackageToken != undefined && data.emoticonPackageToken != null){
                             updateData.emoticonPackageToken = data.emoticonPackageToken;
                         }
                         if(data.emoticonFileSize != undefined && data.emoticonFileSize != null){
                             updateData.emoticonFileSize = data.emoticonFileSize;
                         }
                         if(data.emoticonIconSize != undefined && data.emoticonIconSize != null){
                             updateData.emoticonIconSize = data.emoticonIconSize;
                         }
                         if(data.emoticonPath != undefined && data.emoticonPath != null){
                             updateData.emoticonPath = data.emoticonPath;
                         }
                         if(data.emoticonIconPath != undefined && data.emoticonIconPath != null){
                             updateData.emoticonIconPath = data.emoticonIconPath;
                         }
                         if(data.emoticonFileId != undefined && data.emoticonFileId != null){
                             updateData.emoticonFileId = data.emoticonFileId;
                         }
                         if(data.emoticonIconId != undefined && data.emoticonIconId != null){
                             updateData.emoticonIconId = data.emoticonIconId;
                         }
         
                         var res = cursor.update(updateData);
                            res.onsuccess = function(e){
                                console.log("update success!!");
                            }
                            res.onerror = function(e){
                                console.log("update failed!!");
                                callback(false);
                            }
                        
                        cursor.continue();
                    }
                };
        });	 
	},
    getAllFromLDB:function(userId, callback){
         UserDB.getInstance().create(userId, function(success){
        
                //Making SELECT ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_EMOTICONS], "readwrite")
                    .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS)
                    .getAll();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(event.target.result);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback([]);
            }  
         });	
	},
    
    getByFileIdFromLDB:function(userId, fileId, callback){ 
        // debugger; 
         UserDB.getInstance().create(userId,function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_EMOTICONS, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_FILE_ID);
                var request = index.get(fileId);
                
                //Handler for success operation
                request.onsuccess = function(event) {
                    callback(event.target.result);            
                };

                //Handler for success operation
                request.onerror = function(event) {
                    callback([]);
                }
        }); 
    },
   
	deleteAllFromLDB:function(userId, callback){
        UserDB.getInstance().create(userId, function(success){
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_EMOTICONS], "readwrite")
                        .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS)
                        .clear();
            
            //Handler for success operation
            request.onsuccess = function(event) {
                callback(true);            
            };

            //Handler for success operation
            request.onerror = function(event) {
                callback(false);
            } 
         }); 
	},

    getByEmoticonIdFromLDB:function(userId, emoticonId, callback){ 
        // debugger; 
         UserDB.getInstance().create(userId,function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_EMOTICONS, IDBTransaction.READ_ONLY);
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_PACKAGE_ID);
                // var request = index.get(fileId);
                
                var items = [];
                trans.oncomplete = function(evt) {
                    callback(items)
                };
            
                var cursorRequest = index.openCursor(emoticonId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        items.push(cursor.value);
                        cursor.continue();
                    }
                };
                // //Handler for success operation
                // request.onsuccess = function(event) {
                //     callback(event.target.result);            
                // };

                // //Handler for success operation
                // request.onerror = function(event) {
                //     callback([]);
                // }
        }); 
    },

    deleteByEmoticonIdFromLDB:function(userId, emoticonId, callback){ 
        // debugger; 
         UserDB.getInstance().create(userId,function(success){
                var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_EMOTICONS, 'readwrite');
                var objectStore = trans
                            .objectStore(DatabaseConstants.OBJECT_STORE_EMOTICONS);
                var index = objectStore.index(DatabaseConstants.EMOTICON_PACKAGE_ID);
                // var request = index.delete(emoticonId);

                trans.oncomplete = function(evt) {  
                    callback(true);
                };
            
                var cursorRequest = index.openCursor(emoticonId);
            
                cursorRequest.onerror = function(error) {
                    console.log("Error in fetching contacts : "+error);
                    callback(false);
                };
            
                cursorRequest.onsuccess = function(evt) {                 
                    var cursor = evt.target.result;
                    if (cursor) {
                        var request = cursor.delete();
                        request.onsuccess = function() {
                            console.log('Deleted');
                        };
                        cursor.continue();
                    }
                };
                
        }); 
    }
   	
};

EmoticonDAO.getInstance = function(){
    if(!EmoticonDAO.instance){
        EmoticonDAO.instance = new EmoticonDAO();
    }
    return EmoticonDAO.instance;
};
