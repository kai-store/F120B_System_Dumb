function CommonDB () {}

CommonDB.prototype = {
	constructor: CommonDB,
    instance:null,
    database:null,
    create : function(callback) {
        if (CommonDB.instance.database == null){
            var gotDBInstance = false;
            var databaseName = DatabaseUtils.getInstance().getCommonDatabseName();
            var dbVersion = DatabaseUtils.getInstance().getCommonDBVersionNumber();
            Database.getInstance().createNewDatabase(databaseName, dbVersion, function(db, req, upgradedbcalled){
                CommonDB.instance.database = db;
                
                //Handler for version updates  
                if (upgradedbcalled) {
                    gotDBInstance = true; 
                    CommonDB.instance.createTables(callback); 
                }else{
                    if(!gotDBInstance){
                        gotDBInstance = true; 
                        CommonDB.instance.sendCallBack(callback, 0);
                    }
                } 
            });
        }else{
            CommonDB.instance.sendCallBack(callback, 0);
        }    
    },

    createTables : function(callback){
        if (!CommonDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_ACTIVE_USER)){
             CommonDB.instance.createObjectStoreForActiveUser(callback);
        }; 
        if (!CommonDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_DEVICES)){
             CommonDB.instance.createObjectStoreForDevices(callback);
        }; 

         CommonDB.instance.sendCallBack(callback, 1000); 
    },

    createObjectStoreForActiveUser : function(callback){
        var objectStore = CommonDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_ACTIVE_USER, { keyPath: DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, autoIncrement: true });

         //Add Column/Indexes to the active user store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, { unique: true });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_ID, DatabaseConstants.OBJECT_INDEX_USER_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PWD, DatabaseConstants.OBJECT_INDEX_PWD, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_TOKEN, DatabaseConstants.OBJECT_INDEX_TOKEN, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_NAME, DatabaseConstants.OBJECT_INDEX_USER_NAME, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_STATUS , DatabaseConstants.OBJECT_INDEX_STATUS , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DOMAIN , DatabaseConstants.OBJECT_INDEX_DOMAIN , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_CMP_ADDRESS , DatabaseConstants.OBJECT_INDEX_CMP_ADDRESS , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SERVER_NUMBER , DatabaseConstants.OBJECT_INDEX_SERVER_NUMBER , { unique: false });   
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_NAV_RESPONSE , DatabaseConstants.OBJECT_INDEX_NAV_RESPONSE , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SERVER_KEY , DatabaseConstants.OBJECT_INDEX_SERVER_KEY , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_CREDENTIAL , DatabaseConstants.OBJECT_INDEX_CREDENTIAL , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DATE_TIME , DatabaseConstants.OBJECT_INDEX_DATE_TIME , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_TOKEN_EXPIRY , DatabaseConstants.OBJECT_INDEX_TOKEN_EXPIRY , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_LANGUAGE , DatabaseConstants.OBJECT_INDEX_LANGUAGE , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DEVICE_MODEL , DatabaseConstants.OBJECT_INDEX_DEVICE_MODEL , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_IMAGE , DatabaseConstants.OBJECT_INDEX_USER_IMAGE , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_GENDER , DatabaseConstants.OBJECT_INDEX_USER_GENDER , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_MOOD , DatabaseConstants.OBJECT_INDEX_USER_MOOD , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_QR_CODE , DatabaseConstants.OBJECT_INDEX_USER_QR_CODE , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PORTRAIT_ID , DatabaseConstants.OBJECT_INDEX_PORTRAIT_ID , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_THUMB_DATA , DatabaseConstants.OBJECT_INDEX_THUMB_DATA , { unique: false });
        
        


       
           
    },
    createObjectStoreForDevices : function(callback){
        var objectStore = CommonDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_DEVICES, { keyPath: DatabaseConstants.OBJECT_INDEX_DEVICE_ID, autoIncrement: true });

         //Add Column/Indexes to the devices
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DEVICE_ID, DatabaseConstants.OBJECT_INDEX_DEVICE_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DEVICE_AUTH, DatabaseConstants.OBJECT_INDEX_DEVICE_AUTH, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DEVICE_PRIVATE_STR, DatabaseConstants.OBJECT_INDEX_DEVICE_PRIVATE_STR, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DEVICE_END_POINT, DatabaseConstants.OBJECT_INDEX_DEVICE_END_POINT, { unique: false });
        
    
           
    },
    clearDBAccess:function(){
        CommonDB.instance.database = null;
    },

    sendCallBack : function(callback, delay){
         setTimeout(function(){ 
            if(callback){
                 callback(true);
            } }, delay);
    }


};

CommonDB.getInstance= function(){
    if(!CommonDB.instance){
        CommonDB.instance = new CommonDB();
    }
    return CommonDB.instance
};
