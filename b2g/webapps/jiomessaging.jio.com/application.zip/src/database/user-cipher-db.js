function UserCipherDB () {}

UserCipherDB.prototype = {
	constructor: UserCipherDB,
    instance:null,
    database:null,
    create : function(userId, callback) {
        var newDatabaseName = DatabaseUtils.getInstance().getUserDatabseNameForUserId(userId);
        // console.log("New DataBaseName : " + newDatabaseName);
        // if (UserCipherDB.instance.database == null || UserCipherDB.instance.dbName != newDatabaseName){
        if (UserCipherDB.instance.database == null){

            // mushtaq added this check. Since DB created with null user id
            if (!userId) {
                return;
            }

            var gotDBInstance = false;
            var databaseName = DatabaseUtils.getInstance().getUserCipherDatabseNameForUserId(userId);
            var dbVersion = DatabaseUtils.getInstance().getCipherUserDBVersionNumber();
            UserCipherDB.instance.dbName = databaseName;
            // console.log("Old DataBaseName : " + databaseName);
            //  dbVersion = 2;//Testing
            Database.getInstance().createNewDatabase(databaseName, dbVersion, function(db, req, upgradedbcalled){
                UserCipherDB.instance.database = db;
                // console.log("DB Request : " + db);
                
                //Handler for version updates  
                if (upgradedbcalled) {
                    gotDBInstance = true; 
                    UserCipherDB.instance.createTable(callback); 
                }else{
                    if(!gotDBInstance){
                        gotDBInstance = true; 
                        UserCipherDB.instance.sendCallBack(callback, true, 0);
                    }
                } 
            });
        }else{
             UserCipherDB.instance.sendCallBack(callback, true, 0);
        }    
    },

    createTable : function(callback){
        if (!UserCipherDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_MESSAGES)){
            UserCipherDB.instance.createObjectStoreForMessageContent();
        }; 
        
        UserCipherDB.instance.sendCallBack(callback, true, 1000); 
    },
   
    createObjectStoreForMessageContent : function(){
        var objectStore = UserCipherDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_MESSAGES, { keyPath: DatabaseConstants.OBJECT_INDEX_MSG_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_ID, DatabaseConstants.OBJECT_INDEX_MSG_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_CONTENT, DatabaseConstants.OBJECT_INDEX_MSG_CONTENT, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_DIRECTION, DatabaseConstants.OBJECT_INDEX_MSG_DIRECTION, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_TYPE, DatabaseConstants.OBJECT_INDEX_MSG_TYPE, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_FROM, DatabaseConstants.OBJECT_INDEX_MSG_FROM, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_TO, DatabaseConstants.OBJECT_INDEX_MSG_TO, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME , DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_LOCAL_DATE_TIME , DatabaseConstants.OBJECT_INDEX_MSG_LOCAL_DATE_TIME , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_THUMB_STATUS  , DatabaseConstants.OBJECT_INDEX_MSG_THUMB_STATUS  , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_STATUS , DatabaseConstants.OBJECT_INDEX_MSG_STATUS , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_FILE_STATUS , DatabaseConstants.OBJECT_INDEX_MSG_FILE_STATUS , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_READ , DatabaseConstants.OBJECT_INDEX_MSG_READ , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG__DELETE , DatabaseConstants.OBJECT_INDEX_MSG__DELETE , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_TOS , DatabaseConstants.OBJECT_INDEX_MSG_TOS , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_MULTIMEDIA , DatabaseConstants.OBJECT_INDEX_MSG_MULTIMEDIA , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_LISTEN , DatabaseConstants.OBJECT_INDEX_MSG_LISTEN , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_ID , DatabaseConstants.OBJECT_INDEX_SESSION_ID , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_TYPE , DatabaseConstants.OBJECT_INDEX_SESSION_TYPE , { unique: false }); 

        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID , DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_THUMB_ID , DatabaseConstants.OBJECT_INDEX_MSG_THUMB_ID , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_THUMB_LOCAL_PATH , DatabaseConstants.OBJECT_INDEX_MSG_THUMB_LOCAL_PATH , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_FILE_LOCAL_PATH , DatabaseConstants.OBJECT_INDEX_MSG_FILE_LOCAL_PATH , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_CALL_MODE , DatabaseConstants.OBJECT_INDEX_CALL_MODE , { unique: false }); 

        // Index for getting unread message count
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GET_UNREAD_COUNT, [DatabaseConstants.OBJECT_INDEX_SESSION_ID,DatabaseConstants.OBJECT_INDEX_MSG_STATUS, DatabaseConstants.OBJECT_INDEX_MSG_DIRECTION], {unique:false});
        
    },
    clearDBAccess : function(){
        UserCipherDB.instance.database = null;
    },
    sendCallBack : function(callback, result, delay){
         setTimeout(function(){ 
            if(callback){
                 callback(result);
            } }, delay);
    }


};

UserCipherDB.getInstance = function(){
     if(!UserCipherDB.instance){
        UserCipherDB.instance = new UserCipherDB();
    }
    return UserCipherDB.instance;
};
