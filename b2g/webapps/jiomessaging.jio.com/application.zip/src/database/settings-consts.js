function SettingConstants () {}

SettingConstants.IS_FIRST_LOGIN                          = 'IS_FIRST_LOGIN';
SettingConstants.DND_INTERVAL                            = 'DND_INTERVAL';
SettingConstants.DND_START                               = 'DND_START';
SettingConstants.MESSAGE_SHOW_PREVIEW                    = 'MESSAGE_SHOW_PREVIEW';
SettingConstants.FIRST_HANDLE_PHONEBOOK                  = 'FIRST_HANDLE_PHONEBOOK';
SettingConstants.LAST_SEEN_VISIABLE                      = 'LAST_SEEN_VISIABLE';
SettingConstants.SOCIAL_CONTACT_NOTIFY_ALERT             = 'SOCIAL_CONTACT_NOTIFY_ALERT';
SettingConstants.SOCIAL_CONTENT_NOTIFY_ALERT             = 'SOCIAL_CONTENT_NOTIFY_ALERT';
SettingConstants.MESSAGE_READ_REPLY                      = 'MESSAGE_READ_REPLY';
SettingConstants.GROUP_MAX_COUNT                         = 'GROUP_MAX_COUNT';
SettingConstants.FREE_SMS_DAY_QUOTA                      = 'FREE_SMS_DAY_QUOTA';
SettingConstants.FREE_SMS_MONTH_QUOTA                    = 'FREE_SMS_MONTH_QUOTA';
SettingConstants.RMC_CHANNEL_LIST_VERSION                = 'RMC_CHANNEL_LIST_VERSION';
SettingConstants.SELF_CARD_NAME                          = "SELF_CARD_NAME";
SettingConstants.PUBLIC_RECOMMEND_NEW_NOTIFY             = 'PUBLIC_RECOMMEND_NEW_NOTIFY';
SettingConstants.SELF_CARD_MOOD                          = "SELF_CARD_MOOD";
SettingConstants.PUBLIC_ACCOUNT_FOCUS_LIST_VERSION       = 'PUBLIC_ACCOUNT_FOCUS_LIST_VERSION';
SettingConstants.PUBLIC_ACCOUNT_RECOMMEND_LIST_VERSION   = 'PUBLIC_ACCOUNT_RECOMMEND_LIST_VERSION';
SettingConstants.SELF_CARD_IMPRESA                       = 'SELF_CARD_IMPRESA';
SettingConstants.SELF_CARD_GENDER                        = 'SELF_CARD_GENDER';
SettingConstants.SELF_CARD_VERSION                       = 'SELF_CARD_VERSION';
SettingConstants.SELF_CARD_AVATAR_ID                     = 'SELF_CARD_AVATAR_ID';
SettingConstants.PUBLIC_ACCOUNT_RECOMMEND_LIST_COUNT     = 'PUBLIC_ACCOUNT_RECOMMEND_LIST_COUNT';
SettingConstants.SERVER_CONTACT_VERSION                  = 'SERVER_CONTACT_VERSION';
SettingConstants.RMC_CHANNEL_LIST_PRE_VERSION            = 'RMC_CHANNEL_LIST_PRE_VERSION';
SettingConstants.RMC_NEW_NOTIFY_CONTENT                  = 'RMC_NEW_NOTIFY_CONTENT';
SettingConstants.PUBLIC_ACCOUNT_NEW_USER_STEP            = 'PUBLIC_ACCOUNT_NEW_USER_STEP';
SettingConstants.BLOCK_LIST_VERSION                      = 'BLOCK_LIST_VERSION';
SettingConstants.PUBLIC_RECOMMEND_FIRST_TIME             = 'PUBLIC_RECOMMEND_FIRST_TIME';
SettingConstants.INVITE_REFERRAL_CODE                    = 'INVITE_REFERRAL_CODE';
SettingConstants.INVITE_REFERRAL_MESSAGE                 = 'INVITE_REFERRAL_MESSAGE';
SettingConstants.INVITE_TINY_URL                         = 'INVITE_TINY_URL';
SettingConstants.SESSION_UNREAD_COUNT                    = 'SESSION_UNREAD_COUNT';

SettingConstants.CHAT_MSG_NOTIFICATION                   = 'CHAT_MSG_NOTIFICATION';
SettingConstants.CHAT_NOTIFICATION_SOUND                 = 'CHAT_NOTIFICATION_SOUND';
SettingConstants.CHAT_NOTIFICATION_VIBRATION             = 'CHAT_NOTIFICATION_VIBRATION';
SettingConstants.CHAT_SOUND                              = 'CHAT_SOUND';
SettingConstants.CHAT_MSG_PREVIEW                        = 'CHAT_MSG_PREVIEW';
SettingConstants.CHAT_HANDSETMODE                        = 'CHAT_HANDSETMODE';
SettingConstants.CHAT_DND                                = 'CHAT_DND';
SettingConstants.CHAT_DELAY_SENDING                      = 'CHAT_DELAY_SENDING';
SettingConstants.CHAT_LAST_SEEN                          = 'CHAT_LAST_SEEN';
SettingConstants.CHAT_READ_RECEIPT                       = 'CHAT_READ_RECEIPT';

SettingConstants.AUTOMATIC                               = 'LANG_AUTOMATIC';
SettingConstants.ENGLISH                                 = 'LANG_ENGLISH';
SettingConstants.HINDI                                   = 'LANG_HINDI';
SettingConstants.MARATHI                                 = 'LANG_MARATHI';
SettingConstants.GUJRATI                                 = 'LANG_GUJRATI';
SettingConstants.CHAT_READ_RECEIPT                       = 'LANG_CHAT_READ_RECEIPT';

SettingConstants.DELAY_ZERO                              = 'DELAY_ZERO';
SettingConstants.DELAY_ONE                               = 'DELAY_ONE';
SettingConstants.DELAY_TWO                               = 'DELAY_TWO';
SettingConstants.DELAY_THREE                             = 'DELAY_THREE';

