function ContactDAOWorker() {
    this.worker = null;
    this.nextCallId = 0;
    this.callbacks = {};
}

ContactDAOWorker.prototype = {
    constructor: ContactDAOWorker,
    startWorker:function(){
        
        var that = this;
        this.worker = new Worker('src/database/dao/contact-dao.js');
       
        this.worker.onmessage = function(event) {
            if (!that.callbacks[event.data.callId]) {
                    // console.log('worker ' + event.data.callId + ' callback not defined');
            }else{
                    // send data to callback function
                    that.callbacks[event.data.callId](event.data.result);
                
                    // remove callback reference
                    that.callbacks[event.data.callId] = null;
            }
        };         
	},
    addToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    addByDataToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    updateByDataToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);

    },
    updateByUserIdToLDB:function(userId, data, callback){
       var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateByUserIdToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    bulkUpdateToLDB:function(userId, contacts, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkUpdateToLDB",
            userId : userId,
            contacts : contacts,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    bulkAddToLDB:function(userId, contacts, callback){
       var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkAddToLDB",
            userId : userId,
            contacts : contacts,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    getAllFromLDB:function(userId, callback){
       var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    getByContactUserIdFromLDB:function(userId, contactUserId, callback){	
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getByContactUserIdFromLDB",
            userId : userId,
            contactUserId: contactUserId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    getByMobileNumberFromLDB:function(userId, mobileNumber, callback){	
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getByMobileNumberFromLDB",
            userId : userId,
            mobileNumber: mobileNumber,
            callId: callId
        };

        this.worker.postMessage(params);
    },
	deleteAllFromLDB:function(userId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
	}
	
	
};

ContactDAOWorker.getInstance= function(){
    if(!ContactDAOWorker.instance){
        ContactDAOWorker.instance = new ContactDAOWorker();
        ContactDAOWorker.instance.startWorker();
    }
    return ContactDAOWorker.instance;
};
