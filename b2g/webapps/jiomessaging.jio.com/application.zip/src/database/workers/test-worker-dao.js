function TestDAO() {

}

TestDAO.prototype = {
	constructor: TestDAO,
    listenMessages:function(){
        console.log("Listen Message Started");
          
                // self.importScripts('../../utils/underscore.js');
                // self.importScripts('../user-cipher-db.js');
                // self.importScripts('../user-db.js');
                // self.importScripts('../db-utils.js');
                // self.importScripts('../database.js');
                // self.importScripts('../db.consts.js');
                // self.importScripts('../../app-const.js');
                // self.importScripts('../../app-mode.js');
                // self.importScripts('../dao/group-mapping-dao.js');
                // self.importScripts('../dao/group-dao.js');
                // self.importScripts('../dao/contact-dao.js');
                // self.importScripts('../dao/session-dao.js');
                // // self.importScripts('../dao/channels-list-dao.js');
                // // self.importScripts('../dao/channels-focus-list-dao.js');
                // self.importScripts('../../cin/CinBase64.js');
                // self.importScripts('../../cin/cin.request.conts.js');
                // self.importScripts('../../cin/message/message.const.js');
        self.onmessage = function(event) {
          console.log("************* Child Worker ***************");
//            var userId = "-1,121,87,58"
//             UserDB.getInstance().create(userId, function(success){
//                 var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_CONTACTS, IDBTransaction.READ_ONLY);
//                 var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_CONTACTS);
//                 var items = [];
            
//                 trans.oncomplete = function(evt) {  
//                     // callback(items);
//                     // callback(_.sortBy(items,"phoneBookName"));
// console.log("All Items : ",items);
//                     // callback(_.sortBy(items, function (i) { return i.phoneBookName.toLowerCase(); }));
//                 };
            
//                 var cursorRequest = store.openCursor();
            
//                 cursorRequest.onerror = function(error) {
//                     console.log("Error in fetching contacts : "+error);
//                 };
            
//                 cursorRequest.onsuccess = function(evt) {                 
//                     var cursor = evt.target.result;
//                     if (cursor) {
//                         items.push(cursor.value);
//                         cursor.continue();
//                     }
//                 };
//             });
        };
    },
   
	
};

TestDAO.getInstance = function(){
    if(!TestDAO.instance){
        TestDAO.instance = new TestDAO();
        TestDAO.instance.listenMessages();  
    }
    
    return TestDAO.instance;
};

TestDAO.getInstance();
