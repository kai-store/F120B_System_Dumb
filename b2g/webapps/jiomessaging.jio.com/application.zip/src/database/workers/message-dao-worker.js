function MessagesDAOWorker() {
    this.worker = null;
    this.nextCallId = 0;
    this.callbacks = {};
}

MessagesDAOWorker.prototype = {
	constructor: MessagesDAOWorker,
    startWorker:function(){
        var that = this;
        this.worker = new Worker('src/database/dao/messages-dao.js');
        
        this.worker.onmessage = function(event) {
            if (!that.callbacks[event.data.callId]) {
                    // console.log('worker ' + event.data.callId + ' callback not defined');
            }else{
                    // send data to callback function
                    that.callbacks[event.data.callId](event.data.result);
                
                    // remove callback reference
                    that.callbacks[event.data.callId] = null;
            }
        };     
	},
    createBlob:function(filePath, callback) {
      
        xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET",filePath);
        xmlhttp.send();
       
        xmlhttp.onload = function() 
        {
            // blob = xmlhttp.responseText;//xhr.response is now a blob object
             var fileContent = xmlhttp.responseText;
            //  console.log("fileContent : "+fileContent);
            var binaryData = [];
            binaryData.push(fileContent);

            var blobData = new Blob(binaryData, {type: "application/zip"});
             callback(blobData);
        }
       
        // var blob = null;
        // var xhr = new XMLHttpRequest(); 
        // xhr.open("GET", filePath); 
        // xhr.responseType = "blob";//force the HTTP response, response-type header to be blob
        // xhr.onload = function() 
        // {
        //     blob = xhr.response;//xhr.response is now a blob object
        //     console.log("Blob Obejct: "+blob);
        // }
        // xhr.send();

        // var url = [filePath];
        // var blob = new Blob(url, {type: 'javascript/text'})
        // console.log("Blob : "+blob);
        // callback(blob);
        // var file = new File([filePath], "file", {
        //     type: "text/javascript",
        // });
        // var reader = new FileReader();
        // reader.onload = function() { callback(reader.result) };
        // reader.readAsDataURL(file);
    },
    addToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
        // console.log("addToLDB USER ID : "+userId);
        // var params = [];
        // params.push("addToLDB");
        // params.push(userId);
        // params.push(mesageData);
        
        // // for(var i=0;i<10000;i++){
        //      worker.postMessage(params);
        // // }

        //  worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        // //    debugger;
        //    callback(event.data);

        //    worker.terminate();
        // }; 
       
    },
    addByDataToLDB:function(userId, data, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    updateByDataToLDB:function(userId, data, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);

        //    worker.terminate();
        // }; 

        // var params = [];
        // params.push("updateByDataToLDB");
        // params.push(userId);
        // params.push(data);
     
        // worker.postMessage(params);
      
	},
    updateByDataForSessionToLDB:function(userId, data, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateByDataForSessionToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
        //  var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("updateByDataForSessionToLDB");
        // params.push(userId);
        // params.push(data);
     
        // worker.postMessage(params);
	},
    updateMessageStatusByDataForSessionToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateMessageStatusByDataForSessionToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("updateMessageStatusByDataForSessionToLDB");
        // params.push(userId);
        // params.push(data);
     
        // worker.postMessage(params);
    },
    
    updateMessageStatusForPeerId:function(userId, peerId, messageStatus, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateMessageStatusForPeerId",
            userId : userId,
            peerId : peerId,
            messageStatus : messageStatus,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("updateMessageStatusForPeerId");
        // params.push(userId);
        // params.push(peerId);
        // params.push(messageStatus);
     
        // worker.postMessage(params);
    },
    updateMsgStatusBySequence:function(userId, peerId, lastReadSequence, messageStatus, callback){
        
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateMsgStatusBySequence",
            userId : userId,
            peerId : peerId,
            lastReadSequence : lastReadSequence,
            messageStatus : messageStatus,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("updateMsgStatusBySequence");
        // params.push(userId);
        // params.push(peerId);
        // params.push(lastReadSequence);
        // params.push(messageStatus);
     
        // worker.postMessage(params);
    },
    updatePeerNameForSessionToLDB:function(userId, contact, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updatePeerNameForSessionToLDB",
            userId : userId,
            contact : contact,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    bulkAddToLDB:function(userId, messages, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkAddToLDB",
            userId : userId,
            messages : messages,
            callId: callId
        };

        this.worker.postMessage(params);
       
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("bulkAddToLDB");
        // params.push(userId);
        // params.push(messages);
     
        // worker.postMessage(params);
    },
    getAllBySessionIdFromLDB:function(userId, sessionId, callback){	
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getAllBySessionIdFromLDB");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
	},
    getAllBroadcastBySessionTypeFromLDB:function(userId, callback){	
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllBroadcastBySessionTypeFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getAllBroadcastBySessionTypeFromLDB");
        // params.push(userId);
     
        // worker.postMessage(params);
	},
    getDeleteStatusBySessionIdFromLDB:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getDeleteStatusBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);	
       	//  var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getDeleteStatusBySessionIdFromLDB");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
	},
    getAllDeletedBySessionIdFromLDB:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllDeletedBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);	
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getUnreadMessageCountBySessionIdFromLDB");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
	},
     getUnreadMessageCountBySessionIdFromLDB:function(userId, sessionId, callback){	
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getUnreadMessageCountBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getUnreadMessageCountBySessionIdFromLDB");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
	},
    getTotalMessageCountBySessionIdFromLDB:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getTotalMessageCountBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    getAllNonUploadMessagesFromLDB:function(userId, callback){	
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllNonUploadMessagesFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getAllNonUploadMessagesFromLDB");
        // params.push(userId);
     
        // worker.postMessage(params);
	},
    getByMsgIdFromLDB:function(userId, messageId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getByMsgIdFromLDB",
            userId : userId,
            messageId : messageId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    getRecentMessageForSessionId:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getRecentMessageForSessionId",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getRecentMessageForSessionId");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
    },
    getLastSequenceMessageForSessionId:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getLastSequenceMessageForSessionId",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getLastSequenceMessageForSessionId");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
    },
    getMessageByFileId:function(userId, fileId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getMessageByFileId",
            userId : userId,
            fileId : fileId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    getAllMessagesByMsgTypeForSessionId:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllMessagesByMsgTypeForSessionId",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("getAllMessagesByMsgTypeForSessionId");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
    },
    getAllMediaMessageForSessionId:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllMediaMessageForSessionId",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    deleteAllBySessionIdFromLDB:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data); 
        //    worker.terminate();
        // }; 

        // var params = [];
        // params.push("deleteAllBySessionIdFromLDB");
        // params.push(userId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
	},
    deleteAllChannelMsgBySessionIdFromLDB:function(userId, sessionId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllChannelMsgBySessionIdFromLDB",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    deleteByMessageIdForSessionIdFromLDB:function(userId, messageId, sessionId, deleteType, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteByMessageIdForSessionIdFromLDB",
            userId : userId,
            messageId : messageId,
            sessionId : sessionId,
            deleteType : deleteType,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("deleteByMessageIdForSessionIdFromLDB");
        // params.push(userId);
        // params.push(messageId);
        // params.push(sessionId);
     
        // worker.postMessage(params);
	},
	deleteAllFromLDB:function(userId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
        // var worker = new Worker('src/database/dao/messages-dao.js');
        // worker.onmessage = function(event) {
        //    console.log('DB Message ' + event.data);
        //    callback(event.data);
        //     worker.terminate();
        // }; 

        // var params = [];
        // params.push("deleteAllFromLDB");
        // params.push(userId);
     
        // worker.postMessage(params);
    },
    updateDataForSessionToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateDataForSessionToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    updateMsgStatusBySequence:function(userId, peerId, lastReadSequence, messageStatus, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateMsgStatusBySequence",
            userId : userId,
            peerId : peerId,
            lastReadSequence: lastReadSequence,
            messageStatus: messageStatus,
            callId: callId
        };

        this.worker.postMessage(params);
        
    },
    updateMsgStatusBySequence:function(userId, peerId, lastReadSequence, messageStatus, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateMsgStatusBySequence",
            userId : userId,
            peerId : peerId,
            lastReadSequence: lastReadSequence,
            messageStatus: messageStatus,
            callId: callId
        };

        this.worker.postMessage(params);
    }
	
};

MessagesDAOWorker.getInstance = function(){
    if(!MessagesDAOWorker.instance){
        MessagesDAOWorker.instance = new MessagesDAOWorker();
        MessagesDAOWorker.instance.startWorker();
    }
    return MessagesDAOWorker.instance;
};
