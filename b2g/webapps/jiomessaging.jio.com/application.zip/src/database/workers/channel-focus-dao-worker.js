function ChannelsFocusDAOWorker() {
    this.worker = null;
    this.nextCallId = 0;
    this.callbacks = {};
}
ChannelsFocusDAOWorker.prototype = {
	constructor: ChannelsFocusDAOWorker,
    startWorker:function(){
        console.log("In channel focus dao worker start worker");
        var that = this;
        this.worker = new Worker('src/database/dao/channels-focus-list-dao.js');
        
        this.worker.onmessage = function(event) {
            if (!that.callbacks[event.data.callId]) {
                    // console.log('worker ' + event.data.callId + ' callback not defined');
            }else{
                    // send data to callback function
                    that.callbacks[event.data.callId](event.data.result);
                
                    // remove callback reference
                    that.callbacks[event.data.callId] = null;
            }
        };     
	},
    
    bulkAddOfFocusChannelToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkAddOfFocusChannelToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
       
    },
    updateFocusChannelByDataToLDB:function(userId, data, callback){
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateFocusChannelByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    updateSessionDataByChannelIdToLDB:function(userId, unreadCount, data, callback){
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateSessionDataByChannelIdToLDB",
            userId : userId,
            unreadCount: unreadCount,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    
    getAllFocusChannelsFromLDB:function(userId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllFocusChannelsFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    
     
    getByFocusIdFromLDB:function(userId, channelId, callback){  
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getByFocusIdFromLDB",
            userId : userId,
            channelId : channelId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    bulkUpdateToFocusLDB:function(userId, data, callback){
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkUpdateToFocusLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
   
	deleteAllFocusFromLDB:function(userId, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
    },

    updateRecentMessageBySessionId:function(userId, sessionId, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateRecentMessageBySessionId",
            userId : userId,
            sessionId : sessionId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    deleteFocusChannelById:function(userId, channelId, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteFocusChannelById",
            userId : userId,
            channelId : channelId,
            callId: callId
        };

        this.worker.postMessage(params);
	},
	
};

ChannelsFocusDAOWorker.getInstance= function(){
     if(!ChannelsFocusDAOWorker.instance){
        ChannelsFocusDAOWorker.instance = new ChannelsFocusDAOWorker();
        ChannelsFocusDAOWorker.instance.startWorker();
     }
    return ChannelsFocusDAOWorker.instance;
};
