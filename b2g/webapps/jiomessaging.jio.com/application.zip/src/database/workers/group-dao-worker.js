function GroupDAOWorker() {
}

GroupDAOWorker.prototype = {
	constructor: GroupDAOWorker,
    addToLDB:function(userId, callback){
        var worker = new Worker('src/database/dao/group-dao.js');
        worker.onmessage = function(event) {
           console.log('DB Message ' + event.data);
        }; 

        var params = [];
        params.push("addToLDB");
        params.push(userId);
        // params.push(callback);
        
        // for(var i=0;i<10000;i++){
             worker.postMessage(params);
        // }
       
    },
    deleteByGroupIdFromLDB:function(userId, groupId, callback){
        var worker = new Worker('src/database/dao/group-dao.js');
        worker.onmessage = function(event) {
           console.log('DB Message ' + event.data);
        }; 

        var params = [];
        params.push("deleteByGroupIdFromLDB");
        params.push(userId);
        params.push(groupId);
      
    //   debugger;
        worker.postMessage(params);
    }
	
};

GroupDAOWorker.getInstance= function(){
    if(!GroupDAOWorker.instance){
        GroupDAOWorker.instance = new GroupDAOWorker();
    }
    return GroupDAOWorker.instance;
};
