function ChannelsDAOWorker() {
    this.worker = null;
    this.nextCallId = 0;
    this.callbacks = {};
}
ChannelsDAOWorker.prototype = {
	constructor: ChannelsDAOWorker,
    startWorker:function(){
        var that = this;
        this.worker = new Worker('src/database/dao/channels-list-dao.js');
        
        this.worker.onmessage = function(event) {
            if (!that.callbacks[event.data.callId]) {
                    // console.log('worker ' + event.data.callId + ' callback not defined');
            }else{
                    // send data to callback function
                    that.callbacks[event.data.callId](event.data.result);
                
                    // remove callback reference
                    that.callbacks[event.data.callId] = null;
            }
        };     
	},
    addToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
       
    },
    bulkAddToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkAddToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
       
    },
    addByDataToLDB:function(userId, data, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    updateByDataToLDB:function(userId, data, callback){
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    bulkUpdateToLDB:function(userId, data, callback){
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "bulkUpdateToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    // bulkAddOfFocusChannelToLDB:function(userId, data, callback){
    //     var callId = this.nextCallId++;

    //     // register callback function
    //     this.callbacks[callId] = callback;

    //     var params = {
    //         functionName : "bulkAddOfFocusChannelToLDB",
    //         userId : userId,
    //         data : data,
    //         callId: callId
    //     };

    //     this.worker.postMessage(params);
       
    // },
    // updateFocusChannelByDataToLDB:function(userId, data, callback){
    //       var callId = this.nextCallId++;

    //     // register callback function
    //     this.callbacks[callId] = callback;

    //     var params = {
    //         functionName : "updateFocusChannelByDataToLDB",
    //         userId : userId,
    //         data : data,
    //         callId: callId
    //     };

    //     this.worker.postMessage(params);
	// },
    getAllFromLDB:function(userId, callback){
         var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    // getAllFocusChannelsFromLDB:function(userId, callback){
    //      var callId = this.nextCallId++;

    //     // register callback function
    //     this.callbacks[callId] = callback;

    //     var params = {
    //         functionName : "getAllFocusChannelsFromLDB",
    //         userId : userId,
    //         callId: callId
    //     };

    //     this.worker.postMessage(params);
	// },
    
    getByChannelIdFromLDB:function(userId, channelId, callback){  
          var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getByChannelIdFromLDB",
            userId : userId,
            channelId : channelId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    
    // getByFocusIdFromLDB:function(userId, channelId, callback){  
    //       var callId = this.nextCallId++;

    //     // register callback function
    //     this.callbacks[callId] = callback;

    //     var params = {
    //         functionName : "getByFocusIdFromLDB",
    //         userId : userId,
    //         channelId : channelId,
    //         callId: callId
    //     };

    //     this.worker.postMessage(params);
    // },
   
	deleteAllFromLDB:function(userId, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
	}
   
  
	
};

ChannelsDAOWorker.getInstance= function(){
    if(!ChannelsDAOWorker.instance){
        ChannelsDAOWorker.instance = new ChannelsDAOWorker();
        ChannelsDAOWorker.instance.startWorker();
    }
    return ChannelsDAOWorker.instance;
};
