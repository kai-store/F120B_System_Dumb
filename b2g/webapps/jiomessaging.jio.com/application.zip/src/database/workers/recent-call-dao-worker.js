function RecentCallDAOWorker() {
    this.worker = null;
    this.nextCallId = 0;
    this.callbacks = {};
}

RecentCallDAOWorker.prototype = {
    constructor: RecentCallDAOWorker,
    startWorker:function(){
        
        var that = this;
        this.worker = new Worker('src/database/dao/recent-call-dao.js');
       
        this.worker.onmessage = function(event) {
            if (!that.callbacks[event.data.callId]) {
                    // console.log('worker ' + event.data.callId + ' callback not defined');
            }else{
                    // send data to callback function
                    that.callbacks[event.data.callId](event.data.result);
                
                    // remove callback reference
                    that.callbacks[event.data.callId] = null;
            }
        };         
	},
    addToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;

        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
	},
    removeLastRecord:function(userId,callback){
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "removeLastRecord",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    getRecentLogByIdFromLDB:function(userId, callerId, callback){	
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getRecentLogByIdFromLDB",
            userId : userId,
            callerId : callerId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    addByDataLDB:function(userId, data, callback){
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "addByDataLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
        
    },
    updateByDataToLDB:function(userId, data, callback){
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "updateByDataToLDB",
            userId : userId,
            data : data,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    getAllFromLDB:function(userId, callback){
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "getAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    deleteByLogIdFromLDB:function(userId, callLogId, callback){
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteByLogIdFromLDB",
            userId : userId,
            callLogId : callLogId,
            callId: callId
        };

        this.worker.postMessage(params);
    },
    deleteAllFromLDB:function(userId, callback){
        var callId = this.nextCallId++;
        
        // register callback function
        this.callbacks[callId] = callback;

        var params = {
            functionName : "deleteAllFromLDB",
            userId : userId,
            callId: callId
        };

        this.worker.postMessage(params);
    
    }
 
};

RecentCallDAOWorker.getInstance= function(){
    if(!RecentCallDAOWorker.instance){
        RecentCallDAOWorker.instance = new RecentCallDAOWorker();
        RecentCallDAOWorker.instance.startWorker();
    }
    return RecentCallDAOWorker.instance;
};
