import React from 'react';
import ReactDOM from 'react-dom';
import JioBaseComponent from './shared/jioBaseComponent';
import OptionMenuRenderer from './shared/option_menu_renderer';
import DialogRenderer from './shared/dialog_renderer';
// import ReactSoftKey from 'react-soft-key';
import ReactSoftKey from './lib/react-soft-key';
import Service from 'service';
import history from './shared/my_history';
import HistoryManager from 'history-manager';
import Routes from './routes';
import '../scss/app.scss';
import 'common-scss';
import 'gaia-icons';
import './lib/l10n';
import CallStore from 'data/call-store';
import MessageStore from 'data/message-store';
import ChannelStore from 'data/channels-store';
import GroupListStore from 'data/groupList-store';
import ReactGA from 'react-ga';

// JioChatSDK
import JioChatSDK from './sdk/jio-sdk';

class App extends JioBaseComponent {
    name = 'App';    
    
    componentDidMount() {
        window.appInstance = this;
        window.isDev = false;
        window.isFromPush = false;
        window.deviceId = null;//UUID.randomUUIDHex(); // Hardcoding the device id
        window.msgNotificationEnabled = true;
        window.notificationSoundEnabled = true;
        window.notificationVibrationEnabled = true;
        window.chatSoundEnabled = true;
        window.showMessagePreview = true;
        window.msgDelayTime = 0;
        window.showLastSeen = true;
        window.showReadReceipt = true;
        window.dndFrom = ""; 
        window.dndTo = "";
        window.isTesting = false;
        window.isGroupListAPICalled = false;
        window.pageName = '';
        window.isReleaseBuild = true;//for testing making false, later make it true while pushing

        window.isFirstTimeJioAnalytics = true;
        window.deviceInfoLoaded = false;
        window.onSimChanged = false;
        window.silentPushCall = false;

        this.sdkObj = JioChatSDK.getInstance();
        this.isDeviceMode = this.sdkObj.isDeviceMode();
        if (this.isDeviceMode) {
            window.isFromPush = false;
            this.pushData = null;
        }

        history.replace('/splash');
        // AppConstants.videoFrameRateTestEnabled = true;//It should be true only if video frame change test needs to added
        var sdkInstance = JioChatSDK.getInstance();
        sdkInstance.setSDKCapability(AppMode.TYPE);
        AppConstants.windowHeight = window.innerHeight;

        // Set this value for local contacts when running in browser.
        // sdkInstance.setSDKMode(JCSDKConstants.SDK_DEBUG_MODE);

        if(AppMode.TYPE == "JMS"){ 
            UserModel.getInstance().setFAQlink('http://www.jiochat.com/faq_messages/');
        }
              
        window.getStartTimeForAnalytics = new Date();//Kaal updated
        // no need to set it here..added in lifecycle
        // var deviceInfo = new JCDeviceInfo();
        // deviceInfo.setDeviceID(window.deviceId);
        // sdkInstance.setDeviceInfo(deviceInfo);

        if(AppMode.TYPE  != AppMode.APP_TYPE_JSDK){
            this.setGAErrorUpdateCallback();
        }

        if(AppMode.TYPE != AppMode.APP_TYPE_JVC && AppMode.TYPE  != AppMode.APP_TYPE_JSDK){

            // this.setMessageLocalCallback();
            console.log("[app] listeners open");
            this.setOtherCallbacks();
            this.setUpdatesAvailableOnMessages();
            this.setMessageCallback();
            this.setGroupNotificationCallback();
            // this.setOfflineMessageCallback();
            this.setUploadCallback();
            this.setDownloadCallback();
            
        }

        //added by binesh to check internet connectivity
        this.checkInternetStatus();
        var that = this;

        var pushData = localStorage.getItem('PUSH_DATA');
        if(pushData) {
            localStorage.setItem('PUSH_RECEIVED', true);       
            var pushData = JSON.parse(pushData);
            var clientPushModel = ClientPushModel.getInstance();
            clientPushModel.setPushReceived(true);
            clientPushModel.setPushData(pushData.push_message); 
        }
    }

    checkInternetStatus(){
        var that = this;
        window.addEventListener("offline", function(e) {
            if(AppMode.TYPE == AppMode.APP_TYPE_JVC){
                ReactGA.event({
                    category: 'No internet available',
                    action: '',
                    label: 'Internet not available'
                });
                /* Jio analytic code *****/
                var analyticDataObj = {
                    "eventName" : "no_internet",
                    "eventType" : "events",
                    "dateTime" : new Date()
                };
                JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
            }
            console.log("Internet Disconnected");
            that.emit(AppConstants.EMIT_INTERNET_DISCONNECTED);
        }, false);
          
        window.addEventListener("online", function(e) {
            console.log("Internet Connected");
            that.emit(AppConstants.EMIT_INTERNET_CONNECTED);
        }, false);  
        
        window.addEventListener("visibilitychange", function() {
            console.log("[APP ] VISIBILITY CHANGED",document.visibilityState);
            that.emit(AppConstants.EMIT_VISIBILITY_CHANGED, document.visibilityState);
        });
    }
    

    setGAErrorUpdateCallback(){
        JIOUtils.setGAErrorUpddateCallback(function(gaObject){
            console.log("This is Ga error code test ");
            ReactGA.event({
                category: 'API error ',
                action: 'Videocall',
                label: 'API call failed'
            });
            /**** Jio analytics code */
            var analyticDataObj = {
                "eventName" : "APIerror_"+gaObject.method,
                "eventType" : "events",
                "exceptionType" : gaObject.event,   
                "exceptionMsg" : gaObject.msg,
                "errorMsg" : gaObject.errorCode,
                "dateTime" : new Date()
            };
            JioAnalytics.getInstance().callJioAnalyticHttp(analyticDataObj);
        });
    }    

    setMessageLocalCallback(){
        var that = this;
        var messageStore = MessageStore.getInstance();
        JioChatSDK.getInstance().setMessageLocalCallback({
            onMessageAdded: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.push(chatMsgObj);

                // Do emit
                that.updateMessagesLocally(msgArray);
                
            },
            onMessageSent: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }
                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(String(msgItem.msgId) == String(chatMsgObj.msgId)){
                        msgItem.msgStatus = chatMsgObj.msgStatus;
                        msgItem.msgSequence = chatMsgObj.msgSequence;
                        msgItem.msgDateTime = chatMsgObj.dateTime;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);

            },
            onMessageFailed: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = MessageStore.getInstance().currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = MessageStore.getInstance().getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(String(msgItem.msgId) == String(chatMsgObj.msgId)){
                        msgItem.msgStatus = chatMsgObj.msgStatus;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);
            },
            onMessageReceived: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.push(chatMsgObj);

                // Do emit
                that.updateMessagesLocally(msgArray);
            },
            onReply: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = MessageStore.getInstance().currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = MessageStore.getInstance().getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(String(msgItem.msgId) == String(chatMsgObj.msgId)){
                        msgItem.msgStatus = chatMsgObj.msgStatus;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);
            },
            onReadReply: function(chatMsgObj){
                if(!chatMsgObj) return;
                var currentPeerId = MessageStore.getInstance().currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }

                var msgArray = MessageStore.getInstance().getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                msgArray.forEach(function(msgItem, index){
                    if(msgItem.msgType != MessageConsts.TYPE_FREE_SMS && msgItem.msgType != MessageConsts.TYPE_UPDATE_STATUS && msgItem.msgSequence < chatMsgObj.msgSequence && msgItem.msgDirection == 0){
                        msgItem.msgStatus = MessageConsts.STATUS_READBYFRIEND;
                        // msgItem.msgSequence = chatMsgObj.msgSequence;
                    }
                });

                messageStore.setLocalMsgArray(msgArray);

                // Do emit with msgArray
                that.updateMessagesLocally(msgArray);
            },
            onOfflineMessagesReceived: function(chatMsgObj, chatMsgArr){
                
                if(!chatMsgArr) return;
                if(chatMsgArr.length < 1) return;

                if(!chatMsgObj) return;
                var currentPeerId = messageStore.currentPeerId;
                if(currentPeerId && currentPeerId != "" && String(chatMsgObj.sessionId) != String(currentPeerId)){
                    return;
                }
                var msgArray = messageStore.getLocalMsgArray();
                if(!msgArray){
                    msgArray = new Array();
                }

                chatMsgArr.forEach(function(cMsgObj, index){
                    msgArray.push(cMsgObj);
                });

                // Do emit
                that.updateMessagesLocally(msgArray);
            }
        });
    }

    setOtherCallbacks(){
        var that = this;
        JioChatSDK.getInstance().setOtherCallbacks({
            onUpdateContacts: function(){
                
            },
            onUpdateChannels: function(){

            },
            onUpdateExplore: function(){

            },
            onClearChatHistory: function(){
                that.updateChat();
                that.updateMessages();
            },
            onGroupInfoChanged: function(){
                that.updateGroupInfo();
            }
        });
    }

    setUpdatesAvailableOnMessages(){
        var that = this;
        JioChatSDK.getInstance().setUpdatesAvailableOnMessages({
            onMessagesAvailable: function(){
                that.updateChat();
                that.updateMessages();
            },
            onChatAvailable: function(){
                that.updateChat();
                that.updateMessages();
            },
            onBroadcastMessageAvailable: function(){
                that.updateChat();
                that.updateBroadcastMessages();
            },
            onBuddyLeave: function(){
                that.updateOnBuddyLeave();
            }
        });
    }

    setMessageCallback(){
        var that = this;
        JioChatSDK.getInstance().setMessageCallback({
            onMessageAdded: function(chatMessage){
                // debugger;
                console.log('onMessageAdded invoked. This will be invoked when message gets added to LDB');
            },
            onTextMessage: function(chatMessage){
                console.log('onTextMessage invoked');
                // debugger;
                that.updateChat();
                that.updateMessages();
            },
            onTyping: function(userId){
                // debugger;
                console.log('onTyping invoked');
                that.updateTypingNotification(userId);
            },
            onReply: function(peerId, messageId, chatMsg){
                // debugger;
                console.log('onReplyInvoked invoked');
                that.updateMessages();
            },
            onReadReply: function(peerId, isReadOtherOne, lastReadSeq, chatMsg){
                // debugger;
                console.log('onReadReply invoked');
                that.updateMessages();
            },

            //Offline message callback
            onMessagesReceived: function(chatMessages){
                
                console.log('onMessagesReceived invoked');
                that.updateChat();
                that.updateMessages();
            },
            onOfflineMessagesReceived: function(chatMessages){
                // debugger;
            },
            onOfflineMessageSent: function(chatMessage){
                // debugger;
                console.log('onOfflineMessageSent invoked');
            },
            onOfflineMessageSentError: function(errResponse){
                // debugger;
                console.log('onOfflineMessageSentError invoked');
            },

            onMessageSent: function(chatMessage){
                console.log('onMessageSent invoked');
                that.updateChat();
                that.updateMessages();
            },
            onMessageSentError: function(errResponse){
                console.log('onMessageSentError invoked');
            },

            onContactReceived: function(response){
                // debugger;
            },
            onContactError: function(errResponse){
                // debugger;
            },

            onContactPortraitReceived: function(response){
                // debugger;
            },
            onContactPortraitError: function(contRes, errResponse){
                // debugger;
            },

            onGroupInfoReceived: function(response){
                // Take only the group title
                // debugger;
            },
            onGroupInfoError: function(groupId, errResponse){
                // debugger;
            },

            onGroupMembersReceived: function(groupResponse){
                //Take the group title & the members list
                // debugger;
            },
            onGroupMembersError: function(groupId, version, errResponse){
                // debugger;
            },

            onGroupPortraitReceived: function(response){
                // debugger;
            },
            onGroupPortraitError: function(errResponse){
                // debugger;
            }
        });
    }

    setGroupNotificationCallback(){
        var that = this;
        JioChatSDK.getInstance().setGroupNotificationCallback({
            onGroupJoined: function(group, version){
                console.log("onGroupJoined invoked. Will be invoked whenever you joined to a new group");
                that.updateChat();
            },
            onGroupInfoChanged: function(group, sourceId, name, version, groupMaxCount, updateUserName){
                console.log("onGroupInfoChanged invoked. Will be invoked whenever groupName changed");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupBuddyUpdate: function(group, version, sourceId, sourceName, newMembers, isFromInvite){
                console.log("onGroupBuddyUpdate invoked. Will be invoked whenever member added to the group");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupBuddyLeave: function(group, version, sourceId, sourceName, newMembers){
                console.log("onGroupBuddyUpdate invoked. Will be invoked whenever member removed from the group");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupSetChanged: function(groupId, msgType){
                console.log("onGroupSetChanged invoked.");
            },
            onGroupJoinedSyncNotify: function(groupId){
                console.log("onGroupJoinedSyncNotify invoked.");
            },
            onGroupPortraitChanged: function(group, version, portraitId, portraitSize, sourceId, thumb){
                console.log("onGroupPortraitChanged invoked. Will be invoked whenever group profile photo changed/updated");
                that.updateGroupInfo();
                // that.emit('onGroupPortraitChanged', group);
            },
            onGroupAdminUpdated: function(group, newAdminUserId, newAdminUserName, version){
                console.log("onGroupAdminUpdated invoked. Will be invoked when admin transfers its group admin rights to other member");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            },
            onGroupAdminUpdatedForNewAdmin: function(group, version){
                console.log("onGroupAdminUpdated invoked. Will be invoked when admin quit group & transfers admin rights to other member");
                that.updateChat();
                that.updateMessages();
                that.updateGroupInfo();
            }
        });
    }

  setUploadCallback(){
    var that = this;
    JioChatSDK.getInstance().setUploadCallback({
        onProgressChanged: function(attachment){
            that.emit(AppConstants.EMIT_FILE_UPLOAD_PROGRESS_CHANGED, attachment);
        },
        onSuccess: function(attachment){
            that.emit(AppConstants.EMIT_FILE_UPLOAD_SUCCESS, attachment);
        },
        onError: function(attachment){
            that.emit(AppConstants.EMIT_FILE_UPLOAD_ERROR, attachment);
        }
    });
  }

  setDownloadCallback(){
      var that = this;
      JioChatSDK.getInstance().setDownloadCallback({
        onProgressChanged: function(attachment){
            that.emit(AppConstants.EMIT_FILE_DOWNLOAD_PROGRESS_CHANGED, attachment);
        },
        onSuccess: function(attachment){
            that.emit(AppConstants.EMIT_FILE_DOWNLOAD_SUCCESS, attachment);
        },
        onError: function(attachment){
            that.emit(AppConstants.EMIT_FILE_DOWNLOAD_ERROR, attachment);
        }
    });
  }

  updateChat(){
      if(this.isLocationExists("home") || this.isLocationExists("chatlist")){
          this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_CHAT_HISTORY, true);
        }
        if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
            this.emit(AppConstants.UPDATES_AVAILABLE_ON_RECENT_CHANNELS);
        }
    }

  updateMessages(){
      if(this.isLocationExists("chatDetail") || this.isLocationExists("imagepreview")){
            this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_MESSAGES);
        }
    }

    updateOnBuddyLeave(){
        this.emit(AppConstants.EMIT_SESSION_REMOVED_ON_BUDDY_LEAVE);
    }

    updateMessagesLocally(msgArray){
      if(this.isLocationExists("chatDetail")){
            this.emit(AppConstants.EMIT_LOCAL_UPDATES_AVAILABLE_ON_MESSAGES, msgArray);
        }
    }
  
  updateBroadcastMessages(){
      if(this.isLocationExists("broadcastDetailView")){
            this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_BROADCAST_MESSAGES);
        }
    }

  updateGroupInfo(){
      if(this.isLocationExists("home") || this.isLocationExists("chatlist") || this.isLocationExists("chatDetail") || this.isLocationExists("groupInformation")){
            this.emit(AppConstants.EMIT_UPDATES_AVAILABLE_ON_CHAT_WHEN_GROUP_INFO_CHANGED, true);
        }
    }
    
updateTypingNotification(userId){
    if(this.isLocationExists("home") || this.isLocationExists("chatlist")){
        this.emit(AppConstants.ON_TYPING_NOTIFICATION, userId);
    }

    else if(this.isLocationExists("chatDetail")){
        this.emit(AppConstants.EMIT_TYPING_NOTIFICATION_ON_CHAT_DETAIL, userId);
    }
}

  isLocationExists(pageName){
    if(AppMode.TYPE == AppMode.APP_TYPE_DESKTOP) {
        return true;
      }
      
      return window.location.href.toLowerCase().indexOf(pageName.toLowerCase()) > -1 ? true : false;
    }
 
    render() {
        return (
            <div id='app' tabIndex='-1'>
                <div className="statusbar-placeholder"></div>
                <HistoryManager className="margin-bottom" ref="history" history={history} routes={Routes} />
                <ReactSoftKey ref="softkey" />
                <div id="menu-root" ></div>
                <DialogRenderer />
            </div>
        );
    }
}
window.__myapp_container = document.getElementById('root');
ReactDOM.render(<App />, document.getElementById('root'));
