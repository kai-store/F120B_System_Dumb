function HTTPRequest(url){
	this.url = url;
	this.header = [];
	this.body = null;
	this.reqMethod = 'GET';
	this.reqType = 0;
	this.callbackMethod = null;
	this.responseParser = 1;
	this.isCallbackCINObj = false;
	this.httpHeader = [];
}
/**
 * Class is for creating CINRequest, and setting an appropriate values.
 */
HTTPRequest.prototype = {	
	/**
	 * Setting for request type, 
	 */	
	getRequestMethod: function(){
		return this.reqMethod;
	},

	setCINResponseParser: function(){
		this.responseParser = 0;
	},

	isCINResponseParser: function(responseParser){
		return this.responseParser !== 1;
	},
	
	isCINMessageObject: function(){
		return this.isCallbackCINObj === true;
	},

	setCINMessageObject: function(){
		this.isCallbackCINObj = true;
	},
	/**
	 * Setting for request type, 
	 */	
	setRequestMethod: function(reqMethod){
		this.reqMethod = reqMethod;
	},

	/**
	 * XHttp header field, 
	 */	
	addHTTPHeader: function(id, value){
		this.httpHeader.push(id);
		this.httpHeader.push(value);
	},

	addHeader: function(id, value, convertValueBase64){
		if(convertValueBase64 != undefined && convertValueBase64 === true){
			value = CinBase64.encode(value);
		}
		var obj = {};
		obj[id] = value;
		this.header.push(obj);
	},
	
	setBody: function(value){
		this.body = value;
	},
	
	setCallback: function(callback){
		this.callbackMethod = callback;
	},

	getCallback: function(){
		return this.callbackMethod;
	},
	
	setMetaInfo: function(method, event){
		JIOUtils.initCallback(this.callbackMethod, method, event);
	}
}

HTTPRequest.prototype.prepareHTTPRequest = function(xhttp){
	var payload = '?';
	Object.keys(this.header).forEach(function(key, index) {
		 payload = payload + Object.keys(this[key])[0] + '=' + this[key][Object.keys(this[key])[0]] + '&';	     
	}, this.header);	
	console.log(payload);
	payload = payload.slice(0, -1);
	console.log(payload);
	//xhttp.header('Access-Control-Allow-Origin', '*');
	xhttp.open(this.getRequestMethod(), 
				this.url + payload, true);
	if(this.httpHeader.length > 0)		
      xhttp.setRequestHeader(this.httpHeader[0], this.httpHeader[1]);
	return xhttp;
}
