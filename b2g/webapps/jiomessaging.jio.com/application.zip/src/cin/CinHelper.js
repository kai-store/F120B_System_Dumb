function CinHelper() {
	// body...
}

function JIOUtils.long2Bytes(value) {
	if (value != 0) {
		var zeros = Long.numberOfLeadingZeros(value);
		var length = 8 - zeros / 8;
		byte[] rawValue = new byte[length];
		for (var i = 0; i < length; i++) {
			rawValue[i] = (byte) (value >>> ((i) * 8));
		}
		return rawValue;
	}
	else {
		return new byte[] { (byte) 0 };
	}
}
