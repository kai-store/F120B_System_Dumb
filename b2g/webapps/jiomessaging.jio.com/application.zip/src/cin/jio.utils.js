function JIOUtils () {
}

JIOUtils.getKeyAsString=function(key){
	switch(key){
		case 0x0B:
            return "pwdPattern";
		case CINRequestConts.CREDENTIAL: 
			return "credential";
		case CINRequestConts.HEADER_TYPE_CONTACT_VERSION: 
			return "contactVersion";	 
		case CINRequestConts.HEADER_TYPE_REVERSE_CONTACT_VERSION: 
			return "reverseContactVersion";
		case CINRequestConts.HEADER_TYPE_SWITCH_VALUE: 
			return "HEADER_TYPE_SWITCH_VALUE";
		case CINRequestConts.HEADER_TYPE_GROUP_MAX_COUNT: 
			return "groupMaxCount";
		case CINRequestConts.HEADER_TYPE_DND_START: 
			return "DndStart";
		case CINRequestConts.HEADER_TYPE_DND_INTERVAL: 
			return "DndInterval";
		case CINRequestConts.EXPIRE: 
			return "expire";
		case CINRequestConts.EVENT: 
			return "event";							
		case CINRequestConts.VERSION: 
			return "version";
		case CINRequestConts.INDEX: 
			return "index";
		case CINRequestConts.NAME: 
			return "name";
		case CINRequestConts.SUBVERSION: 
			return "subVersion";
		case CINRequestConts.EMAIL: 
			return "email";
		case CINRequestConts.LANGUAGE: 
			return "language";
		case CINRequestConts.CAPABILITY: 
			return "capability";
		case CINRequestConts.ENCRYPT: 
			return "encrypt";
		case CINRequestConts.JIOMONEYMSG: 
			return "jioMoneyMsg";
	}
	return key;
};

JIOUtils.toString = function(buf) {
	if(typeof buf === 'string'){
		return buf;
	}
  // return String.fromCharCode.apply(null, new Uint16Array(buf));
  var encodedString, decodedString;
  try{
	  encodedString = String.fromCharCode.apply(null, new Uint8Array(buf));
 	  decodedString = window.decodeURIComponent(escape(encodedString));
  }
  catch(e){
	  console.log("Error:"+e);
	  decodedString="";
  }
  
  return decodedString;
};

JIOUtils.utf16to8 = function(str){
    var out, i, len, c;

    out = "";
	// debugger;
    len = str.length;
	var byteArray = new Array();
    for(i = 0; i < len; i++) {
		c = str.charCodeAt(i);
		if ((c >= 0x0001) && (c <= 0x007F)) {
			out += str.charAt(i);
			byteArray.push(str.charCodeAt(i));
		} else if (c > 0x07FF) {
			out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
			byteArray.push(0xE0 | ((c >> 12) & 0x0F));

			out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
			byteArray.push(0x80 | ((c >>  6) & 0x3F));

			out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
			byteArray.push(0x80 | ((c >>  0) & 0x3F));

		} else {
			out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
			byteArray.push(0xC0 | ((c >>  6) & 0x1F));

			out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
			byteArray.push(0x80 | ((c >>  0) & 0x3F));
		}
    }
    // return out;
	return byteArray;
}

JIOUtils.getBytes = function(str){
	if(!str || str.length==0){
		return JIOUtils.emptyByteArray();
	}
	var buf = new ArrayBuffer(str.length*2); // 2 bytes for each char
  	var bufView = new Uint16Array(buf);
  	for (var i=0, strLen=str.length; i<strLen; i++) {
    	bufView[i] = str.charCodeAt(i);
  	}
  	return Array.prototype.slice.call(bufView);

	// var bytes = []; // char codes
	// //var bytesv2 = []; // char codes

	// for (var i = 0; i < str.length; ++i) {
	//   var code = str.charCodeAt(i) & 0xff;

	//   bytes = bytes.concat(code);
	  
	//   //bytesv2 = bytesv2.concat([code & 0xff, code / 256 >>> 0]);
	// }
	// return bytes;
};

JIOUtils.doubleToBytes = function(number){
	var buffer = new ArrayBuffer(8);         // JS numbers are 8 bytes long, or 64 bits
	var longNum = new Float64Array(buffer);  // so equivalent to Float64

	longNum[0] = number;

	return Array.from(new Int8Array(buffer)).reverse();  // reverse to get little endian
}
JIOUtils.base64 = function(bytes){
    return window.btoa( JIOUtils.toString(bytes) );
};

JIOUtils.long2Bytes = function(value) {

	if (value != 0) {
		//vat str = i.toString(2);

		//JIOUtils.convertLongToByte(value);
		var zeros = JIOUtils.numberOfLeadingZeros(value);
		var length = 8 - parseInt(zeros / 8);
		rawValue = new Int8Array(length);
		for (var i = 0; i < length; i++) {
			var val = (value >>> i * 8)
			rawValue[i] = val;

		}
		return rawValue;
	}
	return JIOUtils.emptyByteArray();
}

JIOUtils.initCallback = function(callbackMethod, method, event){
	if(callbackMethod==null || callbackMethod==undefined){
		return;
	}
	var apiInfo = {"method": method, "event": event};
	callbackMethod.apiInfo = apiInfo;
}

JIOUtils.emptyByteArray = function(){
	rawValue = new Int8Array(1);
	rawValue[0] = 0;
	return rawValue;
}

JIOUtils.numberOfLeadingZeros = function(i) {
        // HD, Figure 5-6
     if (i == 0)
        return 64;
    var n = 1;
    var x = parseInt(i >>> 32);
    if (x == 0) { n += 32; x = parseInt(i); }

    /*if (i == 0)
        return 64;
    var n = 1;
    var x = (i >>> 32);
    if (x == 0) { n += 32; x = i; }
    if (x >>> 16 == 0) { n += 16; x <<= 16; }
    if (x >>> 24 == 0) { n +=  8; x <<=  8; }
    if (x >>> 28 == 0) { n +=  4; x <<=  4; }
    if (x >>> 30 == 0) { n +=  2; x <<=  2; }
    n -= x >>> 31;

    return n;*/
    return 64 - i.toString(2).length;

};

JIOUtils.toLong = function(/*byte[]*/byteArray) {
    var value = 0;
    for ( var i = byteArray.length - 1; i >= 0; i--) {

    	var byte = byteArray[i];
    	if(byte<0){
    		byte = 256 + byte;
    	}
        value = (value * 256) + byte;
    }
    return value;
};

//http://stackoverflow.com/questions/15761790/convert-a-32bit-integer-into-4-bytes-of-data-in-javascript

JIOUtils.convertLongToByte =  function(i){

	var zeros = JIOUtils.numberOfLeadingZeros(i);
	var length = 8 - parseInt(zeros / 8);

	arr = new ArrayBuffer(length); // an Int32 takes 4 bytes
    view = new DataView(arr);
    view.setInt32(0, i, true); // byteOffset = 0; litteEndian = false
    var byteArray = new Int8Array(length);

    for(index = 0; index<length; index++){
    	byteArray[index] = view.getInt8(index);
    }
    return arr;
 	// var result = [];
 	// var mask = 255;
 	// while( i > 0){
 	// 	var byte = i & mask;
 	// 	result.push(byte);
 	// 	i = i>>8;
 	// }
 	// return result;

};

JIOUtils.copyDataBytes=function(buffer,offset, values){
	for(index=0;index<values.length;index++){
		var value=values[index];
		buffer.setInt8(offset+index, value);
	}
	return offset+values.length;
};


JIOUtils.length = function(){

}

JIOUtils.getVal = function(values, index){
	if(values instanceof ArrayBuffer){
		
	}
};

JIOUtils.log=function(buffer, length){
	var str="[";
	for(logIndex=0;logIndex<length;logIndex++){
		// str+="("+logIndex+")->"+buffer.getInt8(logIndex)+",";
		str+=buffer.getInt8(logIndex)+",";
	}
	str+="]";
	console.log(str);
};

JIOUtils.logArray=function(array, length){
	var len = array.length;//>255?255:array.length;
	var str="[";
	for(var logIndex=0;logIndex<len;logIndex++){
		// str+="("+logIndex+")->"+buffer.getInt8(logIndex)+",";
		str+=array[logIndex]+",";
	}
	if(len!=array.length){
		str+=".... More";
	}
	str+="]";
	console.log(str);
};

JIOUtils.isEmpty = function(str) {
    return (str.length === 0 || !str.trim());
};

JIOUtils.toHexString = function(byteArray) {
    var chars = [];
    for(var i = 0, n = byteArray.length; i < n;) {
        chars.push(((byteArray[i++] & 0xff) << 8) | (byteArray[i++] & 0xff));
    }
    return String.fromCharCode.apply(null, chars);
};

JIOUtils.toByteArray = function(hexString) {
	hexString = hexString.toLowerCase();
	if(hexString.length%2!==0){
		hexString = "0"+hexString;
	}
	var len = parseInt(hexString.length / 2);
	byteArray = new Int8Array(len);
	var k = 0;
	for (i = 0; i < len; i++) {
		var high = Number('0x'+hexString[k]);
		var low = Number('0x'+hexString[k+1]);
		high = high & 0xff;
		low  = low & 0xff;
		byteArray[i] = CinBase64.getByte((high << 4 | low));
		k += 2;
	}
	return byteArray;
}

JIOUtils.toDoubleBytes = function(num){
	var buffer = new ArrayBuffer(8);         // JS numbers are 8 bytes long, or 64 bits
	var longNum = new Float64Array(buffer);  // so equivalent to Float64

	// longNum[0] = value;
	longNum[0] = num;//value;

	return Array.from(new Int8Array(buffer)).reverse(); 

}
JIOUtils.getDouble = function(value){
	var data=new Int8Array(value);
	var buf = new ArrayBuffer(8);
	// Create a data view of it
	var view = new DataView(buf);

	// set bytes
	data.forEach(function (b, i) {
		view.setUint8(i, b);
	});

	// Read the bits as a float; note that by doing this, we're implicitly
	// converting it from a 32-bit float into JavaScript's native 64-bit double
	var num = view.getFloat64(0);
		
	return value;
}

JIOUtils.trackEvent = function(errorCode, msg, callback){
	// if(!callback || callback === null || !callback.apiInfo || callback.apiInfo == undefined || callback.apiInfo == null){
	// 	return;
	// }
	try{
		if(!msg){
			msg = "Unknown error!!";
		}
		if(typeof msg !== 'string'){
			msg = JIOUtils.toString(msg);
		}

		if(msg.toLowerCase().includes('log out') || msg.toLowerCase().includes('logged out') || msg.toLowerCase().includes('logout')){
			console.log("user is logged out");
			return;
		}
		
		var apiInfo, gaObject;// = callback.apiInfo
		if(callback.apiInfo){
			apiInfo = callback.apiInfo
			var method = apiInfo.method;
			if(!method || method==undefined || method==null){
				method="SERVICE";
			}
			var event = apiInfo.event;
			if(!event || event == undefined || event == null){
				event = "NO_EVENT";
			}
			gaObject = {
				errorCode:errorCode,
				method:method,
				event:event,
				msg:msg
			};			
			console.log("GA: "+" errorCode "+errorCode+" Method:"+method+", Event: "+ event+" Msg:"+msg);	
		}else{
			gaObject = {
				errorCode:errorCode,
				method:"",
				event:"",
				msg:msg
			};
		}

		if(this.GAErrorUpddateCallback){
			console.log("sending gaObject to GAErrorUpddateCallback, gaObject is",gaObject);
			
			this.GAErrorUpddateCallback(gaObject);		
		}else{
			console.log("GAErrorUpddateCallback is not present for jsdk, gaObject is",gaObject);
		}
	}catch(e){
		console.log("GA Error:"+e);
	} 
}

JIOUtils.sendError = function(code, msg, callback, errorCode){
	//Check onError method is implemented?
	if(!callback || callback === null || typeof callback.onError !== "function"){
		return;
	}

	if(!msg){
		msg = "Unknown error!!";
	}
	if(msg.errCode !== undefined && msg.errCode !==null){
		callback.onError(msg, errorCode);
		return;
	}
	
	if(typeof msg !== 'string'){
		// if(msg.length % 4 === 0){
		// 	msg = CinBase64.decode(msg);
		// }
		msg = JIOUtils.toString(msg);
	}

	if(msg.toLowerCase().includes('log out') || msg.toLowerCase().includes('logged out')){
		// debugger;
		// code = ErrorCodes.FORCED_LOGOUT;
		instance = JIOClient.getInstance();
		callback = instance.getNotificationCallback();
		var sdkInstance = JioChatSDK.getInstance();
		if(!(sdkInstance.isSDKMode()==JCSDKConstants.SDK_DISABLED_MODE && sdkInstance.isDeviceMode())){
			UserModel.getInstance().clearAll();
			callback.onLogoff();
			return;
		}
		DeviceModel.deleteJioFileFromDevice(UserModel.getInstance().getFileName(),{
			onSuccess: function(){
				console.log("[Model:: User] user model file deleted");
				UserModel.getInstance().clearAll();
				callback.onLogoff();
			},
			onError: function(){
				UserModel.getInstance().clearAll();
				// console.log("[Model:: User] error while deleting user model file");
				callback.onLogoff();
			}
		});
		return;
	}
	if(callback && callback!==null && typeof callback.onError === "function")
		callback.onError({"errCode":code, "errMsg":msg}, errorCode);
};

JIOUtils.getRandomString = function(){
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 100; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
};

JIOUtils.toDate = function(dateByteArray){
	return new Date(JIOUtils.toLong(dateByteArray));
}

JIOUtils.toImage = function(imgByteArray){
	 return 'data:image/jpeg;base64,' + btoa(String.fromCharCode.apply(null, new Uint8Array(imgByteArray)));
}

JIOUtils.isUserIDExsits = function(uids,uid){
	var userIDsLong = new Array();
	for(userIDIndex = 0; userIDIndex< uids.length; userIDIndex++){
		userIDsLong[userIDIndex] = JIOUtils.toLong(uids[userIDIndex]);
	}
	var userIDLong = JIOUtils.toLong(uid);
	return userIDsLong.indexOf(userIDLong)!==-1;
}

JIOUtils.getTruncatedString = function(str){
	if(str || str=== null){
		return "";
	}
	 return str.substring(0, 255-2);
}

JIOUtils.getSockAddess = function(IPvalue){
	if(!IPvalue || IPvalue === null || IPvalue.length === 0){
		return null;
	}
    var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\:(\d{1,4})$/;
    var ipArray = IPvalue.match(ipPattern);

    var isValidIP = (ipArray !== null);
	var ipAddress  = "ws"
	if(!isValidIP){
		ipAddress+= "s";
	}
	return ipAddress+="://"+IPvalue;

} 
JIOUtils.toInt8Array = function(data){
	if(data instanceof Object){
		return new Int8Array(JIOUtils.objectToArray(data));
	}
	return data;
}
JIOUtils.objectToArray=function(data){
    var arr=new Array();
    for( var i in data ) {
        if (data.hasOwnProperty(i)){
            arr.push(data[i]);
        }
    }
    return arr;
};

JIOUtils.setGAErrorUpddateCallback = function(callback){
    this.GAErrorUpddateCallback = callback;
};

