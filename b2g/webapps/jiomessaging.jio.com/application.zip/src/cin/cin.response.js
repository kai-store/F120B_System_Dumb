function CINResponse(callback){
	this.resHeaders = [];
	this.resBody = [];
	this.cinMethod = null;
	this.callbackMethod = callback;
	this.isCallbackCINObj = false;
}

CINResponse.REQUEST = CinBase64.getByte(0x7F);
/**
 * Class is for creating CINRequest, and setting an appropriate values.
 */
CINResponse.prototype = {
	constructor: CINResponse,
	_setCinMethod: function(cinMethod){
		// data = new Int8Array([cinMethod]);
		// this.cinMethod = data[0];
		this.cinMethod = cinMethod;
	},

	isMethod: function(method){
		return this.cinMethod === method;
	},

	isServerRequest: function(){
		return ((this.cinMethod | CINResponse.REQUEST) === CINResponse.REQUEST);
	},


	getMethod: function(){
		return this.cinMethod;
	},

	getEvent:  function(){
		var event = this.getHeader(CINRequestConts.REQ_EVENT);
		if(event.length === 0){
			return 0;
		}
		return JIOUtils.toLong(event);
	},

	getHeaders: function(headerKey){
		if(!headerKey || headerKey === null){
			return this.resHeaders;
		}
		var headers  = new Array();
		for(index=0; index<this.resHeaders.length; index++){
			if(this.resHeaders[index].key === headerKey){
				headers.push(this.resHeaders[index].val);
			}
		}
		return headers;
	},
	// getHeadersWithKey: function(headerKey){
	// 	var headers  = new Arrary();
	// 	for(index=0; index<this.resHeaders.length; index++){
	// 		if(this.resHeaders[index].key === headerKey){
	// 			headers.push(this.resHeaders[index].val);
	// 		}
	// 	}
	// 	return headers;
	// },
	getHeader: function(headerKey){

		array = this.getHeaders(headerKey);
		if(array.length === 0)
			return "";

		return array[0];
	},

	getString: function(headerKey){
		var value = this.getHeader(headerKey);
		if(value && typeof value !== 'string')
			value = JIOUtils.toString(value);
		return value;
	},
	getObjStrings: function(headerKey){
		var values = this.getHeaders(headerKey);
		var arrStrings = new Array();

		values.forEach(function(val, index){
			arrStrings.push({"key":val.key, "val":JIOUtils.toString(val.val)});
		});
		return arrStrings;
	},
	getInt: function(headerKey){
		var value = this.getHeader(headerKey);
		if(value && typeof value !== 'string')
			return JIOUtils.toLong(value);
		if(value && typeof value === 'string')
			return parseInt(value);
		return 0;
	},	
	getFloat: function(headerKey){
		if(!this.containsHeader(headerKey)){
			return 0.0;
		}
		return JIOUtils.getDouble(this.getHeader(headerKey));
	},
	getBody: function(){
		if(this.resBody.length>0)
			return this.resBody[0].val;
		return null;
	},

	hasBody: function(){
	 	return this.resBody.length>0;
	},

	getBodys: function(){
		return this.resBody;
	},
	
	_setCallback: function(callback){
		this.callbackMethod = callback;
	},

	getCallback: function(){
		return this.callbackMethod;
	},

	_addHeader: function(key, value){		
		//this.resHeaders[key]=value;
		// var obj = {};
		// obj[key] = value;
		this.resHeaders.push({"key":key, "val":value});
	},

	_addBody: function(key, value){
		// var obj = {};
		// obj[key] = value;
		this.resBody.push({"key":key,"val":value});
	},
	
	/**
	 *
	 **/
	_getCINRequestHeaders: function(){

	},

	/**
	 *
	 **/
	_getCINRequestBody: function(){

	},
	containsHeader: function(headerKey){
		var val = this.getHeader(headerKey);
		if(val && val !==""){
			return true;
		}
		return false;
	}
};

/**
* Method for init response and invoke the callback.
**/
CINResponse.getCINMessage = function(data, callbackMethod, isDecoded){
	
	if(!isDecoded){
		isDecoded = false;
	}

	// var data = response;
	
	var cinResponse = new CINResponse(callbackMethod);

	if(data instanceof String)
		data = JIOUtils.getBytes(data);

	if (data[0] === 0x00){
		callbackMethod.onError({"error":"Unable to get data from server."});
		return;
	}

	cinResponse._setCinMethod(data[0]);	

	var index = 1;
	while(true){
		if (data[index] === CINRequestConts.END){
			index++;
			// index++;
		}

		if(!(index < data.length) || isNaN(index)){
			break;
		}

		if(cinResponse._isHeader(data[index])){
			var headerKey = data[index];
			index++;
			var size = data[index] & 0xFF;
			// var tmp = size & 0xFF;
			index++;
			var headerValue = data.slice(index, index+size);
			cinResponse._parseHeader(headerKey, headerValue, isDecoded);
			index+= size;
			continue;
		} 

		//if(this._isBody(response.charAt(index))){
		index++;
		var bodyKey = data[index];
		index++;
		var length1stByte = data[index];
		index++;
		var length = bodyKey & 0xFF | ((length1stByte & 0xFF) << 8);
		// index++;
		var bodyValue = data.slice(index, index+length);
		cinResponse._parseBody(bodyKey, bodyValue, isDecoded);
		index+= length;
		//}
	}
	return cinResponse;
};

CINResponse.prototype.toString = function(){	
	callback = this.callbackMethod;
	this.callbackMethod = undefined;
	var json = JSON.stringify(this);
	this.callbackMethod = callback;
	return json;
};

/**
* Method for init response and invoke the callback.
**/
CINResponse.prototype.convert = function(response, isDecoded){

	if(!isDecoded){
		isDecoded = false;
	}

	var data = response;
	
	if(response instanceof String)
		data = JIOUtils.getBytes(response);

	if (data[0] === 0x00){
		this.callbackMethod.onError({"error":"Unable to get data from server."});
		return;
	}

	this._setCinMethod(data[0]);

	var index = 1;
	while(true){

		if (data[index] === CINRequestConts.END){
			index++;
			index++;
		}
		
		if(!(index < data.length)){
			break;
		}

		if(this._isHeader(data[index])){
			var headerKey = data[index];
			index++;
			var size = data[index];
			index++;
			var headerValue = data.slice(index,index+size);
			this._parseHeader(headerKey, headerValue, isDecoded);
			index+= size;
			continue;
		} 

		//if(this._isBody(response.charAt(index))){
		index++;
		var bodyKey = data[index];
		index++;
		var length1stByte = data[index];
		index++;
		var length = length1stByte & 0xFF | ((data[index] & 0xFF) << 8);
		var bodyValue = data.slice(index, index+length);
		this._parseBody(bodyKey, bodyValue);
		index+= length;
		//}
	}
	_callback = this.callbackMethod;
	this.callbackMethod = undefined;
	var json = JSON.stringify(this);
	this.callbackMethod = _callback;
	this.callbackMethod.onSuccess(json);
};

CINResponse.prototype._isBody = function(headerKey){
	return headerKey === CINRequestConts.BODY;
}

CINResponse.prototype._isHeader =function(headerKey){
	return headerKey !== CINRequestConts.BODY;
}

CINResponse.prototype._parseHeader =function(headerKey, headerValue, isDecoded){
	this._addHeader(headerKey, headerValue);

	// if(isDecoded == undefined || isDecoded == null){
	// 	isDecoded=false;
	// }
	// switch(headerKey){
	// 	case CINRequestConts.FROM:
	// 	case CINRequestConts.TO:
	// 	case CINRequestConts.CALLID:
	// 	case CINRequestConts.TOKEN:
	// 	case CINRequestConts.SERVERDATA:
	// 	case CINRequestConts.PASSWORD:
	// 	case CINRequestConts.KEY:
	// 	case CINRequestConts.CSEQUENCE:
	// 	case CINRequestConts.MESSAGEID:
	// 	case CINRequestConts.DATETIME:
	// 	case CINRequestConts.CREDENTIAL:
	// 	case CINRequestConts.EXPIRE:
	// 	case CINRequestConts.ENCRYPT:
	// 	case CINRequestConts.INDEX:
	// 	case CINRequestConts.VERSION:
	// 	case CINRequestConts.TYPE:
	// 	case CINRequestConts.STATUS:
	// 	case CINRequestConts.HEADER_RCS_EXPRESSION:
	// 	case CINRequestConts.HEADER_RCS_GENDER:
	// 	case CINRequestConts.REQ_EVENT:
	// 		this._addHeader(headerKey, headerValue);
	// 		return;
	// }
	// if(isDecoded == undefined || isDecoded == null){
	// 	isDecoded=false;
	// }
	// switch(headerKey){
	// 	case CINRequestConts.FROM:
	// 	case CINRequestConts.TO:
	// 	case CINRequestConts.CALLID:
	// 	case CINRequestConts.TOKEN:
	// 	case CINRequestConts.SERVERDATA:
	// 	case CINRequestConts.PASSWORD:
	// 	case CINRequestConts.KEY:
	// 	case CINRequestConts.CSEQUENCE:
	// 	case CINRequestConts.MESSAGEID:
	// 	case CINRequestConts.DATETIME:
	// 	case CINRequestConts.CREDENTIAL:
	// 	case CINRequestConts.EXPIRE:
	// 	case CINRequestConts.ENCRYPT:
	// 	case CINRequestConts.INDEX:
	// 	case CINRequestConts.TYPE:
	// 	case CINRequestConts.STATUS:
	// 	case CINRequestConts.HEADER_RCS_EXPRESSION:
	// 	case CINRequestConts.HEADER_RCS_GENDER:
	// 	case CINRequestConts.REQ_EVENT:
	// 		this._addHeader(headerKey, headerValue);
	// 		return;
	// }
	
	// var value = "";
	// // for(index=0;index<headerValue.length;index++){
	// // 	value+=String.fromCharCode(headerValue[index]);
	// // }
	// var value = headerValue;
	// if(headerKey == CINRequestConts.NAME || headerKey == CINRequestConts.HEADER_RCS_NAME){
	// 	value = JIOUtils.toString(value);
	// 	this._addHeader(headerKey, value);
	// 	return;
	// }
	// var value = headerValue;
	//if(headerKey == CINRequestConts.NAME){
	// value = JIOUtils.toString(value);
	// }
	// else if(value && value.length >= 4){
	// 	if(!isDecoded && value.length%4 === 0){
	// 		value = CinBase64.decode(value);
	// 	}
	// 	value = JIOUtils.toString(value);
	// }
}

CINResponse.prototype._parseBody = function(bodyKey, bodyValue, isDecoded){
	if(isDecoded == undefined || isDecoded == null){
		isDecoded=false;
	}

	// var str = JIOUtils.getKeyAsString(bodyKey);
	var value = bodyValue;
	
	// if(value && value.length >= 4){
	// 	if(!isDecoded && value.length % 4 ==0){
	// 		value = CinBase64.decode(value);
	// 	}
	// }
	this._addBody(bodyKey, value, bodyValue);
}

CINResponse.prototype.toRequest = function(responseCode){
	if(!responseCode || responseCode === null){
		responseCode = HTTPRequestConts.OK;		
	}

	var cinReq = new CINRequest(responseCode, -1);

	for(var index=0; index<this.resHeaders.length; index++){
		var headerKey = this.resHeaders[index].key;
		switch(headerKey){
			case CINRequestConts.FROM:
			case CINRequestConts.TO:
			case CINRequestConts.CALLID:
			case CINRequestConts.CSEQUENCE:
				cinReq.addHeader(headerKey, this.resHeaders[index].val);
				break;							
		}
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback());
	/*JIOClient.getInstance().getCINClient().send(cinReq);*/
	return cinReq;
}

