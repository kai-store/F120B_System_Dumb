function CINRequest(method, event){
	this.header = [];
	this.reqBodyArray = [];
	this.reqBody = null;
	this.reqMethod = 0;
	this.reqType = 0;
	this.callbackMethod = null;
	this.tryCount = 0;
	
	this.isCallbackCINObj = false;
	
	this.isRefeshAfterLogon = true;
	this.isLogonReq = false;

	if(method && method !== null){
		this.setRequestMethod(method);
	}

	if(event && event !== null){
		this.setRequestEvent(event);
	}

	this.args = null;
}

/**
 * Class is for creating CINRequest, and setting an appropriate values.
 */
CINRequest.prototype = {
	/**
	 * Setting for request type, 
	 */
	setRequestMethod: function(reqType){
		this.reqType = reqType;
	},
		
	setRequestEvent: function(reqMethod){
		this.addHeaderInt8(CINRequestConts.REQ_EVENT, reqMethod);
	},

	isCINMessageObject: function(){
		return this.isCallbackCINObj === true;
	},

	setCINMessageObject: function(){
		return this.isCallbackCINObj = true;
	},

	addHeader:function(id, value){
		if(!value || value == undefined || value == null){
			return;
		}
		this.header.push({'key':id, "value":value});
	},
	addHeaderInt8: function(id, value){
		var _value = new Int8Array(1);
		_value[0] = value;

		this.addHeader(id, _value);
	},
	addHeaderDouble: function(id, value){
		var _value = JIOUtils.toDoubleBytes(value);
		this.addHeader(id, new Int8Array(_value));
	},
	addHeaderInt32: function(id, value){
		this.addHeader(id, JIOUtils.long2Bytes(value));
	},
	addHeaderFloat64: function(id, value){
		this.addHeader(id, JIOUtils.doubleToBytes(value));
	},
	addHeaderInt64: function(id, value){
		this.addHeader(id, JIOUtils.long2Bytes(value));
	},

	addHeaderString: function(id, value){
		this.addHeader(id, JIOUtils.getBytes(value));
	},
	
	addBody: function(id, value){
		if(!value || value == undefined || value == null){
			return;
		}
		this.reqBodyArray.push({'key':id, "value":value});
	},
	addBodyString: function(value){
		if(!value || value == undefined || value == null){
			return;
		}
		var data = JIOUtils.getBytes(value);
		while(data.length) {
    		this.addBody(CINRequestConts.BODY,data.splice(0,254));
		}
	},

	setCallback:function(callback){
		this.callbackMethod=callback;
	},

	getCallback: function(){
		return this.callbackMethod;
	},
	setMetaInfo: function(method, event){
		JIOUtils.initCallback(this.callbackMethod, method, event);
	},
	retry: function(){
		this.tryCount++;
	},

	getRetryCount: function(){
		return this.tryCount;
	},

	isMaxRetryReached: function(){
		return this.tryCount >= 3;
	},
	/**
	 *
	 **/
	_getCINRequestHeaders: function(){

	},

	/**
	 *
	 **/
	_getCINRequestBody: function(){
		
	},

	getHeader: function(headerKey){
		for(index=0; index<this.header.length; index++){
			if(this.header[index].key === headerKey){
				return this.header[index].value;
			}
		}
		return "";
	},
	getInt: function(headerKey){
		var value = this.getHeader(headerKey);
		if(value && typeof value !== 'string')
			return JIOUtils.toLong(value);
		if(value && typeof value === 'string')
			return parseInt(value);
		return 0;
	},	
	setIsRefeshAfterLogon: function(val){
		this.isRefeshAfterLogon = val;
	},
	getIsRefeshAfterLogon: function(){
		return this.isRefeshAfterLogon;
	},

	containsHeader: function(headerKey){
		var val = this.getHeader(headerKey);
		if(!val || val ==="" || val === undefined || val.length === 0){
			return false;
		}
		return true;
	}

};
CINRequest.prototype.setArgs = function(args){
	this.args = args;
}
CINRequest.prototype.getArgs = function(args){
	return this.args;
}
CINRequest.prototype.convert = function(){
	// console.log(this);
	var messageSize = 2;
	if(this.reqType === CINRequestConts.NO_METHOD){
		messageSize = 0;
	}
	
	for (var key in this.header){
	    if (this.header.hasOwnProperty(key)) {

	    	var val = this.header[key].value;
	    	var len = 1;
	    	if(val instanceof ArrayBuffer){
	    		len = val.byteLength;
	    	}else{	    		
	    			len = val.length;	    		
	    	}
			messageSize += len + 2;
		}
	}

	for (var key in this.reqBodyArray){
		 if (this.reqBodyArray.hasOwnProperty(key)) {
			messageSize += this.reqBodyArray[key].value.length + 3;
		}
	}
	var byteBuffer = new ArrayBuffer(messageSize);
	var buffer = new DataView(byteBuffer);

	offset = 0;
	if(this.reqType !== CINRequestConts.NO_METHOD){
		buffer.setInt8(offset, this.reqType);
		// JIOUtils.log(buffer,messageSize);
		offset++;
	}

	for(var key in this.header) {
	  if (!this.header.hasOwnProperty(key)) {
	  	continue;
	  }
		var length = this.header[key].value.length;
		var value = this.header[key].value;
		var _key = this.header[key].key;
		buffer.setInt8(offset, _key);
		offset++;

		// JIOUtils.log(buffer,offset);

		buffer.setInt8(offset, length);
		offset++;

		// JIOUtils.log(buffer,offset);

		if(length > 0){
			offset = JIOUtils.copyDataBytes(buffer, offset, value);
			// JIOUtils.log(buffer, offset);
		}
		
		//conver+= key+this.header[key].length+;
	}

	for(var key in this.reqBodyArray) {
		 if (!this.reqBodyArray.hasOwnProperty(key)) {
		 	continue;
		 }
		var length = this.reqBodyArray[key].value.length;
		var value = this.reqBodyArray[key].value;
		var bodyKey = this.reqBodyArray[key].key;
		buffer.setInt8(offset, bodyKey);
		offset++;

		buffer.setInt8(offset, (length & 0x000000FF));
		offset++;

		buffer.setInt8(offset, ((length >> 8) & 0x000000FF));
		offset++;

		if (length > 0) {
			offset = JIOUtils.copyDataBytes(buffer,offset, value);
			// buffer.put(b.getValue(), 0, length);
			//buffer.setInt8(value,0);
		}
		
		// conver+= key+this.reqBodyArray[key].length+this.reqBodyArray[key];
	}

	buffer.setInt8(messageSize-1, 0);
	console.log('--------');	
	JIOUtils.log(buffer,messageSize);

	// return CinBase64.encode(conver);
	var returnBuffer=[];
	for (var i=0;i<messageSize;i++){
		returnBuffer.push(buffer.getInt8(i));
	}
	return returnBuffer;
};
