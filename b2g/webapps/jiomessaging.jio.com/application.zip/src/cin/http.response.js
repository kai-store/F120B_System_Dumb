function HTTPResponse(callback){
	this.resHeaders = [];
	this.resBody = null;
	this.callbackMethod=callback;
}
/**
 * Class is for creating CINRequest, and setting an appropriate values.
 */
HTTPResponse.prototype = {
	constructor: HTTPResponse,
	
	getHeaders:function(){
		return this.resHeaders;
	},
	
	getBody: function(){
		return this.resBody;
	},
	
	_setCallback:function(callback){
		this.callbackMethod = callback;
	},

	getCallback: function(){
		return this.callbackMethod;
	},
	/**
	 *
	 **/
	/*function getHTTPRequestHeaders(){

	},*/

	/**
	 *
	 **/
	/*function getHTTPRequestBody(){

	}*/

}

/**
* Method for convert response and invoke callback.
**/
HTTPResponse.prototype.convert = function(xhttp){
	//Convert the data,
	this.callbackMethod.onSuccess(xhttp.responseText);
}
