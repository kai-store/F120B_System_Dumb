function CinRequestMethod() {
}

CinRequestMethod.Service = CinBase64.getByte(0x01);
CinRequestMethod.Message = CinBase64.getByte(0x02);
CinRequestMethod.Reply = CinBase64.getByte(0x03);
CinRequestMethod.ReadReply = CinBase64.getByte(0x04);
CinRequestMethod.KeepAlive = CinBase64.getByte(0x05);
CinRequestMethod.Logon = CinBase64.getByte(0x07);
CinRequestMethod.Notify = CinBase64.getByte(0x0A);
CinRequestMethod.Ask = CinBase64.getByte(0x0B);
CinRequestMethod.Typing = CinBase64.getByte(0x0C);
CinRequestMethod.Take = CinBase64.getByte(0x0F);
CinRequestMethod.Group = CinBase64.getByte(0x10);
CinRequestMethod.GroupMessage = CinBase64.getByte(0x11);
CinRequestMethod.Data = CinBase64.getByte(0x15);
CinRequestMethod.Verify = CinBase64.getByte(0x17);
CinRequestMethod.Report = CinBase64.getByte(0x19);
CinRequestMethod.PhoneBook = CinBase64.getByte(0x1A);
CinRequestMethod.Emoticon = CinBase64.getByte(0x1B);
CinRequestMethod.Video = CinBase64.getByte(0x1C);
CinRequestMethod.PPService = CinBase64.getByte(0x1E);
CinRequestMethod.PPMessage = CinBase64.getByte(0x1F);
CinRequestMethod.RobotMessage = CinBase64.getByte(0x20);
CinRequestMethod.ChannelNotify = CinBase64.getByte(0x21);
CinRequestMethod.Social = CinBase64.getByte(0x62);
CinRequestMethod.SocialNotify = CinBase64.getByte(0x64);
CinRequestMethod.Unknown = CinBase64.getByte(0X7E);
CinRequestMethod.NetworkState = CinBase64.getByte(0X7D);
CinRequestMethod.Session = CinBase64.getByte(0x7C);
CinRequestMethod.Contact = CinBase64.getByte(0x80);
CinRequestMethod.RMC = CinBase64.getByte(0x21);
CinRequestMethod.TRACK = CinBase64.getByte(0x23);
CinRequestMethod.IdamToken = CinBase64.getByte(0x53);
CinRequestMethod.CONTACT_PERMISSION = CinBase64.getByte(0x88);

CinRequestMethod.EVENT_GROUP_JOINED = CinBase64.getByte(0x10);
CinRequestMethod.EVENT_GROUP_INFO_CHANGED = CinBase64.getByte(0x11);
CinRequestMethod.EVENT_GROUP_BUDDY_UPDATE = CinBase64.getByte(0x12);
CinRequestMethod.EVENT_GROUP_BUDDY_LEAVE = CinBase64.getByte(0x13);
CinRequestMethod.EVENT_GROUP_SET_CHANGED = CinBase64.getByte(0x14);
CinRequestMethod.EVENT_GROUP_JOIN_NOTIFY = CinBase64.getByte(0x15);
CinRequestMethod.EVENT_GROUP_OTHER_CHANGE_PORTRAIT = CinBase64.getByte(0x18);
CinRequestMethod.EVENT_GROUP_ADMIN_UPDATE = CinBase64.getByte(0x30);
CinRequestMethod.EVENT_GROUP_ADMIN_UPDATE_FOR_NEW_ADMIN = CinBase64.getByte(0x31);

//Notification request callback

CinRequestMethod.EVENT_CONTACT_LIST_CHANGED = CinBase64.getByte(0x02);
CinRequestMethod.EVENT_BLACK_LIST_CHANGED = CinBase64.getByte(0x03);
CinRequestMethod.EVENT_SELECTED_MSG_CHANGED = CinBase64.getByte(0x04);
CinRequestMethod.EVENT_REVERSE_CONTACT_VERSION_CHANGED = CinBase64.getByte(0x05);
CinRequestMethod.EVENT_DND_CHANGED = CinBase64.getByte(0x07);
CinRequestMethod.EVENT_SET_SOCIAL_RECIEVE_NOTIFY = CinBase64.getByte(0x08);
CinRequestMethod.EVENT_SET_LAST_SEEN = CinBase64.getByte(0x09);
CinRequestMethod.EVENT_SET_MESSAGE_PREVIEW = CinBase64.getByte(0x10);
CinRequestMethod.EVENT_NOTIFY_CONTACT_LIST = CinBase64.getByte(0x11);

CinRequestMethod.EVENT_NOTIFY_CLIENT_STATUS = CinBase64.getByte(0x0C);
CinRequestMethod.EVENT_NOTIFY_FREE_SMS_QUOTA_CHANGED = CinBase64.getByte(0x0D);

CinRequestMethod.EVENT_FAVORITE_CONTACT_CHANGED = CinBase64.getByte(0x14);
CinRequestMethod.EVENT_PHONE_BOOK_CHANGED = CinBase64.getByte(0x15);
CinRequestMethod.EVENT_SELF_AVATAR_CHANGED = CinBase64.getByte(0x1A);
CinRequestMethod.EVENT_PC_UPLOAD_CONTACT_NOTIFY = CinBase64.getByte(0x19);
CinRequestMethod.EVENT_PC_CANCRL_UPLOAD_CONTACT_NOTIFY = CinBase64.getByte(0x1D);
CinRequestMethod.EVENT_PC_OFFLINE_UPLOAD_CONTACT_NOTIFY = CinBase64.getByte(0x1C);
CinRequestMethod.EVENT_NOTIFY_PUBLIC_SET_FOUCS = CinBase64.getByte(0x20);

CinRequestMethod.EVENT_PC_NOTIFY_READREPLY = CinBase64.getByte(0x23);
CinRequestMethod.EVENT_NOTIFY_MESSAGE_READREPLY_CHANGE = CinBase64.getByte(0x25);

CinRequestMethod.EVENT_CONVERSATION_INFO_PEERID = CinBase64.getByte(0x01);
CinRequestMethod.EVENT_CONVERSATION_INFO_UNREAD_COUNT = CinBase64.getByte(0x02);
CinRequestMethod.EVENT_CONVERSATION_INFO_MAX_INDEX = CinBase64.getByte(0x03);
CinRequestMethod.TYPE_RECEIVE_CONTENT = 1;
CinRequestMethod.TYPE_RECEIVE_FRIEND = 2;	
