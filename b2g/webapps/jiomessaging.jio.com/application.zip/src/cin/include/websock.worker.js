self.addEventListener('message', function(e) {
  var data = e.data;
  // console.log(">> addEventListener" + data.byteLength);
  self.postMessage(data);
  // console.log("<< END addEventListener" + data.byteLength);
}, true);