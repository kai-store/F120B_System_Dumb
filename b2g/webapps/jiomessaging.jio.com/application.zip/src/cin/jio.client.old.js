function JIOClient(){

}

JIOClient.getInstance = function(){
    if( !JIOClient.instance ){
        JIOClient.instance = new JIOClient();
    }
    return JIOClient.instance;
}

JIOClient.prototype.setChatCallback = function(callback){
	this.chatCallback = callback;
}

JIOClient.prototype.getChatCallback = function(){
	return this.chatCallback;
}

JIOClient.prototype.setGroupCallback = function(callback){
	this.groupCallback = callback;
}

JIOClient.prototype.getGroupCallback = function(){
	return this.groupCallback;
}

JIOClient.prototype.register = function(contactNumber, callback) {
	UserModel.getInstance().setPhoneNumber(contactNumber);
	var httpReq = new HTTPRequest(HTTPRequestConts.GET_NAV);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,true);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.setCINResponseParser();
	httpReq.setCINMessageObject();
	// httpReq.addHeader(HTTPRequestConts.GET_NAV_END, '',false);
	httpReq.setCallback(new NavProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);
};

JIOClient.prototype.getSmsCode = function(contactNumber, callback) {
	var instance = UserModel.getInstance();
	instance.setPhoneNumber(contactNumber);
	contactNumber = instance.getEPhoneNumber();
	var httpReq = new HTTPRequest(HTTPRequestConts.SMS_ACP);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.addHeader('lv', '0', false);
	httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
	httpReq.setCINMessageObject();
	httpReq.setCINResponseParser();
	httpReq.setCallback(new SMSProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);
};

JIOClient.prototype.validateCaptcha = function(key, validationNumber, callback){
	var httpReq = new HTTPRequest(HTTPRequestConts.SMS_ACP);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	var contactNumber = UserModel.getInstance().getEPhoneNumber();
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_R_VER, HTTPRequestConts.GET_NAV_R_VER_VAL,false);
	httpReq.addHeader('lv', '0', false);
	httpReq.addHeader('pid', key, true);
	httpReq.addHeader('pc', validationNumber, true);
	httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
	httpReq.setCINResponseParser();
	httpReq.setCallback(callback);
	HTTPClient.getInstance().send(httpReq);
};

JIOClient.prototype.generateCaptcha = function(callback){
	var httpReq = new HTTPRequest(HTTPRequestConts.GEN_CAPTCHA_CODE);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	// var contactNumber = "KzkxOTkwMTM5NjM0MA;;";
	var contactNumber = UserModel.getInstance().getEPhoneNumber();
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,false);
	httpReq.addHeader('oem', HTTPRequestConts.OEM, false);
	httpReq.setCINMessageObject();
	httpReq.setCINResponseParser();
	httpReq.setCallback(new GenrateCaptchaProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);
};


JIOClient.prototype.validateOtp = function(contactNumber, otp, callback){
	var instance  = UserModel.getInstance();
	instance.setPhoneNumber(contactNumber);
	var httpReq = new HTTPRequest(HTTPRequestConts.VALIDATE_OTP);
	httpReq.setRequestMethod(HTTPRequestConts.GET);

	var code = otp +""+ instance.getDomain();

	spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(JIOUtils.getBytes(code)));
	var data = spark.end(true);

	spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(JIOUtils.getBytes(data)));
	data = spark.end(true);	
	data = new Int8Array(JIOUtils.getBytes(data));

	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);

	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, instance.getEPhoneNumber(), false);
	httpReq.addHeader('rd', data, true);
	httpReq.addHeader('dev', HTTPRequestConts.DEV_ID, true);
	httpReq.addHeader('na', '', false);
	httpReq.addHeader('lv', 0, false);	
	httpReq.addHeader('oem', HTTPRequestConts.OEM);	
	httpReq.addHeader('imei', HTTPRequestConts.IMEI, true);
	httpReq.addHeader('dm', HTTPRequestConts.BRAND, true);
	httpReq.addHeader('osv', HTTPRequestConts.OS_VERSION, true);

	httpReq.setCINMessageObject();
	httpReq.setCINResponseParser();
	httpReq.setCallback(new SMSValidationProxyCallback(callback));
	HTTPClient.getInstance().send(httpReq);
};


JIOClient.prototype.getTinyUrl = function(callback){
	var httpReq = new HTTPRequest(HTTPRequestConts.TINY_URL);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.setCallback(callback);
	HTTPClient.getInstance().send(httpReq);
}

JIOClient.prototype.challenge = function(callback){
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.LOGON);
	cinReq.setRequestMethod(CINRequestConts.EVENT_CHALLENGE);
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	//280001378 [3900000546]
	// cinReq.addHeaderInt64(CINRequestConts.FROM,280001378);
	cinReq.setCINMessageObject();
	cinReq.addHeaderInt8(CINRequestConts.LANGUAGE, 0);
	// cinReq.addHeaderInt8(4, 0);
	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.logon = function(user, callback) {
	var instance =	UserModel.getInstance();

	var array = new Array();

	spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(instance.getUserID()));
	spark.append(new Int8Array(instance.getToken()));
	spark.append(new Int8Array(instance.getServerKey()));

	md5FirstBytes = new Int8Array(JIOUtils.getBytes(spark.end(true)));
		
	m5PasswordSpark = new SparkMD5.ArrayBuffer();

	m5PasswordSpark.append(new Int8Array(instance.getPassword()));
	var m5Password = m5PasswordSpark.end(true);
	m5Password = new Int8Array(JIOUtils.getBytes(m5Password));

	var array = new Array();

	for(index=0;index<16;index++){
		array[index] = md5FirstBytes[index];
		array[index+16] = m5Password[index];
	}
	
	JIOUtils.logArray(array);

	var cinReq = new CINRequest();

	cinReq.setRequestEvent(CINRequestConts.LOGON);

	cinReq.setRequestMethod(CINRequestConts.EVENT_LOGON);

	cinReq.addHeaderInt64(CINRequestConts.LANGUAGE, user.getLanguage());
	cinReq.addHeaderString(CINRequestConts.NAME, user.getName());
	cinReq.addHeaderInt32(CINRequestConts.TYPE, CINRequestConts.PLATFORM_TYPE);
	cinReq.addHeaderString(CINRequestConts.VERSION, CINRequestConts.PLATFORM_VERSION);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, 100001);
	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, HTTPRequestConts.DEV_ID); 
	cinReq.addHeader(CINRequestConts.PASSWORD, array); 
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, CINRequestConts.PLATFORM_CAPABILITY);
	cinReq.setCINMessageObject();

	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);	
};

JIOClient.prototype.checkCredential = function(user, callback) {
	var instance =	UserModel.getInstance();

	cinReq.setRequestEvent(CINRequestConts.LOGON);

	cinReq.setRequestMethod(CINRequestConts.EVENT_CHECKCREDENTIAL);

	cinReq.addHeaderInt64(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderString(CINRequestConts.LANGUAGE, user.getLanguage());
	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, HTTPRequestConts.DEV_ID); 
	cinReq.addHeaderInt32(CINRequestConts.CREDENTIAL, instance.getCredential());
	cinReq.addHeaderString(CINRequestConts.VERSION, CINRequestConts.PLATFORM_VERSION);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, 100001);
	cinReq.addHeaderInt32(CINRequestConts.CAPABILITY, CINRequestConts.PLATFORM_CAPABILITY);//c	cinReq.setCallback(callback);
	cinReq.setCINMessageObject();
	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);	
};

JIOClient.prototype.keepAlive = function(){
	setTimeout(function(){
		cinReq = new CINRequest();
		cinReq.setRequestMethod(CINRequestConts.EVENT_LOGON);
		cinReq.setRequestEvent(CINRequestConts.LOGON);
		cinReq.addHeaderInt32(CINRequestConts.Status, 1);
		cinReq.setCINMessageObject();
		cinReq.setCallback({
			onSuccess: function(cinMessage){
				var instance = UserModel.getInstance();
				if(instance.isLoggedIn()){
					instance.initKeepAlive(cinMessage);
					JIOClient.getInstance().keepAlive();
				}
			},
			onError: function(){
				// if(UserModel.getInstance().isLoggedIn()){
				// 	JIOClient.getInstance().keepAlive();
				// }
			}
		});
		CINClient.getInstance().send(cinReq);
	}, 1000);
};

JIOClient.prototype.updateProfile = function(profile, callback){
	var name = profile.getName();
	var mood = profile.getMood();
	var gender = profile.getGender();
	var exprassion = profile.getExpression();

	cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.REQ_METHOD);
	cinReq.setRequestMethod(CINRequestConts.EVENT_UPDATE_CARD);

	msg = new CINRequest();
	msg.setRequestEvent(CINRequestConts.REQ_METHOD)

	if(name && name.length > 0){
		msg.addHeaderString(CINRequestConts.HEADER_RCS_NAME, name);
	}

	if(mood && mood.length > 0){
		msg.addHeaderString(CINRequestConts.HEADER_RCS_MOOD, mood);
	}

	if(exprassion && exprassion.length > 0){
		msg.addHeaderInt32(CINRequestConts.HEADER_RCS_EXPRESSION, exprassion);		
	}

	if(gender){
		msg.addHeaderInt32(CINRequestConts.HEADER_RCS_EXPRESSION, gender);		
	}

	cinReq.addBody(CINRequestConts.BODY, msg.convert());

	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.getProfile = function(callback){
	var instance = UserModel.getInstance();
	this.getContactProfile(instance.getUserID(), 10, callback);
};

JIOClient.prototype.getContactProfile = function(userId, version, callback){
	cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.TAKE);
	cinReq.setRequestMethod(CINRequestConts.EVENT_TAKE_CARD);
	cinReq.addHeader(CINRequestConts.TO, userId);
	cinReq.addHeaderInt32(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new ProfileProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

// JIOClient.prototype.inviteViaEmail = function(emails, callback){

// };

// JIOClient.prototype.inviteViaSMS = function(phoneNumbers, callback){

// };

JIOClient.prototype.checkVersion = function(contactNumber, callback) {
	var httpReq = new HTTPRequest(HTTPRequestConts.GET_NAV);
	httpReq.setRequestMethod(HTTPRequestConts.GET);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_C_VER, HTTPRequestConts.GET_NAV_C_VER_VAL,false);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_ID, contactNumber,true);
	httpReq.addHeader(HTTPRequestConts.GET_NAV_END, '',false);
	httpReq.setCINResponseParser();
	httpReq.setCallback(callback);
	HTTPClient.getInstance().send(httpReq);
};

JIOClient.prototype.isJIOContact = function(){

};

JIOClient.prototype.sendMessage = function(contactNumbers, userIDs, msgType, message, callback) {

	var instance = UserModel.getInstance();

	if(instance.getToken() === null) {
		JIOUtils.sendError(100,"Unable to send text msg.", callback);
		return;
	}

	var userId = instance.getUserID();
	
	var cinReq = new CINRequest();
	
	cinReq.setRequestEvent(CINRequestConts.MESSAGE);
	cinReq.setRequestMethod(CINRequestConts.EVENT_SEND_MSG);

	cinReq.addHeader(CINRequestConts.TO, instance.getUserID());
	if (contactNumbers && contactNumbers !== null) {
		contactNumbers.forEach(function(mobile, index){
			cinReq.addHeader(CINRequestConts.MOBILENO, mobile);
		});
	}

	if (userIDs && userIDs !== null) {
		userIDs.forEach(function(userID, index){
			cinReq.addHeader(CINRequestConts.INDEX, userID);
		});
	}
	var uuid = UUID.randomUUID();
	cinReq.addHeader(CINRequestConts.MESSAGEID, uuid);
	
	var messageStatus = MessageStatus.getValue(false, false, true, false);

	if (messageStatus !== 0) {
		cinReq.addHeaderInt32(CINRequestConts.STATUS, messageStatus);
	}

	if (msgType !== MessageConsts.TYPE_TEXT) {
		cinReq.addHeaderInt32(CINRequestConts.TYPE, msgType);
	}

	if((msgType == MessageConsts.TYPE_TEXT 
		|| msgType == MessageConsts.TYPE_CARD
		|| msgType == MessageConsts.TYPE_FREE_SMS)) {

		uuid =  UUID.randomUUID();
		
		cinReq.addHeader(CINRequestConts.ENCRYPT, uuid);
		
		var bodyBytes = EncryptionUtils.encrypt(message, uuid);

		cinReq.addBody(CINRequestConts.BODY, bodyBytes);
	} else {
		cinReq.addBody(CINRequestConts.BODY, message);
	}
	cinReq.setCINMessageObject();
	cinReq.setCallback(new ChatProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.typing = function(peerId, callback) {
	var cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.TYPING);
	cinReq.addHeader(CINRequestConts.TO, peerId);
	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);
	//return req;
}

JIOClient.prototype.chat = function(contactNumber, message, callback) {
	array = new Array();
	array.push(contactNumber);
	this.sendMessage(null, array, MessageConsts.TYPE_TEXT, message, callback);
};


	
JIOClient.prototype.logOff = function(callback) {
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.EVENT_LOGOFF);
	cinReq.setRequestMethod(CINRequestConts.REQ_METHOD);
	cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID()); // User id for testing
	//cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);
};

//----------------PhoneBook------------------------
JIOClient.prototype.uploadPhoneBook = function(phoneBook,callback) {
	console.log('phonebook called');
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	//cinReq.setRequestMethod(CINRequestConts.PHONEBOOK);
	//cinReq.setRequestEvent(CINRequestConts.EVENT_PHONEBOOK_UPLOAD);

	cinReq.setRequestMethod(CINRequestConts.TYPE);
	cinReq.setRequestEvent(CINRequestConts.PHONEBOOK);

	cinReq.addHeaderString(CINRequestConts.VERSION, "2.1.7");

	//---looping through object of contacts
	
	//var phoneBookInfo = new PhoneBookInfo(phoneBook);
	phoneBook.forEach(function(eachContact, index) {

		//msg = new CINRequest();

		var name = eachContact.name[0];
		var nickname = eachContact.nickname;
		cinMessage = new CINRequest();
		if(name && name.length > 0)
			cinMessage.addHeaderString(0X01,name[0]);
		if(nickname && nickname.length > 0)
			cinMessage.addHeaderString(0X02, nickname);
		/*if(birthday && birthday.length > 0)    Long Value
			cinMessage.addHeaderString(0X01, birthday);*/
		var phoneList = [];	
		eachContact.tel.forEach(function(contact,index){
			var objContact = {};
			objContact.dataType = contact.type[0];
			objContact.dataTypeName = contact.value;
			//objContact.data = contact;
			phoneList.push(objContact);
		});	
			cinMessage.addBody(CINRequestConts.BODY, phoneList);
			var emailList = [];
			var objEmail = {};
			objEmail.dataType = 'default';
			objEmail.dataTypeName = eachContact.email;
			//objEmail.data = email;
			emailList.push(objEmail);
			cinMessage.addBody(CINRequestConts.BODY, emailList);

			var addressList = [];
			var objAddress = {};
			objAddress.dataType = 'default';
			objAddress.dataTypeName = eachContact.adr;
			//objAddress.data = address;
			addressList.push(objAddress);
			cinMessage.addBody(CINRequestConts.BODY, addressList);

		// right now email is single value - if email have list of email with type
		/*var emailList = [];
		phoneBookInfo.email.forEach(function(email,index){
			var objEmail = {};
			objEmail.type = email.type[0];
			objEmail.dataType = email.value;
			//objContact.sme = contact;
			emailList.push(objEmail);
		});	*/

		// right now address is single value - if email have list of email with type
		/*var addressList = [];
		phoneBookInfo.address.tel.forEach(function(address,index){
			var objAddress = {};
			objAddress.type = address.type[0];
			objAddress.dataType = address.value;
			//objContact.sme = contact;
			addressList.push(objAddress);
		});*/		
    });
	var user = instance.getUserID();
	console.log('my user id' + user);
    phoneData = new CINRequest();
    spark = new SparkMD5.ArrayBuffer();
	spark.append(new Int8Array(JIOUtils.getBytes(cinMessage)));
	var data = spark.end(true);
    phoneData.addHeader(CinBase64.getByte(0x02),data)
    phoneData.addBody(CINRequestConts.BODY, cinMessage.convert());
    cinReq.addBody(CINRequestConts.BODY, phoneData.convert());	
    cinReq.setCINMessageObject();
	cinReq.setCallback(new PhoneUploadProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
}

/*JIOClient.prototype.phoneBookUpload = function(phoneBook,callback) {
	
	var phoneBookObj = phoneBook //ContactsStore.getAll();//need method to get all contacts from local database
	
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.PHONEBOOK);
	cinReq.setRequestEvent(CINRequestConts.EVENT_PHONEBOOK_UPLOAD);

	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());//pass UserID
	// cinReq.addHeader(CINRequestConts.CALLID,null);//need call ID ???
	// cinReq.addHeader(CINRequestConts.FPID, JIOUtils.getBytes("pass fpid"));//need FPID ???
	// cinReq.addHeader(CINRequestConts.CSEQUENCE,null);//need csequence ???
	// cinReq.addHeaderInt64(CINRequestConts.PHONEBOOK_VERSION,null); //need client phonebook version ???
	cinReq.addHeaderString(CINRequestConts.PHONEBOOK_VERSION, '1.1'); //need client phonebook version ???

	//---looping through object of contacts
	phoneBookObj.forEach(function(eachContact, index) {
		var phoneBookInfo = new PhoneBookInfo(eachContact);
		//cinReq = phoneBookInfo.getPhoneBookInfo(cinReq);
		cinReq.addBody(CINRequestConts.BODY,phoneBookInfo.getPhoneBookInfo().convert());

    });
	//need to get phonebook from contact-store/data-service or make another class for phonebookinfo as per documnetation 
	cinReq.setCallback(callback);
	CINClient.getInstance().send(cinReq);
};*/


JIOClient.prototype.phoneBookDownload = function(callback) {
	instance = UserModel.getInstance();
	//var phoneBookObj = []; //dummmy
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.PHONEBOOK);
	cinReq.setRequestEvent(CINRequestConts.MOBILENO);	
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	// cinReq.addHeaderInt64(CINRequestConts.FROM,2323232);
	// cinReq.addHeader(CINRequestConts.CALLID,null);
	// cinReq.addHeader(CINRequestConts.FPID,null);
	// cinReq.addHeader(CINRequestConts.CSEQUENCE,null);
	cinReq.addHeaderString(CINRequestConts.VERSION,'2.1.7');
	//cinReq.addHeader(CINRequestConts.PHONEBOOK_VERSION, '1.0'); 
	cinReq.setCINMessageObject();
	cinReq.setCallback(callback);
	console.log("cin Request is for download"+JSON.stringify(cinReq));
	CINClient.getInstance().send(cinReq);
};


JIOClient.prototype.inviteViaEmail = function(email ,callback) {

	instance = UserModel.getInstance();
	tinyInstance = TinyUrl.getInstance();
	var url = tinyInstance.getUrl();
	 if (url && url.length > 0){

	 }else{

	 }
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.SERVICE);
	cinReq.setRequestEvent(CINRequestConts.INVITE_VIA_EMAIL);
	//cinReq.addHeaderInt64(CINRequestConts.FROM,2323232);//pass USERID
	cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeader(CINRequestConts.CALLID,null);
	cinReq.addHeader(CINRequestConts.CSEQUENCE,null);
	cinReq.addHeader(CINRequestConts.EMAIL,email);//pass email
	cinReq.setCINMessageObject();
	cinReq.setCallback(new InviteProxyCallback(callback));
	console.log("cin Request is"+JSON.stringify(cinReq));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.inviteViaSMS = function(phoneNumber ,callback) {
	instance = UserModel.getInstance();
	tinyInstance = TinyUrl.getInstance();
	var url = tinyInstance.getUrl();
	 if (url && url.length > 0){

	 }else{
	 	
	 }
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.SERVICE);
	cinReq.setRequestEvent(CINRequestConts.INVITE_VIA_SMS);

	//cinReq.addHeaderInt64(CINRequestConts.FROM, 2323232);//pass USERID
	cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	// cinReq.addHeader(CINRequestConts.CALLID,null);
	// cinReq.addHeader(CINRequestConts.CSEQUENCE,null);
	cinReq.addHeaderString(CINRequestConts.MOBILENO,phoneNumber);//pass mobileNo.	
	cinReq.setCINMessageObject();
	cinReq.setCallback(new InviteProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.initializeGroup = function(callback){
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.GROUP);
	cinReq.setRequestEvent(CINRequestConts.CSEQUENCE);
	cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeader(CINRequestConts.FROM, 2323232); // user id
	cinReq.addHeader(CINRequestConts.TO, 2323232); // group id
	cinReq.addHeaderString(CINRequestConts.VERSION, "2.1.7");
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
}

JIOClient.prototype.getGroupList = function(selfUserId, callback){
	var cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.GROUP);
	cinReq.setRequestMethod(CINRequestConts.EVENT_GET_GROUP_LIST);
	cinReq.addHeader(CINRequestConts.TO, selfUserId);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));

	CINClient.getInstance().send(cinReq);
}

JIOClient.prototype.readReply = function(selfId, peerId, lastSeq, unreadCount, type, callback){
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.READ_REPLY);
	//cinReq.setRequestEvent(CINRequestConts.EVENT_GET_GROUP_LIST);
	//cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, selfId);
	cinReq.addHeader(CINRequestConts.INDEX, peerId);
	cinReq.addHeader(CINRequestConts.CREDENTIAL, unreadCount);

	if(lastSeq > 0){
		cinReq.addHeader(CINRequestConts.KEY, lastSeq);	
	}
	if(type === CINRequestConts.READ_REPLY_TYPE_DELETE_SESSION){

		cinReq.addHeader(CINRequestConts.TYPE, type);	

	}
	cinReq.setCINMessageObject();	
	cinReq.setCallback(new ReadReplyProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
}


JIOClient.prototype.getGroupInfo = function(groupId, callback){
	var cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.GROUP);
	cinReq.setRequestMethod(CINRequestConts.EVENT_GET_GROUP_INFO);
	//cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
}

JIOClient.prototype.getUserCard = function(userId, version, notifyNow, callback){
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.TAKE);
	cinReq.setRequestEvent(CINRequestConts.EVENT_TAKE_CARD);
	//cinReq.addHeaderInt64(CINRequestConts.FROM,instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, userID);
	cinReq.addHeader(CINRequestConts.VERSION, version);
	
	if (notifyNow) {
		cinReq.addHeader(CINRequestConts.TOKEN, 1);
	}

	cinReq.setCINMessageObject();
	cinReq.setCallback(new CardProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
}

JIOClient.prototype.createGroup = function(userId, selfName, name, userIDs,callback) {
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestEvent(CINRequestConts.GROUP);
	cinReq.setRequestMethod(CINRequestConts.EVENT_CREATE_GROUP);
	cinReq.addHeader(CINRequestConts.FROM, userId);
	cinReq.addHeaderString(CINRequestConts.NAME, name);
	cinReq.addHeaderString(CINRequestConts.TYPE, selfName);

	userIDs.forEach(function(groupUserId) {
		cinReq.addHeader(CINRequestConts.INDEX, groupUserId);
    });
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.updateGroup = function(groupId, name, userName, callback) {
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.GROUP);
	cinReq.setRequestEvent(CINRequestConts.EVENT_UPDATE_GROUP);
	//cinReq.addHeaderInt64(CINRequestConts.FROM, 2323232); //pass USERID
	//cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.addHeaderString(CINRequestConts.NAME, name);
	cinReq.addHeader(CINRequestConts.INDEX, userName);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.updateGroupSet = function(userId, groupId, token, callback) {
	instance = UserDB.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.GROUP);
	cinReq.setRequestEvent(CINRequestConts.EVENT_UPDATE_GROUP_SET);
	cinReq.addHeader(CINRequestConts.FROM, userId);//pass USERID
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.addHeaderString(CINRequestConts.TOKEN, token);
	//cinReq.addHeader(CINRequestConts.INDEX,userName);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.updateGroupMessageAcceptSet = function(userId, token, callback) {
	instance = UserDB.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.GROUP);
	cinReq.setRequestEvent(CINRequestConts.EVENT_UPDATE_GROUP_MESSAGE_ACCEPT_SET);
	cinReq.addHeader(CINRequestConts.FROM, userId);//pass USERID
	cinReq.addHeader(CINRequestConts.TO, userId);//may be groupID
	cinReq.addHeaderString(CINRequestConts.TOKEN, token);
	//cinReq.addHeader(CINRequestConts.INDEX,userName);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.deleteMessage = function(peerId, messageIds, albumMessageIds, sessionID, callback) {
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.MESSAGE);
	cinReq.setRequestEvent(CINRequestConts.EVENT_DELETE_MSG);
	//cinReq.addHeader(CINRequestConts.FROM, ownerUserId);//pass USERID
	cinReq.addHeader(CINRequestConts.TO, peerId);//may be groupID

	messageIds.forEach(function(messageId) {
		cinReq.addHeader(CINRequestConts.VERSION, messageId);//check version
					
    });

	albumMessageIds.forEach(function(messageId) {
		cinReq.addHeader(CINRequestConts.VERSION, messageId);//check version
					
    });

	cinReq.addHeader(CINRequestConts.TOKEN, sessionID);
	// cinReq.addHeader(CINRequestConts.CSEQUENCE,csequence);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new DeleteMessageProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.deleteContact = function(list, callback) {
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.SERVICE);
	cinReq.setRequestEvent(CINRequestConts.EVENT_DELETE_CONTACT_LIST);
	//cinReq.addHeader(CINRequestConts.FROM, ownerUserId);//pass USERID

	list.forEach(function(mobileNo) {
		cinReq.addHeader(CINRequestConts.MOBILENO, mobileNo);//check version
					
    });

	cinReq.setCINMessageObject();
	cinReq.setCallback(new DeleteContactProxyCallback(callback));
	
	CINClient.getInstance().send(cinReq);
};


JIOClient.prototype.groupInvite = function(name, groupInvitees, callback) {
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.GROUP);
	cinReq.setRequestEvent(CINRequestConts.EVENT_INVITE_GROUP);
	//cinReq.addHeaderInt64(CINRequestConts.FROM, 2323232);//pass USERID
	//cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderString(CINRequestConts.NAME, name); //inviter name
	var groupInfo = new CINRequest();

	groupInvitees.forEach(function(invitee) {
			groupInfo.addHeader(CINRequestConts.GROUP_USER_NAME, invitee.name);
			groupInfo.addHeader(CINRequestConts.GROUP_USERID, invitee.userid);
    });
	cinReq.addBody(CINRequestConts.BODY, groupInfo.convert());
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};

JIOClient.prototype.quitGroup = function(userId, groupId, name, groupQuiters, callback) {
	instance = UserModel.getInstance();
	var cinReq = new CINRequest();
	cinReq.setRequestMethod(CINRequestConts.GROUP);
	cinReq.setRequestEvent(CINRequestConts.EVENT_QUIT_GROUP);
	cinReq.addHeader(CINRequestConts.FROM, userId);
	cinReq.addHeader(CINRequestConts.TO, groupId);
	cinReq.addHeaderString(CINRequestConts.NAME, name); //kicked user name
	var groupInfo = new CINRequest();

	groupQuiters.forEach(function(quiter) {
			groupInfo.addHeader(CINRequestConts.GROUP_USERID, quiter.userid);
			groupInfo.addHeader(CINRequestConts.GROUP_USER_NAME, quiter.name);
    });
	cinReq.addBody(CINRequestConts.BODY, groupInfo.convert());
	cinReq.setCINMessageObject();
	cinReq.setCallback(new GroupProxyCallback(callback));
	CINClient.getInstance().send(cinReq);
};



