function CINClient(){
}
/**
 * Class is for creating CINResponse, and setting an appropriate values.
 */
CINClient.prototype = {
    constructor: CINClient,
    instance: null,
    _socket: null,
	_reqs: new Array(),
	
    _getSocket: function(cinRequest){
        if (!CINClient.socket){
            _socket = new WebSocket('ws://192.168.1.13:8887');
			_socket.onopen = function(){
				alert("connected...");
			};
            _socket.onclose = function(evt){
               CINClient.socket =  null;
            };          
            _socket.extraParameter = null;

            /* var uri = 'ws://echo.websocket.org';
            _socket = new Websock();
            console.log("connecting to: " + uri);
            _socket.open(uri);
            _socket.on('open', function (evt) {
                alert("Connected");
            });
            _socket.on('message', function () {
                alert("Received: " + _socket.rQshiftStr());
            });
            _socket.on('close', function () {
                alert("Disconnected");
            });*/
            CINClient.socket=_socket;
        }
        return CINClient.socket;
    },
    
    send: function(cinRequest){
        var localSocket = this._getSocket(cinRequest);
        localSocket.onclose = function(evt){
            CINClient.socket = null;
            CINClient.getInstance().sendErrorCallback(evt, cinRequest.getCallback());
        };

        // localSocket.extraParameter = new Date().toString();
        localSocket.onmessage = function(evt) {
            console.log("on message...");
        	var callback = cinRequest.getCallback();
        	if(callback == null || !callback){
        		return;
        	}
        	cinRes = new CINResponse(callback);
        	cinRes.convert(evt.data);
    	};
        // localSocket.originalDataSent = cinRequest.convert();
        // Socket is ready state
        if(localSocket.readyState === 1){
            localSocket.send(cinRequest.convert());
            return true;
        }

       if(cinRequest.isMaxRetryReached() === true){
            //Call error method, for error callback
            var callback = cinRequest.getCallback();
            this.sendErrorCallback(-1, callback);
        }
        this._waitForConnection(cinRequest);
        return false;
   },

    _waitForConnection: function(cinRequest){
        var that = this;
        //For incremental retry
        var delay = 1000 * (cinRequest.getRetryCount()+1);
        var timeOut = setTimeout(function () {
            if(cinRequest.isMaxRetryReached() === true){
                return;
            }
            cinRequest.retry();
            var result = that.send(cinRequest);

            // if(result === true){
            //     clearTimeout(timeOut);
            // }
        }, delay);
    }
};

CINClient.getInstance= function(){
    if(!CINClient.instance){
        CINClient.instance = new CINClient();
    }
    return CINClient.instance;
};

CINClient.prototype.sendErrorCallback=function(event, callback){
    
    if(!callback){
        return;
    }

   var reason;
    // See http://tools.ietf.org/html/rfc6455#section-7.4.1
    switch (event.code){
        case 1000:
            reason = "Normal closure, meaning that the purpose for which the connection was established has been fulfilled.";
            break;

        case 1001:
            reason = "An endpoint is \"going away\", such as a server going down or a browser having navigated away from a page.";
            break;

        case 1002:
            reason = "An endpoint is terminating the connection due to a protocol error";
            break;

        case 1003:
            reason = "An endpoint is terminating the connection because it has received a type of data it cannot accept (e.g., an endpoint that understands only text data MAY send this if it receives a binary message).";
            break;

        case 1004:
            reason = "Reserved. The specific meaning might be defined in the future.";
            break;

        case 1005:
            reason = "No status code was actually present.";
            break;

        case 1006:
           reason = "The connection was closed abnormally, e.g., without sending or receiving a Close control frame";
           break;

        case 1007:
           reason = "An endpoint is terminating the connection because it has received data within a message that was not consistent with the type of the message (e.g., non-UTF-8 [http://tools.ietf.org/html/rfc3629] data within a text message).";
           break;

        case 1008:
            reason = "An endpoint is terminating the connection because it has received a message that \"violates its policy\". This reason is given either if there is no other sutible reason, or if there is a need to hide specific details about the policy.";
            break;

        case 1009:
           reason = "An endpoint is terminating the connection because it has received a message that is too big for it to process.";
           break;

        case 1010:  // Note that this status code is not used by the server, because it can fail the WebSocket handshake instead.
            reason = "An endpoint (client) is terminating the connection because it has expected the server to negotiate one or more extension, but the server didn't return them in the response message of the WebSocket handshake. <br /> Specifically, the extensions that are needed are: " + event.reason;
            break;

        case 1011:
            reason = "A server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.";
            break;

        case 1015:
            reason = "The connection was closed due to a failure to perform a TLS handshake (e.g., the server certificate can't be verified).";
            break;
        case -1:
            reason = "Reached max retries.";
            break;

        default:
            reason = "Unknown reason";
    }
    callback.onError(event.code, reason);
}
