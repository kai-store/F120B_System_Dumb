function ErrorCodes(){

}

ErrorCodes.FORCED_LOGOUT = -1;

ErrorCodes.REFRESH_REQUEST = -2000;

ErrorCodes.NO_PACKET = -1000;
ErrorCodes.NO_NETWORK = -400;

ErrorCodes.SOCKET_CLOSE = 1000;
ErrorCodes.SOCKET_SERVER_ERROR = 1001;
ErrorCodes.SOCKET_PROTOCOL_ERROR = 1002;
ErrorCodes.SOCKET_WRONG_DATA = 1003;
ErrorCodes.SOCKET_NO_FEATURE = 1004;
ErrorCodes.SOCKET_NO_STATUS = 1005;
ErrorCodes.SOCKET_ABNORMALLY_CLOSED = 1006;
ErrorCodes.SOCKET_ENCODE_ERROR = 1007;
ErrorCodes.SOCKET_VIOLATION_ERROR = 1008;
ErrorCodes.SOCKET_MESSAGE_TOO_BIG = 1009;
ErrorCodes.SOCKET_TCP_ERROR = 1010;
ErrorCodes.SOCKET_UNEXPECTED_ERROR = 1011;
ErrorCodes.SOCKET_TLS_ERROR = 1015;
ErrorCodes.MAX_RETRY=-1;

ErrorCodes.NO_USER_ID = 0;
ErrorCodes.UNKNOWN = 1;
ErrorCodes.REGISTER = 2;
ErrorCodes.INVALID_OTP = 3;
ErrorCodes.CIN = 4;
ErrorCodes.INVALID_TOKEN = 5;
ErrorCodes.NO_MOBILE_NO = 6;
ErrorCodes.NO_EMAIL = 7;
ErrorCodes.NO_OTP = 8;
ErrorCodes.NO_USERID = 9;
ErrorCodes.NO_PEERID = 10;
ErrorCodes.NO_TINY_URL = 20;
ErrorCodes.NO_USER_NAME = 30;
ErrorCodes.NO_GROUP_TITLE = 40;
ErrorCodes.NO_MESSAGE_ID = 50
ErrorCodes.CAPTCHA_CODE = 150;
//chat
ErrorCodes.CLEAR_CHAT = 250;

// Callbacks
ErrorCodes.INVALID_LENGTH = 101;
ErrorCodes.BLACK_LIST = 150;
ErrorCodes.SEND_MSG = 300;
ErrorCodes.DELETE_CONTACT = 350;
ErrorCodes.GROUP_INFO = 400;
ErrorCodes.GROUP_ADMIN = 450;
ErrorCodes.GROUP_INIT = 500;
ErrorCodes.INVITE = 550;
ErrorCodes.NO_EMAIL = 600;

// feedback
ErrorCodes.NO_CONTENT = 650;
ErrorCodes.CONTENT_LIMIT = 700;

ErrorCodes.AUTO_LOGON_FAILED = -100;

