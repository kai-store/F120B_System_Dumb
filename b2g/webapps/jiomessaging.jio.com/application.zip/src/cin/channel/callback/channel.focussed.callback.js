function FocussedChanelListCallback(callback) {
	this.callback = callback;
}

FocussedChanelListCallback.prototype = {
	onSuccess: function(cinResponse){
		var totalCount = 0;
		if(cinResponse.containsHeader(CINRequestConts.STATUS)){
			totalCount = cinResponse.getInt(CINRequestConts.STATUS);
		}
		var channels = new Array();
		if(cinResponse.hasBody()){
			var response = CINResponse.getCINMessage(cinResponse.getBody(), null, false);
			channels = RMCManager.getChannels(response);
		}
		var version = cinResponse.getInt(CINRequestConts.VERSION);

		this.callback.onSuccess(channels, version);
	},
	onError: function(cinResponse){
        JIOUtils.sendError(100, cinResponse, this.callback);
	}
}
