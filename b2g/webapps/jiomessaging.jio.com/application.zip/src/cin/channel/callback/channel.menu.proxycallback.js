function ChannelMenuProxyCallback(channel, callback) {
	this.channel = channel;
	this.callback = callback;
}

ChannelMenuProxyCallback.prototype = {
	onSuccess: function(cinResponse){
		
		if(!this.callback){
			return;
		}
		var that = this;
		var responses = cinResponse.getBodys();
		responses.forEach(function(body){
            var response = CINResponse.getCINMessage(body.val, null, false);
    		var bodys = cinResponse.getBodys();
    		responses.forEach(function(menuBody){
	            var menuItem = new MenuItem();
                var menuRespose = CINResponse.getCINMessage(menuBody.val, null, false);
	            menuItem.init(menuRespose);
	            that.channel.menuItems.push(menuItem);
        	});
		});
		this.callback.onSuccess(this.channel);
	},
	onError: function(cinResponse){
		
        JIOUtils.sendError(100, cinResponse, this.callback);
	}
};
