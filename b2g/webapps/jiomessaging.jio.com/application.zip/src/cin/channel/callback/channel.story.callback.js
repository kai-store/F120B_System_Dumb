function ChannelStoryCallback(callback){
    this.uiCallback = callback;
}

ChannelStoryCallback.prototype = {
    onSuccess: function(cinMessage){
        var storyId = cinResponse.getInt(CINRequestConts.INDEX);
        var channelId = cinResponse.getInt(CINRequestConts.TO);
        info = new ContentInfo();
        info.setContentID(storyId);
        pages = [];

        var bodys = cinMessage.getBodys();
        bodys.forEach(function(cinMessageBody){
            pageInfo = new PageInfo();
            pageMessage = CINResponse.getCINMessage(cinMessageBody, null, false);
            pageInfo.parseFromMsg(pageMessage);
            pages.push(pageInfo);
        });
        info.setPageInfo(pages);
        this.uiCallback.onSuccess(info, channelId);
    },
    onError: function(error){
        JIOUtils.sendError(100, error, this.uiCallback);
    }
};
