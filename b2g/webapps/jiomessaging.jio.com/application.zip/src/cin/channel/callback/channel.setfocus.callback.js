function SetFocusCallback(channel, callback) {
	this.channel = channel;
	this.callback = callback;
}

SetFocusCallback.prototype = {
	onSuccess: function(cinResponce){
		this.channel.setIsAttentive(cinResponce.getInt(CINRequestConts.TYPE)===1);
		var pinToChat = -1;
		var body = cinResponce.getBody();
		if(body){
			var cinMsg = CINResponse.getCINMessage(body, null, false);
			if(cinMsg.containsHeader(0x10)){
				pinToChat = cinMsg.getInt(0x10);
			}
		}
		this.channel.setPinToChat(pinToChat);
		this.callback.onSuccess(this.channel);
	},
	onError: function(error){
	    JIOUtils.sendError(100, error, this.callback);
	}
};
