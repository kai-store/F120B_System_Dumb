function ChannelListCallback(callback){
    this.uiCallback = callback;
}

ChannelListCallback.prototype = {
    onSuccess: function(cinMessage){
        var bodys = cinMessage.getBodys();
        var channelSummaryInfos = new Array();
        bodys.forEach(function(cinVal, index){
            var response = CINResponse.getCINMessage(cinVal.val, null, false);
			var channel = new ChannelSummaryInfo();
			channel.init(response);
			channelSummaryInfos.push(channel);
        });
        this.uiCallback.onSuccess(channelSummaryInfos);
    },
    onError: function(error){
        JIOUtils.sendError(100, error, this.uiCallback);
    }
};
