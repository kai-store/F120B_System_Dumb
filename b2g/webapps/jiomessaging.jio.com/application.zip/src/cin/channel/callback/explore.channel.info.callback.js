function ExploreChannelInfoCallback(callback){
    this.uiCallback = callback;
}

ExploreChannelInfoCallback.prototype = {
    onSuccess: function(cinMessage){
        var bodys = cinMessage.getBodys();
        entityProfile = null;//new ChannelProfileInfo();
        entityContent = null;
        bodys.forEach(function(cinBody){
            var cinMsg = CINResponse.getCINMessage(cinBody.val, null, false);
            var typeHeader = JIOUtils.toLong(cinMsg.getHeader(CinBase64.getByte(0x01)));
            switch(typeHeader){
                case ChannelConst.TYPE_HEADER1:
                    if(entityProfile == null){
                        entityProfile = new ChannelProfileInfo();
                    }
                    entityProfile.parseFromMsg(CINResponse.getCINMessage(cinBody.val, null, false));
                    break;
                case ChannelConst.TYPE_HEADER2: 
                    if(entityContent == null){
                        entityContent = new ExploreChannelContentInfo();
                    }
                    entityContent.parseFromMsg(CINResponse.getCINMessage(cinBody.val, null, false));
                    break;
            }
        });        
        this.uiCallback.onSuccess(entityProfile, entityContent);
    },
    onError: function(error){
        JIOUtils.sendError(100, error, this.callback);
    }
};
