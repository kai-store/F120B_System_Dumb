function RMCManager(){

}

RMCManager.getInstance = function(){
    if( !RMCManager.instance ){
        RMCManager.instance = new RMCManager();
    }
    return RMCManager.instance;
}

RMCManager.prototype.getChannelList = function(version, callback) {
    var cinReq = new CINRequest(ChannelConst.RMC, ChannelConst.EVENT_RMC_CHANNEL_LIST);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeaderInt64(CINRequestConts.VERSION, version);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new ChannelListCallback(callback));

	cinReq.setMetaInfo('RMC','EVENT_RMC_CHANNEL_LIST');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.getCheckStory = function(channelId, storyId, callback) {
    var cinReq = new CINRequest(ChannelConst.RMC, ChannelConst.EVENT_RMC_CHECK_STORY);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeaderInt64(CINRequestConts.INDEX, storyId);
	cinReq.addHeaderInt64(CINRequestConts.TO, channelId);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new ChannelStoryCallback(callback));

	cinReq.setMetaInfo('RMC','EVENT_RMC_CHECK_STORY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.getChannelInfo = function(channelId, profileVersion, contentVersion, callback) {
	var cinReq = new CINRequest(ChannelConst.RMC, ChannelConst.EVENT_RMC_CHANNEL_INFO);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());	
	cinReq.addHeaderInt64(CINRequestConts.TO, channelId);
	cinReq.addHeaderInt64(CINRequestConts.VERSION, profileVersion);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, contentVersion);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new ChannelInfoCallback(callback));

	cinReq.setMetaInfo('RMC','EVENT_RMC_CHANNEL_INFO');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};
