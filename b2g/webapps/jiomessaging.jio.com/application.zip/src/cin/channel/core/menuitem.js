function MenuItem() {
	this.type = -1;
	this.title = undefined;
	this.key = undefined;
	this.url = undefined;
	this.menuItems = [];
}

MenuItem.prototype.setType = function(type) {
	this.type = type;
};

MenuItem.prototype.getType = function() {
	return this.type;
};

MenuItem.prototype.setTitle = function(title) {
	this.title = title;
};

MenuItem.prototype.getTitle = function() {
	return this.title;
};

MenuItem.prototype.setKey = function(key) {
	this.key = key;
};

MenuItem.prototype.getKey = function() {
	return this.key;
};

MenuItem.prototype.setUrl = function(url) {
	this.url = url;
};

MenuItem.prototype.getUrl = function() {
	return this.url;
};

MenuItem.prototype.init = function(cinResponse){
	this.initObj(cinResponse);
	var bodys = cinResponse.getBodys();
	if(bodys === null || bodys === undefined || bodys.length ===0){
		return;
	}
	for (var i = 0; i < bodys.length; i++) {
        var response = CINResponse.getCINMessage(bodys[i].val, null, false);
        var menuItem = new MenuItem();
        menuItem.init(response);
        this.menuItems.push(menuItem);
	}
}

MenuItem.prototype.initObj = function(cinResponse){
	var headers = cinResponse.getHeaders();
	var that = this;
	headers.forEach(function(header){
		switch(header.key){
			case 0x01:
				that.setType(JIOUtils.toLong(header.val));
				break;
			case 0x02:
				that.setTitle(JIOUtils.toString(header.val));
				break;
			case 0x03:
				that.setKey(JIOUtils.toString(header.val));
				break;
			case 0x04:
				that.setUrl(JIOUtils.toString(header.val));
				break;
		}
	});
}
