function Channel() {
	this.publicId = null;
	this.name = "";
	this.portraitId = "";
	this.description ="";
	this.isReceiveMsg = false;
	this._isAttentive = false;
	this._isOfficial = false;
	this.cardVersion = null;
	this.follwType = -1;
	this.pinToChat = -1;
	this.menuItems = [];
}

Channel.prototype.setPublicId = function(publicId) {
	this.publicId = publicId;
};

Channel.prototype.getPublicId = function() {
	return this.publicId;
};

Channel.prototype.getChannelId = function() {
	return this.publicId;
};

Channel.prototype.setName = function(name) {
	this.name = name;
};

Channel.prototype.getName = function() {
	return this.name;
};

Channel.prototype.setPortraitId = function(portraitId) {
	this.portraitId = portraitId;
};

Channel.prototype.getPortraitId = function() {
	return this.portraitId;
};

Channel.prototype.setDescription = function(description) {
	this.description = description;
};

Channel.prototype.getDescription = function() {
	return this.description;
};

Channel.prototype.setIsReceiveMsg = function(isReceiveMsg) {
	this.isReceiveMsg = isReceiveMsg;
};
Channel.prototype.isReceiveMssage = function() {
	return this.isReceiveMsg;
};

Channel.prototype.setIsAttentive = function(isAttentive) {
	this._isAttentive = isAttentive;
};

Channel.prototype.setFollowing = function(isAttentive) {
	this._isAttentive = isAttentive;
};

Channel.prototype.isFollowing = function() {
	return this._isAttentive;
};

Channel.prototype.setIsOfficial = function(_isOfficial) {
	this._isOfficial = _isOfficial;
};
Channel.prototype.isOfficial = function() {
	return this._isOfficial;
};

Channel.prototype.setCardVersion = function(cardVersion) {
	this.cardVersion = cardVersion;
};
Channel.prototype.getCardVersion = function() {
	return this.cardVersion;
};

Channel.prototype.setFollwType = function(follwType) {
	this.follwType = follwType;
};
Channel.prototype.getFollwType = function() {
	return this.follwType;
};

Channel.prototype.setPinToChat = function(pinToChat) {
	this.pinToChat = pinToChat;
};
Channel.prototype.getPinToChat = function() {
	return this.pinToChat;
};

Channel.prototype.addMenuItemList = function(menuItem) {
	this.menuItems.push(menuItem);
};

Channel.prototype.getMenuList = function() {
	return this.menuItems;
};
Channel.prototype.setMenuList = function(menuItems) {
	this.menuItems = menuItems;
};

Channel.prototype.isPrivateChannel = function(){
	return this.follwType === ChannelConst.FOLLOW_PRIVATE_CHANNEL;
};

Channel.prototype.init = function(cinMessage){
	var that = this;
	var headers = cinMessage.getHeaders();
	headers.forEach(function(headerObject, index){
		switch(headerObject.key){
			case ChannelConst.HEADER_PUBLIC_ID:
				that.setPublicId(headerObject.val);
				break;
			case ChannelConst.HEADER_PUBLIC_NAME:
				that.setName(JIOUtils.toString(headerObject.val));
				break;
			case ChannelConst.HEADER_PUBLIC_PORT_ID:
				that.setPortraitId(JIOUtils.toString(headerObject.val));
				break;
			case ChannelConst.HEADER_PUBLIC_IS_RECEIVE_MSG:
				that.setIsReceiveMsg(JIOUtils.toLong(headerObject.val) === 0);
				break;
			case ChannelConst.HEADER_PUBLIC_IS_OFFICIAL:
				that.setIsOfficial(JIOUtils.toLong(headerObject.val) === 1);
				break;
			case ChannelConst.HEADER_PUBLIC_FOLLOW_TYPE:
				that.setFollwType(JIOUtils.toLong(headerObject.val));
				break;
			case ChannelConst.HEADER_PUBLIC_VERSION:
				that.setCardVersion(JIOUtils.toLong(headerObject.val));
				break;
			case ChannelConst.HEADER_PUBLIC_PIN_TO_CHAT:
				that.setPinToChat(JIOUtils.toLong(headerObject.val));
				break;
		}
	});
	var desc = cinMessage.getBody();

	if(desc){
		this.setDescription(JIOUtils.toString(desc));
	}
}
