function PublicMessage() {
	this.publicId = null;
	this.name = "";
	this.portraitId = "";
	this.description ="";
	this.isReceiveMsg = false;
	this._isAttentive = false;
	this._isOfficial = false;
	this.cardVersion = null;
	this.follwType = -1;
	this.pinToChat = -1;
	this.menuItems = [];
}

PublicMessage.prototype.setPublicId = function(publicId) {
	this.publicId = publicId;
};

PublicMessage.prototype.getPublicId = function() {
	return this.publicId;
};

PublicMessage.prototype.setName = function(name) {
	this.name = name;
};

PublicMessage.prototype.getName = function() {
	return this.name;
};

PublicMessage.prototype.setPortraitId = function(portraitId) {
	this.portraitId = portraitId;
};

PublicMessage.prototype.getPortraitId = function() {
	return this.portraitId;
};

PublicMessage.prototype.setDescription = function(description) {
	this.description = description;
};

PublicMessage.prototype.getDescription = function() {
	return this.description;
};

PublicMessage.prototype.setIsReceiveMsg = function(isReceiveMsg) {
	this.isReceiveMsg = isReceiveMsg;
};
PublicMessage.prototype.isReceiveMssage = function() {
	return this.isReceiveMsg;
};

PublicMessage.prototype.setIsAttentive = function(isAttentive) {
	this._isAttentive = isAttentive;
};
PublicMessage.prototype.isFollowing = function() {
	return this._isAttentive;
};

PublicMessage.prototype.setIsOfficial = function(_isOfficial) {
	this._isOfficial = _isOfficial;
};
PublicMessage.prototype.isOfficial = function() {
	return this._isOfficial;
};

PublicMessage.prototype.setCardVersion = function(cardVersion) {
	this.cardVersion = cardVersion;
};
PublicMessage.prototype.getCardVersion = function() {
	return this.cardVersion;
};

PublicMessage.prototype.setFollwType = function(follwType) {
	this.follwType = follwType;
};
PublicMessage.prototype.getFollwType = function() {
	return this.follwType;
};

PublicMessage.prototype.setPinToChat = function(pinToChat) {
	this.pinToChat = pinToChat;
};
PublicMessage.prototype.getPinToChat = function() {
	return this.pinToChat;
};

PublicMessage.prototype.addPublicMessaeList = function(publicMessage) {
	this.publicMessage.push(publicMessage);
};

PublicMessage.prototype.getPublicMessageList = function() {
	return this.publicMessageList;
};
PublicMessage.prototype.setPublicMessageList = function(publicMessageList) {
	this.publicMessageList=publicMessageList;
};

PublicMessage.prototype.isPrivateChannel = function(){
	return this.follwType === ChannelConst.FOLLOW_PRIVATE_CHANNEL;
};

PublicMessage.prototype.init = function(cinMessage){
	var headers = cinMessage.getHeaders();
	headers.forEach(function(headerObject, index){
		switch(header.key){
			case ChannelConst.HEADER_PUBLIC_ID:
				this.setPublicId(headerObject.val);
				break;
			case ChannelConst.HEADER_PUBLIC_NAME:
				this.setName(JIOUtils.toString(headerObject.val));
				break;
			case ChannelConst.HEADER_PUBLIC_PORT_ID:
				this.setPortraitId(JIOUtils.toString(headerObject.val));
				break;
			case ChannelConst.HEADER_PUBLIC_IS_RECEIVE_MSG:
				this.setIsReceiveMsg(JIOUtils.toLong(headerObject.val) === 0);
				break;
			case ChannelConst.HEADER_PUBLIC_IS_OFFICIAL:
				this.setIsOfficial(JIOUtils.toLong(headerObject.val) === 1);
				break;
			case HEADER_PUBLIC_FOLLOW_TYPE:
				this.setFollwType(JIOUtils.toLong(headerObject.val));
				break;
			case HEADER_PUBLIC_VERSION:
				this.setCardVersion(headerObject.val);
				break;
			case HEADER_PUBLIC_PIN_TO_CHAT:
				this.setPinToChat(JIOUtils.toLong(headerObject.val));
				break;
		}
	});
	var desc = cinMessage.getBody();

	if(desc){
		this.setDescription(JIOUtils.toString(desc));
	}
}
