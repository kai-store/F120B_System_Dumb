function RMCManager(){

}

RMCManager.getInstance = function(){
    if( !RMCManager.instance ){
        RMCManager.instance = new RMCManager();
    }
    return RMCManager.instance;
}

RMCManager.prototype.getChannelInfo = function(channelSummaryInfo, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_CARD_INFO)
	// var cinReq = new CINRequest(CINRequestConts.RMC, ChannelConst.EVENT_RMC_CHANNEL_INFO);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channelSummaryInfo.getChannelId());
	cinReq.addHeaderInt64(CINRequestConts.VERSION, 0);
	// cinReq.addHeaderInt64(CINRequestConts.STATUS, 0);

	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new ChannelCardProxyCallback(callback, true));  	
	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_CARD_INFO');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.getChannelMenus = function(channel, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_GET_MENU);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new ChannelMenuProxyCallback(channel, callback));  	
	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_GET_MENU');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.followChannel = function(channel, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_SET_FOCUS);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	cinReq.addHeaderInt64(CINRequestConts.TYPE, channel.isFollowing() ? 1 : 0);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new EmptyResponseCallback(callback));

	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_SET_FOCUS');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.setReceiveChannelMessages = function(channel, callback) {
	// if(!channel.isFollowing()){
	// 	JIOUtils.sendError(-1, "Please follow channel to receive messages.", callback);
	// 	return;
	// }

	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_SET_RECEIVE);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	cinReq.addHeaderInt64(CINRequestConts.STATUS, channel.isReceiveMssage() ? 0 : 1);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new EmptyResponseCallback(callback));

	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_SET_RECEIVE');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.getPublicMenuMsg = function(channel, menuItem, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_MENU_MSG);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	cinReq.addHeaderString(CINRequestConts.KEY, menuItem.getKey());
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new ChannelMenuMessageCallback(callback));
	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_MENU_MSG');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.sendMessage = function(chatMessage, callback){
	var userId = chatMessage.getTo();
	var from = chatMessage.getFrom();
	var uuid = chatMessage.getMessageId();
	var message = chatMessage.getMessageBody();

	var cinReq = new CINRequest(CINRequestConts.PPMessage, 0x01);
	cinReq.addHeader(CINRequestConts.TO, from);
	cinReq.addHeader(CINRequestConts.FROM, userId);
	cinReq.addHeader(CINRequestConts.MESSAGEID, uuid);
	var msgType = chatMessage.getMessageType();

	if (msgType !== MessageConsts.TYPE_TEXT) {
		cinReq.addHeaderInt32(CINRequestConts.TYPE, msgType);
		var attachment = chatMessage.getAttachment();
		if(!attachment){
			return;
		}
		cinReq.addBody(CINRequestConts.BODY, attachment.getPPMCINRequest());
	} else{
		cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(message));
	}
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new ChatProxyCallback(callback, chatMessage));

	cinReq.setMetaInfo('PPMessage', '0x01');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);

	// uuid =  UUID.randomUUID();
	// var bodyBytes = EncryptionUtils.encrypt(message, uuid);
	// cinReq.addHeader(CINRequestConts.ENCRYPT, uuid);
	// uuid =  UUID.randomUUID();

		// var messageBytes = JIOUtils.getBytes(message);
	// var bodyBytes = EncryptionUtils.encrypt(message, uuid);
	// cinReq.addBody(CINRequestConts.BODY, bodyBytes);
	// cinReq.addHeader(CINRequestConts.SERVERDATA, instance.getToken());
	// chatMessage.sendMethod = CinRequestMethod.PPMessage;

	// JIOClient.getInstance().sendMessage(chatMessage, callback);
}

RMCManager.prototype.getChannels=function(version, callback){

}
RMCManager.prototype.getRecommendChannels = function(index, count, version, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_GET_RECOMMENDED_ACCOUNT);
	cinReq.addHeaderInt64(CINRequestConts.KEY, count);
	// cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeaderInt64(CINRequestConts.INDEX, index);
	cinReq.addHeaderInt64(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new RecommendChanelListCallback(index, callback));
	
	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_GET_RECOMMENDED_ACCOUNT');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.getFocusChannels = function(type, version, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_GET_FOCUS);
	if(type > 0) {
		cinReq.addHeaderInt64(CINRequestConts.TYPE, type);
	}
	cinReq.addHeaderInt64(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);
	cinReq.setCallback(new FocussedChanelListCallback(callback));  	

	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_GET_FOCUS');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.editFollowChannel = function(channel, version, callback) {
	this.setFocusChannel(channel,version,callback);
}

RMCManager.prototype.setFocusChannel = function(channel, version, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_SET_FOCUS);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	cinReq.addHeaderInt64(CINRequestConts.TYPE, channel.isFollowing()?1:0);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new SetFocusCallback(channel,callback));
	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_SET_FOCUS');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.search = function(searchContent, callback){
	this.searchWithPageIndex(0,20, searchContent, callback);
};

RMCManager.prototype.searchWithPageIndex = function(indexStart, countPerPag, content, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_SEARCH);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, UserModel.getInstance().getUserID());
	cinReq.addHeaderInt64(CINRequestConts.KEY, countPerPag);
	cinReq.addHeaderInt64(CINRequestConts.INDEX, indexStart);
	cinReq.addHeaderString(CINRequestConts.STATUS, content);

	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new ChannelSearchProxyCallback(callback, indexStart, countPerPag));  	
	cinReq.setMetaInfo('PPService','EVENT_PUBLIC_SEARCH');	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.getOfflineMessages = function(channels, callback){
	var cinReq = new CINRequest(CINRequestConts.PPMessage, ChannelConst.EVENT_PPM_OFFLINE);
    cinReq.addHeader(CINRequestConts.TO, UserModel.getInstance().getUserID());
    for(var index=0;index<channels.length; index++){
        var cinRequest = new CINRequest(CINRequestConts.SERVICE);
		cinRequest.addHeader(0x01, channels[index].getPublicId());
		var cardVersion = channels[index].getCardVersion();
		cardVersion = (cardVersion==null || cardVersion==undefined)? 0 :cardVersion;
        cinRequest.addHeaderInt64(0x02, cardVersion);
        cinReq.addBody(CINRequestConts.BODY, cinRequest.convert());
    }
    cinReq.setCINMessageObject();   
    cinReq.setArgs(arguments);
    cinReq.setCallback(new EmptyResponseCallback(callback));       
	cinReq.setMetaInfo('PPMessage','EVENT_PPM_OFFLINE');	
    JIOClient.getInstance().getCINClient().send(cinReq);

}

RMCManager.prototype.getLastUpdatedChannel = function(channel, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_LAST_UPDATETIME);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	// cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	// cinReq.addHeaderInt64(CINRequestConts.KEY, type);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback({
		onSuccess: function(cinReponse){
			var timeStamp = 0;
            var body = cinReponse.getBody();
            if(body && cinReponse.containsHeader(0x01)){
            	timeStamp = cinReponse.getInt(0x01);
            }
            callback.onSuccess(timeStamp);
		},
		onError: function(error){

		}
	});  	
	cinReq.setMetaInfo('PPService', 'EVENT_PUBLIC_LAST_UPDATETIME');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.prototype.requestPublicReport = function(channel, type, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_REPORT);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.TO, channel.getPublicId());
	cinReq.addHeaderInt64(CINRequestConts.KEY, type);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new EmptyResponseCallback(callback));  	
	cinReq.setMetaInfo('PPService', 'EVENT_PUBLIC_REPORT');	
	JIOClient.getInstance().getCINClient().send(cinReq);
}
RMCManager.prototype.requestPublicGetAll = function(selfUserId, toUserId, indexStart, countPerPage, callback) {
	var cinReq = new CINRequest(CINRequestConts.PPService, ChannelConst.EVENT_PUBLIC_GET_ALL);
	cinReq.addHeader(CINRequestConts.FROM, selfUserId);
	cinReq.addHeader(CINRequestConts.TO, toUserId);
	cinReq.addHeader(CINRequestConts.KEY, countPerPage);
	cinReq.addHeader(CINRequestConts.INDEX, indexStart);
	cinReq.setCINMessageObject(); 	
	cinReq.setArgs(arguments);	 	
	cinReq.setCallback(new PublicGetAllCallback(callback));  	
	cinReq.setMetaInfo('PPService', 'EVENT_PUBLIC_GET_ALL');	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RMCManager.getChannels = function(cinMessage){
    var bodys = cinMessage.getBodys();
    var channels = new Array();
    bodys.forEach(function(cinVal, index){
        var response = CINResponse.getCINMessage(cinVal.val, null, false);
		var channel = new Channel();
		channel.init(response);
		channels.push(channel);
    });
    return channels;
}

RMCManager.prototype.getExploreChannelList = function(version, callback) {
    var cinReq = new CINRequest(ChannelConst.RMC, ChannelConst.EVENT_RMC_CHANNEL_LIST);
    
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeaderInt64(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new ExploreChannelsListProxyCallback(callback));
	cinReq.setMetaInfo('RMC', 'EVENT_RMC_CHANNEL_LIST');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.getExploreCheckStory = function(channelId, storyId, callback) {
    var cinReq = new CINRequest(ChannelConst.RMC, ChannelConst.EVENT_RMC_CHECK_STORY);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.INDEX, storyId);
	cinReq.addHeader(CINRequestConts.TO, channelId);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new ChannelStoryCallback(callback));

	cinReq.setMetaInfo('RMC', 'EVENT_RMC_CHECK_STORY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RMCManager.prototype.getExploreChannelInfo = function(channelId, profileVersion, contentVersion, callback) {
	var cinReq = new CINRequest(ChannelConst.RMC, ChannelConst.EVENT_RMC_CHANNEL_INFO);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());	
	cinReq.addHeader(CINRequestConts.TO, channelId);
	cinReq.addHeaderInt64(CINRequestConts.VERSION, profileVersion);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, contentVersion);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new ExploreChannelInfoCallback(callback));
	cinReq.setMetaInfo('RMC', 'EVENT_RMC_CHANNEL_INFO');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};


