function UserModel(){
	this.domain = null;
	this.cmpAddress = null;
	this.serverNumber = null;
	this.navResponse = null;
	this.userId = null;
	this.password = null;
	this.token = null;
	this.serverKey = null;
	this.phoneNumber = null;
	this.credential = null;
	this.dateTime = null;
	this.tokenExpiry = null;
	this.deviceModel = null;
	this.language = 0;
}

UserModel.getInstance= function(){
    if(UserModel.instance == null || UserModel.instance == undefined){
        UserModel.instance = new UserModel();
    }
    return UserModel.instance;
};

UserModel.prototype.init = function(cinMessage){
	this.userId = new Int8Array(cinMessage.getHeader(CINRequestConts.FROM));
	this.password = new Int8Array(cinMessage.getHeader(CINRequestConts.PASSWORD));
	this.token = new Int8Array(cinMessage.getHeader(CINRequestConts.TOKEN));
};

UserModel.prototype.setPhoneNumber = function(phoneNumber) {
	this.phoneNumber = phoneNumber;
};

UserModel.prototype.getPhoneNumber = function() {
	return this.phoneNumber;
};

UserModel.prototype.getEPhoneNumber = function() {
	 return CinBase64.encode(this.getPhoneNumber());
	// return 'KzkxOTkwMTM5NjM0MA;;';
};

UserModel.prototype.isLoggedIn = function() {
	return this.getUserID() !== null;
};

UserModel.prototype.getUserID = function(){
	return this.userId;
}

UserModel.prototype.getPassword = function(){
	return this.password;
}

UserModel.prototype.getToken = function(){
	return this.token;
}

UserModel.prototype.setServerKey = function(serverKey){
	this.serverKey = new Int8Array(serverKey);
}

UserModel.prototype.getServerKey = function(){
	return this.serverKey;
}

UserModel.prototype.setCredential = function(credential){
	this.credential=credential;
}

UserModel.prototype.getCredential = function(){
	return this.credential;
}

UserModel.prototype.setTokenExpiry = function(tokenExpiry){
	this.tokenExpiry=tokenExpiry;

	// mushtaq added this code 
	// indexedDB
}

UserModel.prototype.geTokenExpiry = function(){
	return this.tokenExpiry;
}

UserModel.prototype.initNav = function(cinMessage){
	this.domain = JIOUtils.toString(cinMessage.getHeader(0x07));
	this.serverNumber = JIOUtils.toString(cinMessage.getHeader(0x08));
	this.navResponse = cinMessage.toString();
	this.cmpAddress = cinMessage.getString(0x01);

	// mushtaq added this code 
	// indexedDB
}

UserModel.prototype.initLogon = function(cinMessage){
	var token = cinMessage.getHeader(CINRequestConts.TOKEN);
	
	if(token.length >0){
		this.token = token;
	}

	this.tokenExpiry = cinMessage.getHeader(CINRequestConts.EXPIRE);
	this.credential = cinMessage.getHeader(CINRequestConts.CREDENTIAL);
	this.dateTime = cinMessage.getHeader(CINRequestConts.DATETIME);
}

UserModel.prototype.initKeepAlive = function(cinMessage){
	this.initLogon(cinMessage);
}


UserModel.prototype.getDateTime = function(){
	return this.dateTime;
}

UserModel.prototype.getNavResponse = function(){
	return this.navResponse;
} 

UserModel.prototype.getDomain = function(){
	return this.domain;
}

UserModel.prototype.setDeviceModel = function(deviceModel){
	this.deviceModel = deviceModel;
}

UserModel.prototype.getDeviceModel = function(){
	return this.deviceModel;
}

UserModel.prototype.setLanguage = function(language){
	// Jitendra's code
	return this.language = language;
};

UserModel.prototype.setCMPIP = function(cmpAddress){
	this.cmpAddress = cmpAddress;
}

UserModel.prototype.getCMPIP = function(){
	return this.cmpAddress;
}

UserModel.prototype.getLanguage = function(){
	return this.language;
};

UserModel.prototype.getName = function(){
	return "Jitendra";
}

UserModel.prototype.getPushToken = function(){
	return new PushToken();
}
