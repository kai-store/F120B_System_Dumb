function User () {
	this.uname = "";
	this.password = "";
	this.language = "";
	this.cilenttype = 2;
	this.devicetoken = "";
	this.capability = "";
	this.dayQuota = 0;
	this.monthQuota = 0;
}

User.prototype = {
	constructor: User,

	setName: function(uname){
		this.uname=uname;
	},

	getName: function(){
		return this.uname;
	},

	setPassword: function(password){
		this.password = password;
	},

	getPassword: function(){
		return this.password;
	},
	setLanguage: function(language){
		this.language = language;
	},
	
	getLanguage: function(){
		return this.language;
	},
	
	setClientType: function(cilenttype){
		this.cilenttype = cilenttype;
	},

	getClientType: function(){
		this.cilenttype;
	},
	setDeviceToken: function(devicetoken){
		this.devicetoken=devicetoken;
	},
	getDeviceToken: function(){
		return this.devicetoken;
	},
	setCapability: function(capability){
		this.capability=capability;
	},
	getCapability: function(){
		return this.capability;
	}
};

