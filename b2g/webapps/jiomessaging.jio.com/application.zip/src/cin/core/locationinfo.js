function LocationInfo(){
    this.addressLine = null;
    this.city = null;
    this.subLocality = null;
    this.state = null;
    this.county = null;
    this.postalCode = null;
    this.knownName = null;
    this.setDefaultInfo();
}

LocationInfo.getInstance = function(){
    if(!LocationInfo.instance || LocationInfo.instance === null){
        LocationInfo.instance = new LocationInfo();
    }
    return LocationInfo.instance;
}

LocationInfo.prototype.setAddressLine = function(addressLine){
    this.addressLine = addressLine;
}

LocationInfo.prototype.setCity = function(city){
    this.city = city;
}

LocationInfo.prototype.setSubLocality = function(subLocality){
    this.subLocality = subLocality;
}

LocationInfo.prototype.setState = function(sate){
    this.state = state;
}

LocationInfo.prototype.setCountry = function(county){
    this.country = contry;
}

LocationInfo.prototype.setPostalCode = function(postalCode){
    this.postalCode = postalCode;
}

LocationInfo.prototype.setKnownName = function(knownName){
    this.knownName = knownName;
}

LocationInfo.prototype.setDefaultInfo = function(){
    this.addressLine = 'Krishna reddy';
    this.city = 'Bangalore';
    this.county = 'India';
    this.state = 'KA';
    this.postalCode = '560073';
    this.knownName = null;
}

LocationInfo.prototype.getInfo = function(){
    var locactionInfo = "";
    if(this.addressLine && this.addressLine !== null){
        locactionInfo = this.addressLine;
    }
    
    if(this.city && this.city !==null){
        locactionInfo+=","+this.city;
    }

    if(this.county && this.county!==null){
        locactionInfo+= ","+this.county;
    }

    if(this.state && this.state!==null){
        locactionInfo+= ","+this.state;
    }

    if(this.postalCode && this.postalCode!==null){
        locactionInfo+= ","+this.postalCode;
    }

    if(this.knownName && this.knownName!==null){
        locactionInfo+= ","+knownName;
    }
    return locactionInfo;
}
