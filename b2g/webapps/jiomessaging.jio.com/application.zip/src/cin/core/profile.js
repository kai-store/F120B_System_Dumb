function Profile () {
	this.name = "";
	this.gender = 0;
	this.mood = 0;
	this.expression = "";
	this.userId = null;
	this.version = null;
	this.isOnline = null ;
	this.notifyNow = null;
	this.value  = null; 
	this.mobileNo = null;
	this.portraitId = null;
	this.pictureSize = null;
	this.thumbData = null;
}

Profile.prototype = {
	constructor: Profile,

	setName: function(uname){
		this.name=uname;
	},

	getName: function(){
		return this.name;
	},

	setMood: function(mood){
		this.mood = mood;
	},

	getMood: function(){
		return this.mood;
	},
	
	setGender: function(gender){
		this.gender = gender;
	},
	
	getGender: function(){
		return this.gender;
	},

	setExpression: function(expression){
		this.expression = expression;
	},

	getExpression: function(){
		return this.expression;
	},

	init: function(cinMessage){
		this.userId = cinMessage.getHeader(CINRequestConts.TO);
		this.isOnline = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.STATUS)) === 1;
		this.version = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.VERSION));
		this.notifyNow = cinMessage.getHeader(CINRequestConts.TOKEN);
		this.value =  cinMessage.getBody();

		if(!this.value){
			this.value = null;
		}
	}
};

Profile.prototype.setUserID = function(userId){
	this.userId = userId;
}

Profile.prototype.getUserID = function(){
	return this.userId;
}

Profile.prototype.setVersion = function(version){
	this.version = version;
}

Profile.prototype.getVersion = function(){
	return this.userId;
}

Profile.prototype.setIsOnline = function(isOnline){
	this.isOnline = isOnline;
}

Profile.prototype.isOnline = function(){
	return this.isOnline;
}

Profile.prototype.setNotifyNow = function(notifyNow){
	this.notifyNow = notifyNow;
}

Profile.prototype.getNotifyNow = function(){
	return this.notifyNow;
}

Profile.prototype.setValue = function(value){
	this.value = value;
}

Profile.prototype.getValue = function(){
	return this.value;
}

Profile.prototype.setMobileNo = function(mobileNo){
	this.mobileNo = mobileNo;
}

Profile.prototype.getMobileNo = function(){
	return this.mobileNo;
}

Profile.prototype.setPortraitId = function(portraitId){
	this.portraitId = portraitId;
}

Profile.prototype.getPortraitId = function(){
	return this.portraitId;
}

Profile.prototype.setPictureSize = function(pictureSize){
	this.pictureSize = pictureSize;
}

Profile.prototype.getPictureSize = function(){
	return this.pictureSize;
}

Profile.prototype.setThumbData = function(thumbData){
	this.thumbData = thumbData;
}

Profile.prototype.getThumbData = function(){
	return this.thumbData;
}
