/**
 * @class OfflineMessageInfo
 * is for offline message info
 */
function OfflineMessageInfoModel () {
	this.to = null;
	this.totalMessageCount = 0;
	this.unReadMsgCount = 0;
}

OfflineMessageInfoModel.prototype.init = function(cinMessage){
	this.to = cinMessage.getHeader(CINRequestConts.INFO_HEADER_USERID);
	this.unReadMsgCount = cinMessage.getInt(CINRequestConts.INFO_HEADER_OFFLINE_COUNT);
	this.totalMessageCount = cinMessage.getInt(CINRequestConts.INFO_HEADER_OFFLINE_READ_SEQ);
};

OfflineMessageInfoModel.prototype.setTo = function(to){
	this.to = to;
}

OfflineMessageInfoModel.prototype.setTotalMessageCount = function(totalMessageCount){
	this.totalMessageCount = totalMessageCount;
}

OfflineMessageInfoModel.prototype.setUnReadMsgCount = function(unReadMsgCount){
	this.unReadMsgCount = unReadMsgCount;
}

OfflineMessageInfoModel.prototype.getTo = function(){
	return this.to;
}

/**
 * Method will get the total message count from the server for the session
 * @return {Number}
 * @memberof OfflineMessageInfo#
 */
OfflineMessageInfoModel.prototype.getTotalMessageCount= function(){
	return this.totalMessageCount;
}

/**
 * Method will get the total unread message count from the server for the session
 * @return {Number}
 * @memberof OfflineMessageInfo#
 */
OfflineMessageInfoModel.prototype.getUnReadMsgCount= function(){
	return this.unReadMsgCount;
}
