/**
 * Class is for chat information. 
 * @class
 */
function ChatMessage () {
	this.from = null;
	this.to = null;
	this.msgType = MessageConsts.TYPE_TEXT;
	this.messageID = null;
	this.mobileNumbers = null;
	this.status = null;
	this.version = null;
	this.dateTime = null;
	this.serverKey = null;
	this.uuid = null;
	this.token = null;
	this.messageBody = null;
	this.eventType = -1;
	this.sessionType = CINRequestConts.SESSIONSINGLE;
	this.csequence = null;
	this.imageInfo = null;
	this.attachment = null;
	this._isBroadCast = false;
	this.name = null;
}

ChatMessage.prototype = {
	/**
	 * 
	 */
	setSessionType: function(sessionType){
		this.sessionType = sessionType;
	},
	setBroadCast: function(isBroadCast){
		this._isBroadCast=isBroadCast;
	},
	isBroadCast: function(){
		return this._isBroadCast;
	},
	isGroup: function(){
		return this.sessionType === CINRequestConts.SESSIONGROUP;
	},
	getSessionType: function(){
		return this.sessionType;
	},
	setMessageType: function(msgType){
		this.msgType = msgType;
	},

	getMessageType: function(){
		return this.msgType;
	},

	init: function(cinMessage){
		var msgType = cinMessage.getHeader(CINRequestConts.TYPE);
		if(!cinMessage.containsHeader(CINRequestConts.TYPE)){
			if(cinMessage.containsHeader(CINRequestConts.JIOMONEYMSG)){
				this.msgType = MessageConsts.TYPE_JIOMONEY;
			}
		}else{
			this.msgType = JIOUtils.toLong(msgType);
		}
		
		this.from = this.isGroup() ? cinMessage.getHeader(CINRequestConts.INDEX) :  cinMessage.getHeader(CINRequestConts.FROM);
		
		this.to = this.isGroup() ? cinMessage.getHeader(CINRequestConts.FROM) : cinMessage.getHeader(CINRequestConts.TO);
		
		// this.from = cinMessage.getHeader(CINRequestConts.FROM);
		// this.to = cinMessage.getHeader(CINRequestConts.TO);

		this.messageID = cinMessage.getHeader(CINRequestConts.MESSAGEID);

		this.mobileNumbers = cinMessage.getHeaders(CINRequestConts.MOBILENO);

		this.name = cinMessage.getString(CINRequestConts.NAME);


		// this.csequence = cinMessage.getHeader(CINRequestConts.CSEQUENCE);
		this.csequence = cinMessage.getInt(CINRequestConts.CSEQUENCE);
				
		this.status = cinMessage.getInt(CINRequestConts.STATUS);
		
		this.msgStatusObj = new MessageStatus();
		this.msgStatusObj.init(this.status);

		if((this.status & 16) !== 0 ){
			this.status = MessageConsts.STATUS_IGNORE;
		} else {

			// debugger;
			this.status = MessageConsts.STATUS_SENT;
			if(this.from != "" && this.from != undefined && this.from != null){
				if(String(UserModel.getInstance().getUserID()) != String(this.from)){
					this.status = MessageConsts.STATUS_ARRIVED;
				}
			}

			/*if((this.status & 8) !== 0 ){
				this.status = MessageConsts.STATUS_ARRIVED;
			}
			
			if((this.status & 8) === 0 ){
				this.status = MessageConsts.STATUS_SENT;
			}*/
		}


		this.version = cinMessage.getHeader(CINRequestConts.VERSION);

		this.dateTime = cinMessage.getHeader(CINRequestConts.DATETIME);
		this.dateTime = JIOUtils.toDate(this.dateTime);

		this.serverKey = cinMessage.getHeader(CINRequestConts.SERVERDATA);

		this.uuid = cinMessage.getHeader(CINRequestConts.ENCRYPT);

		this.token = cinMessage.getHeader(CINRequestConts.TOKEN);

		var msg = cinMessage.getBody();
		// if(msg && this.msgType === MessageConsts.TYPE_TEXT){
		if(msg && ((this.msgType === MessageConsts.TYPE_TEXT || this.msgType === MessageConsts.TYPE_FREE_SMS) && this.sessionType !== 3)){
			
			if(this.uuid && this.uuid.length>0 && msg && msg !== null){
				msg = EncryptionUtils.decrypt(msg, this.uuid, this.serverKey);
			} else{
				msg = JIOUtils.toString(CinBase64.decode(msg));
			}

		} else if(this.msgType !== MessageConsts.TYPE_TEXT || this.sessionType == 3){
			this.attachment = DataManager.getDataInfo(cinMessage, this.uuid, this.serverKey);
			msg = undefined;
		}
		
		this.messageBody = msg;		
	},

	setFrom: function(from){
		this.from = from;
	},

	setTo:  function(to){
		this.to = to;
	},

	setMessageId: function(messageID){
		if(messageID === null || !messageID){
			messageID = UUID.randomUUID();
		}

		this.messageID = messageID;	
	},

	setMobileNumbers: function(mobileNumbers){
		this.mobileNumbers = mobileNumbers;
	},
	setMobileNumber: function(mobileNumber){
		var mobileNums = new Array(mobileNumber);
		this.setMobileNumbers(mobileNums);
	},
	setStatus: function(status){
		this.status = status;
	},

	setVersion: function(version){
		this.version = version;
	},

	setDateTime: function(dateTime){
		this.dateTime = dateTime;
	},

	setServerKey: function(serverKey){
		this.serverKey = serverKey;
	},

	setSessionID: function(serverKey){
		this.serverKey = serverKey;
	},
	setUUid: function(uuid){
		this.uuid = uuid;
	},

	setToken: function(token){
		this.token = token;
	},

	setMessageBody: function(messageBody){
		this.messageBody = messageBody;
	}, 

	/**
	 * Method will return, from id.
	 * @return {Int8Array} - UserId
	 */
	getFrom: function(){
		return this.from;
	},
	/**
	 * Method will return, to id.
	 * @return {Int8Array} - UserId.
	 */
	getTo:  function(){
		return this.to;
	},
	/**
	 * Method will return message id.
	 * @return {Int8Array} - messageid
	 */
	getMessageId: function(){
		return this.messageID;
	},
	/**
	 * Method will return phone number's.
	 * @return {Array}
	 */
	getMobileNumbers: function(){
		return this.mobileNumbers;
	},
	/**
	 * Method will return mobile number. If any numbers are setting via setMobileNumbers or from the server it will return first number,
	 * Otherwise it will return null.
	 * @return {String}
	 */
	getMobileNumber: function(){
		if(this.mobileNumbers && this.mobileNumbers.length>0)
			return this.mobileNumbers[0];
		return null;
	},
	getStatus: function(){
		return this.status;
	},

	getVersion: function(){
		return this.version;
	},

	getDateTime: function(){
		return this.dateTime;
	},

	getServerKey: function(){
		return this.serverKey;
	},

	getSessionID: function(){
		return this.serverKey;
	},
	getUUid: function(){
		return this.uuid;
	},

	getToken: function(){
		return this.token;
	},

	getMessageBody: function(){
		return this.messageBody;
	},

	setEventType: function(eventType){
		this.eventType =  eventType;
	},

	getEventType: function(){
		return this.eventType;
	},

	setAttachment: function(attachment){
		this.attachment =  attachment;
	},

	getAttachment: function(){
		return this.attachment;
	},

	setName: function(name){
		if(!name || name == "") return;
		this.name = name;
	},

	getName: function(){
		return this.name;
	}
};
