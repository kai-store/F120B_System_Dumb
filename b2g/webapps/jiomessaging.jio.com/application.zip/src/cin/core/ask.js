function Ask(to, cinMessage) {
	this.to = to;
	this.expire = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.EXPIRE))  * 60 * 1000;
	this.isOnline = false;
	lastSeen = cinMessage.getHeader(CINRequestConts.DATETIME);
	if(lastSeen !== ""){
		this.lastSeen = JIOUtils.toDate(lastSeen);
	}else if(lastSeen == ""){
		this.isOnline = true
		this.lastSeen = 0;
	}
};

Ask.prototype.getTo = function() {
	return this.to;
};

Ask.prototype.getExpire = function() {
	return this.expire;
};

Ask.prototype.isUserOnline = function() {
	return this.isOnline;
};
Ask.prototype.getLastSeen = function(first_argument) {
	return this.lastSeen;
};
