function GroupModel () {
	this.userId = null; 
	this.to = null;					//from
	this.groupId = null;					//to
	this.groupMaxMember = null; 			//status
	this.groupVersion = null; 				//version
	this.groupTitle = null; 
	this.name = null;				//name
	this.userName = null ;
	this.newsNotify = null; 				//index
	this.version = null;
	this.sourceId = null;
	this.sourceName = null;
	this.adminName = null;
	this.adminUserId = null;
	this.msgType = null;
	this.isFromInvite = false;
	this.newMembers = [];
	this.portraitId = null;
	this.portraitSize = null;
	this.inviter = null;
	this.inviterName = null;
	this.fileId = null;
	this.fileSize = null;
	this.thumb = null;
	this.createrId = null;
}

GroupModel.prototype.initGroup = function(cinMessage){
	this.userId = cinMessage.getHeader(CINRequestConts.FROM);
	this.to = cinMessage.getHeader(CINRequestConts.TO);
	this.adminUserId = this.to;
	this.groupId = cinMessage.getHeader(CINRequestConts.KEY);
	this.groupTitle = cinMessage.getString(CINRequestConts.NAME);
	this.newMembers = cinMessage.getHeaders(CINRequestConts.INDEX);
	this.adminUserId = cinMessage.getHeader(CINRequestConts.INDEX);
	this.groupMaxMember = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.STATUS));
	this.groupVersion = cinMessage.getHeader(CINRequestConts.HEADER_TYPE_CONTACT_VERSION);
	this.newsNotify = cinMessage.getHeader(CINRequestConts.TYPE);
	this.version = JIOUtils.toLong(cinMessage.getHeader(CINRequestConts.VERSION));
};

GroupModel.prototype.setUserID = function(userId){
	this.userId = userId;
}

GroupModel.prototype.getUserID = function(){
	return this.userId;
}

GroupModel.prototype.setTo = function(to){
	this.to = to;
}

GroupModel.prototype.getTo = function(){
	return this.to;
}

GroupModel.prototype.setGroupId = function(groupId){
	this.groupId = groupId;
}

GroupModel.prototype.getGroupId = function(){
	return this.groupId;
}

GroupModel.prototype.setGroupMaxMember = function(groupMaxMember){
	this.groupMaxMember = groupMaxMember;
}

GroupModel.prototype.getGroupMaxMember = function(){
	return this.groupMaxMember;
}

GroupModel.prototype.setGroupVersion = function(groupVersion){
	this.groupVersion = groupVersion;
}

GroupModel.prototype.getGroupVersion = function(){
	return this.groupVersion;
}

GroupModel.prototype.setGroupTitle = function(groupTitle){
	this.groupTitle = groupTitle;
}

GroupModel.prototype.getGroupTitle = function(){
	return this.groupTitle;
}

GroupModel.prototype.setUserName = function(userName){
	this.userName = userName;
}

GroupModel.prototype.getUserName = function(){
	return this.userName;
}

GroupModel.prototype.setName = function(name){
	this.name = name;
}

GroupModel.prototype.getName = function(){
	return this.name;
}

GroupModel.prototype.setNewsNotify = function(newsNotify){
	this.newsNotify = newsNotify;
}

GroupModel.prototype.getNewsNotify = function(){
	return this.newsNotify;
}

GroupModel.prototype.setVersion = function(version){
	this.version = version;
}

GroupModel.prototype.getVersion = function(){
	return this.version;
}

GroupModel.prototype.setSourceID = function(sourceId){
	this.sourceId = sourceId;
}

GroupModel.prototype.getSourceID = function(){
	return this.sourceId;
}

GroupModel.prototype.setSourceName = function(sourceName){
	this.sourceName = sourceName;
}

GroupModel.prototype.getSourceName = function(){
	return this.sourceName;
}

GroupModel.prototype.setAdminName = function(adminName){
	this.adminName = adminName;
}

GroupModel.prototype.getAdminName = function(){
	return this.adminName;
}

GroupModel.prototype.setAdminUserId = function(adminUserId){
	this.adminUserId = adminUserId;
}

GroupModel.prototype.getAdminUserId = function(){
	return this.adminUserId;
}

GroupModel.prototype.setMsgType = function(msgType){
	this.msgType = msgType;
}

GroupModel.prototype.getMsgType = function(){
	return this.msgType;
}

GroupModel.prototype.setIsFromInvite = function(isFromInvite){
	this.isFromInvite = isFromInvite;
}

GroupModel.prototype.getIsFromInvite = function(){
	return this.isFromInvite;
}

GroupModel.prototype.setNewMembers = function(newMembers){
	this.newMembers = newMembers;
}

GroupModel.prototype.getNewMembers = function(){
	return this.newMembers;
}

GroupModel.prototype.setPortraitId = function(portraitId){
	this.portraitId = portraitId;
}

GroupModel.prototype.getPortraitId = function(){
	return this.portraitId;
}	

GroupModel.prototype.setPortraitSize = function(portraitSize){
	this.portraitSize = portraitSize;
}

GroupModel.prototype.getPortraitSize = function(){
	return this.portraitSize;
}	

GroupModel.prototype.setInviter = function(inviter){
	this.inviter = inviter;
}

GroupModel.prototype.getInviter = function(){
	return this.inviter;
}

GroupModel.prototype.setInviterName = function(inviterName){
	this.inviterName = inviterName;
}

GroupModel.prototype.getInviterName = function(){
	return this.inviterName;
}

GroupModel.prototype.setThumb = function(thumb){
	this.thumb = thumb;
}

GroupModel.prototype.getThumb = function(){
	return this.thumb;
}

GroupModel.prototype.setCreaterId = function(createrId){
	this.createrId = createrId;
}

GroupModel.prototype.getCreaterId = function(){
	return this.createrId;
}
