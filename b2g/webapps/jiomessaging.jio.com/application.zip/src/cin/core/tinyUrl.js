function TinyUrl () {
	this.url = "";
}

TinyUrl.getInstance= function(){
    if(TinyUrl.instance == null || TinyUrl.instance == undefined){
        TinyUrl.instance = new TinyUrl();
    }
    return TinyUrl.instance;
};


TinyUrl.prototype = {
	constructor: TinyUrl,

	setUrl: function(url){
		this.url = url;
	},

	getUrl: function(){
		return this.url;
	}	

};

