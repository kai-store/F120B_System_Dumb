function DeviceInfo(){
    this.deviceStatistics = null;
    this.carrierName = null;
    this.networkType = null;
    this.manufacturer = null;
    this.model = null;
    this.version = null;
    this.versionRelease = null;
    this.locationStats = null;
    // this.setDefaultInfo();
};

DeviceInfo.getInstance = function(){
    if(!DeviceInfo.instance || DeviceInfo.instance === null){
        DeviceInfo.instance = new DeviceInfo();
    }
    return DeviceInfo.instance;
}


DeviceInfo.prototype.setCarrierName = function(carrierName){
    this.carrierName = carrierName;
}

DeviceInfo.prototype.setNetworkType = function(networkType){
    this.networkType = networkType;
}

DeviceInfo.prototype.setManufacturer = function(manufacturer){
    this.manufacturer = manufacturer;
}

DeviceInfo.prototype.setModel = function(model){
    this.model = model;
}

DeviceInfo.prototype.setVersion = function(version){
    this.version = version;
}

DeviceInfo.prototype.setVersionRelease = function(versionRelease){
    this.versionRelease = versionRelease;
}

DeviceInfo.prototype.getDeviceInfo =  function(){
	this.carrierName = "Reliance jio";
	this.networkType = "GSM";
	this.manufacturer = "LYF";
	this.model = "Featued phone";
	this.version = 20;
	this.versionRelease = "1.2";
	this.deviceStatistics = this.carrierName + "," + this.networkType + "," + this.manufacturer + "," + this.model + "," + this.version + "," + this.versionRelease; /*+ "," + versionName;*/
	this.locationStats = LocationInfo.getInstance().getInfo();
	this.deviceStatistics = this.deviceStatistics + "," + this.locationStats;
    return this.deviceStatistics;
}
