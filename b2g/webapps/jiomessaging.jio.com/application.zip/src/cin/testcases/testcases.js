function TestCase(callback) {
	this.uiCallback = callback;
}

TestCase.prototype.run = function() {


    //  JIOClient.getInstance().sendFeedback('my feedback is', 1,{
    //     onSuccess: function(msg){            
    //         console.log("sendFeedback ---- "+ msg);
    //     },
    //     onError: function(msg){
    //        console.log('sendFeedback Error' + msg);
    //     },
    // });

    hdCall = new HDCall();
    hdCall.setTo(new Int8Array([-85, -108, -22, -48, 1]));
    //  hdCall.setTo(new Int8Array([2,68,42,66,2]));
    hdCall.setFrom(UserModel.getInstance().getUserID());
    // hdCall.setDeviceInfo("android_1.2");
    // hdCall.setTurnServer("");
    hdCall.setEligibilityVersion("1.0");


    RTMManager.getInstance().call(hdCall, {
        onTURNRecived: function(hdCall){
            hdCall.setSdp('{"sdp":"v=0\r\n\o=- 20518 0 IN IP4 203.0.113.1\r\n\s= \r\n\t=0 0\r\n\c=IN IP4 203.0.113.1\r\n\a=ice-ufrag:F7gI\r\n\a=ice-pwd:x9cml/YzichV2+XlhiMu8g\r\n\a=fingerprint:sha-1 42:89:c5:c6:55:9d:6e:c8:e8:83:55:2a:39:f9:b6:eb:e9:a3:a9:e7\r\n\m=audio 54400 RTP/SAVPF 0 96\r\n\a=rtpmap:0 PCMU/8000\r\n\a=rtpmap:96 opus/48000\r\n\a=ptime:20\r\n\a=sendrecv\r\n\a=candidate:0 1 UDP 2113667327 203.0.113.1 54400 typ host\r\n\a=candidate:1 2 UDP 2113667326 203.0.113.1 54401 typ host\r\n\m=video 55400 RTP/SAVPF 97 98\r\n\a=rtpmap:97 H264/90000\r\n\a=fmtp:97 profile-level-id=4d0028;packetization-mode=1\r\n\a=rtpmap:98 VP8/90000\r\n\a=sendrecv\r\n\a=candidate:0 1 UDP 2113667327 203.0.113.1 55400 typ host\r\n\a=candidate:1 2 UDP 2113667326 203.0.113.1 55401 typ host\r\n\", "type":"offer"}');
            //hdCall.initICE("");
        },
        onRingCall: function(hdCall, offlineUserIds){

        },
        onUserAnsCall: function(hdCall){
            
        },
        onCallBusy: function(hdCall, userId, status){
            // debugger;
        },
        onICEInfo: function(hdCall){

        },
        onInvitedUsers: function(hdCall){

        },
        onCallEnd: function(isBusy, hdCall){

        },
        onUserOnShow: function(){

        },
        onSwitchDevice: function(){

        },
        onKickMember: function(){

        },
        onError: function(error){

        }
    });


//   JIOClient.getInstance().getFreeSmsQuota({
//                 onSuccess: function(msg){            
//                     console.log("getFreeSmsQuota ---- "+ JSON.stringify(msg));
//                 },
//                 onError: function(msg){
//                    console.log('getFreeSmsQuota Error' + JSON.stringify(msg));
//                 },
//             });
	// JIOClient.getInstance().keepAlive();
	/* var profile = new Profile();
	profile.setName('aaa');
	JIOClient.getInstance().updateProfile(profile, this.uiCallback);*/
	// JIOClient.getInstance().getProfile(this.uiCallback);

	// LogonProxyCallback.uploadContacts();


	//this.chatTest();
	//LogonProxyCallback.uploadContacts();

	// LogonProxyCallback.createGroupTest();
	// LogonProxyCallback.createGroupTest();
	// LogonProxyCallback.chatTest();
	// LogonProxyCallback.uploadContacts();


	//this.syncUpContacts();
    // this.createGroupTest();

   // this.getContactProfileInfo();
	// this.syncUpContacts();


    //this.createGroupTest();
    //  var profiles = [];
    // var groupId = [61,54,46,-116,-47];
    // var userId = [110,1,103,30,2];
    // var userId2 = [-52,1,103,30,2]
    // var profile = new Profile();
    // profile.setName('sushma');
    // profile.setUserID(userId);   
    // profiles.push(profile);
    // var profile = new Profile();
    // profile.setName('test');
    // profile.setUserID(userId2);
    // profiles.push(profile);

   /* JIOClient.getInstance().groupInvite(groupId, 'test',profiles,{
        onSuccess: function(msg){            
            console.log("Clear ---> HIS ---- "+msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });*/

    //this.getGroupList();
  //  var userID = UserModel.getInstance().getUserID();
  /*  JIOClient.getInstance().getGroupProfile(groupId,{
        onSuccess: function(msg){            
            console.log("Clear ---> HIS ---- "+ msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });*/
    var userID = [110,1,103,30,2];
   /* JIOClient.getInstance().getUserCard(userID,1,1,{
        onSuccess: function(msg){            
            console.log("getprofile ---- "+ msg);
        },
        onError: function(msg){
           console.log('Error' + msg);
        },
    });*/

};
TestCase.prototype.invite = function(){
    tinyInstance = TinyUrl.getInstance();
    var url = tinyInstance.getUrl();
     if (url && url.length > 0){
        callInvite(url);
     }else{
        JIOClient.getInstance().getTinyUrl({
            onSuccess: function(url){
                callInvite(url);
                console.log(msg);
            },
            onError: function(msg){
               console.log('Error');
            },
        });
     }    
}

function callInvite(url){
    /* JIOClient.getInstance().inviteViaEmail('sushma@divum.in',url,{
        onSuccess: function(msg){
            console.log(msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });*/
    JIOClient.getInstance().inviteViaSMS('+919513193889',url,{
        onSuccess: function(msg){
            console.log(msg);
        },
        onError: function(msg){
           console.log('Error');
        },
    });
}

TestCase.prototype.getContactProfileInfo = function(){
    // var userId = [110,1,103,30,2];
     var profile = new Profile();
     profile.setName('Mehak das');
     profile.setMood('liked jio');
     profile.setExpression(1);
     profile.setGender(0);
    /* var phonebook = [];
     phonebook.push('+918259275281');*/

    JIOClient.getInstance().updateProfile(profile,{
        onSuccess: function(msg){
            console.log(msg);
            JIOClient.getInstance().getProfile({
                onSuccess: function(msg){
                    console.log('getProfile'+ msg);
                },
                onError: function(msg){
                   console.log('getProfile'+'Error' + msg);
                },
            });
        },
        onError: function(msg){
           console.log('Error');
        },
    });
};


TestCase.prototype.syncUpContacts = function(){
    var phonebook = [];

    var obj = {};
    obj.name = 'sushma';
    obj.mobileNo = '+918259275281';
    phonebook.push(obj);

    var obj = {};
    obj.name = 'das';
    obj.mobileNo = '+919259275281';
    phonebook.push(obj);
    var index = 1,isLast = 1;

   /*instance1.contactSync(phonebook,index,isLast,{
        onError: function(errorJSON){
            console.log(errorJSON);
        },
        onSuccess: function(response){
           console.log(response);           
        }
    });
*/
   /* var phoneList = [];
            var obj = {};
            obj.name = 'das';
            obj.mobileNo = '+919259275281';
            obj.userId = [-50,1,103,30,2];
            phoneList.push(obj);
            instance1.handleBlackList(phoneList,2,{
                onError: function(errorJSON){
                    console.log('handleBlackList error '+ errorJSON);
                },
                onSuccess: function(version, userId,phonebook){
                   console.log('handleBlackList response '+ version.toString() + " " + userId.toString());
                }
            });*/

    /*var phoneList = [];
    phoneList.push('+919259275281');
    instance1.deleteContact(phoneList,{
        onError: function(errorJSON){
            console.log('delete contact error '+ errorJSON);
        },
        onSuccess: function(response){
           console.log('delete contact response '+ response);
        }
    });*/

   
     /*instance1.getAllBlackListContacts({
        onError: function(errorJSON){
            console.log('getAllBlackListContacts error '+ errorJSON);
        },
        onSuccess: function(response){
           console.log('getAllBlackListContacts response '+ response.toString());
        }
    });*/
}

TestCase.prototype.chatTest = function(){
    userIDs = new Array();

     userID = [-75,85,36,24,1];
    userIDs.push(userID);
    JIOClient.getInstance().sendRawMessage(null, userIDs,
     MessageConsts.TYPE_TEXT,"hi",{
        onSuccess: function(msg){
            console.log('---- Sent message Success chatTest---- ');
            // TestCase.prototype.chatTest();
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
}

TestCase.prototype.getGroupList = function(){
    userId = UserModel.getInstance().getUserID();
    userID = [110,1,103,30,2];
    JIOClient.getInstance().getGroupList(userId, {
        onSuccess: function(msg){
            var groupId = msg.getTo();
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
}

TestCase.prototype.updateGroupTest = function(groupId){
    userId = UserModel.getInstance().getUserID();
    var array = new Array();
    var pratima = [58,44,29,-77,1];
    array.push(userId);
    array.push(pratima);
    var group = new Group();
    var groupId = group.getGroupId();
    JIOClient.getInstance().updateGroup(groupId, "new Testing Group","new Testing Group" ,{
        onSuccess: function(msg){
            console.log('update Group list Success');
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
}


TestCase.prototype.createGroupTest = function(){
    userId = UserModel.getInstance().getUserID();
    user1 = [58,44,29,-77,1];
    user2 = [-52,1,103,30,2];
    var array = new Array();
    array.push(userId);
    array.push(user2);

    JIOClient.getInstance().createChatGroup(userId, "sushma Group","sushma" ,array,{
        onSuccess: function(msg){
           // this.getGroupListTest();
           console.log('create Group Success' + msg);
        },                      
        onError: function(msg){
            console.log('Error');
        },
    });
};

TestCase.prototype.getGroupInformation = function(){
     var groupId = [-117,53,46,-116,-47];

    JIOClient.getInstance().getGroupInfo(groupId, {
        onSuccess: function(msg){
            //var groupId = msg.getTo();
        },
        onError: function(msg){
           console.log('Error');
        },
    });
 };
