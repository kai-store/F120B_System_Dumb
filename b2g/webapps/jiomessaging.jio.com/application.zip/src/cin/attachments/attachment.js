function Attachment() {
 	this.dataInfo = null;
 	this.fileInfo = null;
}

Attachment.parseHeader = function(cinMsg){
	
};

Attachment.parseBody = function(cinBody) {
	var response = CINResponse.getCINMessage(cinBody, null, true);	
	this.dataInfo = new DataInfo();
	this.dataInfo.init(response);
	return this.dataInfo;
};	

