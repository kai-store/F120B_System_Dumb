function DataManager() {
    this.attachments = new Array();
	this.downloadQ = new Array();
	DataManager.uploadingAttachments = false;
	DataManager.DOWNLOAD_FILE_CHUNK = 30*1024;
}

DataManager.getInstance = function(){ 
	if(!DataManager.instance || DataManager.instance === null){
		DataManager.instance = new DataManager();
	}
	return DataManager.instance;
}

DataManager.prototype.getDownloadCallback = function(){
	return this.dataManagerDownloadCallback;
}
DataManager.prototype.setDownloadCallback = function(callback){
	this.dataManagerDownloadCallback = callback;
};

DataManager.prototype.setUploadCallback = function(callback){
	this.dataManagerUploadCallback = callback;
};
DataManager.prototype.getUploadCallback = function(){
	return this.dataManagerUploadCallback;
}

DataManager.prototype.addAttachmet = function(attachment){
    // this.attachments.push(attachment);
    if(this.dataManagerCallback){
        this.dataManagerCallback.onProgressChanged(attachment, -1);
    }
	attachment.status = MessageConsts.ATTACHMENT_QUEUE;
	this.attachments.push(attachment);
	if(attachment.thumbnailObj!==null && attachment.thumbnailObj){
		attachment.thumbnailObj.peerIds = attachment.peerIds;
		this.attachments.push(attachment.thumbnailObj);
	}
	this.start();
};

DataManager.prototype.start = function(){
	if(!DataManager.uploadingAttachments && this.attachments.length>0){
		var attachment = this.attachments.pop();
		this.uploadStart(attachment);
	}
}

DataManager.prototype.fileUploadCompled = function(isError){
	DataManager.uploadingAttachments = false;
	// if(this.attachments.length>0){
	this.start();
	// }
}

/**
 * Build a request for start downloading a file
 * 
 * @return Request for sending to server
 */

DataManager.prototype.downloadStart = function(fileDetails, _callback){
	// Kaal added
	if(!this.downloadQ){
		// debugger;
		this.downloadQ = new Array();
	}
	console.log("[DM] download start ", JSON.stringify(fileDetails));
	fileDetails.status = MessageConsts.ATTACHMENT_QUEUE;
	this.downloadQ.push(fileDetails);
	var cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.EVENT_START);
	var fileSize = fileDetails.getFileSize();
	var packetSize = DataManager.DOWNLOAD_FILE_CHUNK;
	//var packetSize = fileSize; //testing
	// var packetSize = 1*1024;//Testing
	var batchCount = parseInt(fileSize/packetSize);  
	if((batchCount*packetSize) !== fileSize){
		batchCount=batchCount+1;
	}
	var fileOffset = 0;
	// debugger;
	if(fileDetails.fileOffset){
		fileOffset = fileDetails.fileOffset; 
	}
	//Checking file size is less than packet size...
	if(batchCount==1){
		packetSize = Math.min(packetSize, fileSize);
	}
	cinReq.addHeader(CINRequestConts.FROM, fileDetails.from);
	cinReq.addHeaderString(CINRequestConts.KEY, fileDetails.getFileId());
	cinReq.addHeaderInt64(CINRequestConts.TOKEN, fileOffset);
	cinReq.addHeaderInt64(CINRequestConts.TYPE, fileSize);

	// Sushma Updated - In Production, downloading image/video not handled by chunks
	if(fileDetails.isDownloadAsBatch === true){
		cinReq.addHeaderInt64(CINRequestConts.STATUS, packetSize);//pkgSize
		cinReq.addHeaderInt64(CINRequestConts.EXPIRE, batchCount);//batchCount
	}else{
		cinReq.addHeaderInt64(CINRequestConts.STATUS, packetSize);//pkgSize
		cinReq.addHeaderInt64(CINRequestConts.EXPIRE, 1);//batchCount
	}
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new DownloadStartCallback(fileDetails, _callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.prototype.updateStatus = function(attachment, status){
	console.log("[DM] update status: "+status, JSON.stringify(attachment));
	var fileID = attachment.getFileId();
	for(var index=0;index<this.downloadQ.length;index++){
		var fileDetails = this.downloadQ[index];
		if(fileDetails.getFileId() === fileID){
			fileDetails.status = status;
			this.downloadQ[index] = fileDetails;
			return;
		}
	}
}

DataManager.prototype.getFileDownloadStatus = function(attachment){
	try{
		var fileID = attachment.getFileId();
		for(var index=0;index<this.downloadQ.length;index++){
			var fileDetails = this.downloadQ[index];
			if(fileDetails.getFileId() === fileID){
				if(!fileDetails.status){
					return MessageConsts.ATTACHMENT_UNKNOWN_STAUS;
				}
				return fileDetails.status;
			}
		}
		return MessageConsts.ATTACHMENT_NOT_FOUND;
	}catch(ex){
		return MessageConsts.ATTACHMENT_NOT_FOUND;
	}
}

DataManager.prototype.cancelDownload = function(attachment){
	var fileID = attachment.getFileId();
	for(var index=0;index<this.downloadQ.length;index++){
		var fileDetails = this.downloadQ[index];
		if(fileDetails.getFileId() === fileID){
			this.downloadQ.splice(index, 1);
			return;
		}
	}
}

DataManager.prototype.downloadRemain = function(fileDetails, callback){
	// debugger;
	var fileSize = fileDetails.getFileSize();

	var packetSize = parseInt(DataManager.DOWNLOAD_FILE_CHUNK);
	// var packetSize = 10*1024;//Testing
	var batchCount = parseInt(fileSize / packetSize);
	if((batchCount*packetSize) !== fileSize){
		batchCount+=1;
	}
	var fileOffset = 0;
	if(fileDetails.fileOffset){
		fileOffset = fileDetails.fileOffset; 
	}
	var size = Math.min(packetSize, (parseInt(fileSize)-parseInt(fileOffset)));
	console.log("[DM] Method, download size:"+size+", size:"+DataManager.DOWNLOAD_FILE_CHUNK);

	// if(fileDetails.isDownloadAsBatch === true && size === DataManager.DOWNLOAD_FILE_CHUNK){
	// 	return;
	// }
	console.log("[DM] Download...");	
	var cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.EVENT_START);

	console.log("[DM] After offset..."+fileOffset);

	cinReq.addHeader(CINRequest.FROM, fileDetails.from);
	cinReq.addHeaderString(CINRequestConts.KEY, fileDetails.getFileId());
	cinReq.addHeaderInt64(CINRequestConts.TOKEN, fileOffset);
	cinReq.addHeaderInt64(CINRequestConts.TYPE, fileSize);
	console.log("[DM] After size..."+size);

	cinReq.addHeaderInt64(CINRequestConts.STATUS, size);//pkgSize
	cinReq.addHeaderInt64(CINRequestConts.EXPIRE, 1);//batchCount

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	console.log("[DM] After size..."+size);
	cinReq.setCallback(new DownloadFileCallback(fileDetails, callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.prototype.updateDownloadProgress = function(fileID, fileOffset, len){
	// debugger;
	console.log("[DM] FileID: "+fileID+" fileOffset: "+fileOffset+" len:"+len);
	var callback = this.dataManagerDownloadCallback;
	var downloadedFile = fileOffset+len;
	for(var index=0;index<this.downloadQ.length;index++){
		var fileDetails = this.downloadQ[index];
		if(fileDetails.getFileId() === fileID){
			var progress = (downloadedFile/fileDetails.getFileSize())*100;
			console.log("[DM] Inside FileID: "+fileID+" fileOffset: "+fileOffset+" len:"+len+" Progress:"+progress);
			this.updateStatus(fileDetails, MessageConsts.ATTACHMENT_DOWNLOADING);
			if(callback && typeof callback.onProgressChanged === "function"){
				callback.onProgressChanged(fileDetails, progress);
			}
			if(parseInt(progress) === 100){
				callback.onSuccess(fileDetails);
				this.downloadQ.splice(index, 1);
				break;
			}
			console.log("[DM] After if");
			fileDetails.fileOffset = downloadedFile;
			this.downloadQ[index] = fileDetails;
			console.log("[DM] After init");
			if(!fileDetails.isDownloadAsBatch){
				this.downloadRemain(fileDetails, null);
			}
			break;
		}	
	}
	// downloadQ.forEach(function(fileDetails, index){
	// 	if(fileDetails.getFileId() === fileID){
	// 		var progress = fileDetails.getFileSize();
	// 		callback.onProgressChanged(fileDetails, progress);
	// 		if(parseInt(progress) === 100){
	// 			callback.onSuccess(fileDetails);
	// 			downloadQ.splice(index, 1);
	// 			return;
	// 		}
	// 	}
	// });

};

/**
 * Tell server client wants to upload a file
 * 
 * @return Request for sending to server
 */
DataManager.prototype.uploadStart = function(attachment, callback){
    peerIds = attachment.peerIds;
	// debugger;
	attachment.status = MessageConsts.ATTACHMENT_QUEUE;
	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x11));
	cinReq.addHeaderString(CINRequestConts.KEY, attachment.getFileId());
	cinReq.addHeaderInt64(CINRequestConts.TYPE, attachment.getFileSize());
	if (peerIds && peerIds !== null) {
		peerIds.forEach(function(userID){
			cinReq.addHeader(CINRequestConts.INDEX, userID);
		});
	}else{
		cinReq.addHeaderInt8(CINRequestConts.INDEX, -1);
	}
	cinReq.addHeaderInt8(CINRequestConts.STATUS, 1);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new UploadStartCallback(attachment, callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Build a Request for sending data to server	
 * @return Request for sending to server
 */
DataManager.prototype.setAttachmentData = function(attachment, callback){
    if(attachment.data.byteLength === 0){
        if(attachment.fileOffset > attachment.getFileSize()){
            this.confirm(attachment, {
                onSuccess: function(){
                    var callback = DataManager.getInstance().getUploadCallback();
                    callback.onProgressChanged(attachment, 100);
                    callback.onSuccess(attachment);
                },
                onError: function(){
                    DataManager.getInstance().getUploadCallback().onError(attachment);
                }
            });
            return;
        }
        this.interrupt(attachment, {
            onSuccess: function(){
                DataManager.getInstance().getUploadCallback().onError(attachment);
            },
            onError: function(error){
                DataManager.getInstance().getUploadCallback().onError(attachment);
            }
        });
        return;
    }

	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x12));
	cinReq.addHeaderString(CINRequestConts.KEY, attachment.getFileId());
	cinReq.addHeaderInt64(CINRequestConts.INDEX, attachment.fileOffset);
	cinReq.addBody(CINRequestConts.BODY, new Int8Array(attachment.data));
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new UploadAttachmentData(attachment));
	JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.prototype.interrupt = function(attachment, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x25));
	cinReq.addHeaderString(CINRequestConts.KEY, attachment.getFileId());
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new EmptyResponseCallback(callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};
/**
 * Build a Request for sending video to server	
 * Key is Fileid
 * @return Request for sending to server
 */

DataManager.prototype.transportVideoData = function(key, status, data, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x12));
	var instance =	UserModel.getInstance();
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderString(CINRequestConts.KEY, key);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, status);
	cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(data));
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback((callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};


/**
 * Build a request for telling server client wants to pause uploading
 * isUpload is true if pausing upload and false if pausing download
 * @return Request for sending to server
 */

DataManager.prototype.pause = function(fileId, isUpload, callback){
	if(isUpload !== true)
	    cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.EVENT_PAUSE);
	else
		cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x15));
	cinReq.addHeaderString(CINRequestConts.KEY, fileId);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

// request for confirming download/upload status
DataManager.prototype.confirm = function(attachment, callback){
	if(attachment.isUpload !== true){
	    cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.CONFIRM);
	    cinReq.addHeaderInt64(CINRequestConts.TOKEN, attachment.getFileSize());
	}else{
		cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x13));
    }
	cinReq.addHeaderString(CINRequestConts.KEY, attachment.getFileId());	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new EmptyResponseCallback(callback));	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

//Get Emoticon List
DataManager.prototype.getEmoticons = function(version, callback) {
	var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GETLIST);
	cinReq.addHeaderInt32(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new EmoticonsProxyCallback(callback));	
	JIOClient.getInstance().getCINClient().send(cinReq);
};
/**
 * Build a request for get emoticon packages info
 * 
 * @param list
 *            Package ids which client want to get info
 */
DataManager.prototype.getEmoticonInfo = function(list, callback) {
	var cinReq  = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GETEMOTICONINFO);
	list.forEach(function(key){
		cinReq.addHeaderInt64(CINRequestConts.KEY, key);
	});
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new EmoticonsInfoProxyCallback(callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};
/**
 * Build a request for ordering a emoticon package
 * 
 * @param key
 *            Key of emoticon package
 */
DataManager.prototype.order = function(emoticon, callback) {
    var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_ORDER);
    cinReq.addHeaderInt64(CINRequestConts.KEY, emoticon.getKey());
    cinReq.setCINMessageObject();
    cinReq.setArgs(arguments);  
    // cinReq.setCallback(callback);
    cinReq.setCallback(new EmoticonsOrderProxyCallback(emoticon, callback));
    JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Build a request for Check order a emoticon package
 * 
 * @param key
 *            Key of emoticon package
 */
DataManager.prototype.checkOrderEmoticon = function(emoticon, callback) {
    var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_CHECKORDEREMOTICON);
    cinReq.addHeaderInt64(CINRequestConts.KEY, emoticon.getKey());
    cinReq.setCINMessageObject();
    cinReq.setArgs(arguments);  
    // cinReq.setCallback(callback);
    cinReq.setCallback(new EmoticonOrderStatusCallback(emoticon, callback));
    JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.prototype.getRecommendEmoticonList = function(version, callback) {
    var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GET_RECOMMEND_EMOTICON_LIST);
    cinReq.addHeaderInt64(CINRequestConts.VERSION, version);
    cinReq.setCINMessageObject();
    cinReq.setArgs(arguments);  
    cinReq.setCallback(callback);   
    JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.prototype.downloadEmoticonPackage = function(emtoti, isForceDelete, callback){
    // debugger;
    var emotiFile = new Thumbnail();
    emotiFile.from = UserModel.getInstance().getUserID();
    emotiFile.setFileId(emtoti.getToken());
    emotiFile.setFileSize(emtoti.getPkgSize());
	emotiFile.setFileName("EMOTICON_PACKAGE");//Added by shubham //to differentiate beetween thumb and pakage
	emotiFile.setEmoticonId(emtoti.getKey());//added by shubham
    emotiFile.isDownloadAsBatch = true;
    this.downloadStart(emotiFile,callback);
 //    // var cinReq = new CINRequest(CINRequestConts.EMOTICON, MessageConsts.EMOTICON_PACKAGE_DOWNLOAD);
	// var cinReq = new CINRequest(CINRequestConts.MESSAGE, MessageConsts.EMOTICON_PACKAGE_DOWNLOAD);
 //    cinReq.addHeaderString(CINRequestConts.TOKEN, emtoti.getToken());
 //    cinReq.addHeaderInt64(CINRequestConts.INDEX, emtoti.getPkgSize());
 //    cinReq.addHeaderInt64(CINRequestConts.KEY, emtoti.getKey());

 //    // if(isForceDelete){
 //    //     cinReq.addHeaderInt64(CINRequestConts.SUBVERSION, 1);
 //    // }
 //    cinReq.setCINMessageObject();
 //    cinReq.setArgs(arguments);  
 //    cinReq.setCallback(new EmptyResponseCallback(callback));
    
 //    JIOClient.getInstance().getCINClient().send(cinReq);
}

DataManager.prototype.downloadEmoticon = function(dynamicEmoticon, callback){
	var thumb = new Thumbnail();
	thumb.setFileId(dynamicEmoticon.getDynPictureId());
	thumb.setFileSize(dynamicEmoticon.getDynPictureSize());
	thumb.setSingleEmoticonObject(dynamicEmoticon);
	thumb.setFileName("SINGLE_EMOTICON");
	thumb.from = UserModel.getInstance().getUserID();
	this.downloadStart(thumb, callback);
}

/**
 * Build a request for getting ordered emoticon package list
 */
DataManager.prototype.getOrderedList = function(callback) {
	var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GETORDEREDLIST);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.getDataInfo = function(cinMessage, uuid, serverKey){
	if(!cinMessage.containsHeader(CINRequestConts.TYPE)){
		var msg = cinMessage.getBody();
		if(uuid && uuid.length>0 && msg && msg !== null){
			msg = EncryptionUtils.decrypt(msg, this.uuid, this.serverKey);
		} else if(msg.length%4==0){
			msg = JIOUtils.toString(CinBase64.decode(msg));
		}else{
			msg = JIOUtils.toString(msg);
		}
		return msg;
	}

	var type = cinMessage.getInt(CINRequestConts.TYPE);

	switch(type){
		case MessageConsts.TYPE_EMOTICON:
			var cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			var info = new DynamicEmoticonsInfo();
			info.init(response);
			return info;
		// break;

		case MessageConsts.TYPE_IMAGE:
			var msgs = cinMessage.getBodys();
			var info = [];		
			
			msgs.forEach(function(cinMessageBody){
				var imageInfo = new ImageInfo();
				var response = CINResponse.getCINMessage(cinMessageBody.val, null, false);	
				imageInfo.init(response);	
				info.push(imageInfo);
			});	
			return info;
		// break;

		case MessageConsts.TYPE_CARD:
			var cinMessageBody = EncryptionUtils.decryptBytes(cinMessage.getBody(), uuid, serverKey);
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new CardInfo();
			info.init(response);
			return info;
		// break;

		case MessageConsts.TYPE_FILE:
			var cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new FileInfo();
			info.init(response);
			return info;
		// break;

		case MessageConsts.TYPE_LOCATION:
			var cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new LocationCard();
			info.init(response);
			return info;
		// break;

		case MessageConsts.TYPE_VOICE:
			var cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new VoiceInfo();
			info.init(response);
			return info;
		// break;

		case MessageConsts.TYPE_VIDEO:
			var cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			info = new VideoInfo();
			info.init(response);
			return info;
		// break;

		case MessageConsts.TYPE_PUBLIC_IMAGETEXT:
			var index = cinMessage.getInt(CINRequestConts.INDEX);
			var messages = new Array();
			if(index === 0){
				var ppmAttachment = new PublicImageText();
				var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
				ppmAttachment.init(index, response);
				messages.push(ppmAttachment);
				return messages;
			}

			var bodys = cinMessage.getBodys();
			bodys.forEach(function(body){
				var ppmAttachment = new PublicImageText();
				var response = CINResponse.getCINMessage(body.val, null, false);	
				ppmAttachment.init(index, response);	
				messages.push(ppmAttachment);
			});	
			return messages;
			// break;
		
		case MessageConsts.TYPE_CLIENT_FORWARD_PUBLICACCOUNT_CARD:
			var cinMessageBody = cinMessage.getBody();
			var response = CINResponse.getCINMessage(cinMessageBody, null, false);	
			var publicCard = new PublicCard();
			publicCard.init(response);
			return publicCard;
		default:
			return null;
	}
}
// DataManager.prototype.getRecommendEmoticonList = function(version, callback) {
// 	var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GET_RECOMMEND_EMOTICON_LIST);
// 	cinReq.addHeaderInt64(CINRequestConts.VERSION, version);
// 	cinReq.setCINMessageObject();
// 	cinReq.setArgs(arguments);	
// 	cinReq.setCallback(callback);	
// 	JIOClient.getInstance().getCINClient().send(cinReq);
// };

/**
 * Build a request for ordering a emoticon package
 * 
 * @param key
 *            Key of emoticon package
 */
// DataManager.prototype.order = function(key, callback) {
// 	var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_ORDER);
// 	cinReq.addHeaderInt64(CINRequestConts.KEY, key);
// 	cinReq.setCINMessageObject();
// 	cinReq.setArgs(arguments);	
// 	cinReq.setCallback(callback);
// 	JIOClient.getInstance().getCINClient().send(cinReq);
// }

/**
 * Build a request for Check order a emoticon package
 * 
 * @param key
 *            Key of emoticon package
 */
// DataManager.prototype.checkOrderEmoticon = function(key, callback) {
// 	var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_CHECKORDEREMOTICON);
// 	cinReq.addHeaderInt64(CINRequestConts.KEY, key);
// 	cinReq.setCINMessageObject();
// 	cinReq.setArgs(arguments);	
// 	cinReq.setCallback(callback);
// 	JIOClient.getInstance().getCINClient().send(cinReq);
// };

