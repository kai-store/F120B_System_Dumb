function DataManager() {
}

DataManager.getInstance = function(){ 
	if(!DataManager.instance || DataManager.instance === null){
		DataManager.instance = new DataManager();
	}
	return DataManager.instance;
}

DataManager.prototype.getCallback = function(){
	return this.dataManagerCallback;
}

DataManager.prototype.setCallback = function(callback){
	this.dataManagerCallback = callback;
}

/**
 * Build a request for start downloading a file
 * 
 * @return Request for sending to server
 */

DataManager.prototype.downloadStart = function(fileDetails, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.EVENT_START);

	fileDetails.forEach(function(fileDetail){
		console.log('key' +fileDetail.getThumbId());
		cinReq.addHeaderString(CINRequestConts.KEY, fileDetail.getThumbId());
		cinReq.addHeaderInt64(CINRequestConts.TOKEN, 0);//downloadSize
		cinReq.addHeaderInt64(CINRequestConts.TYPE, fileDetail.getFileSize());
		cinReq.addHeaderInt64(CINRequestConts.STATUS, fileDetail.getThumbSize());//pkgSize
		cinReq.addHeaderInt64(CINRequestConts.EXPIRE, 1);//batchCount
	});

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new DataDownloadProxyCallback(callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Tell server client wants to upload a file
 * 
 * @return Request for sending to server
 */

DataManager.prototype.uploadStart = function(fileId, fileSize, peerIds, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x11));
	cinReq.addHeaderString(CINRequestConts.KEY, fileId);
	cinReq.addHeaderInt64(CINRequestConts.TYPE, fileSize);
	if (peerIds && peerIds !== null) {
		peerIds.forEach(function(userID){
			cinReq.addHeader(CINRequestConts.INDEX, userID);
		});
	}else{
		cinReq.addHeader(CINRequestConts.INDEX, -1);
	}
	cinReq.addHeaderInt8(CINRequestConts.STATUS, 1);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);
	JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Build a Request for sending data to server	
 * @return Request for sending to server
 */

DataManager.prototype.setAttachmentData = function(attachment, data, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x12));
	cinReq.addHeaderString(CINRequestConts.KEY, fileId);
	cinReq.addHeaderInt64(CINRequestConts.INDEX, index);
	cinReq.addBody(CINRequestConts.BODY, new Int8Array(data));
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);
	JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Build a Request for sending video to server	
 * Key is Fileid
 * @return Request for sending to server
 */

DataManager.prototype.transportVideoData = function(key, status, data, callback){
	var cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x12));
	var instance =	UserModel.getInstance();
	cinReq.addHeader(CINRequestConts.FROM, instance.getUserID());
	cinReq.addHeaderString(CINRequestConts.KEY, key);
	cinReq.addHeaderInt64(CINRequestConts.STATUS, status);
	cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(data));
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback((callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};


/**
 * Build a request for telling server client wants to pause uploading
 * isUpload is true if pausing upload and false if pausing download
 * @return Request for sending to server
 */

DataManager.prototype.pause = function(fileId, isUpload, callback){
	if(isUpload !== true)
	    cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.EVENT_PAUSE);
	else
		cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x15));
	cinReq.addHeaderString(CINRequestConts.KEY, fileId);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

// request for confirming download/upload status
DataManager.prototype.confirm = function(fileId, receivedSize, isUpload, callback){
	if(isUpload !== true){
	    cinReq = new CINRequest(CINRequestConts.DATA, CINRequestConts.CONFIRM);
	    cinReq.addHeaderInt64(CINRequestConts.TOKEN, receivedSize);
	}
	else
		cinReq = new CINRequest(CINRequestConts.DATA, CinBase64.getByte(0x13));
	cinReq.addHeaderString(CINRequestConts.KEY, fileId);	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new DataDownloadProxyCallback(callback));	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

//Get Emoticon List
DataManager.prototype.getEmoticons = function(version, callback) {
	var cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GETLIST);
	cinReq.addHeaderInt32(CINRequestConts.VERSION,version);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new EmoticonsProxyCallback(callback));	
	JIOClient.getInstance().getCINClient().send(cinReq);
};
/**
 * Build a request for get emoticon packages info
 * 
 * @param list
 *            Package ids which client want to get info
 */
DataManager.prototype.getEmoticonInfo = function(list, callback) {
	cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GETEMOTICONINFO);
	list.forEach(function(key){
		cinReq.addHeaderInt64(CINRequestConts.KEY, key);
	});	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(new EmoticonsInfoProxyCallback(callback));
	JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Build a request for getting ordered emoticon package list
 */
DataManager.prototype.getOrderedList = function(callback) {
	cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GETORDEREDLIST);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

DataManager.prototype.getRecommendEmoticonList = function(version, callback) {
	cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_GET_RECOMMEND_EMOTICON_LIST);
	cinReq.addHeaderInt8(CINRequestConts.VERSION, version);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

/**
 * Build a request for ordering a emoticon package
 * 
 * @param key
 *            Key of emoticon package
 */
DataManager.prototype.order = function(key, callback) {
	cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_ORDER);
	cinReq.addHeaderInt64(CINRequestConts.KEY, key);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);
	JIOClient.getInstance().getCINClient().send(cinReq);
}

/**
 * Build a request for Check order a emoticon package
 * 
 * @param key
 *            Key of emoticon package
 */
DataManager.prototype.checkOrderEmoticon = function(key, callback) {
	cinReq = new CINRequest(CINRequestConts.EMOTICON, CINRequestConts.EVENT_CHECKORDEREMOTICON);
	cinReq.addHeaderInt64(CINRequestConts.KEY, key);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	
	cinReq.setCallback(callback);
	JIOClient.getInstance().getCINClient().send(cinReq);
};

