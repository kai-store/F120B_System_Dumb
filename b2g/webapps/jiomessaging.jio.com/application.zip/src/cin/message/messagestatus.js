// function MessageStatus() {
// };

// MessageStatus.IS_SLIENCE = 0x00000001;
// MessageStatus.IS_SYNC = 0x00000002;
// MessageStatus.IS_MULTI = 0x00000004;
// MessageStatus.IS_ARRIVED = 0x00000008;

// MessageStatus.getValue = function(isSlience,isSync,isMulti,isArrived){
// 	var value = 0;
// 	value = isSlience === true ? value | MessageStatus.IS_SLIENCE : value;
// 	value = isSync  === true ? value | MessageStatus.IS_SYNC : value;
// 	value = isMulti   === true ? value | MessageStatus.IS_MULTI : value;
// 	value = isArrived   === true ? value | MessageStatus.IS_ARRIVED : value;
// 	return value;
// };

// MessageStatus.getDefaultValue = function(isSlience,isSync,isMulti,isArrived){
// 	var value = 0;
// 	value = isSlience === true ? value | MessageStatus.IS_SLIENCE : value;
// 	value = isSync ? value | MessageStatus.IS_SYNC : value;
// 	value = isMulti ? value | MessageStatus.IS_MULTI : value;
// 	value = isArrived ? value | MessageStatus.IS_ARRIVED : value;
// 	return value;
// };
function MessageStatus() {
	this.value = 0;
	this.isSlience = false;
	this.isArrived = false;
	this.isSync = false;
	this.isMulti = false;
};

MessageStatus.IS_SLIENCE = 0x00000001;
MessageStatus.IS_SYNC = 0x00000002;
MessageStatus.IS_MULTI = 0x00000004;
MessageStatus.IS_ARRIVED = 0x00000008;

MessageStatus.prototype = {
	constrator: MessageStatus,

};

MessageStatus.prototype.init = function(value){
	this.value = value;
	this.isSlience =  (value & MessageStatus.IS_SLIENCE) === MessageStatus.IS_SLIENCE;
	this.isSync = (value & MessageStatus.IS_SYNC) === MessageStatus.IS_SYNC;
	this.isMulti = (value & MessageStatus.IS_MULTI) === MessageStatus.IS_MULTI;
	this.isArrived = (value & MessageStatus.IS_ARRIVED) === MessageStatus.IS_ARRIVED;
};

MessageStatus.getValue = function(isSlience, isSync, isMulti, isArrived){
	var value = 0;
	value = isSlience === true ? value | MessageStatus.IS_SLIENCE : value;
	value = isSync  === true ? value | MessageStatus.IS_SYNC : value;
	value = isMulti   === true ? value | MessageStatus.IS_MULTI : value;
	value = isArrived   === true ? value | MessageStatus.IS_ARRIVED : value;
	return value;
};
