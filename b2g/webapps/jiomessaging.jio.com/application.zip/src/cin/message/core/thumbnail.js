function Thumbnail(){
	this.fileId = "";
	this.mFileSize = 0;
	this.mFileName = "";
	this.mThumbId = "";//Kaal Added
	this.fileOffset = 0;//shubham added
	this.batchcount = false;
	this.fileHEXId = UUID.randomUUIDHex();
	this.emoticonId = 0;
	this.singleEmoticon = {};//shubham added
	this.msgId = "";
	this.msgType = "";
	this.chunkIndex = 0;
}

Thumbnail.prototype = {
	constructor: Thumbnail,

	setBatchCount: function(batchcount){
		this.batchcount = batchcount;
	},

	isBatchCount: function(){
		return this.batchcount;
	},

	setFileId: function(fileId){
		this.fileId=fileId;
		console.log("fileid for channel"+this.fileId);
	},

	getFileId: function(){
		return this.fileId;
	},

	setFileSize: function(mFileSize){
		this.mFileSize = mFileSize;
		console.log("mfilesize for channel"+this.mFileSize);
	},

	getFileSize: function(){
		return this.mFileSize;
	},
	
	setFileName: function(mFileName){
		this.mFileName = mFileName;
	},
	
	getFileName: function(){
		return this.mFileName;
	},

	setThumbId: function(mThumbId){
		this.mThumbId = mThumbId;
	},

	getThumbId: function(){
		return this.mThumbId;
	},

	setFileOffset: function(fileOffset){
		this.fileOffset = fileOffset;
	},

	getFileOffset: function(){
		return this.fileOffset;
	},

	setEmoticonId: function(emoticonId){
		this.emoticonId = emoticonId;
	},

	getEmoticonId: function(){
		return this.emoticonId;
	},

	setSingleEmoticonObject: function(singleEmoticon){
		this.singleEmoticon = singleEmoticon;
	},

	getSingleEmoticonObject: function(){
		return this.singleEmoticon;
	},

	setMsgId: function(msgId){
		this.msgId = msgId;
	},

	getMsgId: function(){
		return this.msgId;
	},

	setMsgType: function(msgType){
		this.msgType = msgType;
	},

	getMsgType: function(){
		return this.msgType;
	}

};

