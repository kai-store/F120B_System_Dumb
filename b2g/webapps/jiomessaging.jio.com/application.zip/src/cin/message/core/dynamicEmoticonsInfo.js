function DynamicEmoticonsInfo () {
	this.dynPictureId = "";
	this.dynPictureSize = 0;
	this.statPictureId = "";
	this.statPictureSize = 0;
	this.mPackageToken = "";
	this.mWidth = 0;
	this.mHeight = 0;
	this.packageId = null;
}

DynamicEmoticonsInfo.prototype = {
	constructor: DynamicEmoticonsInfo,

	setDynPictureId: function(dynPictureId){
		this.dynPictureId=dynPictureId;
	},

	getDynPictureId: function(){
		return this.dynPictureId;
	},

	setDynPictureSize: function(dynPictureSize){
		this.dynPictureSize = dynPictureSize;
	},

	getDynPictureSize: function(){
		return this.dynPictureSize;
	},

	setStatPictureId: function(statPictureId){
		this.statPictureId = statPictureId;
	},

	getStatPictureId: function(){
		return this.statPictureId;
	},

	setStatPictureSize: function(statPictureSize){
		this.statPictureSize = statPictureSize;
	},

	getStatPictureSize: function(){
		return this.statPictureSize;
	},

	setWidth: function(mWidth){
		this.mWidth = mWidth;
	},

	getWidth: function(){
		return this.mWidth;
	},

	setHeight: function(mHeight){
		this.mHeight = mHeight;
	},

	getHeight: function(){
		return this.mHeight;
	},

	setPackageToken: function(mPackageToken){
		this.mPackageToken = mPackageToken;
	},

	getPackageToken: function(){
		return this.mPackageToken;
	},

	setPackageId: function(packageId){
		this.packageId = packageId;
	},

	getPackageId: function(){
		return this.packageId;
	},

	init: function(response){
		this.dynPictureId = response.getString(MessageConsts.EMOTICON_FILE_ID);
		this.dynPictureSize = response.getInt(MessageConsts.EMOTICON_FILE_SIZE);
		this.statPictureId = response.getString(MessageConsts.EMOTICON_THUMB_ID);
		this.statPictureSize = response.getInt(MessageConsts.EMOTICON_THUMB_SIZE);
		this.mPackageToken = response.getInt(MessageConsts.EMOTICON_PACKAGE_TOKEN);
		this.mWidth = response.getInt(MessageConsts.EMOTICON_WIDTH);
		this.mHeight = response.getInt(MessageConsts.EMOTICON_HEIGHT);
		this.packageId = response.getInt(MessageConsts.EMOTICON_PACKAGE_ID);
		console.log(this);
	},
     
    getCinRequest: function(){
    	var cinMsg = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.TYPE_EMOTICON);
		cinMsg.addHeaderString(CinBase64.getByte(0x02), this.dynPictureId);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x03), this.dynPictureSize);
		cinMsg.addHeaderString(CinBase64.getByte(0x06), this.statPictureId);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x07), this.statPictureSize);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x01), this.mPackageToken);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x04), this.mWidth);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x05), this.mHeight);
		cinMsg.addHeaderInt64(CinBase64.getByte(0x08), this.packageId);
		return cinMsg.convert();
    }    
};
