function CardInfo() {
	this.hasThumnail = true;
	this.userId = "";
	this.mobileNo = "";
	this.name = "";
}

CardInfo.prototype = {
	constructor: CardInfo,

	setUserId: function(userId){
		this.userId=userId;
	},

	getUserId: function(){
		return this.userId;
	},

	setMobileNo: function(mobileNo){
		this.mobileNo = mobileNo;
	},

	getMobileNo: function(){
		return this.mobileNo;
	},
	
	setName: function(name){
		this.name = name;
	},
	
	getName: function(){
		return this.name;
	},
	
	init: function(response){
		this.userId = response.getHeader(MessageConsts.CARDBODY_USERID);
		this.mobileNo = response.getString(MessageConsts.CARDBODY_MOBILENUM);
		this.name = response.getString(MessageConsts.CARDBODY_NAME);
	},
     
    getCinRequest: function(){
    	cinMsg = new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.TYPE_CARD);
		cinMsg.addHeader(CinBase64.getByte(0x01), this.userId);
		cinMsg.addHeaderString(CinBase64.getByte(0x02), this.mobileNo);
		cinMsg.addHeaderString(CinBase64.getByte(0x03), this.name);
		return cinMsg.convert();
    }    

};
