function PublicCard() {
	this.userId = undefined;
	this.name = undefined;
	this.portid = undefined;
}

PublicCard.prototype.init = function(cinMessage) {
	if(cinMessage.containsHeader(0x01)){
		this.userId = cinMessage.getHeader(0x01);
	}

	if(cinMessage.containsHeader(0x02)){
		this.name = cinMessage.getString(0x02);
	}

	if(cinMessage.containsHeader(0x03)){
		this.portid = cinMessage.getString(0x03);
	}
};

PublicCard.prototype.getCinRequest=function(){
	cinMsg = new CINRequest(CINRequestConts.MESSAGE);
	cinMsg.addHeader(CinBase64.getByte(0x01), this.userId);
	cinMsg.addHeaderString(CinBase64.getByte(0x02), this.name);
	cinMsg.addHeaderString(CinBase64.getByte(0x03), this.portid);
	/*cinMsg.addHeader(CinBase64.getByte(0x04), dataInfo.getThumbId());
	cinMsg.addHeader(CinBase64.getByte(0x05), dataInfo.getThumbSize());
	cinMsg.addHeader(CinBase64.getByte(0x06), dataInfo.getOriginId());
	cinMsg.addHeader(CinBase64.getByte(0x07), dataInfo.getOriginSize());*/
	return cinMsg.convert();
}    
