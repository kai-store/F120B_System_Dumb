function EmoticonOrderStatusCallback (emoticon, callback) {
	this.uiCallback = callback;
	this.emoticon = emoticon;
}

EmoticonOrderStatusCallback.prototype = {
	onSuccess: function(cinMessage){
		// debugger;
		DataManager.getInstance().downloadEmoticonPackage(this.emoticon, true, this.callback);
	},
	onError: function(){

	}
}
