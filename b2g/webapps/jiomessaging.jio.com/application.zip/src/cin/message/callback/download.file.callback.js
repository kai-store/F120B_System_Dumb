function DownloadFileCallback(fileObj, callback){
    this.downloadCallback = callback;
    this.fileDetails = fileObj;
}
DownloadFileCallback.prototype = {
    onSuccess: function(cinMessage){    
        console.log("Success Download file call");
        console.log("[DM] Download File Callback (Success): ", JSON.stringify(this.fileDetails));

    },
    onError: function(cinMessage){
        console.log("Error Download file call");
        console.log("[DM] Download File Callback (Error): ", JSON.stringify(this.fileDetails));

    }
}
