function UploadStartCallback(attachment, callback){
    this.attachment = attachment;
    this.attachment.isUpload = true;
    this.attachment.fileOffset = 0;
    this.attachment.chunkSize = 10*1024;
    
    this.uiCallback = callback;
}

UploadStartCallback.prototype = {
    onSuccess: function(cinMessage){
        if(this.uiCallback && this.uiCallback!==null){
            this.uiCallback.onSuccess(cinMessage);
            return;
       }
       var callback = DataManager.getInstance().getUploadCallback();
       if(callback && callback!==null){
           
           var isThumnail = this.attachment.getFileId().endsWith("_THUMB");
           if(!isThumnail){
                callback.onReqFile(this.attachment);
           }else{
                callback.onReqThumb(this.attachment);
           }
       }
    },
    onError: function(error){
         var callback = DataManager.getInstance().getUploadCallback();
    }

};
