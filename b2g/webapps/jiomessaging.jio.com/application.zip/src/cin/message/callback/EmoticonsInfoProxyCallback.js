function EmoticonsInfoProxyCallback(uiCallback, version) {
	this.uiCallback = uiCallback;
	this.version = version;
}

EmoticonsInfoProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		var emoticons = [];
		
		try{
			var info = cinMessage.getBodys();
			info.forEach(function(cinMessageBody){
				var response = CINResponse.getCINMessage(cinMessageBody.val, null, false);
				icons = new Emoticons();
				icons.initDetails(response);
				console.log(icons.toString());
				emoticons.push(icons);
			});			
			console.log(emoticons.toString());
		}catch(err){

		}			
		this.uiCallback.onSuccess(emoticons);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
