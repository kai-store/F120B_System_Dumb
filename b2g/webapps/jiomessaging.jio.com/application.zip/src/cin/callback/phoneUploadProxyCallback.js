function PhoneUploadProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

PhoneUploadProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		var phoneBook = [];
		console.log(cinMessage);
		try{
			var keys = cinMessage.getBodys();
			keys.forEach(function(cinMessageBody,index){
				contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, false);
				profileObj = new Profile();
				profileObj.setUserID(contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_ID));
				profileObj.setMobileNo(JIOUtils.toString(contactResponse.getHeader(CINRequestConts.GET_USER_ID_BODY_PHONE)));
				profileObj.setIsOnline(JIOUtils.toLong(contactResponse.getHeader(CINRequestConts.GET_ACTIVE_STATUS_BODY_ID)) === 1);
				phoneBook.push(profileObj);
			});
		}catch(err){

		}	
		
		this.uiCallback.onSuccess(phoneBook);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
