function InviteProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

InviteProxyCallback.prototype =  {
	onSuccess: function(data){
		var resJson = JSON.parse(data);
		this.uiCallback.onSuccess(resJson);
	},
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.INVITE, 'unable to send invitation', this.uiCallback);
	}
}
