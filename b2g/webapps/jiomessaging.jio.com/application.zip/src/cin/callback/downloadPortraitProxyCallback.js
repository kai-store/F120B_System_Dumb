function DownloadPortraitProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

DownloadPortraitProxyCallback.prototype =  {
	onSuccess: function(cinMessage){	
			var userId = cinMessage.getHeader(CINRequestConts.FROM);	
			var portraits = [];
		
			try{
				var info = cinMessage.getBodys();
				info.forEach(function(cinMessageBody){
					var response = CINResponse.getCINMessage(cinMessageBody.val, null, false);
					profileObj = new Profile();
					profileObj.setUserID(response.getHeader(CINRequestConts.FROM));
					profileObj.setPortraitId(response.getString(CINRequestConts.PORTRAITID));
					profileObj.setPictureSize(response.getHeader(CinBase64.getByte(0x03)));
					profileObj.setThumbData(JIOUtils.toImage(response.getBody()));
					portraits.push(profileObj);
					// console.log(profileObj.thumbData);
				});	
			}catch(err){

			}		
			this.uiCallback.onSuccess(userId, portraits);
	},
	onError: function(error){
		this.uiCallback.onError(error);		
	}
}
