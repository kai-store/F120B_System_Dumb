function GroupProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

GroupProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		var group = new GroupModel();
		group.initGroup(cinResponse);
		var members = [];
		var cinBody = cinResponse.getBodys();
		cinBody.forEach(function(item){
			var profile = new Profile();
			cinItem = CINResponse.getCINMessage(item.val);
			profile.setUserID(cinItem.getHeader(CINRequestConts.FROM));
			profile.setName(cinItem.getString(0x02));			
			members.push(profile);
		});
		group.setNewMembers(members);
		this.uiCallback.onSuccess(group);
		//new StatshThisGroupMembersCode(group, this.uiCallback).init();
	},
	onError: function(cinMessage, errorCode){
		var str="Unkonn error";
		if(CINResponceConts.NotExist == errorCode){
			str="Group not exist."
		}else if(CINResponceConts.Error == errorCode){
			str="Error from server.";
		}else if(CINResponceConts.NotSupport == errorCode){
			str="Not supported";
		}
		console.log('[Error]'+str);
		this.uiCallback.onError(cinMessage, errorCode);
		// JIOUtils.sendError(101, str, this.uiCallback, errorCode);
	}
}

function StatshThisGroupMembersCode(group, callback){
	this.members = group.getNewMembers();
	this.group = group;
	this.uiCallback = callback;
	this.memberProfile = new Array();
}

StatshThisGroupMembersCode.prototype = {
	init: function(){

		if(this.members.length === 0){
			this.uiCallback.onSuccess(this.group);
			return;
		}
		
		instance = JIOClient.getInstance();
		for(i=0; i<this.members.length; i++){
			var memberId = this.members[i];
			instance.getContactProfile(memberId, new Int8Array([1]), this);
		}
	},
	onSuccess: function(profile){
		if(profile.getUserID()!==null){
			var that = this;
			// this.members.forEach(function(member, index){

			// 	if(String(new Array(member)) == String(new Array(profile.getUserID()))){
			// 		that.memberProfile.pop();
			// 	}
			// });
			this.memberProfile.push(profile);
		}

		if(this.members.length === this.memberProfile.length){
			this.group.setNewMembers(this.memberProfile);
			this.group.setGroupId(this.group.getTo());
			this.uiCallback.onSuccess(this.group);
		}
	},

	onError: function(cinResponse){
		this.uiCallback.onError(cinResponse);
	}
};
