function DataDownloadProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

DataDownloadProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		var fileId;
		switch (request.getEvent()) {
			case CINRequestConts.EVENT_CONFIRM:
					fileId = cinMessage.getHeader(CINRequestConts.KEY);
			break;
			case CINRequestConts.EVENT_START: 
					fileId = 'start'; 
			break;
		}
		this.uiCallback.onSuccess(fileId);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
