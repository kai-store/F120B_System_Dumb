function GroupAdminProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

GroupAdminProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		var group = new GroupModel();
		group.initGroup(cinMessage);
		this.uiCallback.onSuccess(group);
	},
	onError: function(error){
		JIOUtils.sendError(ErrorCodes.GROUP_ADMIN, error, this.uiCallback);
	}
}
