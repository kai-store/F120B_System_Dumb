function SettingsProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

SettingsProxyCallback.prototype =  {
	onSuccess: function(data){
		this.uiCallback.onSuccess(data);
	},
	onError: function(cinMessage){
		if(cinMessage.isMethod(CINResponceConts.NeedVerifycation)){
			var messageId = cinMessage.getHeader(0x01);
			var imageData = cinMessage.getBody();
			this.uiCallback.onCaptcha(messageId, imageData);
			return;
		}

		if(cinMessage.isMethod(CINResponceConts.NotAvailable)){
			JIOUtils.sendError(100, "Not Available", this.uiCallback);
			return;
		}
		JIOUtils.sendError(100, cinMessage.getBody(), this.uiCallback);
	}
}
