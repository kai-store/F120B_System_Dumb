function GenrateCaptchaProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

GenrateCaptchaProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
			var messageId = cinMessage.getHeader(0x01);
			var imageData = cinMessage.getBody();
			
			this.uiCallback.onSuccess(messageId, JIOUtils.toImage(imageData));
			// return;
	},
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.CAPTCHA_CODE, "Unable to get captcha.", callback);
	}
}
