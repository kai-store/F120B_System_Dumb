function DeleteMessageProxyCallback(messageIds, uiCallback) {
	this.uiCallback = uiCallback;
	this.messageIds = messageIds;
}

DeleteMessageProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		this.uiCallback.onSuccess(this.messageIds);
	},
	onError: function(cinMessage){
		this.uiCallback.onError(cinMessage);
	}
}
