function AllFavoriteCallback(uiCallback) {
	this.uiCallback = uiCallback;	
}

AllFavoriteCallback.prototype =  {
	onSuccess: function(cinMessage){
		var userID = cinMessage.getHeader(CINRequestConts.FROM);
		var collectInfoList = [];
		var bodys = cinMessage.getBodys();
		bodys.forEach(function(cinBody){
			var info = new CollectInfo();
			var cinMsg = CINResponse.getCINMessage(cinBody.val, null, false); 
			info.init(cinMsg);
			collectInfoList.push(info);
		});
		this.uiCallback.onSuccess(collectInfoList);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
