function OfflineMessageProxyCallback(chatMessage) {
	this.chatMessage = chatMessage;
}

OfflineMessageProxyCallback.prototype = {

	onSuccess: function(cinResponse){
		instance = JIOClient.getInstance();
		offlineCallback = instance.getOfflineCallback();

		if(offlineCallback && offlineCallback!==null)
			offlineCallback.onMessageSent(this.chatMessage);
	},
	onError: function(error){
		instance = JIOClient.getInstance();
		offlineCallback = instance.getOfflineCallback();
		
		if(offlineCallback && offlineCallback!==null)
			offlineCallback.onMessageSentError(this.chatMessage);
	}

};
