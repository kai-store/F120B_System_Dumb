function OfflineMessageCountProxyCallback(callback) {
	this.uiCallback = callback;
}

OfflineMessageCountProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		console.log("----- OfflineMessageCountProxyCallback -----");
		var offlineMessageInfos = new Array();
		var body = cinResponse.getBodys();
		body.forEach(function(cinMessageBody){
			messageBody = CINResponse.getCINMessage(cinMessageBody.val, null, true);
			offlineMessageInfo = new OfflineMessageInfoModel();
			offlineMessageInfo.init(messageBody);
			offlineMessageInfos.push(offlineMessageInfo);
		});

		if(this.uiCallback){
			this.uiCallback.onSuccess(offlineMessageInfos);
			return;
		}

		if(offlineMessageInfos.length === 0){
			return;
		}
		var that = this;
		offlineMessageInfos.forEach(function(offlineMessageInfo){
			that.processOfflineMsgRequest(offlineMessageInfo);
		});
		
	},
	onError: function(cinResponse){

	},

	processOfflineMsgRequest: function(offlineMessageInfo){
		var totalMessageCount = offlineMessageInfo.getTotalMessageCount();
		var unReadCount = offlineMessageInfo.getUnReadMsgCount();

		console.log("Offline msg count Proxycallback");
		console.log(unReadCount + " : " + String(offlineMessageInfo.getTo()));
		
		if((!(totalMessageCount>0))|| !(unReadCount>0)||  isNaN(totalMessageCount)|| isNaN(unReadCount)){
			return;
		}

		var messageStartIndex = totalMessageCount - unReadCount;

		var instance = JIOClient.getInstance();
		
		var MAX_MESSAGE_QUEQU = 100;
		var messageSize = Math.min(MAX_MESSAGE_QUEQU, unReadCount);
		var index =0;

		var n = parseInt(unReadCount / messageSize);
		var startIndex = 0;
		for(index=1;index<=n; index++){
			startIndex = messageStartIndex+(index*messageSize);
			instance.getOfflineMessages(offlineMessageInfo.getTo(), startIndex, messageSize);
		}
		
		var remainMsgsCount =  unReadCount - (n * messageSize);
		startIndex =  messageStartIndex+(index*messageSize);
		if(remainMsgsCount>0){
			instance.getOfflineMessages(offlineMessageInfo.getTo(), startIndex, remainMsgsCount);
		}

		// for(msgCount=1;msgCount<=unReadCount;msgCount++){
		// 	instance.getOfflineMessages(offlineMessageInfo.getTo(), msgCount, 1);
		// }

		//TBD, Not working with index and page size
		
		// var messageSize = Math.min(20, unReadCount);
		// var index = 1;
		// var requestCount = 0;
		// var instance = JIOClient.getInstance();
		// while(true){
			
		// 	if(index >= unReadCount){
		// 		return;
		// 	}
		// 	// var endIndex = index + Math.min(unReadCount, messageSize);
		// 	instance.getOfflineMessages(offlineMessageInfo.getTo(), index, messageSize);
		// 	index = index + messageSize;
		// 	// index = endIndex;
		// }
	}
};
