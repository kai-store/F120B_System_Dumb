function DeleteContactProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

DeleteContactProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		console.log(cinMessage);
		var keys = cinMessage.getHeaders();
		var phoneList = [];
		keys.forEach(function(cinMessageBody,index){
			contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, true);
			var resNo = contactResponse.getString(CINRequestConts.MOBILENO);
			if(resNo != "") phoneList.push(resNo);
		})
		this.uiCallback.onSuccess(phoneList);
	},
	onError: function(error){
		this.uiCallback.onError(error);
		//JIOUtils.sendError(ErrorCodes.DELETE_CONTACT, "Unable to delete contact.", callback);
	}
}
