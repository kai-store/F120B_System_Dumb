function CreateGroupProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

CreateGroupProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		var group = new GroupModel();
		group.setUserID(cinResponse.getHeader(CINRequestConts.FROM));
		group.setTo(cinResponse.getHeader(CINRequestConts.TO));
		group.setGroupId(cinResponse.getHeader(CINRequestConts.KEY));
		group.setGroupMaxMember(cinResponse.getInt(CINRequestConts.STATUS));
		group.setGroupVersion(cinResponse.getInt(CINRequestConts.VERSION));		
		this.uiCallback.onSuccess(group);
	},
	onError: function(cinMessage){
		this.uiCallback.onError(cinMessage);
	}
}
