function AutoLoginProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;	
}

AutoLoginProxyCallback.prototype =  {
	onSuccess: function(data){
		var resJson = JSON.parse(data);	
		if(resJson)	
			this.uiCallback.onSuccess(resJson);
		else
			JIOUtils.sendError(ErrorCodes.AUTO_LOGON_FAILED, "Auto logon failed", this.uiCallback);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
