function AutoLoginDetailsProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;	
}

AutoLoginDetailsProxyCallback.prototype =  {
	onSuccess: function(data){
		var resJson = JSON.parse(data);	
		if(resJson.success)	
			this.uiCallback.onSuccess(resJson);
		else
			JIOUtils.sendError(ErrorCodes.AUTO_LOGON_FAILED, "Auto logon failed", this.uiCallback);
	},
	onError: function(error){
		this.uiCallback.onError(error);
	}
}
