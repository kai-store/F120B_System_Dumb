function SMSValidationProxyCallback(uiCallback, phoneNumber) {
	this.uiCallback = uiCallback;
	this.phoneNumber = phoneNumber;
}

SMSValidationProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		UserModel.getInstance().init(cinMessage);
		var that = this;
		if(!JioChatSDK.getInstance().isDeviceMode()){
			JIOClient.getInstance().getProfile(this.uiCallback);
			return;
		}
		// JIOClient.getInstance().challenge(new ChallengeProxyCallback(this.uiCallback, true));
		// JIOClient.getInstance().getProfile(new GetProfileProxy(this.uiCallback));
		UserModel.getInstance().readMetaData({
			onSuccess: function(data){
				that.updateFile(data);
			},
			onError: function(error){
				JIOClient.getInstance().getProfile(that.uiCallback);
			}
		});
		
		// JIOClient.getInstance().getProfile(this.uiCallback);

	},
	onError: function(cinMessage){
		if(cinMessage.resBody){
			cinMessage = cinMessage.getBody();
		}

		JIOUtils.sendError(100, cinMessage, this.uiCallback);
	},
	updateFile: function(data){
		// debugger;
		var instance = UserModel.getInstance();
		// var phNum = instance.getPhoneNumber();
		var phNum = this.phoneNumber;
		if(!(phNum.includes(data)|| data.includes(phNum))){
			JIOClient.getInstance().getProfile(this.uiCallback);
			return;
		}
		var that = this;
		UserModel.getInstance().setPhoneNumber(phNum);
		DeviceModel.deleteJioFileFromDevice(UserModel.getInstance().getFileName(phNum),{
			onSuccess : function(){
				// debugger;
				JIOClient.getInstance().getProfile(that.uiCallback);
			},
        	onError : function(){
				// debugger;
				JIOClient.getInstance().getProfile(that.uiCallback);
        	}
    	});
	}
}
