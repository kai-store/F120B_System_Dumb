function UploadPortraitProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

UploadPortraitProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		// debugger;
			var userId = cinMessage.getHeader(CINRequestConts.FROM);
			var ownerCardVer = cinMessage.getInt(CINRequestConts.VERSION);		
			this.uiCallback.onSuccess(userId, ownerCardVer);
	},
	onError: function(error){
		// debugger;
		// this.uiCallback.onError(error);
		JIOUtils.sendError(ErrorCodes.CAPTCHA_CODE, "Unable to upload image.", this.uiCallback);
	}
}
