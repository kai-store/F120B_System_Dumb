function EmptyResponseCallback(callback, errorCode, errorMessage) {
	this.uiCallback = callback;
	this.errorCode = errorCode;
	this.errMsg = errorMessage;
}

EmptyResponseCallback.prototype = {
	onSuccess: function(cinMessage){
		console.log("[Empty] Response success.");
		if (!this.uiCallback || this.uiCallback === null) {
			return;
		}
		this.uiCallback.onSuccess(cinMessage);
	},
	onError: function(errorMessage){
		console.log("[Empty] Error response"+this.errMsg);
		JIOUtils.sendError(this.errorCode, errorMessage, this.uiCallback);
	}
};
