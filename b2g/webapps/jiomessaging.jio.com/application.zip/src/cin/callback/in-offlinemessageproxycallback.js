function InOfflineMessageProxyCallback(callback) {
	this.uiCallback = callback;
}

InOfflineMessageProxyCallback.prototype =  {
	onSuccess: function(cinResponse){
		var instance = JIOClient.getInstance();
		var cinBody = cinResponse.getBodys();

		var chatMessages = new Array();

		cinBody.forEach(function(cinMessageBody){
			messageBody = CINResponse.getCINMessage(cinMessageBody.val, null, true);

			var chat = new ChatMessage();
			chat.setSessionType(messageBody.getMethod());
			// offline group messages
			if(messageBody.getMethod() == 17)
				chat.setSessionType(CINRequestConts.SESSIONGROUP);
			chat.init(messageBody);
			chat.setMobileNumbers(messageBody.getString(-10));
			chatMessages.push(chat);
		});

		if(this.uiCallback!== undefined && this.uiCallback !== null){
			this.uiCallback.onPullMessageRecived(chatMessages);
			return;
		}
		
		var offlineCallback = instance.getOfflineCallback();
		if(offlineCallback && offlineCallback !== null){
			offlineCallback.onMessagesReceived(chatMessages);
		}
	},
	onError: function(cinResponse){

	}
};
