function NavProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

NavProxyCallback.prototype =  {
	onSuccess: function(cinMessage){
		// nav = cinMessage.getObjStrings();
		// console.log(nav);
		UserModel.getInstance().initNav(cinMessage);
		this.uiCallback.onSuccess(cinMessage);
	},
	onError: function(error){
		//this.uiCallback.onError(error);
		JIOUtils.sendError(ErrorCodes.REGISTER, error, this.uiCallback);
	}
}
