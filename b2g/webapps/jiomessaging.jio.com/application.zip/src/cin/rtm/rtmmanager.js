function RTMManager() {
}

RTMManager.getInstance = function(){ 
	if(!RTMManager.instance || RTMManager.instance === null){
		RTMManager.instance = new RTMManager();
	}
	return RTMManager.instance;
}

RTMManager.prototype.getCallback = function(){
	return this.rtmCallback;
}

RTMManager.prototype.setCallback = function(callback){
	this.rtmCallback = new InCallParserProxyCallback(callback);
}

RTMManager.prototype.getReq = function(isOneToOne){
	if(!isOneToOne){
		isOneToOne=true
	}
};

RTMManager.prototype.getVideoReq = function(isOneToOne){
	if(!isOneToOne){
		isOneToOne=true
	}
};

RTMManager.prototype.call = function(hdCall, callback){
	rtmSession = RTMSession.getInstance();
	var from  = hdCall.getFrom();
	
	if(from === undefined || from=== null){
		hdCall.setFrom(UserModel.getInstance().getUserID());
	}

	rtmSession.setHDCall(hdCall);
	hdCallback = new HDCallProxyCallback(callback, 1);
	hdCall.setCallback(hdCallback);
	this.getP2PEligibilityRequest(hdCall, hdCallback);
};

RTMManager.prototype.getP2PEligibilityRequest = function(hdCall, callback){

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_CHECK_P2P_ELIGIBILITY);
	// cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getDeviceInfo()));
	// cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getTurnServer()));
	// cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getCodec()));
	cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	cinReq.addHeader(CINRequestConts.TO, hdCall.getTo());
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isReconnect() ? 1 : 0);
	cinReq.addHeaderString(RTMRequestConsts.ELIGIBILITY_VERSION, hdCall.getEligibilityVersion());
	
	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();
	
	cinReq.setCallback(new GetP2PEligibilityCallback(callback));

	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.createSession = function(hdCall, callback) {
	
	if(!callback){
		callback = hdCall.getCallback();
	}
	if(!callback){
		return;
	}
	var cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_CREATE_SESSION);
	var sessionType = hdCall.getSessionType();
	// debugger;
	var isMulti = hdCall.isMulti() === true? 2: 1;
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());

	cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, sessionType);

	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.getType());
	cinReq.addHeaderInt8(CINRequestConts.STATUS, isMulti);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	var deviceToken = hdCall.getDeviceInfo();

	// if(deviceToken && deviceToken!==null) {
	// 	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, deviceToken);
	// }
	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();

	cinReq.setCallback(new CreateSessionCallback(hdCall, callback));

	cinReq.setMetaInfo('VIDEO','EVENT_CREATE_SESSION');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);

	// var cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_CREATE_SESSION);
	// var sessionType = hdCall.getSessionType();

	// var isMulti = hdCall.isMulti() === true? 2: 1;
	// cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());

	// cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	// cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getCallType());

	// cinReq.addHeaderInt32(CINRequestConts.TYPE, hdCall.getType());
	// cinReq.addHeaderInt32(CINRequestConts.STATUS, isMulti);
	
	// cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	// var deviceToken = hdCall.getDeviceInfo();

	// if(deviceToken && deviceToken!==null) {
	// 	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, deviceToken);
	// }
	// cinReq.setArgs(arguments);
	// cinReq.setCINMessageObject();

	// cinReq.setCallback(new CreateSessionCallback(hdCall, callback));

	// JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.setDeviceInfoRequest = function(hdCall, callback){
	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SET_DEVICE_INFO);
	
	var sessionType = hdCall.getSessionType();
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getCallType());

	cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	cinReq.addHeaderInt8(CINRequestConts.TYPE,  hdCall.isReconnect() ? 1 : 0);

	cinReq.addHeaderString(RTMRequestConsts.ELIGIBILITY_VERSION, hdCall.getEligibilityVersion());
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());

	cinReq.addHeader(CINRequestConts.TO, hdCall.getTo());

	cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getDeviceInfo()));

	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();

	cinReq.setCallback(new EmptyResponseCallback(callback));

	cinReq.setMetaInfo('VIDEO','EVENT_SET_DEVICE_INFO');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}


RTMManager.prototype.invite = function(userIds, callback) {
userInfo = UserModel.getInstance();

	session = RTMSession.getInstance();

	key = session.getKey();
	cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_INVITE);
	cinReq.addHeader(CINRequestConts.FROM, userInfo.getUserID());
	cinReq.addHeaderString(CINRequestConts.MOBILENO, userInfo.getPhoneNumber());
	// debugger;

	cinReq.addHeaderString(CINRequestConts.NAME, userInfo.getName());
	cinReq.addHeader(CINRequestConts.KEY, key);

	userIds.forEach(function(profile, index){
		cinReq.addHeader(CINRequestConts.INDEX, profile);
	});

	//dummy header added
	// if(sdpString && sdpString !== null){
	// 	cinReq.addHeaderString(CINRequestConts.EMAIL, "test@abc.com");
	// 	//addHeader(req, CinHeaderType.Password, sdpString);
	// 	cinReq.addHeaderString(CINRequestConts.PASSWORD, "121212");
	// }

	cinReq.setCINMessageObject();

	cinReq.setArgs(arguments);
	cinReq.setCallback(new InviteCallProxyCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_INVITE');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);

	// userInfo = UserModel.getInstance();

	// session = RTMSession.getInstance();

	// key = session.getKey();
	// var sessionType = hdCall.getSessionType();

	// cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_INVITE);
	// cinReq.addHeader(CINRequestConts.FROM, userInfo.getUserID());
	// cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getCallType());

	// cinReq.addHeaderString(CINRequestConts.MOBILENO, userInfo.getPhoneNumber());

	// cinReq.addHeaderString(CINRequestConts.NAME, userInfo.getName());
	// cinReq.addHeader(CINRequestConts.KEY, key);

	// userIds.forEach(function(profile, index){
	// 	cinReq.addHeader(CINRequestConts.INDEX, profile);
	// });

	// //dummy header added
	// // if(sdpString && sdpString !== null){
	// // 	cinReq.addHeaderString(CINRequestConts.EMAIL, "test@abc.com");
	// // 	//addHeader(req, CinHeaderType.Password, sdpString);
	// // 	cinReq.addHeaderString(CINRequestConts.PASSWORD, "121212");
	// // }

	// cinReq.setCINMessageObject();

	// cinReq.setArgs(arguments);
	// cinReq.setCallback(new InviteCallProxyCallback(callback));

	// JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.quitSession = function(callback) {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_KICK_MEMBER);

	cinReq.addHeader(CINRequestConts.KEY, rtmSession.getKey());

	isInitiativeQuit = rtmSession.isInitiator()?1:0;
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, isInitiativeQuit);

	cinReq.setCINMessageObject();

	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	cinReq.setMetaInfo('VIDEO','EVENT_KICK_MEMBER');	
	
	this.getCINClient(hdCall).send(cinReq);
};

RTMManager.prototype.getSessionInfo = function(callback){
	rtmSession = RTMSession.getInstance();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_GET_SESSION_INFO);
	cinReq.addHeader(CINRequestConts.KEY, key);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback));

	cinReq.setMetaInfo('VIDEO','EVENT_GET_SESSION_INFO');	
	
	this.getCINClient(hdCall).send(cinReq);
};

RTMManager.prototype.switchNegotiate = function(hdCall, callback) {
	rtmSession = RTMSession.getInstance();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO,RTMRequestConsts.EVENT_SWITCH_NEGOTIATION);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION');	

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.switchNegotiationResp =  function(hdCall, callback) {
	rtmSession = RTMSession.getInstance();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO,RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION_RESP');	
	
	this.getCINClient(hdCall).send(cinReq);

}

RTMManager.prototype.switchNegotiationResp =  function(hdCall, callback) {
	rtmSession = RTMSession.getInstance();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO,RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION_RESP');	

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.switchNegotiationSdpRequest = function(hdCall, callback) {

	rtmSession = RTMSession.getInstance();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());


	len = data.length;
	x = parseInt(len/254);
	start = 0;
	end = 254;

	for(i = 0; i<x; i++){
		dataChunk = new Int8Array(data, start, end);
		cinReq.addBody(CINRequestConts.BODY, dataChunk);
		start = end;
		end = start + 254;
	}

	if(len%254 !== 0){
		end = start + len%254;
		dataChunk = new Int8Array(data, start, end);
		cinReq.addBody(CINRequestConts.BODY, dataChunk);
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION_RESP');	
	
	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.enterSession =  function(hdCall, argument) {
	rtmSession = RTMSession.getInstance();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_ENTER_SESSION);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, call.getCallCapability());
	//dummy header
	cinReq.addHeaderString(CINRequestConts.NAME, "MyNameWebrtc");
	cinReq.addHeaderString(CINRequestConts.LANGUAGE, "english");

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	cinReq.setMetaInfo('VIDEO','EVENT_ENTER_SESSION');	
	
	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.onShowApply = function(isOnShow, callback) {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_USER_ONSHOW_APPLY);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, isOnShow ? 1 : 2);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_USER_ONSHOW_APPLY');	
	
	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.keepSession = function() {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_KEEP_OR_RESORE_SESSION);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 1);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_KEEP_OR_RESORE_SESSION');	
	
	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.restoreSession = function() {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_KEEP_OR_RESORE_SESSION);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 2);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.applySwitchDevice = function(key, callback) {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();
	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SWTICH_DEVICE_APPLY);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 1);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.executeSwitchDevice = function(key, callback) {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();
	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SWTICH_DEVICE_APPLY);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 2);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.settingVideoQuality = function(videoQualityList, callback) {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();
	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_VIDEO_QUALITY_SETTING);
	cinReq.addHeader(CINRequestConts.KEY, key);
	videoQualityList.forEach(function(videoQuality){
		cinReq.addBody(CINRequestConts.BODY, videoQuality.toCinReq());
	});

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.sendPackageCount = function(rtmPacket, callback) {
	rtmSession = RTMSession.getInstance();
	hdCall = rtmSession.getHDCall();

	key = rtmSession.getKey();

	if(!rtmPacket || rtmPacket === null){
		JIOUtils.sendError(ErrorCodes.NO_PACKET, "Please create packet object", callback);
		return;
	}

	miscellaneous = rtmPacket.getMiscellaneous();

	isConnectionStatsSent = rtmPacket.isStatsSent() === undefined?false:rtmPacket.isStatsSent();

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_VIDEO_SENT_RTP_PACKAGE_COUNT);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt64(CINRequestConts.INDEX, rtmPacket.getCount());

	cinReq.addHeaderInt32(CINRequestConts.TYPE, rtmSession.getCallType());
	cinReq.addHeaderString(CINRequestConts.EXPIRE, rtmPacket.getMediaStats());
	cinReq.addHeaderString(CINRequestConts.VERSION, rtmSession.getVersion());
	if(miscellaneous && miscellaneous !== null && miscellaneous.length > 0){
		cinReq.addHeaderString(RTMRequestConsts.MISCELLANEOUS_DETAILS, miscellaneous);
	}

	if (!isConnectionStatsSent) {
		cinReq.addBody(connectionStats.getBytes());
		iceCounterStats = rtmPacket.getIceCounterStats();
		cinReq.addHeaderString(CINRequestConts.CAPABILITY, rtmSession.getCallCapabilityVerstion());
		cinReq.addHeaderString(CINRequestConts.ENCRYPT, rtmSession.getCallEncryptVerstion());
		cinReq.addHeaderString(CINRequestConts.MOBILENO, iceCounterStats);
		cinReq.addHeaderString(CINRequestConts.EMAIL, JIOUtils.getTruncatedString(iceCounterStats));
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);	
}

RTMManager.prototype.sendBusy = function(hdCall, callback) {
	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_VIDEO_IS_BUSY);

	cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	cinReq.addHeader(CINRequestConts.KEY, hdCall.getKey());
	cinReq.addHeader(CINRequestConts.TO, hdCall.getTo());
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.getState());

	var data = hdCall.getData();

	var len = data.byteLength;
	x = parseInt(len/254);
	start = 0;
	end = 254;
	for(busyDataIndex = 0; busyDataIndex<x; busyDataIndex++){
		dataChunk = new Int8Array(busyDataIndex, start, end);
		cinReq.addBody(CINRequestConts.BODY, dataChunk);
		start = end;
		end = start + 254;
	}

	if(len%254 !== 0){
		end = start + len%254;
		dataChunk = new Int8Array(busyDataIndex, start, end);
		cinReq.addBody(CINRequestConts.BODY, dataChunk);
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);
}

RTMManager.prototype.sendIceCandidates = function(hdCall, callback){

	cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SEND_ICE_CANDIDATE);
	cinReq.addHeader(CINRequestConts.FROM, from);
	cinReq.addHeader(CINRequestConts.KEY, CinHelper.toByteArray(key));
	cinReq.addHeader(CINRequestConts.TO, to);
	iceCandidateList = hdCall.getIceCandidates();
	if(iceCandidateList){
		iceCandidateList.forEach(function(iceCandidate){
			cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(iceCandidate));
		});
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));

	this.getCINClient(hdCall).send(cinReq);
}


RTMManager.prototype.getSubmitFeedBackRequest = function(headers, body, callback) {
	/*CinRequest req =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_JC_CALL_FEEDBACK);
	req.addBody(new CinBody(body));
	for (Map.Entry<Byte, String> entry : headers.entrySet()) {
		if(entry.getKey()== CinHeaderType.Key){
			byte[]session = CinHelper.toByteArray(entry.getValue());
			addHeader(req, entry.getKey(), session);
		} else {
			addHeader(req, entry.getKey(), entry.getValue());
		}
	}
	return req;*/

}

RTMManager.prototype.getCINClient = function(hdCall){
	instance  = CINClient.getInstance(hdCall.getAddress());
	if(!this.isSocketCallbackSet){
		instance.setSocketCallback(new CallInitCallback());
		this.isSocketCallbackSet = true;
	}
	return instance;
}
