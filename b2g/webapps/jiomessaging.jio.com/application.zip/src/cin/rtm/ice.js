function ICEModel(cinMessage) {
	this.sdpMid = null;
	this.sdpLineIndex = null;
	this.sdp = null;
	this.miscellaneous = null;
}
