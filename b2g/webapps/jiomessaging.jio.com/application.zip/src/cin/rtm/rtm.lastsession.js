function RTMLastSession() {
	this.key = null;
	this.from = null;
	this.name = null;
	this.mobileno = null;
	this.to = null;
	this.token = null;
	this.index = null;
	this.type = null;
	this.status = null;
}

RTMLastSession.prototype.initSession = function(cinMessages) {
	this.key = cinMessage.getHeader(CINRequestConts.KEY);
	this.from = cinMessage.getHeader(CINRequestConts.FROM);
	this.name = cinMessage.getString(CINRequestConts.NAME);
	this.mobileno = cinMessage.getString(CINRequestConts.MOBILENO);
	this.to = cinMessage.getHeader(CINRequestConts.TO);
	this.token = cinMessage.getString(CINRequestConts.TOKEN);
	this.index = cinMessage.getInt(CINRequestConts.INDEX);
	this.type = cinMessage.getHeader(CINRequestConts.TYPE);
	this.status = cinMessage.getHeader(CINRequestConts.STATUS);
};

RTMLastSession.prototype.setHDCall = function(hdCall) {
	
};

RTMLastSession.prototype.getHDCall = function(key) {
	
};


RTMLastSession.prototype.getKey = function(){

};

RTMLastSession.prototype.getUICallback = function(key){
	
}

RTMLastSession.prototype.endSession = function(key){
	this.hdCall=null;
};

RTMLastSession.prototype.isSessionActive = function() {
};

RTMLastSession.prototype.isInitiator = function(){

}
