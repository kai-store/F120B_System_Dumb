function RTMPacket() {
	this.count = 0;
	this.mediaStats = null;
	this.connectionStats = null;
	this.isConnectionStatsSent=null;
	this.callType = "Audio P2P";
	this.iceCounterStats = null;
	this.iceServerStats = null;
	this.miscellaneous = null;
	this._isStatsSent = false;
	this.packetCount = 0;
}

RTMPacket.prototype.setCount = function(count) {
	this.count = count;
};
RTMPacket.prototype.getCount = function() {
	return this.count;
};

RTMPacket.prototype.setMiscellaneous = function(miscellaneous) {
	this.miscellaneous=miscellaneous;
};
RTMPacket.prototype.getMiscellaneous = function() {
	return this.miscellaneous;
};

RTMPacket.prototype.setMediaStats = function(mediaStats) {
	this.mediaStats = mediaStats;
};
RTMPacket.prototype.getMediaStats = function() {
	return this.mediaStats;
};

RTMPacket.prototype.getCallType = function() {
	return this.callType;
};

RTMPacket.prototype.setIceCounterStats = function(iceCounterStats) {
	this.iceCounterStats = iceCounterStats;
};
RTMPacket.prototype.getIceCounterStats = function() {
	return this.iceCounterStats;
};

RTMPacket.prototype.setIceServerStats = function(iceServerStats) {
	this.iceServerStats = iceServerStats;
};
RTMPacket.prototype.getIceServerStats = function() {
	return this.iceServerStats;
};

RTMPacket.prototype.isStatsSent = function() {
	return this._isStatsSent;
};

RTMPacket.prototype.setPacketCount = function(packetCount) {
	this.packetCount = packetCount;
};
RTMPacket.prototype.getPacketCount = function(){
	return this.packetCount;
}
