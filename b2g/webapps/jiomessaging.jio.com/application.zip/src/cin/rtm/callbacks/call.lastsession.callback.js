function LastSessionCallback(callback) {
	this.uiCallback = callback;
}

LastSessionCallback.prototype = {
	onSuccess: function(cinMessage) {
		if(!this.uiCallback || this.uiCallback === null){
			return;
		}

		var userID = cinMessage.getHeader(CINRequestConts.FROM);
		var callId = cinMessage.getHeader(CINRequestConts.CALLID);

		var sessionInfoList = [];
		var bodys = cinMessage.getBodys();
		bodys.forEach(function(cinBody){
			var info = new RTMLastSession();
			var cinMsg = CINResponse.getCINMessage(cinBody.val, null, false); 
			info.init(cinMsg);
			sessionInfoList.push(info);
		});
		this.uiCallback.onSuccess(userID, callId, sessionInfoList);
		
	},onError: function(errorMsg){
		if(!this.uiCallback || this.uiCallback === null){
			return;
		}
		this.uiCallback.onError(errorMsg);
	}
};
