function CallBusyCallback(callback) {
	this.uiCallback = callback;
}

CallBusyCallback.prototype = {
	onSuccess: function(cinMessage) {
		if(!this.uiCallback || this.uiCallback === null){
			return;
		}
		this.uiCallback.onSuccess();
	},
	onError: function(errorMsg){
		if(!this.uiCallback || this.uiCallback === null){
			return;
		}
		JIOUtils.sendError(101, errorMsg, this.uiCallback);
	}
};