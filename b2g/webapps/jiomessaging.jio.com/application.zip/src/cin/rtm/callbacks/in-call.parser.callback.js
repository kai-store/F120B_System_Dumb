function InCallParserProxyCallback(callback) {
	this.inCallCallback = callback;
	this.count = 1;
}

InCallParserProxyCallback.prototype.parse = function(cinMessage){
	var event = cinMessage.getEvent();
	this.key = cinMessage.getHeader(CINRequestConts.KEY);
	this.callId = cinMessage.getHeader(CINRequestConts.CALLID);
	switch(event){
		case RTMResponseConsts.NOTIFY_INVITED:
			this.parseInvitation(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_INVITED_USERS:
			this.invitedUsers(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_KICK_MEMBER:
			this.kickMember(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SWITCH_NEGOTIATION:
			this.parseSwitchNegotiation(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SWITCH_NEGOTIATION_RESP:
			this.parseSwitchNegotiationRes(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_USER_ENTER:
			this.parseNotifyUserEnter(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_USER_ONSHOW:
			this.userShow(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_KEEP_OR_RETURN_SESSION:
			this.parseKeepOrReturn(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SWITCH_DEVICE:
			this.parseSwitchDevice(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_DELETE_SESSION:
			this.deleteSession(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SENT_PACKAGE_COUNT:
			this.parseSentPackageCount(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_PEER_BUSY:
			this.parseBusy(cinMessage);
			break;

		case RTMResponseConsts.EVENT_GET_WAITED_SESSION:
			this.parseWaitedSession(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_ICE_CANDEIDATE:
			this.parseNotifyICECandidate(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_REQUIRE_DEVICE_INFO:
			this.parseRequireDeviceInfo(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_ON_TURN_DETAILS:
			this.parseNotifyTurnDetails(cinMessage);
			break;
	}
	
};

InCallParserProxyCallback.prototype.getHDCall = function(cinMessage){
	var invitorId = cinMessage.getHeader(CINRequestConts.FROM);
	var creatorId = invitorId;
	if (cinMessage.containsHeader(CINRequestConts.INDEX)) {
		creatorId = cinMessage.getHeader(CINRequestConts.INDEX);
	}

	var sessionType = cinMessage.getInt(CINRequestConts.TYPE);
	var isMulti = cinMessage.getInt(CINRequestConts.STATUS) === 2;
	var address = cinMessage.getString(CINRequestConts.TOKEN);
	var mobile = null;
	if (cinMessage.containsHeader(CINRequestConts.MOBILENO)) {
		mobile = cinMessage.getString(CINRequestConts.MOBILENO);
	}

	var name = null;
	if (cinMessage.containsHeader(CINRequestConts.NAME)) {
		name = cinMessage.getString(CINRequestConts.NAME);
	}
	
	var version = 0;
	if (cinMessage.containsHeader(CINRequestConts.VERSION)) {
		version = cinMessage.getInt(CINRequestConts.VERSION);
	}
	
	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}
	var groupId = null;
	if(cinMessage.containsHeader(CINRequestConts.DEVICETOKEN)) {
		groupId = cinMessage.getHeader(CINRequestConts.DEVICETOKEN);
	}
	// var reconnect = false;
	// if (request.containsHeader(CinHeaderType.RECONNECT)) {
	// 	reconnect = request.getHeader(CinHeaderType.RECONNECT).getInt64() == 1L;
	// }
	var instance = RTMSession.getInstance();

	var hdCall = new HDCall();
	hdCall.initSession(this.key, address);
	
	hdCall.setSessionType(sessionType);
	hdCall.setIsMulti(isMulti);
	hdCall.setCreatorId(creatorId);
	hdCall.setInvitorId(invitorId);
	hdCall.setCallCapability(videoCap);
	hdCall.setEligibilityVersion(version);
	hdCall.setCallId(cinMessage.getHeader(CINRequestConts.CALLID));
	hdCall.setFrom(invitorId);
	hdCall.setIsIncoming(true);
	hdCall.setGroupId(groupId);
	hdCall.setReconnect();
	
	var rtmUser = new RTMUser();
	rtmUser.setUserID(invitorId);
	rtmUser.setMobileNumber(mobile);
	rtmUser.setName(name);
	hdCall.addUsers(rtmUser);
	// hdCall = this.getCallSDP(cinMessage, hdCall);
	var cinBody = cinMessage.getBodys();
	if(cinBody !== null && cinBody.length>0){
		var turnInfo = JIOUtils.toString(cinBody[0].val);
		turnInfo = new STUNModel(turnInfo);

		cinBody.splice(0, 1);

		var codec = JIOUtils.toString(cinBody[0].val);
		cinBody.splice(0, 1);

		var sdpStr = "";
		cinBody.forEach(function(cinVal){
			sdpStr+=JIOUtils.toString(cinVal.val);
		});
		hdCall.setRemoteSDP(sdpStr);
		hdCall.setTurnServer(turnInfo);
		hdCall.setCodec(codec);
	}
	// if(request.containsHeader(CinHeaderType.Encrypt)) {
	// 	meKey = request.getHeader(CinHeaderType.Encrypt).getValue();
	// }

	// byte[] uuid = null;
	// if(request.containsHeader(CinHeaderType.Email)) {
	// 	uuid = request.getHeader(CinHeaderType.Email).getValue();
	// }

	// String encryptShow = null;
	// if(request.containsHeader(CinHeaderType.Expire)) {
	// 	encryptShow = request.getHeader(CinHeaderType.Expire).getHexString();
	// }

	// boolean reconnect = false;
	// if (request.containsHeader(CinHeaderType.RECONNECT)) {
	// 	reconnect = request.getHeader(CinHeaderType.RECONNECT).getInt64() == 1L;
	// }
	return hdCall;
}

InCallParserProxyCallback.prototype.parseInvitation = function(cinMessage) {
	// debugger;
	var hdCall = this.getHDCall(cinMessage);
	
	var instance = RTMSession.getInstance();
	
	hdCall.setState(RTMRequestConsts.BUSY_STATE_RINGING);
	
	var sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;

	if(cinMessage.containsHeader(RTMRequestConsts.P2P_CALL_TYPE)){
		sessionType = cinMessage.getInt(RTMRequestConsts.P2P_CALL_TYPE);
	}

	if(sessionType>2){
		sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;		
	}
	
	hdCall.setSessionType(sessionType);

	instance.setHDCall(hdCall);

	// debugger;
	RTMManager.getInstance().sendBusy(hdCall);

	var callback = RTMSession.getInstance().getUICallback(this.key);
	//var callback = RTMManager.getInstance().getCallback();
	if(callback!==null && callback){
		callback.onRingCall(hdCall);
	}

};

InCallParserProxyCallback.prototype.invitedUsers = function(cinMessage){
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	var invitorId = cinMessage.getHeader(CINRequestConts.FROM);

	var invitedIds = cinMessage.getHeaders(CINRequestConts.INDEX);

	RTMSession.getInstance().getUICallback(this.key).onInvitedUsers(hdCall, invitorId, invitedIds);
};

InCallParserProxyCallback.prototype.kickMember = function(cinMessage){
	var type = cinMessage.getInt(CINRequestConts.TYPE);
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	RTMSession.getInstance().getUICallback(this.key).onKickMember(userId, type);
};

InCallParserProxyCallback.prototype.parseSwitchNegotiation = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isToAudio = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getHeader(CINRequestConts.CAPABILITY);
	}

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setCallCapability(videoCap);
	instance.getUICallback(this.key).onSwitchNegotiation(hdCall);
};

InCallParserProxyCallback.prototype.parseSwitchNegotiationRes = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isAgree = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	var isToAudio = cinMessage.getInt(CINRequestConts.STATUS) === 1;
	var type = request.getInt(CINRequestConts.TYPE);

	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setCallCapability(videoCap);
	cinBody = cinMessage.getBodys();
	var sdpOffer = "";

	if(cinBody && cinBody!==null&& cinBody.length>0){
		cinBody.forEach(function(sdpChunk){
			sdpOffer+=JIOUtils.toString(sdpChunk.val);
		});
		hdCall.setRemoteSDP(sdpOffer);
	}
	instance.getUICallback(this.key).onSwitchNegotiationResp(hdCall, userId, isAgree, isToAudio, sdpOffer);
};

InCallParserProxyCallback.prototype.parseNotifyUserEnter = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var version = 0;				
	if (cinMessage.containsHeader(CINRequestConts.VERSION)) {
		version = cinMessage.getInt(CINRequestConts.VERSION);
	}
	
	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setCallCapability(videoCap);
	instance.getUICallback(this.key).onUserAnsCall(hdCall, userId, version);
};

InCallParserProxyCallback.prototype.userShow = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isOnShow = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	instance.getUICallback(this.key).onUserOnShow(hdCall, userId, isOnShow);
};

InCallParserProxyCallback.prototype.parseKeepOrReturn = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isKeepSession = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	
	instance.getUICallback(this.key).onKeepOrReturnSession(hdCall, userId, isKeepSession);
};

InCallParserProxyCallback.prototype.parseSwitchDevice = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isApply = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	
	instance.getUICallback(this.key).onSwitchDevice(hdCall, userId, isApply);
}

InCallParserProxyCallback.prototype.deleteSession = function(cinMessage){
	var instance = RTMSession.getInstance();
	instance.getUICallback(this.key).onCallEnd(instance.getHDCall(this.key));
	instance.endSession(this.key);
};

InCallParserProxyCallback.prototype.parseSentPackageCount = function(cinMessage) {
	var packet = new RTMPacket();
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var count = cinMessage.getInt(CINRequestConts.INDEX);
	packet.setCount(count+1);
	RTMManager.getInstance().sendPackageCount(packet);

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	
	instance.getUICallback(this.key).onSentPackageCount(hdCall, userId, count);
};

InCallParserProxyCallback.prototype.parseBusy = function(cinMessage) {
	// debugger;
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var state = cinMessage.getInt(CINRequestConts.TYPE);
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	var cinBodys = cinMessage.getBodys();
	var sdpStr = "";
	cinBodys.forEach(function(cinBody){
		sdpStr+=JIOUtils.toString(cinBody.val);
	});
	if(cinMessage.containsHeader(-1)){
		hdCall.sdpReason = 	cinMessage.getString(-1);	
	}
	if(sdpStr!==null|| sdpStr!==""){
		hdCall.setRemoteSDP(sdpStr);
	}

	var callback = instance.getUICallback(this.key);
	
	if(!callback){
		return;
	}
	if(callback && typeof callback.onCallBusy === "function"){
		// debugger;
		if(state === RTMRequestConsts.BUSY_STATE_RINGING){
			// callback.onRingCall(hdCall);
			return;
		}else if(state === RTMRequestConsts.BUSY_STATE_BUSY){
			callback.onRemoteSDPRecevied(hdCall);
			return;
		}
		callback.onCallBusy(hdCall, null, state);
	}
};

InCallParserProxyCallback.prototype.parseWaitedSession = function (cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var fromUserName = cinMessage.getString(CINRequestConts.NAME);
	var mobileNo = cinMessage.getString(CINRequestConts.MOBILENO);
	var toUserId = cinMessage.getHeader(CINRequestConts.TO);
	var tokenAddress = cinMessage.getString(CINRequestConts.TOKEN);
	var createrId = cinMessage.getInt(CINRequestConts.INDEX);
	var type = cinMessage.getInt(CINRequestConts.TYPE);
	var status = cinMessage.getInt(CINRequestConts.STATUS);
	var instance = RTMSession.getInstance();
	
	this.inCallCallback.onWaitedSession(this.key, fromUserId, fromUserName, mobileNo, toUserId, tokenAddress, createrId, type,status);
};

InCallParserProxyCallback.prototype.parseNotifyICECandidate = function(cinMessage){
	// debugger;
	var bodys = cinMessage.getBodys();
	var iceCandidates = new Array();
	bodys.forEach(function(cinBody){
		iceCandidates.push(JIOUtils.toString(cinBody.val));
	});

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setRemoteICECandidates(iceCandidates);

	var callback = RTMSession.getInstance().getUICallback(this.key);
	
	console.log("Incoming Candidates", iceCandidates);
	console.log(hdCall);
	
	if(callback && typeof callback.onICEInfo === "function"){
		// callback.onICEInfo(hdCall, userId, state);
		callback.onICEInfo(hdCall, iceCandidates, null);
	}
};

InCallParserProxyCallback.prototype.parseRequireDeviceInfo = function(cinMessage){

	var isHDCall = false;
    var status = -1;
    var hdCall = this.getHDCall(cinMessage);
//     debugger;
    var instance = RTMManager.getInstance();
    if(cinMessage.containsHeader(CINRequestConts.STATUS)){
        status = cinMessage.getInt(CINRequestConts.STATUS);
        if(status === 0){
            isHDCall = true;
        }
    }

	var sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;
	if(cinMessage.containsHeader(RTMRequestConsts.P2P_CALL_TYPE)){
		sessionType = cinMessage.getInt(RTMRequestConsts.P2P_CALL_TYPE);
	}
	
	hdCall.setIsIncoming(true);
    hdCall.setEligibilityVersion(RTMRequestConsts.HD_CALL_VERSION);
    hdCall.setSessionType(sessionType);
	hdCall.setTo(cinMessage.getHeader(CINRequestConts.TO));
	
	// var seq = cinMessage.getHeader(CINRequestConts.CSEQUENCE);

	RTMManager.getInstance().setDeviceInfoRequest(hdCall);

	// RTMManager.getInstance().sendDeviceInfoResponse(HTTPRequestConts.OK, seq, hdCall);
};

InCallParserProxyCallback.prototype.getCallSDP = function(cinMessage, hdCall){
	var bodys = cinMessage.getBodys();
	var stunmodel = null;
	if(bodys[0]){
		var turnInfo = JIOUtils.toString(bodys[0].val);
		if(turnInfo!==""){
			stunmodel = new STUNModel(turnInfo);
			hdCall.setTurnServer(stunmodel);
		}
		
	}

	if(bodys[1] !== undefined && bodys[1]!== null){
		codec = JIOUtils.toString(bodys[1].val);
		hdCall.setCodec(codec);

	}

	if(bodys[2] !== undefined && bodys[2]!== null){
		hdCall.videoCodec = JIOUtils.toString(bodys[2].val);
	}	

	return hdCall;
}

InCallParserProxyCallback.prototype.parseNotifyTurnDetails = function(cinMessage){
	var from = cinMessage.getHeader(CINRequestConts.FROM);
	var bodys = cinMessage.getBodys();
	// var stunmodel = null;
	// if(bodys[0]){
	// 	var turnInfo = JIOUtils.toString(bodys[0].val);
	// 	if(turnInfo!==""){
	// 		stunmodel = new STUNModel(turnInfo);
	// 		hdCall.setTurnServer(stunmodel);
	// 	}
		
	// }

	// if(bodys[1] !== undefined && bodys[1]!== null){
	// 	codec = JIOUtils.toString(bodys[1].val);
	// 	hdCall.setCodec(codec);

	// }

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall = this.getCallSDP(cinMessage, hdCall);
		
	// if(bodys[2] !== undefined && bodys[2]!== null){
	// 	hdCall.videoCodec = JIOUtils.toString(bodys[2].val);
	// }

	var callback = RTMSession.getInstance().getUICallback(this.key);

	if(!callback){
		return;
	}

	if(callback && typeof callback.onTURNRecived === "function"){
		callback.onTURNRecived(hdCall);
	}
};
