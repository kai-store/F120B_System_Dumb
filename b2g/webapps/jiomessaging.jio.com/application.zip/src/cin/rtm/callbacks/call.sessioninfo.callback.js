function SessionInfoCallback(uiCallback, code) {
	this.uiCallback = uiCallback;
	this.code = code;
}

SessionInfoCallback.prototype = {
	onSuccess: function(cinMessage){
		userInfos = new Array();
		cinBodys = cinMessage.getBodys();
		cinBodys.forEach(function(cinMessageBody){
			contactResponse = CINResponse.getCINMessage(cinMessageBody.val, null, false);
			rtmUser = RTMUser();
			rtmUser.init(contactResponse);
			userInfos.push(rtmUser);
		});
		this.uiCallback.onSuccess(userInfos);
	},
	onError: function(error){
		JIOUtils.sendError(this.code, error, this.uiCallback);
	}
};