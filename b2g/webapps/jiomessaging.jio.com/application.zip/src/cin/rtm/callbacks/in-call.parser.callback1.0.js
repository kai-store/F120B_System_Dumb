function InCallParserProxyCallback(callback) {
	this.inCallCallback = callback;
	this.count = 1;
	this.callType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;
}

InCallParserProxyCallback.prototype.parse = function(cinMessage){
	var event = cinMessage.getEvent();
	this.key = null;
	if(cinMessage.containsHeader(CINRequestConts.KEY)){
		this.key = cinMessage.getHeader(CINRequestConts.KEY);
	}
	// else{
	// 	this.key = String(cinMessage.getHeader(CINRequestConts.TO)) + String(cinMessage.getHeader(CINRequestConts.FROM));
	// }

	this.callId = cinMessage.getHeader(CINRequestConts.CALLID);
	switch(event){
		case RTMResponseConsts.NOTIFY_INVITED:
			this.parseInvitation(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_INVITED_USERS:
			this.invitedUsers(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_KICK_MEMBER:
			// debugger;
			this.kickMember(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SWITCH_NEGOTIATION:
			this.parseSwitchNegotiation(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SWITCH_NEGOTIATION_RESP:
			this.parseSwitchNegotiationRes(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_USER_ENTER:
			this.parseNotifyUserEnter(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_USER_ONSHOW:
			this.userShow(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_KEEP_OR_RETURN_SESSION:
			this.parseKeepOrReturn(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SWITCH_DEVICE:
			this.parseSwitchDevice(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_DELETE_SESSION:
			this.deleteSession(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_SENT_PACKAGE_COUNT:
			this.parseSentPackageCount(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_PEER_BUSY:
			this.parseBusy(cinMessage);
			break;

		case RTMResponseConsts.EVENT_GET_WAITED_SESSION:
			this.parseWaitedSession(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_ICE_CANDEIDATE:
			this.parseNotifyICECandidate(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_REQUIRE_DEVICE_INFO:
			this.parseRequireDeviceInfo(cinMessage);
			break;

		case RTMResponseConsts.NOTIFY_ON_TURN_DETAILS:
			this.parseNotifyTurnDetails(cinMessage);
			break;
	}
	
};

InCallParserProxyCallback.prototype.getHDCall = function(cinMessage){
	var invitorId = cinMessage.getHeader(CINRequestConts.FROM);
	var creatorId = invitorId;
	if (cinMessage.containsHeader(CINRequestConts.INDEX)) {
		creatorId = cinMessage.getHeader(CINRequestConts.INDEX);
	}

	var sessionType = cinMessage.getInt(CINRequestConts.TYPE);
	var isMulti = cinMessage.getInt(CINRequestConts.STATUS) === 2;
	var address = cinMessage.getString(CINRequestConts.TOKEN);
	var mobile = null;
	if (cinMessage.containsHeader(CINRequestConts.MOBILENO)) {
		mobile = cinMessage.getString(CINRequestConts.MOBILENO);
	}

	var name = null;
	if (cinMessage.containsHeader(CINRequestConts.NAME)) {
		name = cinMessage.getString(CINRequestConts.NAME);
	}
	
	var version = 0;
	if (cinMessage.containsHeader(CINRequestConts.VERSION)) {
		version = cinMessage.getInt(CINRequestConts.VERSION);
	}
	
	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}
	var groupId = null;
	if(cinMessage.containsHeader(CINRequestConts.DEVICETOKEN)) {
		groupId = cinMessage.getHeader(CINRequestConts.DEVICETOKEN);
	}

	var isReconnect = false;
	if(cinMessage.containsHeader(CINRequestConts.ICE_RESTART)) {
		isReconnect = cinMessage.getHeader(CINRequestConts.ICE_RESTART)===1;
	}
	// debugger;
	if(cinMessage.containsHeader(RTMRequestConsts.P2P_CALL_AUDIO_VIDEO_TYPE)){
		sessionType = cinMessage.getInt(RTMRequestConsts.P2P_CALL_AUDIO_VIDEO_TYPE);
	}
	// var reconnect = false;
	// if (request.containsHeader(CinHeaderType.RECONNECT)) {
	// 	reconnect = request.getHeader(CinHeaderType.RECONNECT).getInt64() == 1L;
	// }
	var instance = RTMSession.getInstance();

	var hdCall = new HDCall();
	hdCall.initSession(this.key, address);
	
	hdCall.setSessionType(sessionType);
	hdCall.setIsMulti(isMulti);
	hdCall.setCreatorId(creatorId);
	hdCall.setInvitorId(invitorId);
	hdCall.setCallCapability(videoCap);
	hdCall.setEligibilityVersion(version);
	hdCall.setCallId(cinMessage.getHeader(CINRequestConts.CALLID));
	hdCall.setFrom(invitorId);
	hdCall.setIsIncoming(true);
	hdCall.setGroupId(groupId);
	hdCall.setReconnect(isReconnect);
	
	var rtmUser = new RTMUser();
	rtmUser.setUserID(invitorId);
	rtmUser.setMobileNumber(mobile);
	rtmUser.setName(name);
	hdCall.addUsers(rtmUser);
	// hdCall = this.getCallSDP(cinMessage, hdCall);
	var cinBody = cinMessage.getBodys();
	if(cinBody !== null && cinBody.length>0){
		// debugger;
		var turnInfo = JIOUtils.toString(cinBody[0].val);
		turnInfo = new STUNModel(turnInfo);

		cinBody.splice(0, 1);

		var codec = JIOUtils.toString(cinBody[0].val);
		cinBody.splice(0, 1);
		
		if(this.callType === RTMRequestConsts.CALL_TYPE_SINGLE_VIDEO){
			var codec = JIOUtils.toString(cinBody[0].val);
			hdCall.videoCodec = codec;
			cinBody.splice(0, 1);
		}

		var sdpStr = "";
		cinBody.forEach(function(cinVal){
			sdpStr+=JIOUtils.toString(cinVal.val);
		});
		hdCall.setRemoteSDP(sdpStr);
		hdCall.setTurnServer(turnInfo);
		hdCall.setCodec(codec);
	}
	// if(request.containsHeader(CinHeaderType.Encrypt)) {
	// 	meKey = request.getHeader(CinHeaderType.Encrypt).getValue();
	// }

	// byte[] uuid = null;
	// if(request.containsHeader(CinHeaderType.Email)) {
	// 	uuid = request.getHeader(CinHeaderType.Email).getValue();
	// }

	// String encryptShow = null;
	// if(request.containsHeader(CinHeaderType.Expire)) {
	// 	encryptShow = request.getHeader(CinHeaderType.Expire).getHexString();
	// }

	// boolean reconnect = false;
	// if (request.containsHeader(CinHeaderType.RECONNECT)) {
	// 	reconnect = request.getHeader(CinHeaderType.RECONNECT).getInt64() == 1L;
	// }
	return hdCall;
}

InCallParserProxyCallback.prototype.parseInvitation = function(cinMessage) {
	// debugger;
	var hdCall = this.getHDCall(cinMessage);
	
	var instance = RTMSession.getInstance();
	
	hdCall.setState(RTMRequestConsts.BUSY_STATE_RINGING);
	
	var sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;

	if(cinMessage.containsHeader(RTMRequestConsts.P2P_CALL_TYPE)){
		sessionType = cinMessage.getInt(RTMRequestConsts.P2P_CALL_TYPE);
	}

	if(sessionType>2){
		sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;		
	}
	
	// hdCall.setSessionType(this.callType);

	instance.setHDCall(hdCall);

	// debugger;
	RTMManager.getInstance().sendBusy(hdCall);

	var callback = RTMSession.getInstance().getUICallback(this.key);
	//var callback = RTMManager.getInstance().getCallback();
	if(callback!==null && callback && typeof callback.onRinging === "function"){
		callback.onRinging(hdCall);
	}

};

InCallParserProxyCallback.prototype.invitedUsers = function(cinMessage){
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	var invitorId = cinMessage.getHeader(CINRequestConts.FROM);

	var invitedIds = cinMessage.getHeaders(CINRequestConts.INDEX);
	var callback = RTMSession.getInstance().getUICallback(this.key);
	//var callback = RTMManager.getInstance().getCallback();
	if(callback && typeof callback.onInvitedUsers === "function"){
		callback.onInvitedUsers(hdCall, invitorId, invitedIds);
	}
};

InCallParserProxyCallback.prototype.kickMember = function(cinMessage){
	var type = cinMessage.getInt(CINRequestConts.TYPE);
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var callback = RTMSession.getInstance().getUICallback(this.key);
	
	if(callback && typeof callback.onKickMember === "function"){
	 	callback.onKickMember(userId, type);
	}
	// debugger;
	var hdCall = RTMSession.getInstance().getHDCall(this.key);
	if(hdCall && (String(userId) == String(hdCall.getFrom()) || String(userId) == String(hdCall.getTo()))){
		console.log("call end got kick user in call.parser.callback");
		if(callback && typeof callback.onCallEnd === "function"){
			callback.onCallEnd(hdCall);
		}
	}
};

InCallParserProxyCallback.prototype.parseSwitchNegotiation = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isToAudio = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getHeader(CINRequestConts.CAPABILITY);
	}

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setCallCapability(videoCap);
	var callback = instance.getUICallback(this.key);

	if(callback && typeof callback.onSwitchNegotiation === "function"){
		callback.onSwitchNegotiation(hdCall);
	}
};

InCallParserProxyCallback.prototype.parseSwitchNegotiationRes = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isAgree = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	var isToAudio = cinMessage.getInt(CINRequestConts.STATUS) === 1;
	var type = request.getInt(CINRequestConts.TYPE);

	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setCallCapability(videoCap);
	cinBody = cinMessage.getBodys();
	var sdpOffer = "";

	if(cinBody && cinBody!==null&& cinBody.length>0){
		cinBody.forEach(function(sdpChunk){
			sdpOffer+=JIOUtils.toString(sdpChunk.val);
		});
		hdCall.setRemoteSDP(sdpOffer);
	}

	var callback = instance.getUICallback(this.key);
	
	if(callback && typeof callback.onSwitchNegotiationResp === "function"){
		callback.onSwitchNegotiationResp(hdCall, userId, isAgree, isToAudio, sdpOffer);
	}

};

InCallParserProxyCallback.prototype.parseNotifyUserEnter = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var version = 0;				
	if (cinMessage.containsHeader(CINRequestConts.VERSION)) {
		version = cinMessage.getInt(CINRequestConts.VERSION);
	}
	
	var videoCap = 0;
	if (cinMessage.containsHeader(CINRequestConts.CAPABILITY)) {
		videoCap = cinMessage.getInt(CINRequestConts.CAPABILITY);
	}
	
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setCallCapability(videoCap);
	
	instance.setHDCall(hdCall);

	var callback = instance.getUICallback(this.key);
	
	if(callback && typeof callback.onAnsCall === "function"){
		callback.onAnsCall(hdCall, userId, version);
	}
};

InCallParserProxyCallback.prototype.userShow = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isOnShow = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	var callback = instance.getUICallback(this.key);
	
	if(callback && typeof callback.onUserOnShow === "function"){
		callback.onUserOnShow(hdCall, userId, isOnShow);
	}
};

InCallParserProxyCallback.prototype.parseKeepOrReturn = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	
	var isKeepSession = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	
	var instance = RTMSession.getInstance();
	
	var hdCall = instance.getHDCall(this.key);
	
	var callback = instance.getUICallback(this.key);

	if(callback && typeof callback.onKeepOrReturnSession === "function"){
		callback.onKeepOrReturnSession(hdCall, userId, isKeepSession);
	}
};

InCallParserProxyCallback.prototype.parseSwitchDevice = function(cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var isApply = cinMessage.getInt(CINRequestConts.TYPE) === 1;
	
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	
	var callback = instance.getUICallback(this.key);

	if(callback && typeof callback.onSwitchDevice === "function"){
		callback.onSwitchDevice(hdCall, userId, isApply);
	}
}

InCallParserProxyCallback.prototype.deleteSession = function(cinMessage){
	var instance = RTMSession.getInstance();
	var callback = instance.getUICallback(this.key);

	if(callback && typeof callback.onCallEnd === "function"){
		console.log("call end got DELETE session in call.parser.callback");		
		callback.onCallEnd(instance.getHDCall(this.key));
	}

	instance.endSession(this.key);
};

InCallParserProxyCallback.prototype.parseSentPackageCount = function(cinMessage) {
	var packet = new RTMPacket();
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var count = cinMessage.getInt(CINRequestConts.INDEX);
	// packet.setCount(count+1);
	// RTMManager.getInstance().sendPackageCount(packet);

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);

	var callback = instance.getUICallback(this.key);
	
	if(callback && typeof callback.onPacketRecevied === "function"){
		callback.onPacketRecevied(hdCall, userId, count);
	}

};

InCallParserProxyCallback.prototype.parseBusy = function(cinMessage) {
	// debugger;
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var state = cinMessage.getInt(CINRequestConts.TYPE);
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	var cinBodys = cinMessage.getBodys();
	var sdpStr = "";
	cinBodys.forEach(function(cinBody){
		sdpStr+=JIOUtils.toString(cinBody.val);
	});
	if(cinMessage.containsHeader(-1)){
		hdCall.sdpReason = 	cinMessage.getString(-1);	
	}
	if(sdpStr!==null|| sdpStr!==""){
		hdCall.setRemoteSDP(sdpStr);
	}

	var callback = instance.getUICallback(this.key);
	
	if(!callback){
		return;
	}

	// BUSY_STATE_HOLD
	if(state === RTMRequestConsts.BUSY_STATE_HOLD && typeof callback.onCallHold === "function"){
		callback.onCallHold(hdCall);
		return;
	}

	//Check if remote call is ringing...
	if(state === RTMRequestConsts.BUSY_STATE_RINGING && typeof callback.onRemoteRinging === "function"){
		callback.onRemoteRinging(hdCall);
		return;
	}
	//
	if(state === RTMRequestConsts.BUSY_STATE_BUSY  && typeof callback.onSDPRecevied === "function"){
		callback.onSDPRecevied(hdCall);
		return;
	}

	if(typeof callback.onCallBusy === "function"){
		callback.onCallBusy(hdCall, null, state);
	}
	
};

InCallParserProxyCallback.prototype.parseWaitedSession = function (cinMessage) {
	var userId = cinMessage.getHeader(CINRequestConts.FROM);
	var fromUserName = cinMessage.getString(CINRequestConts.NAME);
	var mobileNo = cinMessage.getString(CINRequestConts.MOBILENO);
	var toUserId = cinMessage.getHeader(CINRequestConts.TO);
	var tokenAddress = cinMessage.getString(CINRequestConts.TOKEN);
	var createrId = cinMessage.getInt(CINRequestConts.INDEX);
	var type = cinMessage.getInt(CINRequestConts.TYPE);
	var status = cinMessage.getInt(CINRequestConts.STATUS);
	var instance = RTMSession.getInstance();
	var callback = instance.getUICallback(this.key);
	if(callback && onWaitedSession.onWaitedSession === "function"){
		this.inCallCallback.onWaitedSession(this.key, fromUserId, fromUserName, mobileNo, toUserId, tokenAddress, createrId, type,status);
	}
};

InCallParserProxyCallback.prototype.parseNotifyICECandidate = function(cinMessage){
	// debugger;
	var bodys = cinMessage.getBodys();
	var iceCandidates = new Array();
	bodys.forEach(function(cinBody){
		iceCandidates.push(JIOUtils.toString(cinBody.val));
	});

	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(this.key);
	hdCall.setRemoteICECandidates(iceCandidates);

	var callback = RTMSession.getInstance().getUICallback(this.key);
	
	console.log("Incoming Candidates", iceCandidates);
	console.log(hdCall);
	
	if(callback && typeof callback.onICERecevied === "function"){
		// callback.onICEInfo(hdCall, userId, state);
		callback.onICERecevied(hdCall, iceCandidates, null);
	}
};

InCallParserProxyCallback.prototype.parseRequireDeviceInfo = function(cinMessage){
	// debugger;
	var isHDCall = false;
    var status = -1;
    var hdCall = this.getHDCall(cinMessage);
//     debugger;
    var instance = RTMManager.getInstance();
    if(cinMessage.containsHeader(CINRequestConts.STATUS)){
        status = cinMessage.getInt(CINRequestConts.STATUS);
        if(status === 0){
            isHDCall = true;
        }
    }

	var sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;
	if(cinMessage.containsHeader(RTMRequestConsts.P2P_CALL_TYPE)){
		sessionType = cinMessage.getInt(RTMRequestConsts.P2P_CALL_TYPE);
	}
	this.callType = sessionType;
	hdCall.setIsIncoming(true);
    hdCall.setEligibilityVersion(RTMRequestConsts.HD_CALL_VERSION);
    hdCall.setSessionType(sessionType);
	hdCall.setTo(cinMessage.getHeader(CINRequestConts.TO));
	
	// var seq = cinMessage.getHeader(CINRequestConts.CSEQUENCE);

	RTMManager.getInstance().setDeviceInfoRequest(hdCall);

	// RTMManager.getInstance().sendDeviceInfoResponse(HTTPRequestConts.OK, seq, hdCall);
};

InCallParserProxyCallback.prototype.getCallSDP = function(cinMessage, hdCall){
	var bodys = cinMessage.getBodys();
	var stunmodel = null;
	if(bodys[0]){
		var turnInfo = JIOUtils.toString(bodys[0].val);
		if(turnInfo!==""){
			stunmodel = new STUNModel(turnInfo);
			hdCall.setTurnServer(stunmodel);
		}
		
	}

	if(bodys[1] !== undefined && bodys[1]!== null){
		codec = JIOUtils.toString(bodys[1].val);
		hdCall.setCodec(codec);

	}

	if(bodys[2] !== undefined && bodys[2]!== null){
		hdCall.videoCodec = JIOUtils.toString(bodys[2].val);
	}	

	return hdCall;
}

InCallParserProxyCallback.prototype.parseNotifyTurnDetails = function(cinMessage){
	var from = cinMessage.getHeader(CINRequestConts.FROM);
	var bodys = cinMessage.getBodys();
	// var stunmodel = null;
	// if(bodys[0]){
	// 	var turnInfo = JIOUtils.toString(bodys[0].val);
	// 	if(turnInfo!==""){
	// 		stunmodel = new STUNModel(turnInfo);
	// 		hdCall.setTurnServer(stunmodel);
	// 	}
		
	// }

	// if(bodys[1] !== undefined && bodys[1]!== null){
	// 	codec = JIOUtils.toString(bodys[1].val);
	// 	hdCall.setCodec(codec);

	// }
	// debugger;
	var key =  String(cinMessage.getHeader(CINRequestConts.TO))+String(cinMessage.getHeader(CINRequestConts.FROM));
	var instance = RTMSession.getInstance();
	var hdCall = instance.getHDCall(key);
	hdCall.setCallId(this.callId);
	hdCall = this.getCallSDP(cinMessage, hdCall);
	instance.setHDCall(hdCall);
	// if(bodys[2] !== undefined && bodys[2]!== null){
	// 	hdCall.videoCodec = JIOUtils.toString(bodys[2].val);
	// }

	var callback = RTMSession.getInstance().getUICallback(key);

	if(!callback){
		return;
	}

	if(callback && typeof callback.onTURNRecived === "function"){
		callback.onTURNRecived(hdCall);
	}
};