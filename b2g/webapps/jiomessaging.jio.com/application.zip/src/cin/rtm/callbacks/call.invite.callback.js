function InviteCallProxyCallback(uiCallback) {
	this.uiCallback = uiCallback;
}

InviteCallProxyCallback.prototype = {
	onSuccess: function(cinMessage){
		var offlineUsers = cinMessage.getHeaders(CINRequestConts.INDEX);
		var key = cinMessage.getHeader(CINRequestConts.KEY);
		var hdCall = RTMSession.getInstance().getHDCall(key);
		this.uiCallback.onSuccess(hdCall, offlineUsers);
	},
	onError: function(error, method){
		if(method === CINResponceConts.NotAvailable){
			JIOUtils.sendError(200, "User is offline.", this.uiCallback);
			return;
		}
		JIOUtils.sendError(100,error, this.uiCallback);
	}
};