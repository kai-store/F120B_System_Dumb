function CallEndCallback(argument) {
	this.callback = argument;
}
CallEndCallback.prototype = {
	onSuccess: function(cinResponse){
		console.log("END CALL SUCCESS CALLBACK : "+this.callback);
		RTMSession.getInstance().endSession();
		this.callback.onSuccess();	
	},
	onError: function(error){
		JIOUtils.sendError(101, error, this.callback);
	}
};