function GetP2PEligibilityCallback(callback){
    this.uiCallback = callback;
}
GetP2PEligibilityCallback.prototype = {
    onSuccess: function(cinResponse){
        var status = cinResponse.getInt(CINRequestConts.STATUS);
        // debugger;
        switch(status){
            case 1:
                JIOUtils.sendError(105, "HD Call not supported.", this.uiCallback)
                break;
            case 2:
                JIOUtils.sendError(200, "User is offline.", this.uiCallback);
                break;
            case 0:
                var hdCall = RTMSession.getInstance().getHDCall(cinResponse.getHeader(CINRequestConts.CALLID));
                if(hdCall && hdCall.getLocalCallback()){
                    var callback = hdCall.getLocalCallback();
                    callback.onSuccess();
                }
                this.uiCallback.onSuccess(cinResponse);
                break;
            default:
                JIOUtils.sendError(100, "Unknown error",this.uiCallback);
                break;
        }
    },
    onError: function(error, method){
        if(method === CINResponceConts.NotAvailable){
			JIOUtils.sendError(201, "User not available", this.uiCallback);
			return;
		}
        JIOUtils.sendError(100, error, this.uiCallback);
    }
}