function CreateSessionCallback(hdCall, uiCallback, code) {
	this.hdCall = hdCall;
	this.uiCallback = uiCallback;
	this.code = code;
}

CreateSessionCallback.prototype = {
	onSuccess: function(cinMessage){
		var key = cinMessage.getHeader(CINRequestConts.KEY);
		var address = cinMessage.getString(CINRequestConts.TOKEN);
		var instance = RTMSession.getInstance();
		// debugger;
		this.hdCall.initSession(key, address);
		this.hdCall.setCallId(cinMessage.getHeader(CINRequestConts.CALLID));
		instance.setHDCall(this.hdCall);
		this.uiCallback.onSuccess(this.hdCall);
	},
	onError: function(error){
		JIOUtils.sendError(this.code, error, this.uiCallback);
	}
};