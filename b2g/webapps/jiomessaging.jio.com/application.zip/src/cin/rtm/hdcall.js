function HDCall() {
	this._isP2PCall = true;
	this.sessionType = RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO;
	this._isMulti = false;
	this._isReconnect = false;
	this.videoCapWidth = 0;
	this.videoCapHeight = 0;
	this.callToken = null;
	this.to = null;
	this.from = null;
	this.creatorId = null;
	this.invitor  = null;
	this.deviceInfo = DeviceInfo.getInstance().getDeviceInfo();
	this.rtmUsers = new Array();
	this.codec = null;
	this.iceServers = new Array();
	this.remoteICEServers = new Array();
	this.turnServer = null;
	this.eligibilityVersion = "1.0";
	this.capability = 0;
	this.key = null;
	this.address = null;
	this.callID = UUID.randomUUID();
	this._isIncoming = false;
	this.hdcallback = null;
	this.localCallback = null;
	this.sdp = null;
	this.remoteSDP = null;
	this.groupId = null;
	this.callState = -1;
};

HDCall.prototype.initSession = function(key, address) {
	this.key = key;
	this.address = address;
};
HDCall.prototype.setKey = function(key){
	this.key = key;
}
HDCall.prototype.getKey = function(){
	return this.key;
};
HDCall.prototype.getAddress = function(){
	this.address = "";
	if(!this.address || this.address === null){
		return null;
	}
	return "ws://"+this.address;
};

HDCall.prototype.getCallType = function(){
	return RTMRequestConsts.SESSION_TYPE_AUDIO_P2P;
}

HDCall.prototype.setIsIncoming = function(_isIncoming) {
	this._isIncoming = _isIncoming;
};
HDCall.prototype.isIncoming = function() {
	return this._isIncoming;
};

HDCall.prototype.setState = function(status){
	this.callState = status;
}
HDCall.prototype.getState = function(status) {
	return this.callState;

}

HDCall.prototype.isAudioCall = function(){
	return this.sessionType === RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO 
			||this.sessionType === RTMRequestConsts.CALL_TYPE_MULTI_AUDIO;
};

HDCall.prototype.setSessionType = function(sessionType){
	this.sessionType = sessionType;
};

HDCall.prototype.getSessionType = function(){
	return this.sessionType;
};

HDCall.prototype.addICECandidate = function(iceServerInfo){
	// debugger;
	console.log("Inside CIN : Sending Ice :"+iceServerInfo);
	this.iceServers.push(iceServerInfo);
	RTMManager.getInstance().sendIceCandidate(this, iceServerInfo);
}

HDCall.prototype.initICECandidates = function(iceServerInfos){
	this.iceServers.push.apply(this.iceServers, iceServerInfos);
	RTMManager.getInstance().sendIceCandidates(this);
}

HDCall.prototype.getIceCandidates = function(){
	return this.iceServers;
}
HDCall.prototype.setLocalCallback = function(lklCallback){
	this.localCallback = lklCallback;
}

HDCall.prototype.getLocalCallback = function(){
	return this.localCallback;
}

HDCall.prototype.getType = function(){
	switch(this.sessionType){
		case RTMRequestConsts.CALL_TYPE_SINGLE_AUDIO:
			return 1;
		case RTMRequestConsts.CALL_TYPE_SINGLE_VIDEO:
			return 2;
		case RTMRequestConsts.CALL_TYPE_MULTI_AUDIO:
			return 4;
		default:
			return 1;
	}
}

HDCall.prototype.getHDCallType = function(){
	return 4;
}
HDCall.prototype.setCallback = function(callback){
	this.hdcallback = callback;
}
HDCall.prototype.getCallback = function(){
	return this.hdcallback;
}
HDCall.prototype.setCreatorId = function(creatorId){
	this.creatorId = creatorId;
};
HDCall.prototype.getCreatorId = function(creatorId){
	return this.creatorId;
};

HDCall.prototype.setInvitorId = function(invitor){
	this.invitor = invitor;
};
HDCall.prototype.getInvitorId = function(invitor){
	return this.invitor;
};

HDCall.prototype.setIsMulti = function(_isMulti){
	this._isMulti = _isMulti;
};
HDCall.prototype.isMulti = function(){
	return this._isMulti;
};

HDCall.prototype.setVideoDimentions = function(width, height) {
	this.videoCapWidth = width;
	this.videoCapWidth = height;
	this.capability = (this.videoCapWidth << 16) + this.videoCapHeight
};

HDCall.prototype.getVideoWidth = function() {
	return this.videoCapWidth;
};
HDCall.prototype.getVideoHeight = function() {
	return this.videoCapHeight;
};

HDCall.prototype.setCallToken = function(callToken) {
	this.callToken = callToken;
};
HDCall.prototype.getCallToken = function() {
	return this.callToken;
};

HDCall.prototype.setTo = function(to) {
	this.to = to;
};
HDCall.prototype.getTo = function(){
	return this.to;
}

HDCall.prototype.setFrom = function(frm) {
	this.from = frm;
};
HDCall.prototype.getFrom = function(){
	return this.from;
}

HDCall.prototype.setDeviceInfo = function(deviceInfo) {
	this.deviceInfo = deviceInfo;
};
HDCall.prototype.getDeviceInfo = function() {
	return this.deviceInfo;
};

HDCall.prototype.setCodec = function(codec) {
	this.codec = codec;
};
HDCall.prototype.getCodec = function() {
	return this.codec;
};

HDCall.prototype.setSdp = function(sdpOffer){
	this.sdp = sdpOffer;
	// debugger;
	if(!this._isIncoming){
		RTMManager.getInstance().createSession(this);
		return;
	}
	this.setState(RTMRequestConsts.BUSY_STATE_BUSY);
	RTMManager.getInstance().sendBusy(this);
}
HDCall.prototype.setSdpForSwitchCamera = function(sdpOffer){
	this.sdp = sdpOffer;
	
	this.setState(RTMRequestConsts.BUSY_STATE_BUSY);
	RTMManager.getInstance().sendBusy(this);
}

HDCall.prototype.getSdp = function(){
	return this.sdp;
}

HDCall.prototype.setIceServers = function(iceServers) {
	this.iceServers = iceServers;
};

HDCall.prototype.getIceServers = function(){
	return this.iceServers;
}

HDCall.prototype.setTurnServer = function(turnServer) {
	this.turnServer = turnServer;
};

HDCall.prototype.getTurnServer = function(){
	return this.turnServer;
}

HDCall.prototype.getTurnString = function(){
	return this.turnServer.toString();
}

HDCall.prototype.setEligibilityVersion = function(eligibilityVersion){
	this.eligibilityVersion =  eligibilityVersion;
}

HDCall.prototype.getEligibilityVersion = function(){
	return this.eligibilityVersion;
}

HDCall.prototype.setReconnect = function(reconnect){
	this._isReconnect = reconnect;
}
HDCall.prototype.isReconnect = function(){
	return this._isReconnect;
}

HDCall.prototype.setCallCapability = function(capability) {
	this.capability = capability;
}

HDCall.prototype.getCallCapability = function() {
	
	if(this.isAudioCall()){
		return 0;
	}
	return this.capability;
}
HDCall.prototype.getCallId = function(){
	return this.callID;
};
HDCall.prototype.setCallId = function(callid){
	this.callID = callid;
};
HDCall.prototype.addUsers = function(rtmUser){
	this.rtmUsers.push(rtmUser);
}

HDCall.prototype.getUICallback = function(){
	if(this.hdcallback){
		return this.hdcallback.getCallback();	
	}
	return undefined;
}
HDCall.prototype.setRemoteSDP = function(sdpString){
	this.remoteSDP = sdpString;
}

HDCall.prototype.getRemoteSDP = function(){
	return this.remoteSDP;

}

HDCall.prototype.setRemoteICECandidates = function(iCEServers){
	// this.remoteICEServers.push.apply(this.remoteICEServers, iCEServers);
	this.remoteICEServers = iCEServers;
}

HDCall.prototype.getRemoteICECandidates = function(){
	return this.remoteICEServers;
}

HDCall.prototype.setGroupId = function(grpID){
	this.groupId = grpID;
}

HDCall.prototype.getGroupID = function(){
	return this.groupId;
}
