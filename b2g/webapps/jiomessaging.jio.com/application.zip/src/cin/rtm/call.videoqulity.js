function VideoQuality(peerId, isHighQuality) {
	this.peerId = peerId;
	this.isHighQuality = isHighQuality;
}

VideoQuality.prototype.toCinReq = function() {
	cinReq = new CINRequest(CINRequestConts.VIDEO);
	cinReq.addHeader(0x01, this.peerId);
	cinReq.addHeaderInt8(0x02, this.isHighQuality ? 1 : 2);
	return cinReq.convert();
};
