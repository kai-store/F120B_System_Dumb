function RTMManager() {
}

RTMManager.getInstance = function(){ 
	if(!RTMManager.instance || RTMManager.instance === null){
		RTMManager.instance = new RTMManager();
	}
	return RTMManager.instance;
}

RTMManager.prototype.getCallback = function(){
	return this.rtmCallback;
}

RTMManager.prototype.setCallback = function(callback){
	// debugger;
	this.rtmCallback = new InCallParserProxyCallback(callback);
}


RTMManager.prototype.getInCallback = function(){
	return this.rtmInCallback;
};

RTMManager.prototype.setInCallback = function(callback){
	this.rtmInCallback = callback;
};

RTMManager.prototype.getReq = function(isOneToOne){
	if(!isOneToOne){
		isOneToOne=true
	}
};

RTMManager.prototype.getVideoReq = function(isOneToOne){
	if(!isOneToOne){
		isOneToOne=true
	}
};

RTMManager.prototype.call = function(hdCall, callback){
	// debugger;
	console.log("[call : incoming] rtm call",hdCall);
	var rtmSession = RTMSession.getInstance();
	var from  = hdCall.getFrom();
	
	if(from === undefined || from === null){
		hdCall.setFrom(UserModel.getInstance().getUserID());
	}
	// debugger;
	hdCall.setLocalCallback(callback);
	rtmSession.setHDCall(hdCall);
	var _hdCallback = new HDCallProxyCallback(null, 1);
	hdCall.setCallback(_hdCallback);
	this.getP2PEligibilityRequest(hdCall, _hdCallback);
};

RTMManager.prototype.getP2PEligibilityRequest = function(hdCall, callback){
	// debugger;
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_CHECK_P2P_ELIGIBILITY);
	// cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getTurnServer()));
	// cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getCodec()));
	cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());
	cinReq.addHeaderInt8(RTMRequestConsts.P2P_CALL_TYPE, hdCall.getSessionType());

	cinReq.addHeader(CINRequestConts.TO, hdCall.getTo());
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isReconnect() ? 1 : 0);
	cinReq.addHeaderString(RTMRequestConsts.ELIGIBILITY_VERSION, hdCall.getEligibilityVersion());
	cinReq.addBodyString(hdCall.getDeviceInfo());
	// if(!hdCall.isAudioCall()){
	// 	cinReq.addBodyString("VP8-100-5-640-480");
	// }

	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();
	
	cinReq.setCallback(new GetP2PEligibilityCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_CHECK_P2P_ELIGIBILITY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.createSession = function(hdCall, callback) {
	// debugger;
	if(!callback){
		callback = hdCall.getCallback();
	}
	if(!callback){
		return;
	}
	var cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_CREATE_SESSION);
	var sessionType = hdCall.getSessionType();
	var isMulti = hdCall.isMulti() === true? 2: 1;
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());

	cinReq.addHeader(CINRequestConts.FROM, hdCall.getFrom());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());

	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.getHDCallType());
	cinReq.addHeaderInt8(CINRequestConts.STATUS, isMulti);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	var deviceToken = hdCall.getDeviceInfo();

	if(deviceToken && deviceToken!==null) {
		cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, deviceToken);
	}
	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();

	cinReq.setCallback(new CreateSessionCallback(hdCall, callback));
	cinReq.setMetaInfo('VIDEO','EVENT_CREATE_SESSION');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.invite = function(hdCall, callback) {
	var userInfo = UserModel.getInstance();

	var key = hdCall.getKey();

	var cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_INVITE);
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());

	cinReq.addHeader(CINRequestConts.FROM, userInfo.getUserID());
	cinReq.addHeaderString(CINRequestConts.MOBILENO, userInfo.getPhoneNumber());
   
	cinReq.addHeaderString(CINRequestConts.NAME, userInfo.getName());
	console.log("jvc ",userInfo.getName());
	cinReq.addHeader(CINRequestConts.KEY, key);

	hdCall.userIds.forEach(function(profile, index){
		cinReq.addHeader(CINRequestConts.INDEX, profile);
	});

	if(hdCall.isReconnect()){
		cinReq.addHeaderInt8(RTMRequestConsts.ICE_RESTART, 1);
	}

	//dummy header added
	// if(sdpString && sdpString !== null){
	// 	cinReq.addHeaderString(CINRequestConts.EMAIL, "test@abc.com");
	// 	//addHeader(req, CinHeaderType.Password, sdpString);
	// 	cinReq.addHeaderString(CINRequestConts.PASSWORD, "121212");
	// }
	cinReq.addBodyString(hdCall.getTurnString());
	cinReq.addBodyString(hdCall.getCodec());
	// debugger;
	var hdCallAudioOrVideoValue = 0x01;
	if(hdCall.videoCodec){
		hdCallAudioOrVideoValue = 0x02;
		cinReq.addBodyString(hdCall.videoCodec);
	}
	cinReq.addHeaderInt32(RTMRequestConsts.P2P_CALL_AUDIO_VIDEO_TYPE, hdCallAudioOrVideoValue);
	cinReq.addBodyString(hdCall.getSdp());

	cinReq.setCINMessageObject();

	cinReq.setArgs(arguments);

	cinReq.setCallback(new InviteCallProxyCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_INVITE');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.setDeviceInfoRequest = function(hdCall, callback){
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SET_DEVICE_INFO);
    
	var sessionType = hdCall.getSessionType();
    cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(hdCall.getDeviceInfo()));

    cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
    cinReq.addHeader(CINRequestConts.TO, hdCall.getFrom());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());
    cinReq.addHeaderInt8(CINRequestConts.TYPE,  hdCall.isReconnect() ? 1 : 0);
    cinReq.addHeaderString(RTMRequestConsts.ELIGIBILITY_VERSION, hdCall.getEligibilityVersion());
	cinReq.addHeaderInt8(CINRequestConts.INDEX, sessionType);

//      cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getCallType());

     cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());

    cinReq.setArgs(arguments);
    cinReq.setCINMessageObject();

    cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SET_DEVICE_INFO');	
    
    JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.sendBusy = function(hdCall, callback) {
	// debugger;
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_VIDEO_IS_BUSY);
	var to = hdCall.getTo();

	if(to === null || to === undefined){
		to = UserModel.getInstance().getUserID();
	}
	
	cinReq.addHeader(CINRequestConts.FROM, to);
	cinReq.addHeader(CINRequestConts.KEY, hdCall.getKey());
	cinReq.addHeader(CINRequestConts.TO, hdCall.getFrom());
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.getState());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());
	cinReq.addHeaderInt32(CINRequestConts.INDEX, hdCall.getSessionType());

	var sdp = hdCall.getSdp();

	if(sdp !== null && sdp!== undefined && sdp.length>0){
		cinReq.addBodyString(sdp);
	}
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	if(hdCall.getState()!== RTMRequestConsts.BUSY_STATE_HOLD){
		callback=undefined;
	}
	cinReq.setCallback(new CallBusyCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_VIDEO_IS_BUSY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);

};

RTMManager.prototype.answerCall =  function(hdCall, callback) {

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_ENTER_SESSION);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.KEY, hdCall.getKey());
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_ENTER_SESSION');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.endCall = function(hdCall, callback) {
	// debugger;
	// var rtmSession = RTMSession.getInstance();
	// var hdCall  = rtmSession.getHDCall();

	// if(!rtmSession ||rtmSession == null || rtmSession == undefined){
	// 	callback.onSuccess();
	// 	return;
	// }
	console.log("[call : incoming] rtm end",hdCall);
	if(!hdCall || hdCall == null || hdCall == undefined){
		callback.onSuccess();
		return;
	}
	
	var cinReq = new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_KICK_MEMBER);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.KEY, hdCall.getKey());
	cinReq.addHeader(CINRequestConts.CALLID, hdCall.getCallId());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());

	var isInitiativeQuit = hdCall.isIncoming()?0:1;
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, isInitiativeQuit);

	cinReq.setCINMessageObject();

	cinReq.setArgs(arguments);
	cinReq.setCallback(new CallEndCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_KICK_MEMBER');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.settingVideoQuality = function(videoQualityList, callback) {
	var rtmSession = RTMSession.getInstance();
	var hdCall  = rtmSession.getHDCall();

	var key = rtmSession.getKey();
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_VIDEO_QUALITY_SETTING);
	cinReq.addHeader(CINRequestConts.KEY, key);
	videoQualityList.forEach(function(videoQuality){
		cinReq.addBody(CINRequestConts.BODY, videoQuality.toCinReq());
	});

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_VIDEO_QUALITY_SETTING');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.sendPackageCount = function(hdCall, rtmPacket, callback) {
	// debugger;
	// var rtmSession = RTMSession.getInstance();
	// var hdCall  = rtmSession.getHDCall();
	
	if(hdCall === null ||!hdCall){
		return;
	}

	// var key = rtmSession.getKey();

	if(!rtmPacket || rtmPacket === null){
		JIOUtils.sendError(ErrorCodes.NO_PACKET, "Please create packet object", callback);
		return;
	}

	var miscellaneous = rtmPacket.getMiscellaneous();

	var isConnectionStatsSent = rtmPacket.isStatsSent() === undefined?false:rtmPacket.isStatsSent();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_VIDEO_SENT_RTP_PACKAGE_COUNT);
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.KEY, hdCall.getKey());
	cinReq.addHeaderInt64(CINRequestConts.INDEX, rtmPacket.getCount());

	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());
	cinReq.addHeaderString(CINRequestConts.TYPE, "HD Audio Call");
	cinReq.addHeaderString(CINRequestConts.EXPIRE, rtmPacket.getMediaStats());
	cinReq.addHeaderString(CINRequestConts.VERSION, hdCall.getEligibilityVersion());
	// if(miscellaneous && miscellaneous !== null && miscellaneous.length > 0){
	// 	cinReq.addHeaderString(RTMRequestConsts.MISCELLANEOUS_DETAILS, miscellaneous);
	// }

	// // if (!isConnectionStatsSent) {
	// cinReq.addBody(connectionStats.getBytes());
	// var iceCounterStats = rtmPacket.getIceCounterStats();
	// cinReq.addHeaderString(CINRequestConts.CAPABILITY, rtmSession.getCallCapabilityVerstion());
	// cinReq.addHeaderString(CINRequestConts.ENCRYPT, rtmSession.getCallEncryptVerstion());
	// cinReq.addHeaderString(CINRequestConts.MOBILENO, iceCounterStats);
	// cinReq.addHeaderString(CINRequestConts.EMAIL, JIOUtils.getTruncatedString(iceCounterStats));
	// }
	// if(!hdCall.isAudioCall()){
	// 	cinReq.addHeaderString(RTMRequestConsts.VIDEO_SEND_STATS,"rtmPacket.videoSentStats");
	// 	cinReq.addHeaderString(RTMRequestConsts.VIDEO_RECIVE_STATS,"rtmPacket.videoReciveStats");
	// 	cinReq.addHeaderString(RTMRequestConsts.VIDEO_SEND_STATS_VERSION,"rtmPacket.videoSentStatsVersion");
	// 	cinReq.addHeaderString(RTMRequestConsts.VIDEO_RECIVE_STATS_VERSION,"rtmPacket.videoReciveStatsVersion");
	// }
	
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_VIDEO_SENT_RTP_PACKAGE_COUNT');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.sendIceCandidate = function(hdCall, iceCandidate){
	var iceCandidateList = new Array();
	iceCandidateList.push(iceCandidate);
	this.sendIceCandidates(hdCall, iceCandidateList);
};

RTMManager.prototype.sendIceCandidates = function(hdCall, iceCandidateList, callback){
	// debugger;
	var key = hdCall.getKey();
	if(key === null || key === undefined){
		key = hdCall.getCallId();
	}
	// debugger;
	
	var to = hdCall.getTo();
	var from = hdCall.getFrom();

	if(hdCall.isIncoming()){
		from = hdCall.getTo();
		to = hdCall.getFrom();
		// debugger;
		if(from === null || from === undefined){
			from = UserModel.getInstance().getUserID();
		}
	}
	
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SEND_ICE_CANDIDATE);
	cinReq.addHeader(CINRequestConts.FROM, from);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeader(CINRequestConts.TO, to);
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());

	if(!iceCandidateList){
		iceCandidateList = hdCall.getIceCandidates();
	}
	
	if(iceCandidateList){
		iceCandidateList.forEach(function(iceCandidate){
			cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(iceCandidate));
		});
	}

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SEND_ICE_CANDIDATE');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);

}

RTMManager.prototype.keepSession = function() {
	var rtmSession = RTMSession.getInstance();
	var hdCall  = rtmSession.getHDCall();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_KEEP_OR_RESORE_SESSION);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 1);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_KEEP_OR_RESORE_SESSION');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.restoreSession = function() {
	var rtmSession = RTMSession.getInstance();
	var hdCall  = rtmSession.getHDCall();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_KEEP_OR_RESORE_SESSION);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 2);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_KEEP_OR_RESORE_SESSION');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.submitFeedBackRequest = function(hdCall, message, rating, isSubmitted, checkBox, callback) {

	if(!hdCall | hdCall === null){
		hdCall = RTMSession.getInstance().getHDCall();
	}

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_JC_CALL_FEEDBACK);
	
	cinReq.addHeader(CINRequestConts.FROM, UserModel.getInstance().getUserID());
	cinReq.addHeader(CINRequestConts.KEY, hdCall.getKey());
	cinReq.addHeaderInt32(RTMRequestConsts.FEEDBACK_QUALITY, rating);
	cinReq.addHeaderInt32(CINRequestConts.VERSION, hdCall.getEligibilityVersion());

	if(message!== null && message!== undefined){
		cinReq.addHeaderString(CINRequestConts.LANGUAGE, message);
	}
	
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, hdCall.getHDCallType());
	cinReq.addHeaderInt32(RTMRequestConsts.FEEDBACK_SUBMIT_TYPE, isSubmitted?1:0);
    cinReq.addBody(CINRequestConts.BODY, JIOUtils.getBytes(checkBox));
	var sessionInfo = hdCall.isAudioCall()?"00":"11";
	//HDCall
	sessionInfo+= "1";
	//Is conf call or P2P call
	sessionInfo+= hdCall.isMulti()?"1":"0"

	cinReq.addHeaderInt32(RTMRequestConsts.FEEDBACK_SESSION_INFO, parseInt(sessionInfo, 2))

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_JC_CALL_FEEDBACK');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.getOfflineCallLogs = function(callback){
	// debugger;
	var cinReq =  new CINRequest(CINRequestConts.MESSAGE, RTMRequestConsts.EVENT_OFFLINE_AV_CALL_LOGS);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new OfflineCallCallback(callback));
	cinReq.setMetaInfo('MESSAGE','EVENT_OFFLINE_AV_CALL_LOGS');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.clearOfflineCallLogs = function(){
	var cinReq =  new CINRequest(CINRequestConts.MESSAGE, RTMRequestConsts.EVENT_CLEAR_OFFLINE_AV_CALL_LOGS);
	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback());
	cinReq.setMetaInfo('MESSAGE','EVENT_CLEAR_OFFLINE_AV_CALL_LOGS');	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.getSessionInfo = function(callback){
	var rtmSession = RTMSession.getInstance();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_GET_SESSION_INFO);
	cinReq.addHeader(CINRequestConts.KEY, key);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('MESSAGE','EVENT_GET_SESSION_INFO');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
};

RTMManager.prototype.switchNegotiate = function(hdCall, callback) {
	var rtmSession = RTMSession.getInstance();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO,RTMRequestConsts.EVENT_SWITCH_NEGOTIATION);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);

	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.switchNegotiationResp =  function(hdCall, callback) {
	var rtmSession = RTMSession.getInstance();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO,RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION_RESP');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);

}
// RTMManager.prototype.switchNegotiationResp =  function(hdCall, callback) {
// 	var rtmSession = RTMSession.getInstance();

// 	var key = rtmSession.getKey();

// 	var cinReq =  new CINRequest(CINRequestConts.VIDEO,RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP);

// 	cinReq.addHeader(CINRequestConts.KEY, key);
	
// 	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
// 	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());

// 	cinReq.setCINMessageObject();
// 	cinReq.setArgs(arguments);

// 	cinReq.setCallback(new EmptyResponseCallback(callback));

// 	JIOClient.getInstance().getCINClient().send(cinReq);
// }

RTMManager.prototype.switchNegotiationSdpRequest = function(hdCall, callback) {

	var rtmSession = RTMSession.getInstance();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SWITCH_NEGOTIATION_RESP);

	cinReq.addHeader(CINRequestConts.KEY, key);
	
	cinReq.addHeaderInt8(CINRequestConts.TYPE, hdCall.isAudioCall() ? 1 : 2);
	
	cinReq.addHeaderInt64(CINRequestConts.CAPABILITY, hdCall.getCallCapability());
	//TODO body
	cinReq.addBodyString("");

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWITCH_NEGOTIATION_RESP');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.onShowApply = function(isOnShow, callback) {
	var rtmSession = RTMSession.getInstance();
	var hdCall  = rtmSession.getHDCall();

	var key = rtmSession.getKey();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_USER_ONSHOW_APPLY);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, isOnShow ? 1 : 2);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_USER_ONSHOW_APPLY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}


RTMManager.prototype.applySwitchDevice = function(key, callback) {
	var rtmSession = RTMSession.getInstance();
	var hdCall  = rtmSession.getHDCall();

	var key = rtmSession.getKey();
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SWTICH_DEVICE_APPLY);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 1);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWTICH_DEVICE_APPLY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.executeSwitchDevice = function(key, callback) {
	var rtmSession = RTMSession.getInstance();
	var hdCall  = rtmSession.getHDCall();

	var key = rtmSession.getKey();
	var cinReq =  new CINRequest(CINRequestConts.VIDEO, RTMRequestConsts.EVENT_SWTICH_DEVICE_APPLY);
	cinReq.addHeader(CINRequestConts.KEY, key);
	cinReq.addHeaderInt8(CINRequestConts.TYPE, 2);

	cinReq.setCINMessageObject();
	cinReq.setArgs(arguments);
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('VIDEO','EVENT_SWTICH_DEVICE_APPLY');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.getCINClient = function(hdCall){
	instance  = CINClient.getInstance(hdCall.getAddress());
	if(!this.isSocketCallbackSet){
		instance.setSocketCallback(new CallInitCallback());
		this.isSocketCallbackSet = true;
	}
	return instance;
}

/**
** This method will return, 
**/
RTMManager.prototype.isActiveCall = function(hdCall) {
	var activeHDCall = RTMSession.getInstance().getHDCall();
	
	if(!activeHDCall || activeHDCall === null){
		return true;
	}
	return JIOUtils.toString(hdCall.getCallId());
}

/**
** This method for auto logon of push notification
**/
RTMManager.prototype.AVAutoLogon = function(pushData) {
	var cinReq =  new CINRequest(CINRequestConts.LOGON, CinBase64.getByte(0x02));
	// from - Userid
	cinReq.addHeaderString(CINRequestConts.NAME, pushData.getName()); // device name 
	cinReq.addHeader(CINRequestConts.KEY, JIOUtils.getBytes(pushData.getKey()));
	cinReq.addHeader(CINRequestConts.PASSWORD, JIOUtils.getBytes(pushData.getPassword())); 
	cinReq.addHeader(CINRequestConts.PUSH_AUTH_KEY, JIOUtils.getBytes(pushData.getAuth()));
	cinReq.addHeaderInt32(CINRequestConts.TYPE, CINRequestConts.PLATFORM_TYPE); // 1
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, pushData.getHDCallType());
	cinReq.addHeaderInt64(CINRequestConts.LANGUAGE, pushData.getLanguage()); // language in long
	cinReq.addHeaderString(CINRequestConts.DEVICETOKEN, pushData.getDeviceToken());
	cinReq.addHeaderString(CINRequestConts.VERSION, pushData.getVersion()); // app version
	cinReq.addHeaderInt8(RTMRequestConsts.P2P_CALL_TYPE, pushData.getSession());
	cinReq.addHeaderInt64(CINRequestConts.STATUS, pushData.getStatus()); // kClientOEMTag
	cinReq.addHeaderInt64(CINRequestConts.APP_TYPE, UserModel.getInstance().getAppType());
	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();
	
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('LOGON', '0x02');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.getLastSessionInfo = function(callType, callback) {
	// debugger;
	console.log("VIDEO CALL CALLTYPE:",callType);
	var userInfo = UserModel.getInstance();

	var cinReq =  new CINRequest(CINRequestConts.VIDEO, CinBase64.getByte(0x31));
	cinReq.addHeader(CINRequestConts.FROM, userInfo.getUserID());
	cinReq.addHeaderInt32(RTMRequestConsts.CALL_TYPE, 4);
	var callId = Math.floor((Math.random() * 10000) + 1);
    cinReq.addHeaderInt64(CINRequestConts.CALLID, callId);

	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();
	
	cinReq.setCallback(new LastSessionCallback(callback));
	cinReq.setMetaInfo('VIDEO','0x31');	
	
	JIOClient.getInstance().getCINClient().send(cinReq);
}

RTMManager.prototype.sendOkForOfflineCalls = function(callback){
	var cinReq =  new CINRequest(CINRequestConts.MESSAGE, CINRequestConts.NOTIFY);
	cinReq.setArgs(arguments);
	cinReq.setCINMessageObject();
	cinReq.setCallback(new EmptyResponseCallback(callback));
	cinReq.setMetaInfo('MESSAGE','NOTIFY');	
	JIOClient.getInstance().getCINClient().send(cinReq);
}