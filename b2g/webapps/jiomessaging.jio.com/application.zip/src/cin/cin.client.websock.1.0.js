/**
* Encoding and encryption implemented.
*/
function CINClient(){
}
/**
 * Class is for creating CINResponse, and setting an appropriate values.
 */
CINClient.CONECTTING = 0;
CINClient.OPENED = 1;
CINClient.CLOSED =2;
CINClient.ERROR = 3;

CINClient.prototype = {
    constructor: CINClient,
    instance: null,
    //_socket: null,
    
    _getSocket: function(){
        if (!CINClient.socket){

            if(!CINClient.reqQueue){
                 CINClient.reqQueue = new Array();
             }
            
            CINClient.isReadyState = CINClient.CONECTTING;
            
            ws = new Websock();
            ws.open('ws://52.76.248.2:8081');
            
            var that = this;
            ws.on('open', function () {
                CINClient.isReadyState = CINClient.OPENED;
                that.processQueue();
            });

            // ws.on('message', function() {
            //     console.log("Root CIN Message byte[] ---");
            // });
            
            ws.on('close', function () {
                CINClient.socket =  null;
                CINClient.isReadyState = CINClient.CLOSED;
            });

            CINClient.socket = ws;
            //_socket = new WebSocket('ws://localhost:8887');
            /*_socket.onclose = function(evt){
               CINClient.socket =  null;
            }
            _socket.extraParameter = null;
            CINClient.socket=_socket;*/
        }
        return CINClient.socket;
    },
    
    send: function(cinRequest){
        var localSocket = this._getSocket();
        if(CINClient.isReadyState === CINClient.CONECTTING){
            CINClient.reqQueue.push(cinRequest);
            return;
        }

        localSocket.on('close', function(evt){
            CINClient.socket = null;
            CINClient.isReadyState = CINClient.CLOSED;
            CINClient.getInstance().sendErrorCallback(evt, cinRequest.getCallback());
        });
        localSocket.on('message', function() {
            console.log(" --- CIN Message byte[] ---");
            var data = localSocket.get_rQ();
            localSocket.resetIncomingrQ();
            var str = new Int8Array(data);
            JIOUtils.logArray(str,str.length);

            var callback = cinRequest.getCallback();
            cinMessage = CINResponse.getCINMessage(str, callback);

            var isCINObjectOut = cinRequest.isCINMessageObject();
            var instance = CINClient.getInstance();

            if(!cinMessage.isServerRequest()){
                instance.processCINResponce(str, cinMessage, callback, isCINObjectOut);
                return;
            }

            cinRequestProxyCallback = new CinRequestProxyCallback(cinMessage, callback);
            cinRequestProxyCallback.processRequest();
        });
        // localSocket.originalDataSent = cinRequest.convert();
        // Socket is ready state
        if(CINClient.isReadyState === CINClient.OPENED){
            localSocket.send(cinRequest.convert());
            return true;
        }

       if(cinRequest.isMaxRetryReached() === true){
            //Call error method, for error callback
            var callback = cinRequest.getCallback();
            this.sendErrorCallback(-1, callback);
        }
        this._waitForConnection(cinRequest);
        return false;
   },

    _waitForConnection: function(cinRequest){
        var that = this;
        //For incremental retry
        var delay = 1000 * (cinRequest.getRetryCount()+1);
        var timeOut = setTimeout(function () {
            if(cinRequest.isMaxRetryReached() === true){
                return;
            }
            cinRequest.retry();
            var result = that.send(cinRequest);

            // if(result === true){
            //     clearTimeout(timeOut);
            // }
        }, delay);
    }
};

CINClient.getInstance= function(){
    if(!CINClient.instance){
        CINClient.instance = new CINClient();
    }
    return CINClient.instance;
};

CINClient.prototype.processCINRequest = function(cinMessage, callback, isCinObject=false){

};

CINClient.prototype.processCINResponce = function(str, cinMessage, callback, isCinObject=false){
    if(callback == null || !callback){
        return;
    }

    if(isCinObject){
        if (cinMessage.isMethod(HTTPRequestConts.OK )){
            callback.onSuccess(cinMessage);
        }else{
            callback.onError(JIOUtils.toString(cinMessage.getBody()));
        }
        return;
    }
    cinRes = new CINResponse(callback);
    cinRes.convert(str);
};

CINClient.prototype.processQueue = function(){
    for(index =0 ; index< CINClient.reqQueue.length; index++){
        if(CINClient.isReadyState === CINClient.OPENED){
            this.send(CINClient.reqQueue[index]);
        }
    }
};

CINClient.prototype.sendErrorCallback=function(event, callback){
    
    if(!callback){
        return;
    }

   var reason;
    // See http://tools.ietf.org/html/rfc6455#section-7.4.1
    switch (event.code){
        case 1000:
            reason = "Normal closure, meaning that the purpose for which the connection was established has been fulfilled.";
            return;

        case 1001:
            reason = "An endpoint is \"going away\", such as a server going down or a browser having navigated away from a page.";
            break;

        case 1002:
            reason = "An endpoint is terminating the connection due to a protocol error";
            break;

        case 1003:
            reason = "An endpoint is terminating the connection because it has received a type of data it cannot accept (e.g., an endpoint that understands only text data MAY send this if it receives a binary message).";
            break;

        case 1004:
            reason = "Reserved. The specific meaning might be defined in the future.";
            break;

        case 1005:
            reason = "No status code was actually present.";
            break;

        case 1006:
           reason = "The connection was closed abnormally, e.g., without sending or receiving a Close control frame";
           break;

        case 1007:
           reason = "An endpoint is terminating the connection because it has received data within a message that was not consistent with the type of the message (e.g., non-UTF-8 [http://tools.ietf.org/html/rfc3629] data within a text message).";
           break;

        case 1008:
            reason = "An endpoint is terminating the connection because it has received a message that \"violates its policy\". This reason is given either if there is no other sutible reason, or if there is a need to hide specific details about the policy.";
            break;

        case 1009:
           reason = "An endpoint is terminating the connection because it has received a message that is too big for it to process.";
           break;

        case 1010:  // Note that this status code is not used by the server, because it can fail the WebSocket handshake instead.
            reason = "An endpoint (client) is terminating the connection because it has expected the server to negotiate one or more extension, but the server didn't return them in the response message of the WebSocket handshake. <br /> Specifically, the extensions that are needed are: " + event.reason;
            break;

        case 1011:
            reason = "A server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.";
            break;

        case 1015:
            reason = "The connection was closed due to a failure to perform a TLS handshake (e.g., the server certificate can't be verified).";
            break;
        case -1:
            reason = "Reached max retries.";
            break;

        default:
            reason = "Unknown reason";
    }

    JIOUtils.sendError(event.code, reason, callback);
}
