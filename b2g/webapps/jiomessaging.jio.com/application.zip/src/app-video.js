import 'l10n';
import React from 'react';
import ReactDOM from 'react-dom';
import JioBaseComponent from './shared/jioBaseComponent';
import OptionMenuRenderer from './shared/option_menu_renderer';
import DialogRenderer from './shared/dialog_renderer';
import ReactSoftKey from 'react-soft-key';
import Service from 'service';
import history from './shared/my_history';
import HistoryManager from 'history-manager';
import Routes from './routes';
import '../scss/app.scss';
import 'common-scss';
import 'gaia-icons';


class App extends JioBaseComponent {

    name = 'App';
    
    componentDidMount() {
        window.appInstance = this; // For debugging purpose
        window.isDev = false;
        // window.onDevice = false;
        window.msgNotificationEnabled = true;
        window.notificationSoundEnabled = true;
        window.notificationVibrationEnabled = true;
        window.chatSoundEnabled = true;
        window.showMessagePreview = true;
        window.msgDelayTime = 0;
        window.showLastSeen = true;
        window.showReadReceipt = true;
        window.dndFrom = "";
        window.dndTo = "";

        this.element = ReactDOM.findDOMNode(this);

        history.replace('/contacts/list/id');//asfdasfddfd
    }


    render() {
        return <div id='app' tabIndex='-1'>
                    <div className="statusbar-placeholder"></div>
                    <HistoryManager className="margin-bottom" ref="history" history={history} routes={Routes} />
                    <ReactSoftKey ref="softkey" />
                    <div id="menu-root" ></div>
                    <DialogRenderer />
                </div>;
    }

}
ReactDOM.render(<App />, document.getElementById('root'));
