// Prathima input
// 'BNsrw_cXflcoJX3V_9w4v8LusaN3Vv7CYA1z6ob0eOS2WrBcQjjVlGRYueSaN2wv_nxIhAb7SNc_O-_oqiLw7hQ'
// 'kPq8axfNc0ycMpCkxTLkmarZ4rJtuD3NDyDv1wEKlMQ'

// Soumya input
// 'BGeoNWH+aSFuu+Bq5DCy1JGF021awFq5QrsHKMwC45wRtexY4JLYUVS9eb3JxswaSEeA8az1HzcsLrmuNuzM+uc='
// 'AL8U4v/G0WquHcXcYBu7oRfbik8ihkUb9O7tHYi+wMID'

// Javascript input
// 'BIuoU7oJ1yjSv9081Kw2tpN10y6Zi3U7OQnHrbssrkVP8z1igHjKFfwQFNl1MnLBXvwyNMNulq-_nBdXzujrxUc'
// 'iZoUhDqh5xHLHlO5zTWUOk64UMHFUmLrFQxiTNNNqRo'

(function() {
    PushModel = function() {
        this.publicKey = 'BGeoNWH+aSFuu+Bq5DCy1JGF021awFq5QrsHKMwC45wRtexY4JLYUVS9eb3JxswaSEeA8az1HzcsLrmuNuzM+uc=';
            
        this.privateKey = 'AL8U4v/G0WquHcXcYBu7oRfbik8ihkUb9O7tHYi+wMID';

        this.initilizeSW = function(callback) {
            this._applicationKeys = {
                publicKey: this.base64UrlToUint8Array(this.publicKey),
                privateKey: this.base64UrlToUint8Array(this.privateKey)
            };
            
            if ('serviceWorker' in navigator) { 
                navigator.serviceWorker.register('./service-worker.js').then(function(reg) {
                    if(reg.installing) {
                        console.log('[Model: Push] Service worker installing.');
                    } else if(reg.waiting) {
                        console.log('[Model: Push] Service worker installed.');
                    } else if(reg.active) {
                        console.log('[Model: Push] Service worker active.');
                    }

                    navigator.serviceWorker.addEventListener('message', function(event) {
                        console.log('[Model: Push] '+ event.data);
                    });

                    navigator.serviceWorker.ready.then(function(reg) {  
                        reg.pushManager.getSubscription().then(function(subscription) {  
                            if (!subscription) {  
                                console.log('[Model: Push] Not yet subscribed to Push')
                                // We aren't subscribed to push, so set UI  
                                // to allow the user to enable push  
                                callback(null);
                            } else { 
                                console.log('[Model: Push] subscription: ' + JSON.stringify(subscription.toJSON()));
                                callback(subscription.toJSON());
                            }
                        });
                        
                        // .catch(function(err) {  
                        //     console.log('[Model: Push] Error during getSubscription()', err);  
                        //     // commenting this because calling everytime
                        //     // callback(null);
                        // }); 
                    });  
                });  
            } else {  
                console.log('[Model: Push] Service workers aren\'t supported in this browser.');
                callback(null);
            }
        };

        this.registerDevice = function(callback) {
            navigator.serviceWorker.ready.then((serviceWorkerRegistration) => {
                return serviceWorkerRegistration.pushManager.subscribe({
                    userVisibleOnly: true,
                    applicationServerKey: this._applicationKeys.publicKey,
                });
            }).then((subscription) => {
                console.log('[Model: Push] subscription: ' + JSON.stringify(subscription));
                callback(subscription.toJSON());
            }).catch((subscriptionErr) => {
                console.log('[Model: Push] subscriptionErr: '  + subscriptionErr);
                callback(subscriptionErr);
            });
        };

        this.unregisterDevice = function(callback) {
            navigator.serviceWorker.ready.then(function(reg) {  
                reg.pushManager.getSubscription().then(function(subscription) {  
                    if (!subscription) {  
                        console.log('[Model: Push] Not yet subscribed to Push')
                        return;  
                    } 
                    console.log('[Model: Push] subscription: ' + JSON.stringify(subscription.toJSON()));

                    // unsubscribe registration
                    subscription.unsubscribe().then(function(successful) {
                        // You've successfully unsubscribed
                        console.log('[Model: Push] successfully unsubscribed!!');
                        callback(successful);
                    }).catch(function(err) {
                        // Unsubscription failed
                        console.log('[Model: Push] Error in unsubscribe :(');
                        callback(err);
                    })
                }).catch(function(err) {  
                    console.log('[Model: Push] Error during getSubscription()', err);  
                    callback(err);
                }); 
            });  
        };

        this.base64UrlToUint8Array = function(base64UrlData) {
            const padding = '='.repeat((4 - base64UrlData.length % 4) % 4);
            const base64 = (base64UrlData + padding)
                .replace(/\-/g, '+')
                .replace(/_/g, '/');

            const rawData = window.atob(base64);
            const buffer = new Uint8Array(rawData.length);

            for (var i = 0; i < rawData.length; ++i) {
                buffer[i] = rawData.charCodeAt(i);
            }
            return buffer;
        };
    };
})();