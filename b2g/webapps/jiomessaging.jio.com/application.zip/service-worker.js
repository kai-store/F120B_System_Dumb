// 'use strict';
// self.importScripts('src/cin/jio.utils.js');
// self.importScripts('src/cin/stringbuffer.js');
// self.importScripts('src/cin/CinBase64.js');
// self.importScripts('src/security/aes.js');
// self.importScripts('src/security/enc-utf16.js');
// self.importScripts('src/security/mode-ecb.js');
// self.importScripts('src/security/pad-nopadding.js');
// self.importScripts('src/security/pbkdf2.js');
// self.importScripts('src/cin/encrypt/md5.spark.js');
// self.importScripts('src/cin/encrypt/encryption.utils.js');
// self.importScripts('src/sdk/server.config.js');
// self.importScripts('src/cin/core/usermodel.js');
// self.importScripts('src/cin/core/deviceinfo.js');
// self.importScripts('src/cin/cin.request.method.conts.js');
// self.importScripts('src/cin/rtm/callbacks/call.endcall.callback.js');
// self.importScripts('src/cin/cin.request.conts.js');
// self.importScripts('src/cin/rtm/rtm.response.consts.js');
// self.importScripts('src/cin/cin.request.method.conts.js');
// self.importScripts('src/cin/jio.client.2.0.2.js');
// self.importScripts('src/cin/rtm/hdcall.js');
// self.importScripts('src/cin/rtm/rtm.request.consts.js');
// self.importScripts('src/cin/rtm/rtmmanager.1.0.js');
// self.importScripts('src/cin/cin.client.websock.2.0.1-beta.js');

self.importScripts('src/cin/jio.utils.js');
self.importScripts('src/cin/stringbuffer.js');
self.importScripts('src/cin/CinBase64.js');
self.importScripts('src/security/aes.js');
self.importScripts('src/security/enc-utf16.js');
self.importScripts('src/security/mode-ecb.js');
self.importScripts('src/security/pad-nopadding.js');
self.importScripts('src/security/pbkdf2.js');
self.importScripts('src/cin/encrypt/md5.spark.js');
self.importScripts('src/cin/encrypt/encryption.utils.js');
self.importScripts('src/sdk/server.config.js');
self.importScripts('src/cin/core/usermodel.js');

self.importScripts('src/cin/errorcodes.js');
self.importScripts("src/cin/core/deviceinfo.js");
self.importScripts("src/cin/core/locationinfo.js");
self.importScripts("src/cin/core/UUID.js");
self.importScripts("src/cin/cin.request.js");
self.importScripts("src/app-const.js");
self.importScripts('src/cin/cin.response.js');
self.importScripts("src/cin/callback/emptyresponseproxycallback.js");
self.importScripts('src/cin/http.request.conts.js');
self.importScripts('src/cin/callback/LogonProxyCallback.js');
self.importScripts('src/cin/callback/ChallengeProxyCallback.js');
self.importScripts('src/cin/cin.request.method.conts.js');
self.importScripts('src/cin/rtm/callbacks/call.endcall.callback.js');
self.importScripts('src/cin/cin.request.conts.js');
self.importScripts('src/cin/rtm/rtm.response.consts.js');
self.importScripts('src/cin/cin.request.method.conts.js');
self.importScripts('src/cin/jio.client.2.0.2.js');
self.importScripts('src/cin/rtm/hdcall.js');
self.importScripts('src/cin/rtm/rtm.request.consts.js');
self.importScripts('src/cin/rtm/rtmmanager.1.0.js');
self.importScripts('src/cin/cin.client.websock.2.0.1-beta.js');

var isIncomingCallNotification = false;
var jsonMessage = '';

self.addEventListener('activate', function(event) {
	event.waitUntil(
    	clients.claim().then(function() {
			// After the activation and claiming is complete, send a message to each of the controlled
			// pages letting it know that it's active.
			// This will trigger navigator.serviceWorker.onmessage in each client.
			return self.clients.matchAll().then(function(clients) {
				return Promise.all(clients.map(function(client) {
					return client.postMessage('The service worker has activated and taken control.');
				}));
			});
    	})
  	);
});

self.addEventListener('push', function(event) {
	var title = 'Jio App';
	var body, message;
	
	isIncomingCallNotification = false;
	jsonMessage = '';

  	if (event.data) {
		body = event.data.text();
		jsonMessage = JSON.parse(body);
		console.log("[ServiceWorker] New push message " + JSON.stringify(jsonMessage));

		message = jsonMessage.alert;        
  	} else {
    	body = 'You have a new message.';
  	}
  	var icon = '/icons/icon192x192.png';
  	var tag = 'interactive-push-notification-tag';
	
  	event.waitUntil(clients.matchAll({
	    type: 'window'
  	}).then(function(clientList) {   
		for (var i = 0; i < clientList.length; i++) {
			var client = clientList[i];
			return client.postMessage('push event from SW');
		}

		try {
			if(jsonMessage.Category === "CATEGORY_MESSAGE"){
				title = "JioChat"
				icon = '/icons/84x84_chat.png';
				message = parseMessage(jsonMessage);
			} else if(jsonMessage.Category === "CATEGORY_CHANNEL"){
				title = "Jio Channels";
				icon = '/icons/84x84_channels.png';
			} else if(jsonMessage.Category === "CATEGORY_CALL"){
				title = jsonMessage.MN; // phone no.
				if (jsonMessage.name) {
					title = jsonMessage.name;
				}
				tag = title;
				console.log("[ServiceWorker] New push message for call");
				icon = ''; // not need of icon
				message = "Incoming video call"; 
				isIncomingCallNotification = true;
			}else if(jsonMessage.Category === "CATEGORY_MISSED"){
				var name = jsonMessage.MN; // phone no.
				if (jsonMessage.name) {
					name = jsonMessage.name;
				}
				tag = name;

				title = "JioVideocall";
				icon = '/icons/84x84_video.png';
				message = "Missed call: "+name;
			}
		} catch(e) {
			message=""+e;
			console.log("[Jio-Chat] Error:", e);
			console.log(e);
		}
		
		if (isIncomingCallNotification) {
			self.registration.showNotification(title, {
				body: message,
				icon: icon,
				data: body,
				requireInteraction: true,
				mozbehavior: {
					soundFile: '/assets/ringtones/audio_video_silent_push.mp3'
				},
				actions: [{
					action: 'answer', 
					title: 'Answer'
				}, { 
					action: 'decline', 
					title: 'Decline'
				}],
				tag: tag
			});
		} else {
			if(jsonMessage.Category === "CATEGORY_MISSED") {
				self.registration.showNotification(title, {
					body: message,
					icon: icon,
					data: body,
					tag: tag
				});
			} else {
				self.registration.showNotification(title, {
					body: message,
					icon: icon,
					data: body
				});
			}
		}
	}));
});

self.addEventListener('notificationclick', function(event) {
	event.notification.close();
	console.log('[SW] notification click');
	if (isIncomingCallNotification) {
		console.log('[SW] event.action '+ event.action);
		if (event.action === 'answer') {
			// console.log('[SW] inside answer '+ event.notification.data);
			if (event.notification.data != undefined) {
				var openAppEvent = {
					msg: event.notification.data
				};
				  
			  	clients.openApp(openAppEvent);
			} else {
			  	clients.openApp();
			}
		} else {
			endCall(event.notification.data);
		}
	} else {
		if (event.notification.data != undefined) {
			var openAppEvent = {
				msg: event.notification.data
			}
			clients.openApp(openAppEvent);
		} else {
			clients.openApp();
		}
	}
});

function getEncodedUserString(userId){
		var encodedString = "";
		for(var index=0;index<userId.length;index++){
			encodedString=encodedString+userId[index]+"|";
		}
		return encodedString;
}

function parseMessage(jsonObject){
	
	if(jsonObject.Category !== "CATEGORY_MESSAGE"){
		return jsonObject.alert;
	}

	var publicKey = "BA91DDD5C35E43FB6BDF622FFECC405E";
	// var serverByteKey = [12, 13, -12, 15, 16];
	console.log("[jio-chat] userId String: ", jsonObject.UserId);

	var userIdByteArray = jsonObject.UserId.split(",");
	console.log("[jio-chat] userId Array: ", userIdByteArray);

	var encryptedString = jsonObject.alert;
	// debugger;

	// var serverKeyStr = CinBase64.encode(serverByteKey);// Value: DA30DxA;
	var serverKeyStr = jsonObject.encryptKey;
	var userIdStr = getEncodedUserString(userIdByteArray);// Value: -12|13|14|-15|
	// debugger;
	//Using byte[], this method we used for Logon Reqeest....
	var spark = new SparkMD5.ArrayBuffer();
	var serverKeyFinalBytes = JIOUtils.getBytes(serverKeyStr);//Value: [68,65,51,48,68,120,65,59]
	var publicKeyBytes = JIOUtils.getBytes(publicKey);// Value: [66,65,57,49,68,68,68,53,67,51,53,69,52,51,70,66,54,66,68,70,54,50,50,70,70,69,67,67,52,48,53,69]
	var userIdFinalBytes = JIOUtils.getBytes(userIdStr); // Value: [45,49,50,124,49,51,124,49,52,124,45,49,53,124]

	spark.append(new Int8Array(serverKeyFinalBytes));
	spark.append(new Int8Array(publicKeyBytes));
	spark.append(new Int8Array(userIdFinalBytes));

	md5FirstBytes = new Int8Array(JIOUtils.getBytes(spark.end(true)));//value: [-60,42,35,75,-28,110,111,18,70,75,110,113,-80,-33,-57,-29]
	md5FirstBytes.reverse();//value: [-29,-57,-33,-80,113,110,75,70,18,111,110,-28,75,35,42,-60]
	var encryptedBytes =  new Array();
	console.log("[jio-chat] Key: ", md5FirstBytes);
	var bytes = CinBase64.decode(encryptedString);
	var index = bytes.length-1;
	for(var i=bytes.length-1;i>=0; i--){
			if(bytes[i]!=0){
				index=i;
				break;
			}
	}
	for(i=0;i<=index;i++){
		encryptedBytes[i] = bytes[i];
	}
	console.log("[jio-chat] en crypted: ", encryptedBytes);

	return EncryptionUtils.decryptNotification(encryptedBytes, md5FirstBytes, serverKeyFinalBytes);
}

function endCall(callJSON){
	try{
		var hdCall = new HDCall();
		var key = JIOUtils.toByteArray(callJSON.KEY);
		var callID = JIOUtils.toByteArray(callJSON.CallId);
		var fromId = new Int8Array(callJSON.UserId.split(","));
		hdCall.setKey(key);
		hdCall.setIsIncoming(true);
		hdCall.setSessionType(RTMRequestConsts.CALL_TYPE_SINGLE_VIDEO);
		hdCall.setCallId(callID);
		RTMManager.getInstance().endCall(hdCall);
	}catch(e){
		console.log("[Call Log]: ",e);
	}
}