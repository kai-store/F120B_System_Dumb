function JioAnalytics() {
    /* device related data */
    this.imei = "";
    this.iccid = "";
    this.adid = "";
    this.imsi = "";
    this.msisdn = "";  
    this.hardware_info = "";
    this.os_name = "";
    this.platform_build_id = "";
    this.platform_version = "";
    this.software = "";

    /* Location data ***/
    this.latitude = "";
    this.longitude = "";
    this.analyticDataArray = [];
}

JioAnalytics.prototype = {
	constructor: JioAnalytics,     
    geoFindMe:function(callback){       
        var that = this;     
        that.logNo = 0;    
        if (!navigator.geolocation) {
            console.log("Geolocation is not supported");
            callback(false);
        }else {
            function success(position) {
                that.latitude = position.coords.latitude;
                that.longitude = position.coords.longitude;
                // console.log("[JIO ANALYTICS] latitude is :: ",that.latitude +"and long :: "+that.longitude )
                callback(true);
            }
            function error(e) {
                // console.log("[JIO ANALYTICS] location error", JSON.stringify(e) )
                callback(false);
            }
            navigator.geolocation.getCurrentPosition(success, error);
        }        
    },
    
    getDeviceInformation:function(callback) {     
        var that = this; 
        const IMEI_INDEX = 5;
        const DEVICE_INFO_INDEX = 6;
        const ICCID_INDEX = 7;
        const ADID_INDEX = 8;
        const IMSI_INDEX = 9;
        const MSISDN_INDEX = 10;
      
        // debugger;
        if(localStorage.getItem('adid') && !window.onSimChanged){
            // console.log("[JIO ANALYTICS] Loading device info from LOCAL storage");                            
            that.adid = localStorage.getItem('adid');
            that.imsi = localStorage.getItem('imsi');
            that.msisdn = localStorage.getItem('msisdn');
            that.imei = localStorage.getItem('imei');
            that.iccid = localStorage.getItem('iccid');

            that.hardware_info = localStorage.getItem('hardware_info');
            that.os_name =  localStorage.getItem('os_name');
            that.platform_build_id = localStorage.getItem('platform_build_id');
            that.platform_version = localStorage.getItem('platform_version');
            that.software = localStorage.getItem('software');

            callback(true);
        }else {
            // console.log("[JIO ANALYTICS] Loading device info from DATA store");                
            var store_name = navigator.getDataStores('jio_service_store');
            store_name.then(function(stores) {
                stores[0].get(ADID_INDEX).then(function(tempAdid) {
                    that.adid = tempAdid;       /* device id */
                    localStorage.setItem('adid',tempAdid);
                });
                stores[0].get(IMSI_INDEX).then(function(tempImsi) {
                    that.imsi = tempImsi;
                    localStorage.setItem('imsi',tempImsi);
                });
                stores[0].get(MSISDN_INDEX).then(function(tempMsisdn) {
                    that.msisdn = tempMsisdn;
                    localStorage.setItem('msisdn',tempMsisdn);
                });
                stores[0].get(IMEI_INDEX).then(function(tempImei) {
                    that.imei = tempImei;
                    localStorage.setItem('imei',tempImei);
                });
                stores[0].get(ICCID_INDEX).then(function(tempIccid) {
                    that.iccid = tempIccid;
                    localStorage.setItem('iccid',tempIccid);
                });
            
                stores[0].get(DEVICE_INFO_INDEX).then(function(deviceinfo_temp) {
    
                    that.hardware_info = deviceinfo_temp.hardware_info;
                    localStorage.setItem('hardware_info',deviceinfo_temp.hardware_info);
                    that.os_name =  deviceinfo_temp.os_name;
                    localStorage.setItem('os_name',deviceinfo_temp.os_name);
                    that.platform_build_id = deviceinfo_temp.platform_build_id;
                    localStorage.setItem('platform_build_id',deviceinfo_temp.platform_build_id);
                    that.platform_version = deviceinfo_temp.platform_version;
                    localStorage.setItem('platform_version',deviceinfo_temp.platform_version);
                    that.software = deviceinfo_temp.software;
                    localStorage.setItem('software',deviceinfo_temp.software);
    
                });
                callback(true);
            });
        }
        
    },

    callJioAnalyticHttp:function(data){
        if(!window.isReleaseBuild){
            return;
        }
        var that = this;
        if(!window.deviceInfoLoaded){
            that.analyticDataArray.push(data);
            return;
        } else {
            that.analyticDataArray.push(data);
            // debugger;
            that.analyticDataArray.forEach(function(item){ 
                that.createAnalyticJSON(item);
            });
            that.analyticDataArray = [];
        }         
    },

    processQueue: function(){
        if(!this.analyticDataArray) return;
        if(!this.analyticDataArray.length <= 0) return;
        // debugger;
        this.analyticDataArray.forEach(function(item){ 
            that.createAnalyticJSON(item);
        }, this);
        this.analyticDataArray = [];
    },

    createAnalyticJSON:function(data){
        // debugger;
        var eventType=sessionId=userId=timeStamp=exceptionType=exceptionMsg=errorMsg=rtc = '';
        var latitude=longitude = 'NA';
        var that = this;
        var jioAnalyticsURL;
        that.logNo = that.logNo+1;
        if(localStorage.getItem('userId')){
            userId = localStorage.getItem('userId');
        }
        
        var isProd = true;

        // debugger;
        if(isProd == true){
            jioAnalyticsURL = "http://collect.media.jio.com/postdata/";
        } else {
            jioAnalyticsURL = "http://collectpreprod.media.jio.com/postdata/"
        }

        if(data.eventType == "begin") {
            eventType = 'B';
            jioAnalyticsURL += "B";
        } else if(data.eventType == "end") {
            eventType = 'E';
            jioAnalyticsURL += 'E';
        } else if(data.eventType == "events") {
            eventType = '';
            jioAnalyticsURL += 'event';
        }

        // console.log('Analytics URL: ' + jioAnalyticsURL);
        // console.log('[JIO ANALYTICS] payload: ' + JSON.stringify(data));
        
        if(data.timeStamp){
            timeStamp = data.timeStamp;
        }
        if(data.exceptionType){
            exceptionType = data.exceptionType;
        }
        if(data.exceptionMsg){
            exceptionMsg = data.exceptionMsg;
        }
        if(data.errorMsg){
            errorMsg = data.errorMsg;
        }
        if(data.dateTime){
            sessionId = that.adid+data.dateTime.getTime();
            rtc = data.dateTime.getTime();
        }else {
            var curDate = new Date();
            sessionId = that.adid+curDate.getTime();
            rtc = curDate.getTime();
        }
        if(that.latitude){
            latitude = that.latitude;
        }
        if(that.longitude){
            longitude = that.longitude;
        }        
       
        var payloadData = {
            "key" : data.eventName,
            "logno" : that.logNo,
            "rtc" : rtc,
            "did" : that.adid,
            "pf" : "K",
            "dtpe" : "F",
            "sid" : sessionId,
            "imei" : that.imei,
            "msisdn" : that.msisdn,
            "osv" : that.os_name,
            "nwk" : "4G",
            "mnu" : "LYF",
            "sty" : eventType,
            "sdv" : "1.0.0",
            "c" : "Jio",
            "mod" : that.hardware_info,
            "res" : "240X320",
            "ori" : "Portrait",
            "lat" : latitude,
            "lng" : longitude,
            "JioChatUID": userId,
            "stkm" : exceptionType,
            "stkt" : exceptionMsg,
            "stkc" : errorMsg,
            "tsd" : timeStamp

        };

        if(AppMode.TYPE == AppMode.APP_TYPE_JVC){
            payloadData.akey = '109159001';
            payloadData.avn = AppMode.APP_VERSION_JVC;
        } else if(AppMode.TYPE == AppMode.APP_TYPE_JCL){
            payloadData.akey = '109157001';
            payloadData.avn = AppMode.APP_VERSION_JCL;
        } else if(AppMode.TYPE == AppMode.APP_TYPE_JMS){
            debugger;
            payloadData.akey = '109154004';
            payloadData.avn = AppMode.APP_VERSION_JMS;
        }  else {
            // Don't call API for other app types.
            return;
        }

        if(payloadData.JioChatUID){
            payloadData.JioChatUID = payloadData.JioChatUID.replace(/[,]/g,"_");
        }
        if(payloadData.sty == ''){
            delete payloadData.sty;
        }
        if(payloadData.mod == ''){
            delete payloadData.mod;
        }
        if(payloadData.osv == ''){
            delete payloadData.osv;
        }
        if(payloadData.stkm == ''){
            delete payloadData.stkm;
        }
        if(payloadData.stkt == ''){
            delete payloadData.stkt;
        }
        if(payloadData.stkc == ''){
            delete payloadData.stkc;
        }
        if(payloadData.tsd == ''){
            delete payloadData.tsd;
        }                        
        that.callXhttpAPI(payloadData, jioAnalyticsURL);
    },
    callXhttpAPI:function(payloadData, jioAnalyticsURL){
        var that = this;
        console.log("[JIO ANALYTICS] Jio analytics data",JSON.stringify(payloadData));
        var xhttp = new XMLHttpRequest({ mozSystem: true });        
        xhttp.open("POST", jioAnalyticsURL, true);        
        xhttp.setRequestHeader("Content-type", "application/json");        
        xhttp.send(JSON.stringify(payloadData));     
        xhttp.onreadystatechange = function() {        
            if (xhttp.readyState == 4) {        
                // if (xhttp.status == 200) {
                //     console.log(xhttp.responseText);
                //     console.log("[JIO ANALYTICS] Jio analytics Success",payloadData.key);
                // } else {
                //     console.log(xhttp.status);
                // }
            }
        };
    },

    getLaunchTime: function(capturedTime){
        var calculatedTime;  
        calculatedTime = new Date().getTime() - capturedTime.getTime();
        // console.log('Calculated Time: ' + calculatedTime);
        calculatedTime = Math.abs(calculatedTime/1000);
        // console.log('Absolute Calculated Time: ' + calculatedTime);
        return calculatedTime;
    }
              
};


JioAnalytics.getInstance = function(){
    if(!JioAnalytics.instance){
        JioAnalytics.instance = new JioAnalytics();
    }
    return JioAnalytics.instance;
};
