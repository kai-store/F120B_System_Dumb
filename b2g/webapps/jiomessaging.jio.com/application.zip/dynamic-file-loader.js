window.isFromPush = false;
window.isAppWindowOpen = false;
openWindow = null;

function checkOpeningFromPushNotification() {
    console.log('[LoadAllFiles] checkOpeningFromPushNotification called.');            
    if(!navigator.mozSetMessageHandler){
        return;
    }

    var that = this;
    navigator.mozSetMessageHandler('serviceworker-notification', function(data) {
        if (data) {         
            console.log('[LoadAllFiles]Push notification Payload ' + JSON.stringify(data));            
            that.pushData = data.msg;
            
            if (that.pushData) {
                that.pushData = JSON.parse(that.pushData);

                var pushObj = {};
                if (that.pushData.Category == 'CATEGORY_CALL') {
                    window.isAppWindowOpen = true;
                    pushObj = {
                        push_category: that.pushData.Category,
                        push_message: that.pushData
                    };
                } else {
                    pushObj = {
                        push_category: that.pushData.Category,
                        push_message: that.pushData
                    };
                }

                localStorage.setItem('PUSH_DATA', JSON.stringify(pushObj));
            }
        }
    });
}

function loadFilesInHead(filename){
    var headId = document.getElementsByTagName("head")[0];
    var newScript = document.createElement('script');
    newScript.type = 'text/javascript';
    newScript.src = filename;
    
    headId.appendChild(newScript)
}

function loadFilesInBody(src, script, callback){
    script = document.createElement('script');
    script.onerror = function() { 
        // handling error when loading script
        console.log('[LoadAllFiles]Error in file load.. ' + src);            
    }
    script.onload = function(){
        console.log('[LoadAllFiles]Success file loaded.. ' + src);            
        callback();
    }
    script.src = src;
    document.getElementsByTagName('body')[0].appendChild(script);
}

function loadAllFiles() {
    setTimeout(function() {
        console.log('[LoadAllFiles] isAppWindowOpen ' + window.isAppWindowOpen);            
        if (!window.isAppWindowOpen) {
            loadFilesInHead('push-model.js');
            loadFilesInHead('jio-analytics.js');    

            loadFilesInHead('src/utils/sso_min_2.1.js');
            // loadFilesInHead('src/utils/VA/recordWorker.js');
            loadFilesInHead('src/utils/DetectRTC.js');

            loadFilesInHead('src/database/dao/messages-dao.js');
            // loadFilesInHead('src/database/dao/channels-list-dao.js');
            // loadFilesInHead('src/database/dao/channels-focus-list-dao.js');

            var scripts = [];
            var _scripts = ['dist/support.js', 'dist/vendors.js', 'dist/bundle.js'];
            loadScriptsSync(_scripts,scripts);

            setTimeout(function(){
                unRegisterKeyDown();
            }, 1000);

        } else {
            openWindow = window.open('index.html', '_blank', 'attention');

            setTimeout(function(){
                unRegisterKeyDown();
            }, 1000);
        }
    }, 1000);
}

function loadScriptsSync(_scripts, scripts) {
    var x = 0;
    var loopArray = function(_scripts, scripts) {
        // call itself
        loadFilesInBody(_scripts[x], scripts[x], function(){
            // set x to next item
            x++;
            // any more items in array?
            if(x < _scripts.length) {
                loopArray(_scripts, scripts);   
            }
        }); 
    }
    loopArray(_scripts, scripts);      
}

function registerKeyDown(){
    // debugger;
    document.addEventListener('keydown', handleKeyDown)
}

function unRegisterKeyDown(){
    // debugger;
    document.removeEventListener('keydown', handleKeyDown);
}

function handleKeyDown(evt){
    // debugger;
    if(evt.key == 'Backspace'){
        window.close();
    }
}

window.addEventListener('load', function() {
    checkOpeningFromPushNotification();
    loadAllFiles();
    registerKeyDown();
}, false);

