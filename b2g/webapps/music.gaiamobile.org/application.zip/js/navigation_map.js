'use strict';

(function (exports) {
  //view and container map
  const VIEW_MAP = {
    1: 'views-tiles',
    2: 'views-list',
    3: 'views-sublist',
    4: 'views-player',
    6: 'search',
    7: 'rating-view'
  };

  //option menu is not a panel, but still keep it's elements
  const OPTION_MENU = 'option-menu';

  const CHANGE_MODE = {
    none: 'none',
    added: 'added',
    removed: 'removed'
  };

  var controls = {};
  var curPanel = null;

  var songchecked = false;

  var nav_id = 0;

  /*store the focused element when option menu is opened,
    and restore it after option menu is closed,
    it should be set null if a new navigable list is created
    in one item of option menu to prevent restore*/
  var _storeFocused = null;
  var intervalId = null;

  /*to fix bug 522:
    as list and selection views share the same control,
    use _storeIndex to store the index of list view when enter selection view,
    and restore when back to list view
  */
  var _storeIndex = -1;

  function navUpdate(elements) {
    var i = 0;
    var id = nav_id;  /*to avoid 'data-nav-id' reproduced with grid*/

    for (i = 0; i < elements.length; i++) {
      elements[i].setAttribute('data-nav-id', id);
      if (ModeManager.currentMode != MODE_TILES || curPanel === 6) {
        elements[i].style.setProperty('--nav-left', -1); //-1: invalid ID
        elements[i].style.setProperty('--nav-right', -1);
        elements[i].style.setProperty('--nav-down', id + 1);
        elements[i].style.setProperty('--nav-up', id - 1);
      } else {
        elements[i].style.setProperty('--nav-left', id - 1);
        elements[i].style.setProperty('--nav-right', id + 1);

        if (i === elements.length - 1 || i === elements.length - 2) {
          elements[i].style.setProperty('--nav-down', nav_id);
        } else {
          elements[i].style.setProperty('--nav-down', id + 2);
        }
        if (i === elements.length - 1)
        {
          elements[i].style.setProperty('--nav-right', nav_id);
        }

        if (i === 0) {
          elements[i].style.setProperty('--nav-down', id + 1);
        }
        if (i === 1)
        {
          elements[i].style.setProperty('--nav-up', id - 1);
          elements[i].style.setProperty('--nav-left', nav_id);
        } else {
          elements[i].style.setProperty('--nav-up', id - 2);
        }
      }
      elements[i].setAttribute('tabindex', 0);
      id++;
    }

    //top element
    elements[0].style.setProperty('--nav-up', id - 1);
    //bottom element
    elements[elements.length - 1].style.setProperty('--nav-down', nav_id);
    nav_id = id;
  };

  function getCurContainerId() {
    var id = null;
    id = VIEW_MAP[curPanel];
    return id;
  };

  function getCurControl() {
    var control = null;
    var containerId = getCurContainerId();

    if (containerId) {
      control = controls[containerId];
    }
    return control;
  };

  function getCurItem() {
    var item = null;
    var curControl = getCurControl();

    if (curControl) {
      if (curControl.index >= 0 &&
          curControl.index < curControl.elements.length) {
        item = curControl.elements[curControl.index];
      }
    }
    return item;
  };

  function sendIndexEvent(panel, index, item) {
    var evt = new CustomEvent('index-changed', {
      detail: {
        panel: panel,
        index: index,
        focusedItem: item
      },
      bubbles: true,
      cancelable: false
    });

    window.dispatchEvent(evt);
  };

  function setCurIndex(index) {
    var curControl = getCurControl();

    if (curControl) {
      if (index >= -1 && index < curControl.elements.length) {
        curControl.index = index;

        /*broadcoast change event*/
        sendIndexEvent(curPanel, index,
            (index == -1) ? null : curControl.elements[index]);
      }
    }
  };

  function observeChange(id) {
    var config = {
      childList: true,
      subtree: true,
      attributes: true
    };

    var observer = new MutationObserver(function(mutations) {
      var changed = CHANGE_MODE.none;
      var nodes = [];

      mutations.forEach(function(mutation) {
        if (changed == true) {
          return;
        }
      });
    });

    //observer.observe(document.getElementById(id), config);
  };

  var NavigationMap = {
    datadone: 0,
    multiSelectFlag: false,
    currentActivatedLength: 0,
    searchfileNames: [],
    fileNames: [],
    songDatas: [],
    savetitle: null,
    option: null,
    isfromsublist: 0,
    isopenpicker: false,
    _settingdata: null,
    _indexOfFinalSong: 0,
    isdeleteflag: false,
    hasFocusin: false,
    _endbacksong: null,
    _endbackposition: null,
    deleteflag: false,
    isprocessevent: false,

    init: function () {
      console.log('NavigationMap init');
      this.listinput = document.getElementById('search-listview');
      this.sublistinput = document.getElementById('views-sublist-search');
      //TODO: debug
      window.addEventListener('moz-app-loaded', function (e) {
        console.log('sk add ModeManager.currentMode:', ModeManager.currentMode);
        NavigationMap.navSetup(NavigationManager.VIEW_MAP[ModeManager.currentMode], '.focusable');
        NavigationManager.curPanel = MODE_LIST;
        NavigationMap.setFocus('first');
        //NavigationMap.onPanelChanged(null, LAYOUT_MODE.list);
        NavigationMap.onPanelChanged(null, MODE_LIST);

        NavigationManager.observeChange(NavigationManager.VIEW_MAP[ModeManager.currentMode]);
      });

      document.addEventListener('focusChanged', function (e) {
        var focusedItem = e.detail.focusedElement;
        console.log('Received event focusChanged: id=' +
          (focusedItem ? focusedItem.id : null));

        var curControl = NavigationManager.getCurControl();
        if (curControl && curControl.elements) {
          /*convert to an array*/
          var elements = Array.prototype.slice.call(curControl.elements);
          /*find the index of focused item in current control*/
          var index = elements.indexOf(focusedItem);
          if (index >= 0) {
            /*update index*/
            NavigationManager.setCurIndex(index);
            console.log('current index updated: ' + index);
          }
        }
      });

      window.addEventListener('keydown', function (event) {
        switch (event.key) {
          case 'BrowserBack':
          case 'Backspace':
          case 'KanjiMode':
            var handled = NavigationMap.navViewBack(event);
            if (handled) {
              // If handled
              event.preventDefault();
            }
            break;
          case 'EndCall':
            NavigationMap.onEndkeyHandled(event);
            break;
        }
      });



      window.addEventListener('menuEvent', function (e) {
        console.log('menuEvent received: menuVisible = ' +
          e.detail.menuVisible);
        if (e.detail.menuVisible) {
          e.detail.softkeyPanel.menu.form.id = NavigationManager.OPTION_MENU;
          //assign id to option menu for navSetup
          NavigationManager._storeFocused = document.querySelector('.focus');
          if (NavigationManager._storeFocused) {
            NavigationManager._storeFocused.classList.add('hasfocused');
          }
          NavigationMap.optionReset();
        }
        else {
          if (NavigationManager._storeFocused) {
            NavigationManager._storeFocused.classList.remove('hasfocused');
            NavigationManager._storeFocused.classList.add('focus');
            NavigationManager._storeFocused.focus();
            NavigationManager._storeFocused = null;
            window.focus();
          }
        }
      });
    },


    onEndkeyHandled: function (event) {
      if (event.key === 'EndCall') {
        if ((typeof PlayerView !== 'undefined' &&
          (PlayerView.playStatus === PLAYSTATUS_PAUSED ||
            PlayerView.playStatus === PLAYSTATUS_STOPPED)) ||
          (typeof PlayerView === 'undefined')) {
          if (typeof PlayerView !== 'undefined') {
            PlayerView.setlastdatapausedtime();
          }
        } else {
          // System will keep audio-channel-content app alive
          // We don't need to do extra work.
        }
      }
    },
    /*set focus for current panel*/
    setFocus: function _setFocus(id) {
      console.log('setFocus: NavigationManager.curPanel=' + NavigationManager.curPanel + ', id=' + id);

      var curControl = NavigationManager.getCurControl();
      if (!curControl) {
        console.log('setFocus failed!');
        return;
      }

      console.log('curIndex=' + curControl.index +
        ', length=' + curControl.elements.length);

      id = id || 0;
      id = (id == 'first') ? 0 :
        ((id > curControl.elements.length - 1) ? curControl.elements.length - 1 : id);

      if (id >= 0 && id < curControl.elements.length) {
        /*remove current focus, only one element has focus */
        var focused = document.querySelectorAll('.focus');
        for (var i = 0; i < focused.length; i++) {
          focused[i].classList.remove('focus');
        }

        var toFocused = curControl.elements[id];
        toFocused.setAttribute('tabindex', 1);
        toFocused.classList.add('focus');
        setTimeout(function () {
          toFocused.focus();
          window.focus();
        }, 150);
      }

      //id may be -1
      NavigationManager.setCurIndex(id);
    },

    /*setup navigation for the items that query from a container.
    @paramters:
        containerId: the id of the container element,
        undefined: coantainer = body
        query: the condition to query the items
    */
    navSetup: function _setup(containerId, query) {
      var elements = null;
      if (containerId === 'views-list') {
        ViewUtils.updateListElement();
      }
      var container = (containerId == undefined) ? document.body :
        document.getElementById(containerId);

      if (container) {
        elements = container.querySelectorAll(query);
        if (containerId === 'search') {
          var inputelements = null;
          if (ModeManager.currentMode === MODE_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST  || ModeManager.currentMode === MODE_SELECTOR_FROM_LIST) {
            inputelements = Array.prototype.slice.call(
              document.querySelectorAll('#search-listview-input'));
          } else if (ModeManager.currentMode === MODE_SUBLIST || ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST || ModeManager.currentMode === MODE_SELECTOR_FROM_SUBLIST) {
            inputelements = Array.prototype.slice.call(
              document.querySelectorAll('#views-sublist-search-input'));
          } else if (ModeManager.currentMode === MODE_TILES) {
            inputelements = Array.prototype.slice.call(
              document.querySelectorAll('#views-tiles-search-input'));
          }
          if (inputelements)
            inputelements = inputelements.concat(
              Array.prototype.slice.call(elements));
          elements = inputelements;
          NavigationManager.curPanel = 6;
        }

        if (elements && elements.length > 0) {
          NavigationManager.navUpdate(elements);
        }
      }

      if (containerId && elements) {
        if (!NavigationManager.controls[containerId]) {
          NavigationManager.controls[containerId] = {};
          NavigationManager.controls[containerId].index = (elements.length > 0) ? 0 : -1;
        }
        NavigationManager.controls[containerId].elements = elements;
        NavigationManager.controls[containerId].query = query;
        //store it for update when list changed
      }
    },

    /*option menu*/
    optionReset: function _reset() {
      console.log('optionReset');

      this.navSetup(NavigationManager.OPTION_MENU, '.menu-button');

      /*remove current focus, only one element has focus */
      var focused = document.querySelectorAll('.focus');
      for (var i = 0; i < focused.length; i++) {
        focused[i].classList.remove('focus');
      }

      var toFocused = NavigationManager.controls[NavigationManager.OPTION_MENU].elements[0];
      if (toFocused) {
        toFocused.setAttribute('tabindex', 1);
        toFocused.classList.add('focus');

        toFocused.focus();
        window.focus();
      }
    },

    /*get the focused item (element)*/
    getCurrentItem: function _currentItem() {
      return NavigationManager.getCurItem();
    },

    /*return current control(the focusable elements of current shown panel)*/
    getCurrentControl: function _currentControl() {
      return NavigationManager.getCurControl();
    },

    updateSoftKey: function _updateKey(paused) {
      var params = {
        header: { l10nId: 'options' },
        items: []
      };
      NavigationManager.optPause.icon = paused ? 'play' : 'pause';
      NavigationManager.optPause.name = paused ? 'Play' : 'Pause';
      NavigationManager.optPause.l10nId = paused ? 'opt-play' : 'opt-pause';
      if (!NavigationMap.isopenpick) {
        asyncStorage.getItem(SETTINGS_OPTION_KEY, function (settings) {
          if (settings) {
            NavigationManager.optShuffle.name = settings && settings.shuffle ?
              NavigationManager.SHUFFLE_ICON.shuffleOff : NavigationManager.SHUFFLE_ICON.shuffleOn;
            NavigationManager.optShuffle.l10nId = settings && settings.shuffle ?
              'opt-shuffleoff' : 'opt-shuffleon';

            switch (settings && settings.repeat) {
              case 0:
                NavigationManager.optRepeat.name = NavigationManager.REPEAT_ICON.repeatAll;
                NavigationManager.optRepeat.l10nId = 'opt-repeatall';
                break;
              case 1:
                NavigationManager.optRepeat.name = NavigationManager.REPEAT_ICON.repeatOne;
                NavigationManager.optRepeat.l10nId = 'opt-repeatone';
                break;
              case 2:
                NavigationManager.optRepeat.name = NavigationManager.REPEAT_ICON.repeatOff;
                NavigationManager.optRepeat.l10nId = 'opt-repeatoff';
                break;
            }
          } else {
            NavigationManager.optShuffle.name = NavigationManager.SHUFFLE_ICON.shuffleOn;
            NavigationManager.optShuffle.l10nId = 'opt-shuffleon';
            NavigationManager.optRepeat.name = NavigationManager.REPEAT_ICON.repeatAll;
            NavigationManager.optRepeat.l10nId = 'opt-repeatall';
          }
        });
      }

      NavigationMap.hideOptionMenu();
      if (NavigationMap.isopenpick) {
        if (!isshowinfo) {
          if (allowSave) {
            params.items = NavigationManager.actOpenWithSave;
          } else {
            params.items = NavigationManager.actOpenpick;
          }
        } else {
          params.items = NavigationManager.actOpenPickCancel;
        }
      } else {
        if (App.pendingPick) {
          params.items = NavigationManager.actPick;
        }
        else {
          if (typeof PlayerView !== 'undefined' && PlayerView.dataSource.length < 2) {
            params.items = NavigationManager.actPlayerNoShuffle;
          } else {
            params.items = NavigationManager.actPlayer;
          }
        }
      }
      if (exports.option) {
        exports.option.initSoftKeyPanel(params);
      } else {
        exports.option = new SoftkeyPanel(params);
        exports.option.show();
      }
    },
    createPlayAction: function () {
      console.log('createPlayAction......');
      this.setSoftKeyBar(ModeManager.currentMode);
    },
    setSoftKeyBar: function _setSoftKeyBar(panel) {
      console.log('setSoftKeyBar: ' + panel);
      var control = null;
      var count = 0;
      var skbParams = {
        header: { l10nId: 'options' },
        items: []
      };
      NavigationMap.hideOptionMenu();
      if (!panel ||
        !document.querySelector('#overlay').classList.contains('hidden')) {
        skbParams.items = NavigationManager.actOk;
      } else {
        var currentNavigator = NavigationManager.getCurPanelManager();
        if (currentNavigator && currentNavigator.setSoftKeyBar) {
          currentNavigator.setSoftKeyBar(skbParams);
        }
      }
      if (skbParams.items.length > 0) {
        if (exports.option) {
          exports.option.initSoftKeyPanel(skbParams);
        }
        else {
          exports.option = new SoftkeyPanel(skbParams);
        }
        exports.option.show();
      } else {
        if (exports.option)
          exports.option.hide();
      }
      if (NavigationMap.searchViewIsActive() &&
        (NavigationMap.searchfileNames.length == 0) &&
        (NavigationMap.multiSelectFlag === true) &&
        (SearchView.totalFound === 0)) {
        if (exports.option)
          exports.option.hide();
      }
    },

    onPanelChanged: function _panelChanged(from, to, args) {
      console.log('onPanelChanged: ' + from + ' --> ' + to + ', args:' + args);

      //store previous panel, it may be needed
      var prevPanel = NavigationManager.curPanel;
      var prevcontrol = NavigationManager.getCurControl();
      NavigationManager.curPanel = to;
      var control = NavigationManager.getCurControl();

      if (from) {
        var prevNavigator = NavigationManager.getModeManager(from);
        if (prevNavigator && prevNavigator.leave) {
          prevNavigator.leave(to);
        }
      }
      this.setSoftKeyBar(to);

      var nextNavigator = NavigationManager.getModeManager(to);
      if (nextNavigator && nextNavigator.enter) {
        nextNavigator.enter(from, prevcontrol, control);
      }
    },

    navViewBack: function _navBack(event) {

      if (NavigationMap.optionsIsVisiable()) {
        return true;
      }
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.navViewBack) {
        return currentNavigator.navViewBack(event);
      }
      return false;
    },

    scrollToElement: function _scroll(bestElementToFocus, evt) {
      console.log('NavigationMap scrollToElement');
      bestElementToFocus.scrollIntoView(false);
    },

    updateFullScreenSet: function _updateSet() {
      setNavigationManager.controlsVisibility(true);
      exports.option.show();
      isFullScreen = false;
    },

    optionsIsVisiable: function () {
      if (exports.option && exports.option.menuVisible) {
        return exports.option.menuVisible;
      } else {
        return false;
      }
    },
    playerfunc: function () {
      if (ModeManager.currentMode === MODE_LIST ||
        ModeManager.currentMode === MODE_SUBLIST ||
        ModeManager.currentMode === MODE_TILES) {
        var mode = ModeManager.currentMode;
        if (typeof PlayerView !== 'undefined') {
          if (PlayerView.dataSource.length !== 0) {
            ModeManager.push(MODE_PLAYER, function () {
              if (PlayerView.playStatus === PLAYSTATUS_PAUSED) {
                PlayerView.pause();
                NavigationMap.updateSoftKey(true);
              } else {
                NavigationMap.updateSoftKey(false);
              }
              NavigationMap.toPlayerPanel(mode);
            });
          } else {
            if (NavigationMap._settingdata != null) {
              ModeManager.push(MODE_PLAYER, function () {
                PlayerView.playRecentSong();
                NavigationMap.toPlayerPanel(mode);
              });
            }
          }
        } else {
          ModeManager.push(MODE_PLAYER, function () {
            PlayerView.playRecentSong();
            NavigationMap.toPlayerPanel(mode);
          });
        }
        NavigationMap.isfromsublist = 0;
      }
    },

    toPlayerPanel: function (mode) {
      if (mode !== MODE_LIST && mode !== MODE_SUBLIST) {
        mode = MODE_TILES;
      }
      NavigationMap.onPanelChanged(mode, MODE_PLAYER);
    },

    deletefunc: function () {
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.deleteSongs) {
        currentNavigator.deleteSongs();
      }
    },

    multifunc: function () {
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.selectMulti) {
        NavigationMap.restoreCurpanel();
        currentNavigator.selectMulti();
      }
    },

    processcheck: function () {
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.processcheck) {
        currentNavigator.processcheck();
      }
      NavigationMap.createPlayAction();
    },

    processCheckedItem: function (index) {
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.processCheckedItem) {
        currentNavigator.processCheckedItem(index);
      }
    },

    onConfirm: function (checkclass) {
      var items;
      var index = 0;
      var deleteindex = 0;
      var deletefilename = [];
      var currentNavigator = NavigationManager.getCurPanelManager();

      if (currentNavigator && currentNavigator.onDeleteConfirmed) {
        currentNavigator.onDeleteConfirmed(checkclass);
        return;
      }
    },

    onCancel: function (checkclass) {
      var checkicons;
      exports.option.show();
      if (NavigationMap.multiSelectFlag === true) {
        checkicons = document.getElementsByClassName(checkclass);
        for (var i = 0; i < checkicons.length; i++) {
          checkicons[i].classList.remove('hidden');
        }
        if (ModeManager.currentMode === MODE_SUBLIST) {
          TitleBar.changeTitleText(navigator.mozL10n.get(
            'song-num-checked', { n: NavigationMap.fileNames.length }));
        } else {
          TitleBar.changeTitleText(navigator.mozL10n.get(
            'song-num-checked', { n: NavigationMap.fileNames.length }));
        }
      }
      else {
        NavigationMap.release();
      }
    },

    changehead: function () {
      TitleBar.changeTitleText(TitleBar.currentTitleString);
    },
    release: function () {
      NavigationMap.multiSelectFlag = false;
      NavigationManager.songchecked = false;
      NavigationMap.fileNames = [];
      NavigationMap.searchfileNames = [];
      NavigationMap.songDatas = [];
    },

    preStartActivity: function (type) {
      if (ModeManager.currentMode === MODE_LIST) {
        this.startActivity.call(ListView, type);
      } else if (ModeManager.currentMode === MODE_PLAYER) {
        PlayerView.startActivity(type);
      } else if (ModeManager.currentMode === MODE_SUBLIST) {
        this.startActivity.call(SubListView, type);
      } else if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST
              || ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
        this.startActivity.call(SearchView, type);
      }
    },

    startActivity: function (type) {
      if (NavigationMap.getCurrentControl().index > 0) {
        var songData = this
          .dataSource[NavigationMap.getCurrentControl().index - 1];
      }
      if (songData.metadata.locked) {
        return;
      }

      musicdb.getFile(songData.name, function (file) {
        AlbumArt.getCoverBlob(songData).then(function (pictureBlob) {
          var filename = songData.name,
            name = filename.substring(filename.lastIndexOf('/') + 1);

          var activityData = {
            type: 'audio/*',
            number: 1,
            blobs: [file],
            filenames: [name],
            filepaths: [filename],
            // We only pass some metadata attributes so we don't share personal
            // details like # of times played and ratings
            metadata: [{
              title: songData.metadata.title,
              artist: songData.metadata.artist,
              album: songData.metadata.album,
              picture: pictureBlob
            }]
          };

          if (typeof PlayerView === 'undefined' ||
            (typeof PlayerView !== 'undefined' &&
              PlayerView.playStatus !== PLAYSTATUS_PLAYING)) {
            var a = new MozActivity({
              name: type,
              data: activityData
            });

            a.onerror = function (e) {
              reinitFocus();
              console.warn('share activity error:', a.error.name);
            };
            a.onsuccess = function (e) {
              reinitFocus();
              console.warn('share activity error:', a.error.name);
            };
          }
          else {
            // HACK HACK HACK
            //
            // Bug 956811: If we are currently playing music and share the
            // music with an inline activity handler (like the set
            // ringtone app) that wants to play music itself, we have a
            // problem because we have two foreground apps playing music
            // and neither one takes priority over the other. This is an
            // underlying bug in the way that inline activities are
            // handled and in our "audio competing policy". See bug
            // 892371.
            //
            // To work around this problem, if the music app is currently
            // playing anything, then before we launch the activity we start
            // listening for changes on a property in the settings database.
            // If the setting changes, we pause our playback and don't resume
            // until the activity returns. Then we pass the name of this magic
            // setting as a secret undocumented property of the activity so that
            // the ringtones app can use it.
            //
            // This done as much as possible in a self-invoking function to make
            // it easier to remove the hack when we have a real bug fix.
            //
            // See also the corresponding code in apps/ringtones/js/share.js
            //
            // HACK HACK HACK
            (function () {
              // This are the magic names we'll use for this hack
              var hack_activity_property = '_hack_hack_shut_up';
              var hack_setting_property = 'music._hack.pause_please';

              // Listen for changes to the magic setting
              navigator.mozSettings
                .addObserver(hack_setting_property, observer);

              // Pass the magic setting name as part of the activity request
              activityData[hack_activity_property] = hack_setting_property;

              // Now initiate the activity. This code is the same as the
              // normal non-hack code in the if clause above.
              var a = new MozActivity({
                name: type,
                data: activityData
              });

              a.onerror = a.onsuccess = cleanup;

              // This is the function that pauses the music if the activity
              // handler sets the magic settings property.
              function observer(e) {
                // If the value of the setting has changed, then we pause the
                // music. Note that we don't care what the new value of the
                // setting is.  We only care whether it has changed.
                //The ringtones app will just toggle it back and forth
                //between true and false.
                PlayerView.pause();
              }

              // When the activity is done, we stop observing the setting.
              // And if we have been paused, then we resume playing.
              function cleanup() {
                navigator.mozSettings.removeObserver(hack_setting_property,
                  observer);
                if (PlayerView.playStatus === PLAYSTATUS_PAUSED) {
                  PlayerView.play();
                }
                reinitFocus();
              }
            } ());
          }

          function reinitFocus() {
            setTimeout(function () {
              window.focus();
            }, 500);
          }

        });
      });
    },
    searchViewIsActive: function () {
      if (!NavigationMap.isopenpick) {
        if (SearchView.view.classList.contains('search-from-sublist-mode') ||
          SearchView.view.classList.contains('search-from-list-mode') ||
          SearchView.view.classList.contains('search-from-tiles-mode') ||
          SearchView.view.classList.contains('hidden')) {
          return false;
        } else {
          return true;
        }
      }
    },
    searchInputIsFocus: function () {
      if (!NavigationMap.isopenpick) {
        if (this.listinput.classList.contains('focused') ||
          this.sublistinput.classList.contains('focused')) {
          return true;
        } else {
          return false;
        }
      }
    },
    restoreCurpanel: function () {
      if (ModeManager.currentMode == MODE_LIST) {
        NavigationManager.curPanel = MODE_LIST;
      } else if (ModeManager.currentMode == MODE_SUBLIST) {
        NavigationManager.curPanel = MODE_SUBLIST;
      } else if (ModeManager.currentMode == MODE_TILES) {
        NavigationManager.curPanel = MODE_TILES;
      }
    },
    clearAndHiddenSearch: function () {
      SearchNavigator.clearSearch(true);
    },
    okfunc: function () {
      window.close();
    },
    cacelfunc: function () {

      if (NavigationMap.isopenpick === true ||
        (App.pendingPick && ModeManager.currentMode != MODE_PLAYER)) {
        SecondScreen.clearMessages();
        window.close();
        return;
      }
      if (ModeManager.currentMode === MODE_PLAYER ||
        NavigationMap.isopenpick !== true) {
        ModeManager.pop();
        NavigationMap.createPlayAction(MODE_LIST);
      } else {
        window.close();
      }
    },
    backfunc: function () {
      SecondScreen.clearMessages();
      window.close();
    },
    pausefunc: function () {
      console.log('sk add dont something');
    },
    donepick: function () {
      var currentFileinfo = PlayerView.dataSource[
        PlayerView.currentIndex
      ];
      var playingBlob = PlayerView.playingBlob;
      AlbumArt.getCoverBlob(currentFileinfo).then(function (picture) {
        var currentMetadata = currentFileinfo.metadata;
        App.pendingPick.postResult({
          type: playingBlob.type,
          blob: playingBlob,
          name: currentMetadata.title || '',
          metadata: {
            title: currentMetadata.title,
            artist: currentMetadata.artist,
            album: currentMetadata.album,
            picture: picture
          }
        });
        PlayerView.stop();
      });
    },
    checksearchresult: function () {
      if (NavigationMap.multiSelectFlag === true) {
        var checkicons = document
          .getElementsByClassName('searchlist-check-icon');
        if (checkicons === null)
          return;
        for (var i = 0; i < NavigationMap.fileNames.length; i++) {
          checkicons[i].classList.add('searchlist-check-icon-on');
        }
      }
    },
    donefunc: function () {
      NavigationMap.donepick();
    },
    withoutItems: function () {
      var tempArray = [];
      LazyLoader.load('js/metadata/album_art.js', function () {
        musicdb.enumerate(
          'metadata.title', null, 'nextunique',
          function (data) {
            if (data !== null) {
              tempArray.push(data);
            }
            else {
              console.log('sk add show withoutItems:', App.currentOverlay);
              if (tempArray.length === 0) {
                App.toggleOverLayAndList(true);
                App.showOverlay('empty');
                NavigationMap.setSoftKeyBar();
              } else {
                App.toggleOverLayAndList(false);
                if (App.pendingPick) {
                  return;
                }
                if (App.softbarflag > 0) {
                  App.softbarflag = 0;
                }
              }
            }
          });
      });
    },
    saveSongHistory: function (index) {
      NavigationMap._indexOfFinalSong = index;
      NavigationMap._settingdata = PlayerView.dataSource[index];
      asyncStorage.setItem(SETTINGS_LASTSONG_KEY, {
        index: NavigationMap._indexOfFinalSong,
        data: NavigationMap._settingdata
      });
    },
    getTitle: function (current_option, option) {
      var obj = new Object();
      var naviTitle = '';
      var mainTitle = '';
      if (current_option === 'played-least') {
        option = 'played';
        naviTitle = navigator.mozL10n.get('playlists-least-played');
        mainTitle = navigator.mozL10n.get('playlists');
      } else if (current_option === 'played') {
        naviTitle = navigator.mozL10n.get('playlists-most-played');
        mainTitle = navigator.mozL10n.get('playlists');
      } else if (current_option === 'date') {
        naviTitle = navigator.mozL10n.get('playlists-recently-added');
        mainTitle = navigator.mozL10n.get('playlists');
      } else if (current_option === 'rated') {
        naviTitle = navigator.mozL10n.get('playlists-highest-rated');
        mainTitle = navigator.mozL10n.get('playlists');
      }
      if (option === 'album' || option === 'artist')
        NavigationMap.option = option;
      else
        NavigationMap.option = null;
      obj.naviTitle = naviTitle;
      obj.mainTitle = mainTitle;
      return obj;
    },

    isVisiableSoftKeyBar: function () {
      if (exports.option && exports.option.softKeyVisible === true) {
        return true;
      }
      return false;
    },
    setCurrentPanel: function (panel) {
      NavigationManager.curPanel = panel;
    },

    updateTitle: function () {
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.updateTitle) {
        currentNavigator.updateTitle();
      }
    },

    clearStatus: function () {
      if (NavigationMap.optionsIsVisiable()) {
        window.dispatchEvent(new CustomEvent('menuChangeEvent', {
          detail: {
            action: 'closeMenu'
          }
        }));
      }
      var currentNavigator = NavigationManager.getCurPanelManager();
      if (currentNavigator && currentNavigator.clearStatus) {
        currentNavigator.clearStatus();
      }
    },

    isexistcheckbox: function (classname) {
      var checkicons = document.getElementsByClassName(classname);
      if (!checkicons)
        return;
      if (checkicons[0].classList.contains('hidden'))
        return false;
      else
        return true;
    },
    isVisibleDialog: function () {
      var dialogscreen = document.querySelector('#dialog-screen');
      if (dialogscreen !== null) {
        return true;
      } else {
        return false;
      }
    },
    isSearchModeOfSublist: function () {
      var mode = document.querySelector('.search-from-sublist-mode');
      if (mode) {
        return true;
      } else {
        return false;
      }
    },
    isSearchModeOfSubSublist: function () {
      var submode = document.querySelector('.search-from-subsublist-mode');
      if (submode) {
        return true;
      } else {
        return false;
      }
    },

    hideOptionMenu: function () {
      if (NavigationMap.optionsIsVisiable()) {
        window.dispatchEvent(new CustomEvent('menuChangeEvent', {
          detail: {
            action: 'closeMenu'
          }
        }));
      }
    }
  };
  exports.NavigationMap = NavigationMap;

})(window);
