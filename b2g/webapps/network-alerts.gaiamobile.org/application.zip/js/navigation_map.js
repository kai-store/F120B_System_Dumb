/* global NavigationMap */
'use strict';

(function(exports) {
  var NavigationMap = {
    init: function() {
      window.addEventListener('panelready', this.panelReadyHandler.bind(this));
      window.addEventListener('navigation-map-reset', this.navigationMapReset.bind(this));
      this.selector = null;
      this.element = null;
    },

    registerPanelNavigation: function(navInfo) {
      var bootFocusElement = NavigationHelper.reset(
        navInfo.navigator,
        navInfo.controls,
        navInfo.defaultFocusIndex,
        navInfo.curViewId,
        navInfo.noSetfocus
      );
      return bootFocusElement;
    },

    focusChanged: function(element) {
      element.focus();
      element.scrollIntoView(false);
    },

    scrollToElement: function(element, event) {
      element.scrollIntoView(false);
    },

    panelReadyHandler: function(event) {
      var navInfo = event.detail;
      this.focusedElement = this.registerPanelNavigation(navInfo);
      if (this.focusedElement) {
        this.focusChanged(this.focusedElement);
      }
    },

    navigationMapReset: function(event) {
      this.element = event.detail.element;
      this.selector = event.detail.selector;
      var navInfo = this.getNavInfo();
      var event = new CustomEvent('panelready', {'detail': navInfo});
      window.dispatchEvent(event);
    },

    getNavInfo: function() {
      var navInfo = {};
      navInfo.navigator = this.navigator || VerticalNavigator;
      navInfo.controls = this.getControls.bind(this);
      navInfo.defaultFocusIndex = this.getDefaultFocusIndex();
      navInfo.curViewId = this.getCurViewId();
      navInfo.noSetfocus = this.menuVisible();

      return navInfo;
    },

    getControls: function() {
      var controls = null;
      if (this.element && this.selector) {
        controls = this.element.querySelectorAll(this.selector);
      }
      return controls;
    },

    getDefaultFocusIndex: function() {
      return 0;
    },

    getCurViewId: function() {
      var curViewId = null;
      if (this.element) {
        curViewId = this.element.id;
      }
      return curViewId;
    },

    menuVisible: function() {
      return this.softkey ? this.softkey.menuVisible : false;
    }

  };

  exports.NavigationMap = NavigationMap;
}(window));
